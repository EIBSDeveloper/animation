import 'package:eapl_student_app/bindings/general_binding.dart';
import 'package:eapl_student_app/features/authendication/screens/splash.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/theme/theme.dart';
import 'package:get_storage/get_storage.dart';

import 'common/widget/menu/bottom_menu/bottom_menu.dart';

final GlobalKey<NavigatorState> navState = GlobalKey<NavigatorState>();
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  runApp(const App());
}
class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) => GetMaterialApp(
      navigatorKey: navState,
      debugShowCheckedModeBanner: false,
      title: TTexts.appName,
      theme: KAppTheme.mobilelighttheme,
      initialBinding: GeneralBinding(),
      home: GetStorage().read(TTexts.userID) != null
          ? OurBottomNavigationBar()
          : const SplashPage(),
      builder: (context, child) {
        return MediaQuery(
          child: child!,
          data: MediaQuery.of(context)
              .copyWith(textScaler: const TextScaler.linear(1.0)),
        );
      },
    );
}
