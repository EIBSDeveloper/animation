/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

import 'dart:convert';

import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:http/http.dart' as http;

class THttpHelper {
  // Helper method to make a GET request
  static Future<Map<String, dynamic>> get(String endpoint) async {
    final response =
        await http.get(Uri.parse('${APIConstants.baseUrl}/$endpoint'));
    return _handleResponse(response);
  }

  // Helper method to make a POST request
  static Future<Map<String, dynamic>> post(
      String endpoint, dynamic data) async {
    final response = await http.post(
      Uri.parse('${APIConstants.baseUrl}/$endpoint'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );
    return _handleResponse(response);
  }

  // Helper method to make a PUT request
  static Future<Map<String, dynamic>> put(String endpoint, dynamic data) async {
    final response = await http.put(
      Uri.parse('${APIConstants.baseUrl}/$endpoint'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );
    return _handleResponse(response);
  }

  // Helper method to make a DELETE request
  static Future<Map<String, dynamic>> delete(String endpoint) async {
    final response =
        await http.delete(Uri.parse('${APIConstants.baseUrl}/$endpoint'));
    return _handleResponse(response);
  }

  // Handle the HTTP response
  static Map<String, dynamic> _handleResponse(http.Response response) {
    if (response.statusCode == 200 ||
        response.statusCode == 404 ||
        response.statusCode == 201 ||
        response.statusCode == 422 ||
        response.statusCode == 410) {
      return json.decode(response.body);
    } else
      throw Exception(
          'Failed to load data: ${response.statusCode} - ${json.decode(response.body)['message']}');
  }
}
