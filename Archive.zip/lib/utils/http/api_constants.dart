/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

/* -- LIST OF Constants used in APIs -- */

// Example
class APIConstants {
  static const String baseUrl = 'https://erp.elysium.academy/api';
  static const String loginEndPoint = 'student_login';
  static const String CourseListEndPoint = 'customer_course_list';
  static const String newCourseListEndPoint = 'new_course_list';
  static const String batchDetailsEndPoint = 'batch_details';
  static const String studentAttendanceEndPoint = 'attendance';
  static const String dailyStatusEndPoint = 'daily_status';
  static const String attendanceFeedbackEndPoint = 'attendance_feedback';
  static const String paymentHistoryEndPoint = 'payment_history';
  static const String courseMaterialsEndPoint = "course_material";
  static const String courseMaterialListEndPoint = "course_material_by_type_id";
  static const String addReferralEndPoint = "add_contact_details";
  static const String studentPointsEndPoint = "customer_points";
  static const String leaderBoardEndPoint = "leaderBoardList";
  static const String queryListEndPoint = "customer_issue_note_list";
  static const String queryAddEndPoint = "customer_issue_note_add";

  /// --- New Implementations
  static const String eventEndPoint = "event_list";
  static const String placementEndPoint = "placement_list";
  static const String appBarPointsEndPoint = "customer_score";
  static const String queryTicketClosingEndPoint = "ticket_closing";

  /// --- NEW Implementations 22th May
  static const String paymentListEndPoint = "payment_list";
  static const String paymentSaveEndPoint = "payment_save";
  static const String newCourseRegisterEndPoint = "add_course";
  static const String existingCourseEndPoint = "existing_course_list";

  ///----Exam
  static const String courseListEndPoint = "exam_course_list";
  static const String examListEndPoint = "exam_topic_list";
  static const String examGuidelinesEndPoint = "exam_guidelines";
  static const String examQuestionEndPoint = "exam_questions";
  static const String saveAnswerEndPoint = "save_answer";
  static const String examReportListEndPoint = "exam_complete_list";
  static const String examReportEndPoint = "exam_result";

  //newly implemented - 22/07/25
  static const String studentdailycheck = "student/daily-check";
  static const String referrel = "add_contacts";
  static const String exchange = "exchange_reward";

  //newly implemented - 14-08-2025
  static const String notifications = "student_notification_list";
  static const String notificationread = "student_clear_notification";
  static const String notificationreadall = "student_clear_all";

  static const String existCourseRegisterEndPoint = "add_course";

  //newly implemented - 18-08-2025
  static const String bookeventendpoint = "book_event";
  static const String otpcheckendpoint = "student_otp_check";

  //newly implemented - 19-8-2025
  static const String redeemaddendpoint = "student/redeem_add";
  static const String redeemlistendpoint = "student/redeem_list";

  //newly implemented - 23-08-25
  static const String courseratingendpoint = "course_rating";

  //newly implemented - 09/09/25
  static const String jobapplyendpoint = "apply_job";

  //newly implemented - 10/09/25
  static const String savejobendpoint = "save_job";
  static const String removejobendpoint = "remove_job";

  //newly implemented - 04/10/25
  static const String interestedcourseendpoint = "interest_course_list";
  static const String removecourseendpoint = "remove_course";
  static const String placementhistoryendpoint = "placement_history_list";
  static const String profileendpoint = "profile_change";
  static const String queryconversationendpoint = "issue_note_conversation";

  //newly implemented - 11/10/25
  static const String comboendpoint = "course_Payment_Combo";
  static const String feedbackalertendpoint = "feedback_alert";
  static const String markseenendpoint = "mark_seen";
  static const String closeendpoint = "customer_issue_closed";

  //newly implemented - 13/10/25
  static const String attendencechapterendpoint = "attendance_chapter";

  //newly implemented - 16/10/25
  static const String placementinterviewendpoint = "Placement_list_interview";
  static const String couponamountendpoint = "coupon_amount";

  //newly implemented - 29/10/25
  static const String placedstudentendpoint = "placement_list_student";
}
