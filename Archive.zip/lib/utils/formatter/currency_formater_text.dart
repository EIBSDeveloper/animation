/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/6/24, 12:59 PM
 */

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class IndianCurrencyText extends StatelessWidget {
  final String? currency_format;
  final String? sympol;
  final int number;
  final TextStyle? style;

  IndianCurrencyText(
      {super.key,
      this.currency_format = 'en_IN',
      required this.number,
      this.sympol = "₹",
      this.style});

  @override
  Widget build(BuildContext context) {
    final formattedNumber = NumberFormat.currency(
            locale: currency_format, symbol: sympol, decimalDigits: 0)
        .format(number);

    return Text(
      formattedNumber,
      textAlign: TextAlign.center,
      style: style /*??Theme.of(context).textTheme.labelLarge*/,
    );
  }
}
