/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class THelperFunctions {
  static bool isDarkMode(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark;
  }

  static Size screenSize() {
    return MediaQuery.of(Get.context!).size;
  }

  static double screenHeight() {
    return MediaQuery.of(Get.context!).size.height;
  }

  static double screenWidth() {
    return MediaQuery.of(Get.context!).size.width;
  }

  static bool islandscape() {
    return MediaQuery.of(Get.context!).orientation == Orientation.landscape;
  }
  static String formatCustomDate(String rawDate) {
    try {
      final date = DateTime.parse(rawDate);
      final dayMonth = DateFormat('dd-MMM').format(date); // 06-May
      final year = DateFormat('yyyy').format(date); // 2025
      return '$dayMonth\n-$year';
    } catch (e) {
      return rawDate; // fallback in case of error
    }
  }
}
