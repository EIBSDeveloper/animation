import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class NetworkManager extends GetxController {
  static NetworkManager get instance => Get.find();

  final Connectivity _connectivity = Connectivity();
  late StreamSubscription<ConnectivityResult> _connectivitySubscription;
  final Rx<ConnectivityResult> _connectionStatus = ConnectivityResult.none.obs;

  /// Initialize the network manager and set up a stream to continually check the connection status
  @override
  void onInit() async {
    super.onInit();
    _connectivitySubscription =
        _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
    final internet = await isConnected();
    if (internet) {
      Get.back();
    } else {
      if (Get.isDialogOpen != true) {
        Get.dialog(
          AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            title: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.wifi_off,
                  color: Colors.redAccent,
                  size: 50,
                ),
                SizedBox(height: 10),
                Text(
                  'No Internet Connection',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            content: const Text(
              'Please check your internet settings and try again.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black54,
              ),
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.redAccent,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                ),
                onPressed: () async {
                  final internet = await isConnected();
                  if (internet) {
                    Get.back();
                  } else {
                    TSnackbar.warningSnackbar(
                        title: 'No Internet Connection',
                        message:
                            'Still no internet connection. Please try again.');
                  }
                },
                child: const Text(
                  'Retry',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
          barrierDismissible: false,
        );
      } else {
        // Close the alert dialog automatically when internet connection is restored
        if (Get.isDialogOpen == true) {
          Get.back();
        }
      }
    }
  }

  /// Update the connection status based on changes in connectivity and show a relevant alert dialog for no internet connection
  Future<void> _updateConnectionStatus(ConnectivityResult result) async {
    _connectionStatus.value = result;

    if (_connectionStatus.value == ConnectivityResult.none) {
      // Show the alert dialog when there is no internet connection
      if (Get.isDialogOpen != true) {
        Get.dialog(
          AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            title: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.wifi_off,
                  color: Colors.redAccent,
                  size: 50,
                ),
                SizedBox(height: 10),
                Text(
                  'No Internet Connection',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            content: const Text(
              'Please check your internet settings and try again.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black54,
              ),
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.redAccent,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                ),
                onPressed: () async {
                  final internet = await isConnected();
                  if (internet) {
                    Get.back();
                  } else {
                    TSnackbar.warningSnackbar(
                        title: 'No Internet Connection',
                        message:
                            'Still no internet connection. Please try again.');
                  }
                },
                child: const Text(
                  'Retry',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
          barrierDismissible: false,
        );
      }
    } else {
      // Close the alert dialog automatically when internet connection is restored
      if (Get.isDialogOpen == true) {
        Get.back();
      }
    }
  }

  /// Check the internet connection status
  /// Returns 'true' if connected, otherwise 'false'
  Future<bool> isConnected() async {
    try {
      final result = await _connectivity.checkConnectivity();
      return result != ConnectivityResult.none;
    } on PlatformException catch (_) {
      return false;
    }
  }

  @override
  void onClose() {
    super.onClose();
    _connectivitySubscription.cancel();
  }
}
