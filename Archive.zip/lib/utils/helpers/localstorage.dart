import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:eapl_student_app/features/personalization/models/placement_model.dart';

class LocalStorage {
  static const String _savedJobsKey = 'saved_jobs';

  // Save a job to local storage
  static Future<void> saveJob(PlacementModel job) async {
    final prefs = await SharedPreferences.getInstance();
    final savedJobs = await getSavedJobs();
    // Avoid duplicates
    if (!savedJobs.any((j) => j.jobId == job.jobId)) {
      savedJobs.add(job);
      final jsonList = savedJobs.map((job) => jsonEncode(job.toJson())).toList();
      await prefs.setStringList(_savedJobsKey, jsonList);
    }
  }

  // Remove a job from local storage
  static Future<void> removeJob(String jobId) async {
    final prefs = await SharedPreferences.getInstance();
    final savedJobs = await getSavedJobs();
    savedJobs.removeWhere((job) => job.jobId == jobId);
    final jsonList = savedJobs.map((job) => jsonEncode(job.toJson())).toList();
    await prefs.setStringList(_savedJobsKey, jsonList);
  }

  // Get all saved jobs
  static Future<List<PlacementModel>> getSavedJobs() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = prefs.getStringList(_savedJobsKey) ?? [];
    return jsonList
        .map((json) => PlacementModel.fromJson(jsonDecode(json)))
        .toList();
  }

  // Check if a job is saved
  static Future<bool> isJobSaved(String jobId) async {
    final savedJobs = await getSavedJobs();
    return savedJobs.any((job) => job.jobId == jobId);
  }
}