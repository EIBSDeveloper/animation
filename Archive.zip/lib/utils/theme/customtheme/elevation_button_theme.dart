/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

import 'package:flutter/material.dart';

import '../../constants/colors.dart';

class KElevationButtonTheme {
  KElevationButtonTheme._();

  static final lightelevatedbuttontheme = ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
          elevation: 0,
          foregroundColor: Colors.white,
          backgroundColor: TColors.buttonPrimary,
          disabledBackgroundColor: TColors.buttonDisabled,
          disabledForegroundColor: TColors.buttonDisabled,
          side: BorderSide(
            color: Colors.transparent,
          ),
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 30),
          textStyle: TextStyle(
              fontSize: 18, color: TColors.white, fontWeight: FontWeight.w600),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
  static final tabletlightelevatedbuttontheme = ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
          elevation: 0,
          foregroundColor: Colors.white,
          backgroundColor: TColors.buttonPrimary,
          disabledBackgroundColor: TColors.buttonDisabled,
          disabledForegroundColor: TColors.buttonDisabled,
          side: BorderSide(color: TColors.buttonPrimary),
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 50),
          textStyle: TextStyle(
              fontSize: 22, color: TColors.white, fontWeight: FontWeight.w600),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))));

  static final darkelevatedbuttontheme = ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white,
          elevation: 0,
          backgroundColor: TColors.primary,
          disabledBackgroundColor: Colors.grey.shade300,
          disabledForegroundColor: Colors.grey.shade300,
          side: BorderSide(
            color: TColors.buttonPrimary,
          ),
          padding: EdgeInsets.symmetric(vertical: 18),
          textStyle: TextStyle(
            fontSize: 18,
            color: TColors.white,
            fontWeight: FontWeight.w600,
          ),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
}
