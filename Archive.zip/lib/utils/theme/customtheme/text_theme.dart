/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

import 'package:flutter/material.dart';

import '../../constants/colors.dart';

class KTextTheme {
  KTextTheme._();

  static TextTheme mobilelightTextTheme = TextTheme(
    // headline1: const TextStyle().copyWith(fontSize: 60.0,fontWeight: FontWeight.w400,color: TColors.black),
    headlineLarge: const TextStyle().copyWith(
        fontSize: 32.0, fontWeight: FontWeight.bold, color: TColors.black),
    headlineMedium: const TextStyle().copyWith(
        fontSize: 24.0, fontWeight: FontWeight.w600, color: TColors.black),
    headlineSmall: const TextStyle().copyWith(
        fontSize: 20.0, fontWeight: FontWeight.w600, color: TColors.black),

    titleLarge: const TextStyle().copyWith(
        fontSize: 18.0, fontWeight: FontWeight.bold, color: TColors.black),
    titleMedium: const TextStyle().copyWith(
        fontSize: 18.0, fontWeight: FontWeight.w500, color: TColors.black),
    titleSmall: const TextStyle().copyWith(
        fontSize: 17.0, fontWeight: FontWeight.w400, color: TColors.black),

    bodyLarge: const TextStyle().copyWith(
        fontSize: 16.0, fontWeight: FontWeight.w500, color: TColors.black),
    bodyMedium: const TextStyle().copyWith(
        fontSize: 16.0, fontWeight: FontWeight.normal, color: TColors.black),
    bodySmall: const TextStyle().copyWith(
        fontSize: 16.0,
        fontWeight: FontWeight.w500,
        color: TColors.black.withOpacity(0.5)),

    labelLarge: const TextStyle().copyWith(
        fontSize: 14.0, fontWeight: FontWeight.w400, color: TColors.black),
    labelMedium: const TextStyle().copyWith(
        fontSize: 14.0,
        fontWeight: FontWeight.normal,
        color: TColors.black.withOpacity(0.5)),
    labelSmall: const TextStyle().copyWith(
        fontSize: 12.0,
        fontWeight: FontWeight.normal,
        color: TColors.black.withOpacity(0.8)),
  );
  static TextTheme tabletlightTextTheme = TextTheme(
    headlineLarge: const TextStyle().copyWith(
      fontSize: 38.0,
      fontWeight: FontWeight.bold,
      color: TColors.black,
    ),
    headlineMedium: const TextStyle().copyWith(
        fontSize: 30.0, fontWeight: FontWeight.w600, color: TColors.black),
    headlineSmall: const TextStyle().copyWith(
        fontSize: 28.0, fontWeight: FontWeight.w600, color: TColors.black),
    titleLarge: const TextStyle().copyWith(
        fontSize: 26.0, fontWeight: FontWeight.bold, color: TColors.black),
    titleMedium: const TextStyle().copyWith(
        fontSize: 26.0, fontWeight: FontWeight.w500, color: TColors.black),
    titleSmall: const TextStyle().copyWith(
        fontSize: 26.0, fontWeight: FontWeight.w400, color: TColors.black),
    bodyLarge: const TextStyle().copyWith(
        fontSize: 22.0, fontWeight: FontWeight.w600, color: TColors.black),
    bodyMedium: const TextStyle().copyWith(
        fontSize: 22.0, fontWeight: FontWeight.normal, color: TColors.black),
    bodySmall: const TextStyle().copyWith(
        fontSize: 22.0,
        fontWeight: FontWeight.w500,
        color: TColors.black.withOpacity(0.5)),
    labelLarge: const TextStyle().copyWith(
        fontSize: 18.0, fontWeight: FontWeight.normal, color: TColors.black),
    labelMedium: const TextStyle().copyWith(
        fontSize: 18.0,
        fontWeight: FontWeight.normal,
        color: TColors.black.withOpacity(0.5)),
  );
  static TextTheme darkTextTheme = TextTheme(
    headlineLarge: const TextStyle().copyWith(
        fontSize: 32.0, fontWeight: FontWeight.bold, color: Colors.white),
    headlineMedium: const TextStyle().copyWith(
        fontSize: 24.0, fontWeight: FontWeight.w600, color: Colors.white),
    headlineSmall: const TextStyle().copyWith(
        fontSize: 24.0, fontWeight: FontWeight.w600, color: Colors.white),
    titleLarge: const TextStyle().copyWith(
        fontSize: 14.0, fontWeight: FontWeight.w600, color: Colors.white),
    titleMedium: const TextStyle().copyWith(
        fontSize: 14.0, fontWeight: FontWeight.w500, color: Colors.white),
    titleSmall: const TextStyle().copyWith(
        fontSize: 14.0, fontWeight: FontWeight.w400, color: Colors.white),
    bodyLarge: const TextStyle().copyWith(
        fontSize: 16.0, fontWeight: FontWeight.w500, color: Colors.white),
    bodyMedium: const TextStyle().copyWith(
        fontSize: 16.0, fontWeight: FontWeight.normal, color: Colors.white),
    bodySmall: const TextStyle().copyWith(
        fontSize: 16.0,
        fontWeight: FontWeight.w500,
        color: Colors.white.withOpacity(0.5)),
    labelLarge: const TextStyle().copyWith(
        fontSize: 14.0, fontWeight: FontWeight.normal, color: Colors.white),
    labelMedium: const TextStyle().copyWith(
        fontSize: 14.0,
        fontWeight: FontWeight.normal,
        color: Colors.white.withOpacity(0.5)),
  );
}
