/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

import 'package:flutter/material.dart';

import 'customtheme/Outlined_button_theme.dart';
import 'customtheme/appbar_theme.dart';
import 'customtheme/bottom_sheet_theme.dart';
import 'customtheme/check_box_theme.dart';
import 'customtheme/chip_theme.dart';
import 'customtheme/elevation_button_theme.dart';
import 'customtheme/text_field_theme.dart';
import 'customtheme/text_theme.dart';

class KAppTheme {
  KAppTheme._();

  //
  static ThemeData mobilelighttheme = ThemeData(
    useMaterial3: true,
    fontFamily: 'Poppins',
    brightness: Brightness.light,
    primaryColor: Colors.blue,
    textTheme: KTextTheme.mobilelightTextTheme,
    scaffoldBackgroundColor: Colors.white,
    chipTheme: KChipTheme.LightChipTheme,
    appBarTheme: KAppBarTheme.lightAppBarTheme,
    checkboxTheme: KCheckboxTheme.lightCheckboxTheme,
    outlinedButtonTheme: KoutlinedButtonTheme.lightOutlinedButtonTheme,
    elevatedButtonTheme: KElevationButtonTheme.lightelevatedbuttontheme,
    inputDecorationTheme: KTextFieldTheme.lightInputDecorationTheme,
    bottomSheetTheme: KBottomSheetTheme.lightbottomsheettheme,
  );
  static ThemeData tabletlighttheme = ThemeData(
    useMaterial3: true,
    fontFamily: 'Poppins',
    // fontFamily: 'Kanit',
    // fontFamily: 'Raleway',
    brightness: Brightness.light,
    primaryColor: Colors.blue,
    textTheme: KTextTheme.tabletlightTextTheme,
    scaffoldBackgroundColor: Colors.white,
    chipTheme: KChipTheme.LightChipTheme,
    appBarTheme: KAppBarTheme.lightAppBarTheme,
    checkboxTheme: KCheckboxTheme.lightCheckboxTheme,
    outlinedButtonTheme: KoutlinedButtonTheme.lightOutlinedButtonTheme,
    elevatedButtonTheme: KElevationButtonTheme.tabletlightelevatedbuttontheme,
    inputDecorationTheme: KTextFieldTheme.lightInputDecorationTheme,
    bottomSheetTheme: KBottomSheetTheme.lightbottomsheettheme,
  );

  static ThemeData darktheme = ThemeData(
    useMaterial3: true,
    // fontFamily: 'Raleway',
    fontFamily: 'Poppins',
    brightness: Brightness.dark,
    primaryColor: Colors.blue,
    textTheme: KTextTheme.darkTextTheme,
    scaffoldBackgroundColor: Colors.black,
    chipTheme: KChipTheme.darkChipTheme,
    appBarTheme: KAppBarTheme.darkAppBarTheme,
    checkboxTheme: KCheckboxTheme.darkCheckboxTheme,
    outlinedButtonTheme: KoutlinedButtonTheme.darkoutlinedButtonTheme,
    elevatedButtonTheme: KElevationButtonTheme.darkelevatedbuttontheme,
    inputDecorationTheme: KTextFieldTheme.darkInputDecorationTheme,
    bottomSheetTheme: KBottomSheetTheme.darkbottomsheettheme,
  );
}
