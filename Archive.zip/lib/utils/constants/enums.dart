/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

/* --
      LIST OF Enums
      They cannot be created inside a class.
-- */

/// Switch of Custom Brand-Text-Size Widget
enum QuestionType { text, radio, checkbox }

enum QuestionStatus { notViewed, viewed, attempt, notAttempt }
