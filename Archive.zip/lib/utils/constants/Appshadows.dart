import 'package:flutter/material.dart';

class AppShadows {
  static const List<BoxShadow> cardShadow = [
    BoxShadow(
      color: Color.fromRGBO(60, 64, 67, 0.3),
      blurRadius: 2,
      spreadRadius: 0,
      offset: Offset(0, 1),
    ),
    BoxShadow(
      color: Color.fromRGBO(60, 64, 67, 0.15),
      blurRadius: 6,
      spreadRadius: 2,
      offset: Offset(0, 2),
    ),
  ];
}
