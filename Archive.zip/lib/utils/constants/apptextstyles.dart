import 'package:flutter/material.dart'; // ✅ Needed for TextStyle
import 'package:google_fonts/google_fonts.dart';

class AppTextStyles {
  static TextStyle title = GoogleFonts.prompt(
    fontSize: 22, // font-size: 22px
    fontWeight: FontWeight.bold, // font-weight: 700
    fontStyle: FontStyle.normal,
    height: 1.0, // line-height: 100%
    letterSpacing: 0.32, // custom letter spacing
  );

  static TextStyle heading = GoogleFonts.prompt(
    fontSize: 16,
    fontWeight: FontWeight.bold,
    fontStyle: FontStyle.normal,
    height: 1.0,
    letterSpacing: 0.32,
  );

  static TextStyle subheading = GoogleFonts.prompt(
    fontSize: 14,
    fontWeight: FontWeight.w500,
    fontStyle: FontStyle.normal,
    height: 1.0,
    letterSpacing: 0.32,
  );
}
