/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

import 'package:flutter/material.dart';

class TColors {
  // App theme colors
  static const Color primary = Color(0xff5855A6);
  static const Color secondary = Color(0xFFA2A0E0);
  static const Color accent = Color(0xFFb0c7ff);
  static const Color darkSkyBlue = Color(0xFF39BFF9);
  static const Color lightSkyBlue = Color(0xffbdecfe);
  static const Color lightAsh = Color(0xffCDCDCD);
  static const Color liteDark = Color(0xff282828);
  static const Color sandal = Color(0xffFFFBFB);
  static const Color primaryblue = Color(0xff605EFE);
  static const Color menubgcolor = Color(0xffF3F3FE);
  static const Color Bottomcolor = Color(0xffB98CF1);
  static const Color lightprimary = Color(0xffE9E8FE);

  ///app bar
  static const Color appbarSecondary = Color(0xFFCECDFF);

  /// Attendance
  static const Color classCompleted = Color(0xFF8077F8);
  static const Color absentOrLeave = Color(0xFFE34B5A);
  static const Color upcomingClasses = Color(0xFF494949);
  static const Color needToFillFeedback = Color(0xFFF3C03B);

  // Dashboard Containers Colors
  static const Color finished = Color(0xFFD4E9C3);
  static const Color currentProcess = Color(0xFFDADAF6);
  static const Color upComing = Color(0xFFF0E9EB);

  //Exam status color
  static const Color attempted = Color(0xFF83E436);
  static const Color notAttempted = Color(0xFFD63A5F);
  static const Color viewed = Color(0xFF8F4FCE);
  static const Color notViewed = Color(0xFFD9D9D9);
//Exam status color
  static const Color correctAnswer = Color(0xFF7EBA28);
  static const Color wrongAnswer = Color(0xFFE34B5A);
  // Text colors
  static const Color textPrimary = Color(0xFF3B2D48);
  static const Color importantText = Color(0xFFE34B5A);
  static const Color lightimportant = Color(0xFFFFD2D7);
  static const Color textSecondary = Color(0xFF605EFE);
  static const Color textWhite = Colors.white;

  // Background colors
  static const Color light = Color(0xFFF6F6F6);
  static const Color dark = Color(0xFF272727);
  static const Color primaryBackground = Color(0xFFF3F5FF);

  // Background Container colors
  static const Color lightContainer = Color(0xFFF6F6F6);
  static Color darkContainer = TColors.white.withOpacity(0.1);

  // Button colors
  static const Color buttonPrimary = Color(0xFF605EFE);
  static const Color buttonSecondary = Color(0xFF83E436);
  static const Color buttonDisabled = Color(0xFFB1B1B1);

  // Border colors
  static const Color borderPrimary = Color(0xFFD9D9D9);
  static const Color borderSecondary = Color(0xFFE6E6E6);

  // Error and validation colors
  static const Color error = Color(0xFFD32F2F);
  static const Color success = Color(0xFF388E3C);
  static const Color warning = Color(0xFFF57C00);
  static const Color info = Color(0xFF1976D2);

  // Neutral Shades
  static const Color black = Color(0xFF232323);
  static const Color red = Color(0xFFFF0000);
  static const Color lightred = Color(0xFFF35252);
  static const Color green = Color(0xFF139D1C);
  static const Color darkerGrey = Color(0xFF4F4F4F);
  static const Color darkGrey = Color(0xFF939393);
  static const Color grey = Color(0xFFE0E0E0);
  static const Color softGrey = Color(0xFFF4F4F4);
  static const Color lightGrey = Color(0xFFF9F9F9);
  static const Color white = Color(0xFFFFFFFF);

  // button Gardient Colors
  static const Color gardientBlue = Color(0xff3835FA);
  static const Color gardientRed = Color(0xffEC2B3E);

// Shadow
  static const Color shadow = Color(0xFFF000000);
}
