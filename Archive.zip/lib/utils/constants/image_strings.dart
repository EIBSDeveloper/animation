/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

/* -- App Image Strings -- */

/// This class contains all the App Images in String formats.
class TImages {
  // -- App Logos
  static const String appLogo = 'assets/logo/logo.png';

  // static const String lightAppLogo = "assets/logos/t-store-splash-logo-white.png";

  static const String coinsexchange = 'assets/logo/coinsexchange.png';
  static const String coursedetailsview = 'assets/logo/coursedetailview.png';
  static const String coursematerialdownload =
      'assets/logo/materialdwoload.png';

  ///---- background
  static const String human_1 = "assets/image/background/human_1.png";
  static const String human_2 = "assets/image/background/human_2.png";
  static const String human_3 = "assets/image/background/human_3.png";

  ///Earning Points
  static const String badge = "assets/image/earning_points/image_EP.png";
  static const String coin = "assets/image/earning_points/Coin.png";
  static const String crown = "assets/image/earning_points/bigcrown.png";
  static const String diamond = "assets/image/earning_points/Diamond.png";
  static const String heart = "assets/image/earning_points/Hearts.png";

  ///leaders board
  static const String gold = "assets/image/batches/Gold.png";
  static const String silver = "assets/image/batches/Silver.png";
  static const String bronze = "assets/image/batches/Bronze.png";

  ///File Types
  static const String folder = "assets/image/files_types/folder.png";
  static const String ppt = "assets/image/files_types/ppt.png";
  static const String pdf = "assets/image/files_types/pdf.png";
  static const String imageFolder = "assets/image/files_types/sample_image.png";
  static const String zip = "assets/image/files_types/zip.png";
  static const String word = "assets/image/files_types/image.png";

  /// Attendance
  static const String present = "assets/image/attendance/present.svg";
  static const String absent = "assets/image/attendance/absent.svg";
  static const String leave = "assets/image/attendance/leave.svg";

  ///Bottom Navigation Icon
  static const String bIcon1 = "assets/image/bottom_menu_icon/bottomhome.png";
  static const String bIcon2 = "assets/image/bottom_menu_icon/bottomcourse.png";
  static const String bIcon3 = "assets/image/bottom_menu_icon/Emerald.png";
  static const String bIcon4 =
      "assets/image/bottom_menu_icon/bottomexchange.png";
  static const String bIcon5 = "assets/image/bottom_menu_icon/bottomevent.png";

  /// -- Animations
  static const String pencilAnimation =
      "assets/image/animations/140429-pencil-drawing.json";

  /// -- Primary Images
  static const String profileImage = "assets/image/others/profile.png";

  /// -- Alert Images
  static const String thinkAlert = "assets/image/alert/think.png";
  static const String certificateAlert = "assets/image/alert/certificate.png";
  static const String queryAlert = "assets/image/alert/query.png";

  /// icons
  static const String explain = "assets/icon/Explanation.png";

  // --------- payment status
  static const String paid = "assets/icon/Paid.png";
  static const String pending = "assets/icon/Pending.png";
  static const String done = "assets/icon/box.png";
  static const String paymentsuccess = "assets/icon/paysuccesscompleted.png";

  //course
  static const String calender = "assets/icon/fontisto_date.png";
  static const String category = "assets/icon/category.png";
  static const String theory = "assets/icon/theroy.png";
  static const String practical = "assets/icon/practical.png";
  static const String hrs = "assets/icon/hrs.png";

  //events
  static const String time = "assets/icon/clock.png";
  static const String location = "assets/icon/address.png";
  static const String speaker = "assets/icon/speaker.png";
  static const String mode = "assets/icon/mode.png";
  static const String certificate = "assets/icon/certificate.png";
  static const String success = "assets/icon/bookedsuccess.gif";

  //sidemenu
  static const String mycourses = "assets/icon/course.png";
  static const String coursematerials = "assets/icon/coursematerials.png";
  static const String payment = "assets/icon/payment.png";
  static const String daily = "assets/icon/daily.png";
  static const String help = "assets/icon/desk.png";
  static const String placements = "assets/icon/jobplacement.png";
  static const String placed = "assets/icon/placed.png";
  static const String referrel = "assets/icon/referralNew.png";
  static const String rewards = "assets/icon/premiumrewards.png";
  static const String notification = "assets/icon/newnotify.png";
  static const String playbutton = "assets/icon/playbutton.png";
  static const String logout = "assets/icon/newlogout.png";

  //rewards
  static const String login = "assets/icon/login.png";
  static const String share = "assets/icon/share.png";

  /// Rating Bar icons
  static const String rat_1 = "assets/image/rating_bar/rating_1.png";
  static const String rat_2 = "assets/image/rating_bar/rating_2.png";
  static const String rat_3 = "assets/image/rating_bar/rating_3.png";
  static const String rat_4 = "assets/image/rating_bar/rating_4.png";
  static const String rat_5 = "assets/image/rating_bar/rating_5.png";

  //events
  //static const String eventImage = "assets/image/others/eventimage.jpg";

  static const String eventImage = "assets/icon/workshop.jpg";

  //exchange
  static const String exchange = "assets/icon/exchange.png";
  static const String exchangesuccess = "assets/icon/exchangesuccess.gif";

  //attendeance
  static const String days = "assets/icon/day.png";
  static const String feed = "assets/icon/feedback.png";

  //placements
  static const String salary = "assets/icon/salary.png";
  static const String interview = "assets/icon/interview.png";
  static const String vacancy = "assets/icon/vacancy.png";
  static const String address = "assets/icon/address.png";
  static const String applied = "assets/icon/done.gif";
  static const String placedstudent = "assets/logo/newcongrats.jpg";
  static const String professionalbagde = "assets/icon/professional.png";
  static const String tesbobadge = "assets/icon/tesbo.png";

  //queries
  static const String issue = "assets/icon/issue.png";
  static const String priority = "assets/icon/priority.png";
  static const String attachment = "assets/icon/file.png";
  static const String status = "assets/icon/loading.png";

  static const String bgcoupon = "assets/icon/bgcard.png";
}
