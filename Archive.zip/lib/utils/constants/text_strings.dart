/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/5/24, 12:07 PM
 */

/// This class contains all the App Text in String formats.
class TTexts {
  // -- GLOBAL Texts
  static const String submit = "Submit";
  static const String appName = "Class Mate";

  /// user Details
  static const String userID = "USERID";
  static const String userName = "USERNAME";
  static const String profileURL = "PROFILEURL";
  static const String userEmailId = "EMAILID";
  static const String userMobNo = "MOBILENO";
  static const String userAutoId = "USERAUTOID";
  static const String userOtp = "USEROTP";

  static const String incrementTimer = 'INCREMENTTIMER';

  static const String newLaunchTour = 'newLaunchTour';
  static const String newLaunchdetailsTour = 'newLaunchdetailsTour';

  static const String eventtour = 'eventtour';
  static const String eventdetailstour = 'eventdetailstour';

  static const String appbartour = 'appbartour';

  static const String leadertour = 'leadertour';

  static const String exchangetour = 'exchangetour';
  static const String exchangedialogtour = 'exchangedialogtour';

  static const String dashboardtour = 'dashboardtour';

  static const String notificationtour = 'notificationtour';

  static const String mycoursetour = 'mycoursetour';
  static const String mycoursedetailstour = 'mycoursedetailstour';
  static const String chapterdetailstour = 'chapterdetailstour';

  static const String materialtour = 'materialtour';
  static const String materialdetailtour = 'materialdetailtour';
  static const String downloadtour = 'downloadtour';

  static const String placementtour = 'placementtour';
  static const String placementdetailtour = 'placementdetailtour';

  static const String attendencetour = 'attendencetour';

  static const String querytour = 'querytour';
  static const String querydetailstour = 'querydetailstour';
  static const String queryviewtour = 'queryviewtour';

  static const String referreltour = 'referreltour';

  static const String rewardtour = 'referreltour';

  static const String paymenttour = 'paymenttour';
  static const String paymenthistorytour = 'paymenthistorytour';

  static const String sidemenutour = 'sidemenutour';

  static const String feedbackGiven =
      "FEEDBACK_GIVEN"; // feedback submitted flag
}
