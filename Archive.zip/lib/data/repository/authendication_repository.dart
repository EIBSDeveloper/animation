import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:get/get.dart';

import '../../features/authendication/models/authendication_model.dart';
import '../../utils/http/http_client.dart';

class AuthendicationRepository extends GetxController {
  static AuthendicationRepository get instance => Get.find();

  Future<AuthendicationModel?> loginRepository(String mobileNo) async {
    try {
      final reqBody = {
        "mobile_no": mobileNo,
      };

      final jsonData =
          await THttpHelper.post(APIConstants.loginEndPoint, reqBody);

      if (jsonData['status'] == "1") {
        // Parse the JSON data into the AuthendicationModel
        AuthendicationModel authModel = AuthendicationModel.fromJson(jsonData);
        return authModel;
      } else {
        // Handle case when login fails

        throw jsonData['message'] ?? 'Login failed';
      }
    } catch (e) {
      throw e.toString();
    }
  }
}
