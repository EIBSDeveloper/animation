import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../utils/http/api_constants.dart';
import '../../utils/http/http_client.dart';

class QueryOrComplaintRepository extends GetxController {
  static QueryOrComplaintRepository get instance => Get.find();
  final isLoading = false.obs;
  var isClosing = false.obs;

/*  Future<List<QueryOrComplaintModel>> queryOrComplaintList() async {
    try {
      final req = {"customer_id": GetStorage().read(TTexts.userID)};
      final response =
          await THttpHelper.post(APIConstants.queryListEndPoint, req);
      print("Query Complaint response: ${response}");
      final queryOrComplaintList = (response['data'] as List)
          .map((e) => QueryOrComplaintModel.fromJson(e))
          .toList();

      print(
          "Query Complaint : ${queryOrComplaintList.first.staffName ?? 'Not assigned'}");

      return queryOrComplaintList;
    } catch (e) {
      print('queryOrComplaintList $e');
      return [];
    }
  }*/

/*  Future<void> addQueryOrComplaint({
    required String category,
    required String priorityLevel,
    required String issue,
    required String attachment,
  }) async {
    final req = {
      "customer_id": GetStorage().read(TTexts.userID),
      "issue": issue,
      "category": category,
      "priority_level": priorityLevel,
      "attachment": attachment,
    };

    print("📤 Request of query: $req");
    try {
      final response =
          await THttpHelper.post(APIConstants.queryAddEndPoint, req);
      print("📥 Response from API: $response");

      if (response["status"] == 200) {
        TSnackbar.successSnackbar(
            title: "Thank You...", message: response['message']);
      }
    } catch (e) {
      print('❌ Error sending query: $e');
    }
  }*/
  Future<void> addQueryOrComplaint({
    required String issue,
  }) async {
    final req = {
      "customer_id": GetStorage().read(TTexts.userID),
      "issue": issue,
      "closed": 0,
    };

    print("📤 Request of query: $req");
    try {
      final response =
          await THttpHelper.post(APIConstants.queryAddEndPoint, req);
      print("📥 Response from API: $response");

      if (response["status"] == 200) {
        TSnackbar.successSnackbar(
          title: "Thank You...",
          message: response['message'],
        );
      } else {
        TSnackbar.errorSnackbar(
          title: "Error",
          message: response['message'] ?? "Something went wrong",
        );
      }
    } catch (e) {
      print('❌ Error sending query: $e');
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    }
  }

// Make the query reactive
/*  late Rx<QueryOrComplaintModel> rxQueryModel;

  void initQuery(QueryOrComplaintModel query) {
    rxQueryModel = query.obs;
  }*/

  // Close query ticket and update status
/*  Future<void> closeQueryResponseTicket() async {
    final model = rxQueryModel.value;
    try {
      final reqBody = {"issue_id": model.issueSno, "customer_id": model.cusSno};
      print("Request Body: $reqBody");

      final response = await THttpHelper.post(
          APIConstants.queryTicketClosingEndPoint, reqBody);

      if (response["status"] == "closed") {
        // Update reactive model
        rxQueryModel.update((q) {
          if (q != null) q.issueStatus = 2; // Closed
        });

        TSnackbar.successSnackbar(title: "Query Rectified Successfully");
        print("Success: closeQueryResponseTicket");
        // ✅ Refresh the query list
        final QueryOrComplaintController controller = Get.find();
        await controller.fetchQueryOrComplaintList();
      } else {
        TSnackbar.errorSnackbar(title: "Failed to close ticket");
      }
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Error closing ticket");
      print("Error in closeQueryResponseTicket: $e");
    }
  }*/
}
