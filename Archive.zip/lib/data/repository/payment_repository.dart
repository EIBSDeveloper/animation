import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get/get.dart';

import '../../features/personalization/models/payment_model.dart';

class PaymentRepository extends GetxController {
  static PaymentRepository get instance => Get.find();

  Future<List<CoursePaymentModel>> fetchPaymentCourseWise(String userId) async {
    try {
      // final reqBody = {"customer_id": userId};
      final reqBody = {"customer_id": userId};
      final response =
          await THttpHelper.post(APIConstants.paymentHistoryEndPoint, reqBody);

      final paymentCourseWise = (response['data'] as List).map((e) {
        e["redeemValue"] = response['redeemValue'];
        e["redeemlist"] = response['redeemlist'];
        return CoursePaymentModel.fromJson(e);
      }).toList();

      return paymentCourseWise;
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap!",
          message: "fetchPaymentCourseWise :${e.toString()}");
      print('Error fetching fetch Payment CourseWise data: $e');
      return [];
    }
  }
}
