import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class PlacementRepository extends GetxController {

//   Future<List<PlacementModel>> fetchPlacementList() async {
//     try {
//       final req = {
//           "customer_id" :GetStorage().read(TTexts.userID)
//       };
//       print("****************** $req");
//       final response = await THttpHelper.post(APIConstants.placementEndPoint, req);
//
//       final placementList = (response['data'] as List)
//           .map((e) => PlacementModel.fromJson(e))
//           .toList();
//       print(placementList);
// print("****************** $req");
//       return placementList;
//     } catch (e) {
//       print(e);
//       return [];
//     }
//   }
  Future<void> applyPlacement(String jobId,String companyId) async {
    try {
      final req =  {
        "customer_id": GetStorage().read(TTexts.userID),
        "job_id" :jobId,
        "company_id" : companyId,
        "interested":1
      };
      final response = await THttpHelper.post("job_interested_by_student", req);

    } catch (e) {
      print(e);

    }
  }
}
