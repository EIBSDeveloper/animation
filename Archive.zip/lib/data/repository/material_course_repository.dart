import 'package:get/get.dart';


class MaterialCourseRepository extends GetxController{
  // static MaterialCourseRepository

}