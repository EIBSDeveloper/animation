import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../features/personalization/models/batch_model.dart';
import '../../utils/constants/text_strings.dart';

class BatchRepository extends GetxController {
  static BatchRepository get instance => Get.find();
  Future<BatchDetailsModel?> fetchBatchDetailsRep(
      {required String courseId}) async {
    final reqBody = {
      "course_id": courseId,
      "customer_id": GetStorage().read(TTexts.userID)
    };

    print("Batch Repository :$reqBody");
    final response =
        await THttpHelper.post(APIConstants.batchDetailsEndPoint, reqBody);
    print("Full API Response: $response");

    if (response.containsKey('data')) {
      final data = response['data'];

      if (data == null || (data is List && data.isEmpty)) {
        return null; // Handle empty or missing batch data
      } else if (data is Map<String, dynamic>) {
        return BatchDetailsModel.fromJson(data); // Parse if valid
      }
    }

    return null; // Fallback return null
  }
}
