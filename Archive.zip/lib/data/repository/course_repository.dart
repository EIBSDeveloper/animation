import 'package:eapl_student_app/features/personalization/models/course_model.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../features/personalization/models/new_course_model.dart';
import '../../utils/constants/text_strings.dart';

class CourseRepository extends GetxController {
  static CourseRepository get instance => Get.find();

  /// Fetch own course
  Future<List<CourseDetailModel>> fetchCourseDetails(String userId,
      {int? limit}) async {
    try {
      final reqBody = {"customer_id": userId};
      final response =
          await THttpHelper.post(APIConstants.CourseListEndPoint, reqBody);

      final course = (response['data']['course'] as List)
          .map((e) => CourseDetailModel.fromJson(e))
          .toList();
      final result = limit != null ? course.take(limit).toList() : course;

      return result;
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap!", message: "Course Repository  :${e.toString()}");
      print('Error fetching Course Repository data: $e');
      return [];
    }
  }

  /// fetch the new course
/*  Future<List<NewCourseModel>> fetchNewCourseDetails({int? limit}) async {
    try {
      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };
      final response =
          await THttpHelper.post(APIConstants.newCourseListEndPoint, body);

      // Parse the response into a list of NewCourseModel.
      final newCourse = (response['data'][0]['coursesDetails'] as List)
          .map((e) => NewCourseModel.fromJson(e))
          .toList();

      // Apply the limit if provided, otherwise return the full list.
      final result = limit != null ? newCourse.take(limit).toList() : newCourse;

      return result;
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap!",
          message: "New Course Repository  :${e.toString()}");
      print('Error fetching fetchNewCourseDetails data: $e');
      return [];
    }
  }*/
  Future<List<NewCourseModel>> fetchNewCourseDetails() async {
    try {
      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };

      final response =
          await THttpHelper.post(APIConstants.newCourseListEndPoint, body);

      // Parse into model
      final newCourse = (response['data'][0]['coursesDetails'] as List)
          .map((e) => NewCourseModel.fromJson(e))
          .toList();

      return newCourse; // ✅ always full list
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap!", message: "New Course Repository: ${e.toString()}");
      print('Error fetching fetchNewCourseDetails data: $e');
      return [];
    }
  }
}
