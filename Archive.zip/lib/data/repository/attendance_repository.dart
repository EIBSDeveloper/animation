import 'package:eapl_student_app/features/personalization/models/attendance_model.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../features/personalization/models/daily_streak_model.dart';
import '../../utils/constants/text_strings.dart';
import '../../utils/http/http_client.dart';
import '../../utils/loaders/loaders.dart';

class AttendanceRepository extends GetxService {
  static AttendanceRepository get instance => Get.find();

  Future<List<AttendanceModel>> fetchAttendanceStatus(String courseId) async {
    try {
      final reqBody = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": courseId
      };

      print("Attendance Status : ${reqBody.toString()}");
      final response = await THttpHelper.post(
          APIConstants.studentAttendanceEndPoint, reqBody);
      final attendance = (response['attendance'] as List)
          .map((e) => AttendanceModel.fromJson(e))
          .toList();

      for (var attendances in attendance) {
        if (attendances.hasFeedbackOrScore()) {
          print(
              'Attendance ID: ${attendances.attendanceId} has feedback or score');
        } else {
          print(
              'Attendance ID: ${attendances.attendanceId} does not have feedback or score');
        }
      }
      return attendance;
    } catch (e) {
      print('Error fetching Attendance Repository data: $e');
      return [];
    }
  }

  Future<List<DailyStreakModel>> fetchDailyStreak({
    required String courseId,
  }) async {
    try {
      final req = {
        "course_id": courseId,
        "customer_id": GetStorage().read(TTexts.userID),
      };
      final response =
          await THttpHelper.post(APIConstants.dailyStatusEndPoint, req);

      // Check if 'data' is a non-empty list
      if (response['data'] != null &&
          response['data'] is List &&
          response['data'].isNotEmpty) {
        final firstData = response['data'][0];

        // Check if 'AttendanceSyllabus' is a non-empty list
        if (firstData["AttendanceSyllabus"] != null &&
            firstData["AttendanceSyllabus"] is List &&
            firstData["AttendanceSyllabus"].isNotEmpty) {
          final date = firstData["AttendanceSyllabus"][0]['date'];

          // Ensure 'date' is not null
          if (date != null) {
            final dailyStreak = (response['data'] as List)
                .map((e) => DailyStreakModel.fromJson(e))
                .toList();
            return dailyStreak;
          }
        }
      }

      // Return an empty list if any condition fails
      return [];
    } catch (e) {
      print("Error in fetchDailyStreak Repository ${e.toString()}");
      return [];
    }
  }

  /// Add Feedback
  Future<void> addFeedback(
      {required String attendanceId,
      required String feedbackScore,
      required String feedback}) async {
    final req = {
      "attendance_id": attendanceId,
      "feedback_score": feedbackScore,
      "feedback": feedback,
    };

    try {
      print("Feedback Request: $req");
      final response =
          await THttpHelper.post(APIConstants.attendanceFeedbackEndPoint, req);
      print("Feedback response: ${response}");

      // TSnackbar.successSnackbar(
      //     title: "Oh Nice...", message: 'Your feedback submitted Successfully');
    } catch (e) {
      print('Error in Feedback:${e}');
    }
  }
}
