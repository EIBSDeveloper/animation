import 'package:eapl_student_app/features/personalization/models/syllabus_model/chapter_model.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../features/personalization/models/syllabus_model/section_and_topics_model.dart';
import '../../utils/constants/text_strings.dart';
import '../../utils/http/http_client.dart';

class SyllabusRepository extends GetxController {
  static SyllabusRepository get instance => Get.find();

/*  Future<List<ChapterModel>> fetchChapterList(int courseId) async {
    try {
      final reqBody = {"course_id": courseId};
print(reqBody);
      final response =
          await THttpHelper.post("student_chapter_Details", reqBody);
      final chapterList = (response['chapters'] as List)
          .map((e) => ChapterModel.fromJson(e))
          .toList();
      return chapterList;
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: "Syllabus -Chapter Repository  :${e.toString()}");
      print('Error fetching Syllabus -Chapter Repository : $e');
      return [];
    }
  }*/
  Future<List<ChapterModel>> fetchChapterList(int courseId) async {
    try {
      final reqBody = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": courseId
      };
      print(reqBody);

      final response =
          await THttpHelper.post("student_chapter_Details", reqBody);

      // check null or wrong type
      final chapters = response['chapters'];
      if (chapters == null || chapters is! List) {
        return [];
      }

      final chapterList = chapters
          .map((e) => ChapterModel.fromJson(e))
          .toList()
          .cast<ChapterModel>();

      return chapterList;
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap!",
          message: "Syllabus -Chapter Repository : ${e.toString()}");
      print('Error fetching Syllabus -Chapter Repository : $e');
      return [];
    }
  }

  /// Fetches course data from the API based on the provided chapter ID.
  Future<List<ChapterAndSectionModel>> fetchSectionAndTopicsList(
      int chapterId) async {
    try {
      final reqBody = {"chapter_id": chapterId};

      // Send the POST request
      print("*********************************** $reqBody");
      final response =
          await THttpHelper.post("student_Chapter_section_list", reqBody);

      // Deserialize the response to a list of CourseData

      final courseData = (response['data'] as List)
          .map((e) => ChapterAndSectionModel.fromJson(e))
          .toList();
      return courseData;
    } catch (e) {
      print('Failed to load Section And Topics List : $e');
      throw Exception('Failed to load Section And TopicsList : $e');
    }
  }
}
