import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';

class NewLaunchTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey dropdownKey,
    required GlobalKey newcourseKey,
    required GlobalKey existcourseKey,
    required GlobalKey existcoursecardKey,
  }) {
    return [
      TargetFocus(
        identify: "searchKey",
        keyTarget: dropdownKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Select Course Category",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "newcourseKey",
        keyTarget: newcourseKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "New course tab",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "existcourseKey",
        keyTarget: existcourseKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Existing course tab",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "existcoursecardKey",
        keyTarget: existcoursecardKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "This is a course card. Tap to view details.",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}

class CourseDetailsTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey existinterestKey,
  }) {
    return [
      TargetFocus(
        identify: "existinterestKey",
        keyTarget: existinterestKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.top, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Click this button to show interest for this course",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}
