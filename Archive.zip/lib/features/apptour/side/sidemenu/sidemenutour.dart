import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';

class SidemenuTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey logoutKey,
    required GlobalKey notificationKey,
  }) {
    return [
      TargetFocus(
        identify: "logoutKey",
        keyTarget: logoutKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Click here to Logout",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "notificationKey",
        keyTarget: notificationKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Click here to see your notifications",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}
