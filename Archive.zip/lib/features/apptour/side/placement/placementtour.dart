import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';

class PlacementTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey placementtabKey,
    required GlobalKey jobkey,
    required GlobalKey saveKey,
  }) {
    return [
      TargetFocus(
        identify: "placementtabKey",
        keyTarget: placementtabKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "In this you have jobs and saved jobs",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "jobkey",
        keyTarget: jobkey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "This is the job card",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "saveKey",
        keyTarget: saveKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Tap this to save your jobs",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}

class PlacementdetailTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey applyKey,
  }) {
    return [
      TargetFocus(
        identify: "applyKey",
        keyTarget: applyKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "click this button to apply job",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}
