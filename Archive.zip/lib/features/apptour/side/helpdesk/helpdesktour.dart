import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';

class QueryTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey querycardKey,
    required GlobalKey statusKey,
    required GlobalKey addKey,
  }) {
    return [
      TargetFocus(
        identify: "querycardKey",
        keyTarget: querycardKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Tap this card to view query details.",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "statusKey",
        keyTarget: statusKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "This is the status for your query",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "addKey",
        keyTarget: addKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.top, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "click this button to add your query",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}

class QueryTourdetailsList {
  static List<TargetFocus> getTargets({
    required GlobalKey categorykey,
    required GlobalKey priorityKey,
    required GlobalKey issueKey,
    required GlobalKey submitKey,
  }) {
    return [
      TargetFocus(
        identify: "categorykey",
        keyTarget: categorykey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Select any one category to proceed",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "priorityKey",
        keyTarget: priorityKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Select any one priority to proceed",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "issueKey",
        keyTarget: issueKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Describe your query here",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "submitKey",
        keyTarget: submitKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.top, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Click this button to add your query",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}

class QueryviewTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey responseKey,
  }) {
    return [
      TargetFocus(
        identify: "responseKey",
        keyTarget: responseKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Click this button to view resposne then clik ok query closed",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}
