import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';

class ReferrelTourList {
  static List<TargetFocus> getTargets({
    required GlobalKey referrelsearchKey,
    required GlobalKey selectallKey,
    required GlobalKey selectKey,
  }) {
    return [
      TargetFocus(
        identify: "referrelsearchKey",
        keyTarget: referrelsearchKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Click here to search your contacts",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "selectallKey",
        keyTarget: selectallKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Select all contacts and tap the button to refer.",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      TargetFocus(
        identify: "selectKey",
        keyTarget: selectKey,
        shape: ShapeLightFocus.RRect, // Corner radius
        alignSkip: Alignment.bottomCenter,
        contents: [
          TargetContent(
            align: ContentAlign.bottom, // Show text above the highlight
            builder: (context, controller) {
              return Container(
                alignment: Alignment.topRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Select contact and tap the button to refer.",
                      style: GoogleFonts.prompt(
                          color: TColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: TSizes.xs,
                    ),
                    ElevatedButton(
                      onPressed: () => controller.next(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          foregroundColor: TColors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5))),
                      // Go to next step
                      child: Text("Next"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
    ];
  }
}
