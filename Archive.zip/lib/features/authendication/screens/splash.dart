/*
import 'package:eapl_student_app/utils/constants/path_provider.dart';

import '../controllers/splashcontroller.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(SplashController());
    return GetBuilder<SplashController>(
        builder: (controller) => SafeArea(
                child: Scaffold(
              backgroundColor: Colors.white,
              body: Padding(
                padding: EdgeInsets.all(TSizes.defaultSpace),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Center(
                      child: Image.asset(TImages.appLogo),
                    )
                  ],
                ),
              ),
            )));
  }
}
*/
import 'package:eapl_student_app/utils/constants/path_provider.dart';

import '../controllers/splashcontroller.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(SplashController());

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Obx(
            () => AnimatedOpacity(
              opacity: controller.opacity.value,
              duration: const Duration(seconds: 1),
              child: Transform.scale(
                scale: controller.scale.value,
                child: Image.asset(
                  TImages.appLogo,
                  width: 150,
                  height: 150,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
