import 'package:eapl_student_app/common/widget/background/background_theme.dart';
import 'package:eapl_student_app/utils/loaders/animation_loaders.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../../utils/helpers/helper_functions.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/validators/validation.dart';
import '../controllers/login_controller.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    bool isTablet = THelperFunctions.screenWidth() > 600;
    final controller = Get.put(LoginController());

    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          physics: NeverScrollableScrollPhysics(),
          child: OurBackgroundTheme(
            child: Center(
              child: Obx(() {
                return controller.isLoading.value
                    ? SizedBox(
                        height: Get.height,
                        child: TAnimationLoaderWidget(
                          text: 'Loading...',
                          animation: TImages.pencilAnimation,
                        ),
                      ) // Show loading indicator
                    : Container(
                        height: Get.height,
                        width: isTablet
                            ? THelperFunctions.screenWidth() / 2
                            : THelperFunctions.screenWidth() * 0.9,
                        padding: EdgeInsets.all(TSizes.md),
                        margin: const EdgeInsets.symmetric(vertical: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          // mainAxisAlignment: MainAxisAlignment.center,
                          // mainAxisSize: MainAxisSize.min,
                          // crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Gain Access',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium!
                                  .copyWith(color: Colors.black),
                            ),
                            SizedBox(height: TSizes.spaceBtwSections),
                            Form(
                              key: controller.loginFormKey,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  TextFormField(
                                      validator: (value) =>
                                          TValidator.validatePhoneNumber(value),
                                      controller: controller.phoneNo,
                                      decoration: InputDecoration(
                                        fillColor: Colors.white,
                                        filled: true,
                                        prefixIcon: const Icon(Icons.phone),
                                        prefixIconColor: Colors.grey,
                                        hintText: "Mobile Number",
                                        hintStyle: const TextStyle(
                                            color: TColors.darkerGrey),
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: BorderSide.none,
                                        ),
                                      ),
                                      keyboardType: TextInputType.phone,
                                      maxLength: 10,
                                      buildCounter: (_,
                                              {required currentLength,
                                              required maxLength,
                                              required isFocused}) =>
                                          null),
                                ],
                              ),
                            ),
                            SizedBox(height: TSizes.spaceBtwSections),
                            controller.isLoading.value
                                ? Center(
                                    child: LoadingAnimationWidget.waveDots(
                                      color: Colors.white,
                                      size: 100,
                                    ),
                                  )
                                : Container(
                                    margin: EdgeInsets.symmetric(
                                        horizontal: isTablet ? 60 : 20),
                                    width: double.infinity,
                                    child: ElevatedButton(
                                      onPressed: controller.loginBtn,
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: TColors.primary,
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 15.0),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                      ),
                                      child: const Text('Obtain OTP'),
                                    ),
                                  ),
                            const SizedBox(height: 25.0),
                            SizedBox(
                                height: 388,
                                width: double.infinity,
                                child: Image.asset(
                                  TImages.human_2,
                                )),
                          ],
                        ),
                      );
              }),
            ),
          ),
        ),
      ),
    );
  }
}
