import 'package:fluttertoast/fluttertoast.dart';
import 'package:pinput/pinput.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../../utils/constants/path_provider.dart';
import '../../../utils/constants/text_strings.dart';
import '../controllers/login_controller.dart';
import '../controllers/timercontroller.dart';

class OTPPage extends StatefulWidget {
  const OTPPage({super.key});

  @override
  State<OTPPage> createState() => _OTPPageState();
}

class _OTPPageState extends State<OTPPage> with CodeAutoFill {
  final TimerController timerController = Get.put(TimerController());
  final loginController = LoginController.instance;
  TextEditingController otp = TextEditingController();
  String signature = "{{ app signature }}";

  @override
  void initState() {
    super.initState();
    //Fluttertoast.showToast(msg: "🔔 OTP Page initState called");
    listenForCode(); // Start listening for SMS
    getAppSignature(); // Optional - log app signature for backend
  }

  Future<void> getAppSignature() async {
    final String signature = await SmsAutoFill().getAppSignature;
    debugPrint("📦 App Signature: $signature");
    //Fluttertoast.showToast(msg: "App Signature: $signature");
    // Give this signature to your backend team to include in SMS
  }

  @override
  void codeUpdated() {
    //Fluttertoast.showToast(msg: "📲 OTP received: $code");
    debugPrint("📲 OTP received: $code");
    setState(() {
      loginController.userCode = code ?? "";
      otp.text = code ?? "";
    });
  }

  @override
  void dispose() {
    //Fluttertoast.showToast(msg: "🛑 OTP Page disposed, cancelling SMS listener");
    cancel(); // Stop listening
    otp.dispose();
    super.dispose();
  }

  void _showToast() {
    Fluttertoast.showToast(
      msg: "OTP Resent",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: TColors.primary, // 👉 your TPrimary color
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  @override
  Widget build(BuildContext context) {
    final LoginController loginController = LoginController.instance;
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: const TextStyle(fontSize: 22, color: Colors.black),
      decoration: BoxDecoration(
        border: Border.all(color: TColors.black, width: 2.0),
        borderRadius: BorderRadius.circular(5),
        color: Colors.white,
      ),
    );

    final PinTheme focusedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(
        border: Border.all(color: Colors.black),
        color: Colors.white,
      ),
    );

    final PinTheme submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(color: Colors.white),
    );

    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          physics: NeverScrollableScrollPhysics(),
          child: OurBackgroundTheme(
            child: Center(
              child: Container(
                height: Get.height,
                width: THelperFunctions.screenWidth() > 600
                    ? THelperFunctions.screenWidth() / 2
                    : THelperFunctions.screenWidth() - 50,
                padding: EdgeInsets.all(TSizes.md),
                margin: const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'OTP Sent to the Registered Mobile Number',
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium!
                          .apply(color: Colors.black),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: TSizes.spaceBtwItems),
      
                    /// OTP Box TextField
                    Pinput(
                      length: 6,
                      defaultPinTheme: defaultPinTheme,
                      focusedPinTheme: focusedPinTheme,
                      submittedPinTheme: submittedPinTheme,
                      showCursor: true,
                      controller: otp,
                      onChanged: (value) {
                        loginController.userCode = value;
                      },
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // ⏱ Timer Text (always black)
                        Obx(
                          () => Text(
                            timerController.timerText.value,
                            style: const TextStyle(
                                color: Colors.black, fontSize: 16),
                          ),
                        ),
                        SizedBox(width: TSizes.md),
      
                        // 🔄 Resend OTP (red when active, grey when disabled)
                        Obx(() {
                          if (loginController.isLoading.value) {
                            return SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator());
                          }
                          return GestureDetector(
                            onTap: timerController.timerText.value == "00:00"
                                ? () {
                                    _showToast();
                                    loginController.login();
                                    timerController.startTimer();
                                  }
                                : null,
                            child: Text(
                              "Resend OTP",
                              style: TextStyle(
                                color: timerController.timerText.value == "00:00"
                                    ? Colors.red
                                    : Colors.grey,
                                fontSize: 16,
                                decoration:
                                    timerController.timerText.value == "00:00"
                                        ? TextDecoration.underline
                                        : TextDecoration.none,
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
      
                    SizedBox(height: TSizes.spaceBtwSections),
      
                    /// Submit Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.primary,
                          side: BorderSide(color: Colors.black),
                        ),
                        onPressed: () {
                          //Fluttertoast.showToast(msg: "🔄 Submit button pressed");
                          /*loginController.validateOTP();*/
                          loginController.otpCheck();
                        },
                        child: Text(TTexts.submit),
                      ),
                    ),
                    SizedBox(height: TSizes.spaceBtwItems),
                    SizedBox(
                      height: 388,
                      width: double.infinity,
                      child: Image.asset(
                        TImages.human_1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
