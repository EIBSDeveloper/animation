import 'package:eapl_student_app/utils/constants/path_provider.dart';

class UnauthUserPage extends StatelessWidget {
  const UnauthUserPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: SingleChildScrollView(
            physics: NeverScrollableScrollPhysics(),
            child: OurBackgroundTheme(
                child: Container(
                  height: Get.height,
                  width: THelperFunctions.screenWidth() > 600
                      ? THelperFunctions.screenWidth() / 2
                      : THelperFunctions.screenWidth() - 50,
                  padding: EdgeInsets.all(TSizes.md),
                  margin: const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
            
                  child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: Theme.of(context)
                        .textTheme
                        .headlineMedium!
                        .copyWith(color: Colors.black),
                    children: [
                      TextSpan(
                        text: 'Oops',
                        style: TextStyle(color: Colors.red),
                      ),
                      TextSpan(
                        text: ', Not an Authorized \n User..!!',
                      ),
                    ],
                  ),
                            ),
                            SizedBox(
                  height: TSizes.spaceBtwSections * 4,
                            ),
                            SizedBox(
                                height: 388,
                                width: 300,
                                child: Image.asset(TImages.human_3,))
                          ],
                        ),
                      ),
                )),
          )
          // Image.asset
      
          ),
    );
  }
}
