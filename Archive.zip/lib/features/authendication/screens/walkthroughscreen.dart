import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../../../utils/constants/colors.dart';
import '../controllers/walkthroughcontroller.dart';
import 'login.dart';

class WalkthroughScreen extends StatelessWidget {
  WalkthroughScreen({super.key});
  final WalkthroughController controller = Get.put(WalkthroughController());

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Get.theme.colorScheme.onPrimary,
        body: SafeArea(
          child: Stack(
            children: [
              Center(
                child: Obx(
                  () => Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FadeTransition(
                        opacity: controller.fadeAnimation,
                        child: SlideTransition(
                          position: controller.slideAnimation,
                          child: Column(
                            children: [
                              Image.asset(
                                controller.images[controller.currentIndex.value],
                                height: screenHeight * 0.3,
                              ),
                              SizedBox(height: screenHeight * 0.02),
                              Text(
                                  controller.texts[controller.currentIndex.value],
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.prompt(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                    fontStyle: FontStyle.normal,
                                    height: 1.5,
                                    letterSpacing: 0.32,
                                  )),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.04),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SmoothIndicator(
                            offset: controller.currentIndex.value.toDouble(),
                            count: controller.images.length,
                            size: const Size(55, 10),
                            effect: ExpandingDotsEffect(
                              expansionFactor: 3,
                              spacing: 8.0,
                              radius: 4.0,
                              dotWidth: 10.0,
                              dotHeight: 10.0,
                              dotColor: TColors.primary,
                              activeDotColor: TColors.secondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
      
              /// FloatingActionButton: Next
              Obx(
                () => controller.currentIndex.value < 2
                    ? Positioned(
                        bottom: screenHeight * 0.05,
                        right: screenWidth * 0.05,
                        child: FloatingActionButton(
                          onPressed: controller.nextPage,
                          backgroundColor: TColors.primary,
                          child: const Icon(
                            Icons.arrow_forward,
                            color: Colors.white,
                          ),
                        ),
                      )
                    : const SizedBox(),
              ),
      
              // Get Started Button on final screen
              Obx(
                () => controller.currentIndex.value == 2
                    ? Positioned(
                        bottom: screenHeight * 0.05,
                        left: 0,
                        right: 0,
                        child: Center(
                          child: ElevatedButton(
                            onPressed: () {
                              Get.offAll(() => const Login());
                            },
                            style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.symmetric(
                                horizontal: screenWidth * 0.1,
                                vertical: screenHeight * 0.018,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              backgroundColor: TColors.primary,
                            ),
                            child: Text(
                              "Get started",
                              style: Get.theme.textTheme.bodyLarge!.copyWith(
                                color: Colors.white,
                                fontSize: screenHeight * 0.022,
                              ),
                            ),
                          ),
                        ),
                      )
                    : const SizedBox(),
              ),
      
              // Back Button
              Obx(
                () => controller.currentIndex.value > 0
                    ? Positioned(
                        top: screenHeight * 0.02,
                        left: screenWidth * 0.02,
                        child: IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: controller.prevPage,
                        ),
                      )
                    : const SizedBox(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
