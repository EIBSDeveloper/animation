class AuthendicationModel {
  final String status;
  final int otp;
  final String? cusName;
  final int sno;
  final String studentId;
  final String? baseUrl;
  final String? cusGender;
  final DateTime? cusDob;
  final String? cusMobile;
  final DateTime? doj;
  final int? cusMaritalStatus;
  final int? active;
  final String? cusEmailId;
  final String? message;
  final String? errorMsg;
  final dynamic data;

  AuthendicationModel({
    required this.status,
    required this.otp,
    this.cusName,
    required this.sno,
    required this.studentId,
    this.baseUrl,
    this.cusGender,
    this.cusDob,
    this.cusMobile,
    this.doj,
    this.cusMaritalStatus,
    this.active,
    this.cusEmailId,
    this.message,
    this.errorMsg,
    this.data,
  });

  // Factory method to create a Customer instance from a JSON map
  factory AuthendicationModel.fromJson(Map<String, dynamic> json) {
    return AuthendicationModel(
      status: json['status'] as String,
      otp: json['otp'] as int,
      cusName: json['cus_name'] as String?,
      sno: json['sno'] as int,
      studentId: json['student_id'] as String,
      baseUrl: json['baseUrl'] as String?,
      cusGender: json['cus_gender'] as String?,
      cusDob: json['cus_dob'] != null
          ? DateTime.parse(json['cus_dob'] as String)
          : null,
      cusMobile: json['cus_mobile'] as String?,
      doj: json['doj'] != null ? DateTime.parse(json['doj'] as String) : null,
      cusMaritalStatus: json['cus_marital_status'] as int?,
      active: json['Active'] as int?,
      cusEmailId: json['cus_email_id'] as String?,
      message: json['message'] as String?,
      errorMsg: json['error_msg'] as String?,
      data: json['data'],
    );
  }
}
