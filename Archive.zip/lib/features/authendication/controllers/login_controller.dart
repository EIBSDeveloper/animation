import 'package:eapl_student_app/features/authendication/controllers/dailycheckcontroller.dart';
import 'package:eapl_student_app/features/authendication/screens/otp.dart';
import 'package:eapl_student_app/features/authendication/screens/unauth_user.dart';
import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/local_storage/storage_utility.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../../common/widget/menu/bottom_menu/bottom_menu.dart';
import '../../../data/repository/authendication_repository.dart';
import '../../../utils/constants/colors.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/http/api_constants.dart';
import '../../../utils/http/http_client.dart';
import '../../../utils/loaders/loaders.dart';
import '../models/authendication_model.dart';

class LoginController extends GetxController {
  static LoginController get instance => Get.find();

  ///variables
  // final phoneNo = TextEditingController(text: '6382288402');
  final phoneNo = TextEditingController();

  String sendOtp = '';
  String userCode = '';
  final AuthendicationRepository authRepo = Get.put(AuthendicationRepository());
  var isLoading = false.obs;
  var authModel = Rxn<AuthendicationModel>();

  GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();
  // void onInit() {
  //   super.onInit();
  //   requestStoragePermission();
  // }
/*  Future<void> loginBtn() async {
    try {
      if (!loginFormKey.currentState!.validate()) {
        return;
      } else {
        login();
      }
    } catch (e) {
      TSnackbar.errorSnackbar(title: "oh snap!", message: e.toString());
    }
  }*/
  Future<void> loginBtn() async {
    try {
      if (!loginFormKey.currentState!.validate()) {
        return;
      } else {
        await login(); // wait for API
        // ✅ Show success toast here
      }
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Oh snap!", message: e.toString());
    }
  }

  // Method to handle login
  Future<void> login() async {
    try {
      final isConnected = await NetworkManager.instance.isConnected();

      if (!isConnected) {
        TSnackbar.warningSnackbar(
            title: 'No Internet', message: 'Please check your connection.');
        return;
      }
      isLoading.value = true;

      final response = await authRepo.loginRepository(phoneNo.text);

      if (response != null) {
        authModel.value = response;

        TLocalStorage.init(authModel.value!.sno.toString());

        sendOtp = authModel.value!.otp.toString();
        print("User id : ${GetStorage().read(TTexts.userName)}");
        isLoading.value = false;
        /*        TSnackbar.successSnackbar(
              title: "OTP Send ${sendOtp}", message: "OTP sent Successfully");*/
        var signature = await SmsAutoFill().getAppSignature;
        Fluttertoast.showToast(
          msg: "OTP sent successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: TColors.primary, // your primary color
          textColor: Colors.white,
          fontSize: 16.0,
        );
        Get.to(() => OTPPage());
        print(" ++++++++++++++++++++++++++ OTP : $sendOtp");
      } else {
        TSnackbar.errorSnackbar(title: "Failed to login. Please try again.");
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Invalid Mobile Number",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: TColors.red, // your primary color
        textColor: Colors.white,
        fontSize: 16.0,
      );
      Get.to(() => const UnauthUserPage());
      // TSnackbar.errorSnackbar(title: "Oh Snap!", message: e.toString());
      isLoading.value = false;
    }
  }

/*  Future<void> validateOTP() async {
    final isConnected = await NetworkManager.instance.isConnected();
    if (!isConnected) {
      TSnackbar.warningSnackbar(
          title: 'No Internet', message: 'Please check your connection.');
      return;
    }
    if (userCode.length != 6) {
      TSnackbar.errorSnackbar(
          title: 'Invalid OTP', message: 'Please enter a valid 6-digit OTP.');
    } else {
      if (sendOtp == userCode) {
        GetStorage().write(TTexts.userID, authModel.value?.sno.toString());
        GetStorage().write(TTexts.userName, authModel.value?.cusName);
        GetStorage()
            .write(TTexts.userAutoId, authModel.value?.studentId.toString());
        GetStorage()
            .write(TTexts.profileURL, authModel.value?.baseUrl.toString());
        GetStorage()
            .write(TTexts.userEmailId, authModel.value?.cusEmailId.toString());
        GetStorage()
            .write(TTexts.userMobNo, authModel.value?.cusMobile.toString());
        print("USER-ID: ${GetStorage().read(TTexts.userID)}");
        Get.offAll(() => OurBottomNavigationBar());
      } else {
        TSnackbar.errorSnackbar(
            title: 'OTP Verification Failed',
            message:
                'The OTP entered does not match. Please check and try again.');
      }
    }
  }*/
  // Future<void> requestStoragePermission() async {
  //   var status = await Permission.manageExternalStorage.request();
  //
  //   if (!status.isGranted) {
  //     Get.snackbar(
  //       "Permission Required",
  //       "Storage access is needed for full functionality.",
  //       snackPosition: SnackPosition.BOTTOM,
  //     );
  //   }
  // }

  Future<AuthendicationModel?> otpCheck() async {
    try {
      // ✅ Check internet connection first
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TSnackbar.warningSnackbar(
          title: 'No Internet',
          message: 'Please check your connection.',
        );
      }

      // ✅ Validate OTP length
      if (userCode.length != 6) {
        TSnackbar.errorSnackbar(
          title: 'Invalid OTP',
          message: 'Please enter a valid 6-digit OTP.',
        );
      }
      final reqBody = {
        "mobile_no": phoneNo.text.trim(),
        "otp": userCode,
      };

      final response =
          await THttpHelper.post(APIConstants.otpcheckendpoint, reqBody);

      // ✅ Check status as bool instead of string
      if (response['status'] == true) {
        GetStorage().write(TTexts.userID, authModel.value?.sno.toString());
        GetStorage().write(TTexts.userName, authModel.value?.cusName);
        GetStorage()
            .write(TTexts.userAutoId, authModel.value?.studentId.toString());
/*        GetStorage()
            .write(TTexts.profileURL, authModel.value?.baseUrl.toString());*/
        GetStorage().write(TTexts.profileURL, authModel.value?.baseUrl ?? '');

        GetStorage()
            .write(TTexts.userEmailId, authModel.value?.cusEmailId.toString());
        GetStorage()
            .write(TTexts.userMobNo, authModel.value?.cusMobile.toString());
        print("USER-ID: ${GetStorage().read(TTexts.userID)}");
        // ✅ Trigger daily check popup for first login
        final dailyCheckController = Get.find<DailycheckController>();
        await dailyCheckController.studentcheck();
        Get.offAll(() => OurBottomNavigationBar());
      } else {
        TSnackbar.errorSnackbar(
            title: 'OTP Verification Failed',
            message:
                'The OTP entered does not match. Please check and try again.');
      }
    } catch (e) {
      TSnackbar.errorSnackbar(title: 'Error', message: e.toString());
      //return null;
    }
  }
}
