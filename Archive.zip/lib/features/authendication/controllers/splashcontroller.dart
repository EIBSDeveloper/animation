import 'dart:async';

import 'package:eapl_student_app/features/authendication/screens/walkthroughscreen.dart';
import 'package:get/get.dart';

class SplashController extends GetxController {
  var opacity = 0.0.obs;
  var scale = 0.8.obs;

  @override
  void onInit() {
    super.onInit();
    _startAnimation();
  }

  void _startAnimation() {
    // Animate logo
    Timer(const Duration(milliseconds: 300), () {
      opacity.value = 1.0;
      scale.value = 1.0;
    });

    // Navigate to next page after 3 seconds
    Timer(const Duration(seconds: 3), () {
      // Replace with your home page route
      Get.offAll(() => WalkthroughScreen());
    });
  }
}
