import 'package:eapl_student_app/common/widget/app_bar/appbar_controller.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../main.dart';
import '../../../utils/constants/text_strings.dart';
import '../../../utils/http/http_client.dart';
import '../../personalization/screens/side_drawer_menu/notifications/notification_controller.dart';

class DailycheckController extends GetxController {
  @override
  void onInit() {
    super.onInit();
    studentcheck(); // Trigger on app start
  }

  Future<void> studentcheck() async {
    try {
      String? userId = GetStorage().read(TTexts.userID);

      if (userId == null || userId.isEmpty) {
        print("❌ User ID is null or empty");
        return;
      }

      final body = {"customer_id": int.parse(userId)};
      print("body $body");

      final response =
          await THttpHelper.post(APIConstants.studentdailycheck, body);

      if (response['status'] == 0) {
        // 🎉 Show reward dialog
        showDialog(
          context: navState.currentState!.context,
          barrierDismissible: false, // user must tap the button
          builder: (BuildContext dialogContext) {
            return RewardDialog();
          },
        );
        await Get.find<AppbarController>().fetchPointsDetails();
        final notificationController = Get.find<NotificationController>();
        await notificationController.fetchNotificationList();
        final appbarController = Get.find<AppbarController>();
        appbarController.incrementNotify();
      } else {
        print("✅ Daily check successful: ${response['message']}");
      }
    } catch (e) {
      print("❌ Exception in studentcheck(): $e");
    }
  }
}

class RewardDialog extends StatefulWidget {
  const RewardDialog({super.key});

  @override
  State<RewardDialog> createState() => _RewardDialogState();
}

class _RewardDialogState extends State<RewardDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _flipAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat();

    _flipAnimation = Tween<double>(begin: 0, end: 2 * 3.1416).animate(
      CurvedAnimation(parent: _controller, curve: Curves.linear),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 10,
      shadowColor: Colors.grey.shade400,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _flipAnimation,
              builder: (context, child) {
                return Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.001)
                    ..rotateY(_flipAnimation.value),
                  child: Image.asset(
                    'assets/image/earning_points/Coin.png',
                    width: 60,
                    height: 60,
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            Text(
              "Reward Earned!",
              style: GoogleFonts.prompt(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "You got 1 coin for today’s check-in!",
              style: GoogleFonts.prompt(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: TColors.primary,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                "Awesome",
                style: GoogleFonts.prompt(
                    fontWeight: FontWeight.bold, fontSize: 16),
              ),
            )
          ],
        ),
      ),
    );
  }
}
