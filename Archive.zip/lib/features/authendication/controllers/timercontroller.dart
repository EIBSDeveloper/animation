import 'dart:async';

import 'package:eapl_student_app/utils/constants/path_provider.dart';

class TimerController extends GetxController {
  // Rx variable to keep track of the time
  RxString timerText = '02:00'.obs;
  late Timer _timer;
  int _secondsRemaining = 0;

  @override
  void onInit() {
    super.onInit();
    startTimer();
  }

  void startTimer() {
    _secondsRemaining = 120; //2 minutes in seconds
    // Start the countdown timer
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining == 0) {
        _timer.cancel(); // Stop the timer when it reaches 0
      } else {
        _secondsRemaining--;
        // Convert seconds into MM:SS format and update the timerText
        int minutes = _secondsRemaining ~/ 60;
        int seconds = _secondsRemaining % 60;
        timerText.value =
            '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
      }
    });
  }

  @override
  void onClose() {
    _timer.cancel(); // Cancel the timer when the controller is disposed
    super.onClose();
  }
}
