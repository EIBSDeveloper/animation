/*import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class WalkthroughController extends GetxController
    with GetTickerProviderStateMixin {
  var currentIndex = 0.obs;
  late AnimationController animationController;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;

  final List<String> images = [
    TImages.coinsexchange,
    TImages.coursedetailsview,
    TImages.coursematerialdownload,
  ];

  final List<String> texts = [
    "Earn coins through daily engagement and exchange them for exciting offers or course benefits."
        "Access detailed insights about your enrolled courses, progress, and upcoming sessions."
        "Instantly download and view course materials to keep learning at your own pace."
  ];

  @override
  void onInit() {
    _initAnimation();
    animationController.forward();
    super.onInit();
  }

  void _initAnimation() {
    animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(animationController);

    slideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset.zero,
    ).animate(animationController);
  }

  void nextPage() {
    if (currentIndex.value < images.length - 1) {
      animationController.reverse().then((_) {
        currentIndex.value++;

        _restartAnimation(forward: true); // Slide from right to left
      });
    }
  }

  void prevPage() {
    if (currentIndex.value > 0) {
      animationController.reverse().then((_) {
        currentIndex.value--;

        _restartAnimation(forward: false); // Slide from left to right
      });
    }
  }

  void _restartAnimation({required bool forward}) {
    slideAnimation = Tween<Offset>(
      begin: forward ? const Offset(1.0, 0) : const Offset(-1.0, 0),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: animationController, curve: Curves.easeOut),
    );

    animationController.forward();
  }

  @override
  void onClose() {
    animationController.dispose();
    super.onClose();
  }
}*/
import 'package:flutter/animation.dart';
import 'package:get/get.dart';

import '../../../utils/constants/image_strings.dart';

class WalkthroughController extends GetxController
    with GetSingleTickerProviderStateMixin {
  final RxInt currentIndex = 0.obs;

  late AnimationController animationController;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;

  final List<String> images = [
    TImages.coinsexchange,
    TImages.coursedetailsview,
    TImages.coursematerialdownload,
  ];

  final List<String> texts = [
    "Earn and exchange coins for real rewards",
    "View and manage your course details with ease",
    "Download all your course materials instantly",
  ];

  @override
  void onInit() {
    super.onInit();

    animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    fadeAnimation =
        Tween<double>(begin: 0, end: 1).animate(animationController);
    slideAnimation = Tween<Offset>(
      begin: const Offset(0.2, 0),
      end: Offset.zero,
    ).animate(animationController);

    animationController.forward();
  }

  void nextPage() {
    if (currentIndex.value < images.length - 1) {
      currentIndex.value++;
      restartAnimation();
    }
  }

  void prevPage() {
    if (currentIndex.value > 0) {
      currentIndex.value--;
      restartAnimation();
    }
  }

  void restartAnimation() {
    animationController.reset();
    animationController.forward();
  }

  @override
  void onClose() {
    animationController.dispose();
    super.onClose();
  }
}
