import 'package:eapl_student_app/features/apptour/bottom/leaderboard/leaderboardtour.dart';
import 'package:eapl_student_app/features/personalization/models/leader_model.dart';
import 'package:eapl_student_app/features/personalization/models/points_model.dart';
import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/path_provider.dart';

class PointsController extends GetxController {
  static PointsController get instance => Get.find();

  var isLoading = false.obs;

  final pointsValue = Rxn<PointsModel>();

  final leaderBoardList = <LeaderModel>[].obs;

  @override
  void onInit() {
    super.onInit();
  }

  Future<void> fetchPoints() async {
    try {
      isLoading.value = true;
      final request = {"customer_id": GetStorage().read(TTexts.userID)};
      print("FetchPoints request : ${request}");
      final response =
          await THttpHelper.post(APIConstants.studentPointsEndPoint, request);
      pointsValue.value = PointsModel.fromJson(response['data'][0]);
      print("FetchPoints result : ${pointsValue.value?.sno}");
      isLoading.value = false;
    } catch (e) {
      print("fetchPoints Error : $e");
      isLoading.value = false;
    }
  }

/*  Future<void> fetchLeaderBoard() async {
    try {
      leaderBoardList.clear();
      isLoading.value = true;
      final request = {"customer_id": GetStorage().read(TTexts.userID)};
      print("fetchLeaderBoard request : ${request}");
      final response =
          await THttpHelper.post(APIConstants.leaderBoardEndPoint, request);
      var leader =
          (response['data'] as List).map((e) => LeaderModel.fromMap(e));
      leaderBoardList.addAll(leader);

      isLoading.value = false;
    } catch (e) {
      print("fetchLeaderBoard Error : $e");
      isLoading.value = false;
    }
  }*/
  final currentUser = Rxn<LeaderModel>();
  Future<void> fetchLeaderBoard() async {
    try {
      leaderBoardList.clear();
      isLoading.value = true;

      final userId = int.tryParse(GetStorage().read(TTexts.userID).toString());

      final response = await THttpHelper.post(
        APIConstants.leaderBoardEndPoint,
        {"customer_id": userId},
      );

      final List<LeaderModel> leaders = (response['data'] as List)
          .map((e) => LeaderModel.fromMap(e))
          .toList();

      leaderBoardList.addAll(leaders);

      // ✅ Get current user's rank using dynamic userId
      currentUser.value = leaders.firstWhereOrNull((e) => e.sno == userId);

      isLoading.value = false;
    } catch (e) {
      print("fetchLeaderBoard Error: $e");
      isLoading.value = false;
    }
  }

  //Leaderboard tour
  final yourpointskey = GlobalKey();
  final otherpointsKey = GlobalKey();

  var isLeaderboardTouron = false.obs;
  Future<void> LeaderboardTour(BuildContext context) async {
    final targets = LeaderboardTourList.getTargets(
        yourpointsKey: yourpointskey, otherpointsKey: otherpointsKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.leadertour, true);
        isLeaderboardTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.leadertour, true);
        isLeaderboardTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
