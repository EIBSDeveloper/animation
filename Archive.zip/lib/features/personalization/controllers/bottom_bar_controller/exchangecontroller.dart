import 'package:eapl_student_app/common/widget/app_bar/appbar_controller.dart';
import 'package:eapl_student_app/features/apptour/bottom/exchange/exchangetour.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/text_strings.dart';
import '../../screens/side_drawer_menu/notifications/notification_controller.dart';

class ExchangeController extends GetxController {
  var isexchangeloading = false.obs;
  var selectedType = ''.obs;
  var selectedAmount = 0.obs;
  // Call this to reset when opening the dialog
  void reset() {
    selectedType.value = '';
    selectedAmount.value = 0;
    isexchangeloading.value = false;
  }

  Future<void> exchangepoints({
    required int customerId,
    required int coin,
    required int diamond,
    required int crown,
  }) async {
    try {
      isexchangeloading.value = true;
      await Future.delayed(const Duration(seconds: 2));
      var userid = GetStorage().read(TTexts.userID);
      print("User ID: $userid");

      final body = {
        "customer_id": customerId,
        "coin": coin,
        "diamond": diamond,
        "crown": crown,
      };

      final response = await THttpHelper.post(
        APIConstants.exchange,
        body,
      );
      print("body--------------$body");

      if (response["status"] == 1) {
        print("Exchange successful: ${response["data"]}");

        // 👇 Refresh points from backend
        await Get.find<AppbarController>().fetchPointsDetails();
        final notificationController = Get.find<NotificationController>();
        await notificationController.fetchNotificationList();
        final appbarController = Get.find<AppbarController>();
        appbarController.incrementNotify();

        // Close the dialog
        Get.back();
      } else {
        Get.snackbar("Failed", response["message"],
            backgroundColor: Colors.red, colorText: Colors.white);
      }
    } catch (e) {
      print("Error: $e");
      Get.snackbar("Error", "Something went wrong",
          backgroundColor: Colors.red, colorText: Colors.white);
    } finally {
      isexchangeloading.value = false;
    }
  }

  //exchange dialogtour
  final exchangebuttonKey = GlobalKey();

  var isExchangeDialogTouron = false.obs;
  Future<void> ExchangeDialogTour(BuildContext context) async {
    final targets =
        ExchangedialogTourList.getTargets(exchangebuttonKey: exchangebuttonKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.exchangedialogtour, true);
        isExchangeDialogTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.exchangedialogtour, true);
        isExchangeDialogTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
