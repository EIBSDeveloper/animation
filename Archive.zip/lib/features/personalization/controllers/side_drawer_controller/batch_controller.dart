/*import 'dart:async';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../data/repository/batch_repository.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../../../utils/http/api_constants.dart';
import '../../../../utils/http/http_client.dart';
import '../../models/attendance_model.dart';
import '../../models/batch_model.dart';

class BatchController extends GetxController {
  final BatchRepository repository = Get.put(BatchRepository());
  final storage = GetStorage();
  // Observable variables to hold batch data and loading state
  var batchDetails = Rxn<BatchDetailsModel>();
  var isLoading = false.obs;

  var isalertLoading = false.obs;

  var showReminder = false.obs;
  var reminderMessage = "".obs;
  var blink = true.obs;

  Timer? reminderTimer;
  Timer? feedbackTimer;
  Timer? blinkTimer;
  Rxn<AttendanceModel> alertAttendanceModel = Rxn<AttendanceModel>();

  @override
  void onClose() {
    reminderTimer?.cancel();
    feedbackTimer?.cancel();
    blinkTimer?.cancel();
    super.onClose();
  }

  @override
  void onInit() {
    fetchFeedbackAlerts();
  } // Method to fetch batch details from the repository

  Future<void> fetchBatchDetailsController({required String courseId}) async {
    try {
      isLoading.value = true; // Set loading state to true
      final data = await repository.fetchBatchDetailsRep(courseId: courseId);
      if (data != null) {
        batchDetails.value = data;
        // Use batchSno (or auto_increment_id) as unique identifier
        if (data.batchId != null) {
          _scheduleReminders(data, data.batchId.toString());
        }
      } else {
        batchDetails = Rxn<BatchDetailsModel>();
      }
      // Update the observable batch details
    } finally {
      isLoading.value = false; // Set loading state to false
    }
  }

  Future<void> fetchFeedbackAlerts() async {
    try {
      isalertLoading.value = true;

      // Prepare request body
      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };

      // Call API
      final response =
          await THttpHelper.post(APIConstants.feedbackalertendpoint, body);

      if (response != null && response['status'] == 200) {
        final alerts = response['alerts'] as List<dynamic>;

        // Find first alert with alert == 1
        final alertItem = alerts.firstWhereOrNull((a) => a['alert'] == 1);

        if (alertItem != null) {
          alertAttendanceModel.value =
              AttendanceModel.fromJson(alertItem); // ✅ FIXED
          // Show blinking reminder banner
          _showBanner(
              "Feedback pending for ${alertItem['batch_name']} (${alertItem['status']})");
        } else {
          // No active alerts
          showReminder.value = false;
        }
      }
    } catch (e) {
      print("Error fetching feedback alerts: $e");
    } finally {
      isalertLoading.value = false;
    }
  }

  /// Schedule reminders based on end time
  void _scheduleReminders(BatchDetailsModel batch, String attendanceId) {
    if (batch.endTime == null || !batch.endTime!.contains(':')) return;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final endParts = batch.endTime!.split(':');

    final endTime = DateTime(
      today.year,
      today.month,
      today.day,
      int.parse(endParts[0]),
      int.parse(endParts[1]),
      int.parse(endParts[2]),
    );

    final reminderTime = endTime.subtract(const Duration(minutes: 15));
    final feedbackDeadline = endTime.add(const Duration(hours: 3));

    // Cancel previous timers
    reminderTimer?.cancel();
    feedbackTimer?.cancel();

    // 🔔 Reminder: 15 min before end time
    if (now.isBefore(reminderTime)) {
      final delay = reminderTime.difference(now);
      reminderTimer = Timer(delay, () {
        _showBanner("Your class will end soon. Please prepare for feedback.");
      });
    } else if (now.isAfter(reminderTime) && now.isBefore(endTime)) {
      _showBanner("Your class will end soon. Please prepare for feedback.");
    }

    // 🕒 Feedback reminder: within 3 hours after class end
    if (now.isAfter(endTime) && now.isBefore(feedbackDeadline)) {
      _checkFeedbackStatus(attendanceId);
    } else if (now.isBefore(endTime)) {
      final feedbackDelay =
          endTime.difference(now) + const Duration(minutes: 5);
      feedbackTimer =
          Timer(feedbackDelay, () => _checkFeedbackStatus(attendanceId));
    }
  }

  /// Check if feedback was given for this attendance/session
  void _checkFeedbackStatus(String attendanceId) {
    final today = DateTime.now().toString().substring(0, 10);
    final key =
        "${TTexts.feedbackGiven}_${attendanceId}_$today"; // unique per session
    final isFeedbackGiven = storage.read(key) ?? false;

    if (!isFeedbackGiven) {
      _showBanner("Please submit your feedback for today's class.");
    }
  }

  /// Mark feedback submitted
  void markFeedbackSubmitted(String attendanceId) {
    showReminder.value = false;
    alertAttendanceModel.value = null;
    print("✅ Feedback submitted for attendance ID: $attendanceId");
  }

  /// Show reminder banner
  void _showBanner(String message) {
    reminderMessage.value = message;
    showReminder.value = true;
    _startBlinking();
  }

  /// Blink effect for red reminder
  void _startBlinking() {
    blinkTimer?.cancel();
    blinkTimer = Timer.periodic(const Duration(milliseconds: 600), (_) {
      blink.value = !blink.value;
    });
  }
}*/
import 'dart:async';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../data/repository/batch_repository.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../../../utils/http/api_constants.dart';
import '../../../../utils/http/http_client.dart';
import '../../models/attendance_model.dart';
import '../../models/batch_model.dart';

class BatchController extends GetxController {
  final BatchRepository repository = Get.put(BatchRepository());
  final storage = GetStorage();
  var isalertLoading = false.obs;
  var batchDetails = Rxn<BatchDetailsModel>();
  var isLoading = false.obs;
  var isAlertLoading = false.obs;

  var showReminder = false.obs;
  var reminderMessage = "".obs;
  var blink = true.obs;

  Timer? blinkTimer;
  Rxn<AttendanceModel> alertAttendanceModel = Rxn<AttendanceModel>();

  @override
  void onInit() {
    super.onInit();
    fetchFeedbackAlerts();
  }

  @override
  void onClose() {
    blinkTimer?.cancel();
    super.onClose();
  }

  /// ✅ Fetch batch details
  Future<void> fetchBatchDetailsController({required String courseId}) async {
    try {
      isLoading.value = true;
      final data = await repository.fetchBatchDetailsRep(courseId: courseId);
      batchDetails.value = data;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchFeedbackAlerts() async {
    try {
      isalertLoading.value = true;

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };

      final response =
          await THttpHelper.post(APIConstants.feedbackalertendpoint, body);

      if (response != null && response['status'] == 200) {
        final alerts = response['alerts'] as List<dynamic>;

        // Pick first alert with alert == 1 AND sno != null
        final alertItem = alerts.firstWhereOrNull(
          (a) => a['alert'] == 1 && a['sno'] != null,
        );

        if (alertItem != null) {
          alertAttendanceModel.value = AttendanceModel.fromJson(alertItem);
          _showBanner(
            "Feedback pending for ${alertItem['batch_name']} (${alertItem['status']})",
          );
        } else {
          showReminder.value = false;
        }
      }
    } catch (e) {
      print("Error fetching feedback alerts: $e");
    } finally {
      isalertLoading.value = false;
    }
  }

  /// ✅ Mark feedback submitted
  void markFeedbackSubmitted(String attendanceId) {
    showReminder.value = false;
    alertAttendanceModel.value = null;
    blinkTimer?.cancel();
    print("✅ Feedback submitted for attendance ID: $attendanceId");
  }

  /// ✅ Show reminder banner
  void _showBanner(String message) {
    reminderMessage.value = message;
    showReminder.value = true;
    _startBlinking();
  }

  /// ✅ Blink effect
  void _startBlinking() {
    blinkTimer?.cancel();
    blinkTimer = Timer.periodic(const Duration(milliseconds: 600), (_) {
      blink.value = !blink.value;
    });
  }
}
