// import 'package:contacts_service/contacts_service.dart';
// import 'package:eapl_student_app/utils/constants/text_strings.dart';
// import 'package:eapl_student_app/utils/http/api_constants.dart';
// import 'package:eapl_student_app/utils/http/http_client.dart';
// import 'package:eapl_student_app/utils/loaders/loaders.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:permission_handler/permission_handler.dart';
//
// class ReferralController extends GetxController {
//   final TextEditingController nameController = TextEditingController();
//   final TextEditingController mobileController = TextEditingController();
//
//   GlobalKey<FormState> referralFormKey = GlobalKey<FormState>();
//
//   final isLoading = false.obs;
//
//   void addReferral() async {
//     String name = nameController.text.trim();
//     String mobile = mobileController.text.trim();
//
//     if (!referralFormKey.currentState!.validate()) return;
//     isLoading.value = true;
//     await addReferContactToDatabase(name: name, mobileNo: mobile);
//     isLoading.value = false;
//
//     // Add to database (replace with actual DB logic)
//     print("Referral Added: Name - $name, Mobile - $mobile");
//
//     // Clear fields after submission
//     nameController.clear();
//     mobileController.clear();
//   }
//
//   var contacts = <Contact>[].obs; // Observable list
//
//   Future<void> fetchContacts() async {
//     PermissionStatus permission = await Permission.contacts.request();
//     if (permission.isGranted) {
//       Iterable<Contact> fetchedContacts = await ContactsService.getContacts();
//       contacts.assignAll(fetchedContacts);
//
//       isLoading.value = true;
//       for (var contact in contacts) {
//         print(
//             "Name: ${contact.displayName}, Number: ${contact.phones?.isNotEmpty == true ? contact.phones!.first.value : 'No Number'}");
//         await addReferContactToDatabase(
//             name: contact.displayName.toString(),
//             mobileNo:
//                 " ${contact.phones?.isNotEmpty == true ? contact.phones!.first.value : 'No Number'}");
//       }
//       TSnackbar.successSnackbar(
//           title: "Sync Contact Successfully", message: "Thank you for support");
//
//       isLoading.value = false;
//     } else {
//       print("Permission Denied!");
//     }
//   }
//
//   Future<void> addReferContactToDatabase(
//       {required String name, required String mobileNo}) async {
//     try {
//       final req = {
//         "name": name,
//         "mobile_no": mobileNo,
//         "referral_by": GetStorage().read(TTexts.userID)
//       };
//       print("Referral request ${req}");
//       final response =
//           await THttpHelper.post(APIConstants.addReferralEndPoint, req);
//
//       print("Refferal Response ${response}");
//       TSnackbar.successSnackbar(
//           title: "Referred Successfully", message: "Thank you for reference");
//     } catch (e) {
//       isLoading.value = false;
//       print("addReferContactToDatabase ${e}");
//       TSnackbar.errorSnackbar(title: 'Error', message: e);
//     }
//   }
// }

import 'dart:convert';

// import 'package:audioplayers/audioplayers.dart';
import 'package:eapl_student_app/common/widget/app_bar/appbar_controller.dart';
import 'package:eapl_student_app/features/apptour/side/referrel/referreltour.dart';
import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/http/api_constants.dart';

class ReferralController extends GetxController {
  // Form Controllers
  final TextEditingController nameController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();

  final GlobalKey<FormState> referralFormKey = GlobalKey<FormState>();

  // Observable States
  final isLoading = false.obs;
  final selectAll = false.obs;
  final contacts = <Map<String, String>>[].obs;
  final selectedIndexes = <int>{}.obs;
  final searchQuery = ''.obs;

  @override
  void onClose() {
    nameController.dispose();
    mobileController.dispose();
    super.onClose();
  }

  void resetSearch() {
    searchQuery.value = '';
  }

  /// Fetch & Sync Contacts
  Future<void> fetchContacts() async {
    final permission = await Permission.contacts.request();
    if (!permission.isGranted) {
      TSnackbar.errorSnackbar(
        title: "Permission Denied",
        message: "Please allow contact permission",
      );
      return;
    }

    isLoading.value = true;
    try {
      final fetchedContacts =
          await FlutterContacts.getContacts(withProperties: true);
      final formattedContacts = <Map<String, String>>[];

      for (final contact in fetchedContacts) {
        final displayName = contact.displayName;
        final phoneNumber = contact.phones.isNotEmpty
            ? _cleanPhoneNumber(contact.phones.first.number)
            : 'No Number';

        if (phoneNumber != 'No Number') {
          formattedContacts.add({
            'name': displayName.trim(),
            'number': phoneNumber,
          });
        }
      }

      contacts.assignAll(formattedContacts);

      TSnackbar.successSnackbar(
        title: "Sync Successful",
        message: "Contacts synced successfully",
      );
    } catch (e) {
      TSnackbar.errorSnackbar(
        title: "Error",
        message: "Failed to sync contacts: $e",
      );
    } finally {
      isLoading.value = false;
    }
  }

  /// Helper to clean and normalize phone numbers
  String _cleanPhoneNumber(String number) {
    return number.replaceAll(RegExp(r'[^\d+]'), '');
  }

  /// Toggle individual contact selection
  void toggleContactSelection(int index) {
    if (selectedIndexes.contains(index)) {
      selectedIndexes.remove(index);
    } else {
      selectedIndexes.add(index);
    }
    selectAll.value = selectedIndexes.length == contacts.length;
  }

  /// Toggle select/unselect all
  void toggleSelectAll() {
    if (selectAll.value) {
      selectedIndexes.clear();
    } else {
      selectedIndexes.value =
          List.generate(contacts.length, (index) => index).toSet();
    }
    selectAll.value = !selectAll.value;
  }

  /// Submit selected contacts as bulk to backend
  Future<void> submitSelectedContactsBulk() async {
    final selected = selectedIndexes.toList();

    if (selected.isEmpty) {
      TSnackbar.errorSnackbar(
        title: "No Selection",
        message: "Please select at least one contact.",
      );
      return;
    }

    isLoading.value = true;

    try {
      final contactList = selected.map((index) {
        final contact = contacts[index];
        return {
          "name": contact['name'] ?? '',
          "mobile_no": contact['number'] ?? '',
        };
      }).toList();

      final requestBody = {
        "customer_id": GetStorage().read(TTexts.userID),
        "contacts": contactList,
      };

      // Debug logs
      print("🔄 Submitting selected contacts...");
      print("📤 Request URL: ${APIConstants.referrel}");
      print("📦 Request Body: ${jsonEncode(requestBody)}");

      final response =
          await THttpHelper.post(APIConstants.referrel, requestBody);

      print("✅ API call completed");
      print("🔁 Response from server: $response");

      await Get.find<AppbarController>().fetchPointsDetails();

      TSnackbar.successSnackbar(
        title: "Success",
        message:
            "${response['message']} (Points awarded: ${response['points_awarded']})",
      );

      selectedIndexes.clear();
      selectAll.value = false;

      // ✅ Show reward dialog
      Get.dialog(
        const ReferrelDialog(),
        barrierDismissible: false, // prevent closing manually
      );

      // ✅ Auto-close after 3 seconds
      Future.delayed(const Duration(seconds: 3), () {
        if (Get.isDialogOpen ?? false) {
          Get.back(); // close dialog safely
        }
      });
    } catch (e) {
      print("❌ Submission error: $e");
      TSnackbar.errorSnackbar(
        title: "Error",
        message: "Submission failed: $e",
      );
    } finally {
      isLoading.value = false;
    }
  }

  /// Filter contacts by search
  List<Map<String, String>> get filteredContacts {
    if (searchQuery.value.isEmpty) return contacts;
    return contacts
        .where((contact) =>
            (contact['name'] ?? '')
                .toLowerCase()
                .contains(searchQuery.value.toLowerCase()) ||
            (contact['number'] ?? '')
                .toLowerCase()
                .contains(searchQuery.value.toLowerCase()))
        .toList();
  }

  void onSearchChanged(String value) {
    searchQuery.value = value;
  }

  //referreltour
  final referrelsearchKey = GlobalKey();
  final selectallKey = GlobalKey();
  final selectKey = GlobalKey();

  var isReferrelTouron = false.obs;
  Future<void> ReferrelTour(BuildContext context) async {
    final targets = ReferrelTourList.getTargets(
      referrelsearchKey: referrelsearchKey,
      selectallKey: selectallKey,
      selectKey: selectKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.referreltour, true);
        isReferrelTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.referreltour, true);
        isReferrelTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}

/*class ReferrelDialog extends StatefulWidget {
  const ReferrelDialog({super.key});

  @override
  State<ReferrelDialog> createState() => _ReferrelDialogState();
}

class _ReferrelDialogState extends State<ReferrelDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _flipAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat();

    _flipAnimation = Tween<double>(begin: 0, end: 2 * 3.1416).animate(
      CurvedAnimation(parent: _controller, curve: Curves.linear),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 10,
      shadowColor: Colors.grey.shade400,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _flipAnimation,
              builder: (context, child) {
                return Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.001)
                    ..rotateY(_flipAnimation.value),
                  child: Image.asset(
                    'assets/image/earning_points/Coin.png',
                    width: 60,
                    height: 60,
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            Text(
              "Reward Earned!",
              style: GoogleFonts.prompt(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "You got 2 coins for your referrels !",
              style: GoogleFonts.prompt(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: TColors.primary,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                "Awesome",
                style: GoogleFonts.prompt(
                    fontWeight: FontWeight.bold, fontSize: 16),
              ),
            )
          ],
        ),
      ),
    );
  }
}*/

class ReferrelDialog extends StatefulWidget {
  const ReferrelDialog({super.key});

  @override
  State<ReferrelDialog> createState() => _ReferrelDialogState();
}

class _ReferrelDialogState extends State<ReferrelDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _flipAnimation;
  // final _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat();

    _flipAnimation = Tween<double>(begin: 0, end: 2 * 3.1416).animate(
      CurvedAnimation(parent: _controller, curve: Curves.linear),
    );

    // _playCoinSound();
    // _autoCloseDialog();
  }

  // Future<void> _playCoinSound() async {
  //   try {
  //     await _audioPlayer.play(AssetSource('sounds/gold-coin-prize.mp3'));
  //   } catch (e) {
  //     debugPrint("⚠️ Error playing sound: $e");
  //   }
  // }

  // void _autoCloseDialog() {
  //   Future.delayed(const Duration(seconds: 3), () {
  //     if (mounted) Get.back();
  //   });
  // }

  @override
  void dispose() {
    _controller.dispose();
    // _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 10,
      shadowColor: Colors.grey.shade400,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _flipAnimation,
              builder: (context, child) {
                return Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.001)
                    ..rotateY(_flipAnimation.value),
                  child: Image.asset(
                    'assets/image/earning_points/Coin.png',
                    width: 60,
                    height: 60,
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            Text(
              "Reward Earned!",
              style: GoogleFonts.prompt(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "You got 2 coins for your referrals!",
              style: GoogleFonts.prompt(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: TColors.primary,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                "Awesome",
                style: GoogleFonts.prompt(
                    fontWeight: FontWeight.bold, fontSize: 16),
              ),
            )
          ],
        ),
      ),
    );
  }
}
