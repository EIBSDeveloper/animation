/*
import 'package:eapl_student_app/features/personalization/models/placement_model.dart';
import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../utils/constants/text_strings.dart';
import '../../../../utils/helpers/localstorage.dart';
import '../../../../utils/http/api_constants.dart';
import '../../../../utils/http/http_client.dart';

class PlacementController extends GetxController {
  static PlacementController get instance => Get.find();
  RxBool isSavedJobsPage = false.obs;

  // final placementRepository = Get.put(PlacementRepository());
  final isLoading = false.obs;
  final isSavedJobs = false.obs;
  final placementList = <PlacementModel>[].obs;
  final savedJobs = <PlacementModel>[].obs;

  @override
  void onInit() {
    super.onInit();

    fetchPlacementDetails();
  }

  Future<void> fetchPlacementDetails() async {
    try {
      final req = {"customer_id": GetStorage().read(TTexts.userID)};
      */
/* final req = {"customer_id": 13}; // 👈 force test*/ /*

      final response =
          await THttpHelper.post(APIConstants.placementEndPoint, req);

      placementList.value = (response["data"] as List)
          .map((e) => PlacementModel.fromJson(e))
          .toList();
      print(req);
      print(placementList);
    } catch (e) {
      print(e);
    }
  }

  // Load saved jobs from local storage
  Future<void> loadSavedJobs() async {
    final jobs = await LocalStorage.getSavedJobs();
    savedJobs.assignAll(jobs);
  }

  // Toggle bookmark for a job
  Future<void> toggleBookmark(PlacementModel job) async {
    final isSaved = savedJobs.any((j) => j.jobId == job.jobId);
    if (isSaved) {
      await LocalStorage.removeJob(job.jobId);
      savedJobs.removeWhere((j) => j.jobId == job.jobId);
      Get.snackbar('Removed', 'Job removed from saved jobs',
          snackPosition: SnackPosition.BOTTOM,
          colorText: TColors.white,
          backgroundColor: TColors.primary);
    } else {
      await LocalStorage.saveJob(job);
      savedJobs.add(job);
      Get.snackbar('Saved', 'Job saved successfully',
          snackPosition: SnackPosition.BOTTOM,
          colorText: TColors.white,
          backgroundColor: TColors.primary);
    }
  }

  // Check if a job is saved
  bool isJobSaved(String jobId) {
    return savedJobs.any((job) => job.jobId == jobId);
  }

  var isApplyLoading = false.obs;

  /// Call apply job API
  Future<bool> applyJob(int sno) async {
    try {
      isApplyLoading.value = true;
      final req = {
        "customer_id":
            GetStorage().read(TTexts.userID), // replace with your key
        "job_id": sno.toString(), // pass int
      };
      print("🔹 Apply Job Request Payload => $req"); // 👈 log the payload
      final response =
          await THttpHelper.post(APIConstants.jobapplyendpoint, req);

      print("Apply Job Response: $response");

      if (response['status'] == 200) {
        fetchPlacementDetails();
        return true;
      } else {
        print("Apply Job Failed: ${response['message']}");
        return false;
      }
    } catch (e) {
      print("Exception in applyJob: $e");
      return false;
    } finally {
      isApplyLoading.value = false;
    }
  }

  var issaveLoading = false.obs;
  var isremoveLoading = false.obs;

  /// store current saved jobs from API
  var savedJobIds = <int>[].obs;

  /// ✅ Save jobs (can pass one or multiple job IDs)
  Future<void> saveJobs(List<int> jobIds) async {
    try {
      issaveLoading.value = true;

      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
        "job_id": jobIds, // 👈 array of integers
      };

      print("🔹 Save Job Request Payload => $req");

      final response =
          await THttpHelper.post(APIConstants.savejobendpoint, req);

      print("✅ Save Job Response => $response");

      if (response != null && response['status'] == "1") {
        print("🎉 Jobs Saved => ${response['data']['job_ids']}");
      } else {
        print("⚠️ Save Job Failed => ${response?['message']}");
      }
    } catch (e) {
      print("❌ Exception in saveJobs: $e");
    } finally {
      issaveLoading.value = false;
    }
  }

  /// ✅ Remove jobs (can pass one or multiple job IDs)
  Future<void> removeJobs(List<int> jobIds) async {
    try {
      isremoveLoading.value = true;

      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
        "job_id": jobIds, // 👈 array of integers
      };

      print("🔹 Remove Job Request Payload => $req");

      final response =
          await THttpHelper.post(APIConstants.removejobendpoint, req);

      print("✅ Remove Job Response => $response");

      if (response != null && response['status'] == "1") {
        print("🗑 Jobs Remaining => ${response['data']['job_ids']}");
      } else {
        print("⚠️ Remove Job Failed => ${response?['message']}");
      }
    } catch (e) {
      print("❌ Exception in removeJobs: $e");
    } finally {
      isremoveLoading.value = false;
    }
  }

  /// ✅ Toggle bookmark
  Future<void> togglemark(int jobId) async {
    if (savedJobIds.contains(jobId)) {
      // already saved → remove
      await removeJobs([jobId]);
    } else {
      // not saved → save
      await saveJobs([jobId]);
    }
  }
}
*/

import 'package:eapl_student_app/features/apptour/side/placement/placementtour.dart';
import 'package:eapl_student_app/features/personalization/models/placement_model.dart';
import 'package:eapl_student_app/features/personalization/models/placementmodel/placementinterviewmodel.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../../../utils/http/api_constants.dart';
import '../../../../utils/http/http_client.dart';
import '../../models/placementmodel/placedstudentmodel.dart';
import '../../screens/side_drawer_menu/notifications/notification_controller.dart';

class PlacementController extends GetxController {
  static PlacementController get instance => Get.find();

  final isLoading = false.obs;
  final isSavedJobs = false.obs;

  /// All jobs
  final placementList = <PlacementModel>[].obs;
  var placementinterviewList = <PlacementInterviewModel>[].obs;

  /// Split into 2 tabs
  final jobsForYou = <PlacementModel>[].obs;
  final savedJobs = <PlacementModel>[].obs;

  /// Store saved job IDs from API
  var savedJobIds = <int>[].obs;

  var isApplyLoading = false.obs;
  var issaveLoading = false.obs;
  var isremoveLoading = false.obs;
  var isinterviewLoading = false.obs;

  var isplacedstudentLoading = false.obs;
  final placedstudentlist = <PlacedStudentModel>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchPlacementDetails();
    fetchPlacedstudents();
  }

  /// ✅ Fetch all jobs
  Future<void> fetchPlacedstudents() async {
    try {
      isplacedstudentLoading.value = true;

      final req = {"customer_id": GetStorage().read(TTexts.userID)};
      final response =
          await THttpHelper.post(APIConstants.placedstudentendpoint, req);

      // ✅ Clear and assign once
      placedstudentlist.clear();

      if (response["data"] != null && response["data"] is List) {
        placedstudentlist.value = (response["data"] as List)
            .map((e) => PlacedStudentModel.fromJson(e))
            .toList();
      }
    } catch (e) {
      print("❌ fetchPlacedstudents error: $e");
    } finally {
      isplacedstudentLoading.value = false;
    }
  }

  /// ✅ Fetch all jobs
  Future<void> fetchPlacementDetails() async {
    try {
      isLoading.value = true;
      final req = {"customer_id": GetStorage().read(TTexts.userID)};
      final response =
          await THttpHelper.post(APIConstants.placementEndPoint, req);

      placementList.value = (response["data"] as List)
          .map((e) => PlacementModel.fromJson(e))
          .toList();

      _refreshJobs();
    } catch (e) {
      print("❌ fetchPlacementDetails error: $e");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchPlacementinterview() async {
    try {
      isinterviewLoading.value = true;
      final req = {"customer_id": GetStorage().read(TTexts.userID)};
      final response =
          await THttpHelper.post(APIConstants.placementinterviewendpoint, req);

      placementinterviewList.value = (response["data"] as List)
          .map((e) => PlacementInterviewModel.fromJson(e))
          .toList();

      _refreshJobs();
    } catch (e) {
      print("❌ fetchPlacementinterviewDetails error: $e");
    } finally {
      isinterviewLoading.value = false;
    }
  }

  var ishistoryLoading = false.obs;
  var isHistory = false.obs;
  final placementhistoryList = <PlacementModel>[].obs;
  Future<void> fetchPlacementhistory() async {
    try {
      ishistoryLoading.value = true;
      final req = {"customer_id": GetStorage().read(TTexts.userID)};
      final response =
          await THttpHelper.post(APIConstants.placementhistoryendpoint, req);

      placementhistoryList.value = (response["data"] as List)
          .map((e) => PlacementModel.fromJson(e))
          .toList();
    } catch (e) {
      print("❌ fetchPlacementhistory error: $e");
    } finally {
      ishistoryLoading.value = false;
    }
  }

  /// ✅ Apply Job
  Future<bool> applyJob(int sno) async {
    try {
      isApplyLoading.value = true;
      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
        "job_id": sno.toString(),
      };
      print("🔹 Apply Job Request => $req");

      final response =
          await THttpHelper.post(APIConstants.jobapplyendpoint, req);

      print("Apply Job Response: $response");

      if (response['status'] == 200) {
        fetchPlacementDetails();

        final notificationController = Get.find<NotificationController>();
        await notificationController.fetchNotificationList();
        // 🔥 instantly increment AppBar badge
        final appbarController = Get.find<AppbarController>();
        appbarController.incrementNotify();
        return true;
      } else {
        print("⚠️ Apply Job Failed => ${response['message']}");
        return false;
      }
    } catch (e) {
      print("❌ Exception in applyJob: $e");
      return false;
    } finally {
      isApplyLoading.value = false;
    }
  }

  /// ✅ Save jobs (API only)
  Future<void> saveJob(int sno) async {
    try {
      issaveLoading.value = true;

      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
        "job_id": [sno],
      };

      print("🔹 Save Job Request => $req");

      final response =
          await THttpHelper.post(APIConstants.savejobendpoint, req);

      print("✅ Save Job Response => $response");

      if (response != null && response['status'].toString() == "1") {
        // update model directly
        final job = placementList.firstWhereOrNull((j) => j.sno == sno);
        if (job != null) job.jobSaved.value = 1;

        _refreshJobs();
      } else {
        print("⚠️ Save Job Failed => ${response?['message']}");
      }
    } catch (e) {
      print("❌ saveJob error: $e");
    } finally {
      issaveLoading.value = false;
    }
  }

  /// ✅ Remove jobs (API only)
  Future<void> removeJob(int sno) async {
    try {
      isremoveLoading.value = true;

      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
        "job_id": [sno],
      };

      print("🔹 Remove Job Request => $req");

      final response =
          await THttpHelper.post(APIConstants.removejobendpoint, req);

      print("✅ Remove Job Response => $response");

      if (response != null && response['status'].toString() == "1") {
        // update model directly
        final job = placementList.firstWhereOrNull((j) => j.sno == sno);
        if (job != null) job.jobSaved.value = 0;

        _refreshJobs();
      } else {
        print("⚠️ Remove Job Failed => ${response?['message']}");
      }
    } catch (e) {
      print("❌ removeJob error: $e");
    } finally {
      isremoveLoading.value = false;
    }
  }

/*  /// ✅ Toggle bookmark with API
  Future<void> togglemark(int sno) async {
    final job = placementList.firstWhereOrNull((j) => j.sno == sno);
    if (job != null) {
      if (job.jobSaved.value == 1) {
        await removeJob(sno);
        job.jobSaved.value = 0; // update locally
        Get.snackbar(
          'Removed',
          'Job removed successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.primary,
          colorText: TColors.white,
        );
      } else {
        await saveJob(sno);
        job.jobSaved.value = 1; // update locally
        Get.snackbar(
          'Saved',
          'Job saved successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.primary,
          colorText: TColors.white,
        );
      }
      _refreshJobs(); // refresh jobsForYou & savedJobs
    }
  }

  /// ✅ Re-split jobs based on job_saved
  void _refreshJobs() {
    jobsForYou.assignAll(
      placementList.where((job) => job.jobSaved == 0).toList(),
    );
    savedJobs.assignAll(
      placementList.where((job) => job.jobSaved == 1).toList(),
    );
  }*/
  /// Toggle bookmark with API
  Future<void> togglemark(int sno) async {
    final job = placementList.firstWhereOrNull((j) => j.sno == sno);
    if (job != null) {
      if (job.jobSaved.value == 1) {
        // Un-save job
        job.jobSaved.value = 0; // update locally first for instant UI feedback
        await removeJob(sno); // API call
        Get.snackbar(
          'Removed',
          'Job removed successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.primary,
          colorText: Colors.white,
        );
      } else {
        // Save job
        job.jobSaved.value = 1; // update locally first
        await saveJob(sno); // API call
        Get.snackbar(
          'Saved',
          'Job saved successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.primary,
          colorText: Colors.white,
        );
      }

      // Refresh reactive lists
      _refreshJobs();
    }
  }

  /// Re-split jobs based on jobSaved
  void _refreshJobs() {
    // Jobs for you = all jobs
    jobsForYou.assignAll(placementList);

    // Saved jobs = filter by jobSaved
    savedJobs.assignAll(
        placementList.where((job) => job.jobSaved.value == 1).toList());
  }

  //placementtour
  final placementtabKey = GlobalKey();
  final jobKey = GlobalKey();
  final saveKey = GlobalKey();

  var isPlacementTouron = false.obs;
  Future<void> PlacementTour(BuildContext context) async {
    final targets = PlacementTourList.getTargets(
        placementtabKey: placementtabKey, jobkey: jobKey, saveKey: saveKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.placementtour, true);
        isPlacementTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.placementtour, true);
        isPlacementTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //placementdetailstour
  final applyKey = GlobalKey();
  var isPlacementdetailTouron = false.obs;
  Future<void> PlacementdetailTour(BuildContext context) async {
    final targets = PlacementdetailTourList.getTargets(applyKey: applyKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.placementdetailtour, true);
        isPlacementdetailTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.placementdetailtour, true);
        isPlacementdetailTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
