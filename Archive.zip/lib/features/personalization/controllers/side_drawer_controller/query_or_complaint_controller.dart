import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:eapl_student_app/data/repository/query_or_complaints_repository.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../../apptour/side/helpdesk/helpdesktour.dart';
import '../../models/query/conversationmodel.dart';

class QueryOrComplaintController extends GetxController {
  static QueryOrComplaintController get instance => Get.find();
  var selectedQueryTab = 0.obs;

  final queryRepository = Get.put(QueryOrComplaintRepository());
  final ImagePicker _picker = ImagePicker();
  Rx<File?> attachment = Rx<File?>(null);
  final isLoading = false.obs;
  final issueController = TextEditingController();
  var wordCount = 0.obs;
  List<String> queryCategory = [
    'Course Fees',
    'Course Selection',
    'Course Availability'
  ];
  String? selectedCategory;
  final List<String> queryPriority = ['High', 'Medium', 'Low'];
  String? selectedPriority;

  final GlobalKey<FormState> addFormQuery = GlobalKey<FormState>();
  Timer? refreshTimer;
  @override
  void onInit() {
    super.onInit();
    conversationquery(refresh: true);
    startAutoRefresh();
  }

  void startAutoRefresh() {
    refreshTimer?.cancel();
    refreshTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      conversationquery(refresh: true);
    });
  }

  var attachmentBase64 = "".obs;
  void pickAttachment(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(source: source);
      if (pickedFile != null) {
        File file = File(pickedFile.path);
        attachment.value = file;

        // 🔥 Convert to Base64
        List<int> imageBytes = await file.readAsBytes();
        attachmentBase64.value = base64Encode(imageBytes);

        print("✅ Attachment File Path: ${file.path}");
        print(
            "✅ Attachment Base64 (first 50 chars): ${attachmentBase64.value.substring(0, 50)}...");
      } else {
        print('⚠️ No image selected.');
      }
    } catch (e) {
      print('❌ Error picking attachment: $e');
    }
  }

  void resetForm() {
    selectedCategory = null;
    selectedPriority = null;
    issueController.clear();
    attachment.value = null;
  }

  Uint8List? getAttachmentBytes(String? attachment) {
    if (attachment == null || attachment.isEmpty) return null;

    // If it's Base64 (starts with /9j/ or data:image)
    if (attachment.startsWith('/9j/') || attachment.startsWith('data:image')) {
      try {
        return base64Decode(attachment);
      } catch (e) {
        print('❌ Base64 decode error: $e');
        return null;
      }
    }

    // If it looks like a local file path
    if (attachment.startsWith('File:')) {
      final path = attachment.replaceFirst('File: ', '').replaceAll("'", "");
      return File(path).readAsBytesSync();
    }

    // Otherwise, cannot decode
    return null;
  }

  // ADD QUERY NEW PAGE
  var selectedCategorys = RxnString();
  var selectedPrioritys = RxnString();

  void clearform() {
    issueController.clear();
    selectedCategorys.value = null;
    selectedPrioritys.value = null;
    wordCount.value = 0;
    attachment.value = null;
    attachmentBase64.value = "";
  }

  var isConversationLoading = false.obs;
  var conversationList = <Issue>[].obs;

  Future<void> conversationquery({bool refresh = false}) async {
    try {
      final customerId = GetStorage().read(TTexts.userID);
      isConversationLoading.value = true;

      final body = {"customer_id": customerId};
      final response = await THttpHelper.post(
        APIConstants.queryconversationendpoint,
        body,
      );

      if (response != null && response['status'] == 200) {
        final parsedResponse = ConversationResponse.fromJson(response);
        conversationList.value = parsedResponse.data;
      }
    } catch (e) {
      print("Error fetching conversations: $e");
    } finally {
      isConversationLoading.value = false;
    }
  }

  final TextEditingController messageController = TextEditingController();
  Future<void> sendMessage() async {
    final issue = messageController.text.trim();
    if (issue.isEmpty) {
      Fluttertoast.showToast(
        msg: "Please enter your query",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: TColors.red,
        textColor: TColors.white,
        fontSize: 14.0,
      );
      return;
    }

    try {
      final customerId = GetStorage().read(TTexts.userID);

      // ✅ Optimistically add the message to the conversation list
      final now = DateTime.now();
      final timestamp =
          "${now.day.toString().padLeft(2, '0')} ${_monthName(now.month)} ${now.year}, "
          "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')} ${now.hour >= 12 ? 'PM' : 'AM'}";

      // Check if there is already an Issue object
      Issue issueObj;
      if (conversationList.isEmpty) {
        issueObj = Issue(issueId: 0, conversationList: []);
        conversationList.add(issueObj);
      } else {
        issueObj = conversationList[0];
      }

      final newMessage = Conversation(
        sender: "Student",
        name: GetStorage().read(TTexts.userName) ?? "You",
        message: issue,
        attachment: null,
        timestamp: timestamp,
        seen: false, closed: 2, // ✅ student sees their own message
      );

      issueObj.conversationList.add(newMessage);
      conversationList.refresh();

      // Clear the input
      messageController.clear();

      // ✅ Send to backend
      final body = {
        "customer_id": customerId,
        "issue": issue,
        "closed": 0,
      };

      final response =
          await THttpHelper.post(APIConstants.queryAddEndPoint, body);

      if (response != null && response['status'] == 200) {
        // Optionally update the conversation from API
        await conversationquery(refresh: true);
      }
    } catch (e) {
      print("❌ Error sending message: $e");
    }
  }

  String _monthName(int month) {
    const months = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month];
  }

  var ismarkLoading = false.obs;

  Future<void> markseen() async {
    try {
      final customerId = GetStorage().read(TTexts.userID);
      ismarkLoading.value = true;

      final body = {"customer_id": customerId};
      final response = await THttpHelper.post(
        APIConstants.markseenendpoint,
        body,
      );

      // ✅ Only check status, no parsing needed
      if (response != null && response['status'] == 200) {
        print("✅ Messages marked as seen: ${response['message']}");
        /*Get.snackbar("Success", response['message'] ?? "Marked as seen",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: TColors.primary,
            colorText: TColors.white);*/
      } else {
        Get.snackbar(
            "Error", response?['message'] ?? "Failed to mark messages as seen",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: TColors.red.withOpacity(0.8),
            colorText: TColors.white);
      }
    } catch (e) {
      print("❌ Error marking messages as seen: $e");
      Get.snackbar(
        "Error",
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: TColors.red.withOpacity(0.8),
        colorText: TColors.white,
      );
    } finally {
      ismarkLoading.value = false;
    }
  }

  var iscloseLoading = false.obs;
  Future<void> closeconversation() async {
    try {
      final customerId = GetStorage().read(TTexts.userID);
      iscloseLoading.value = true;

      final body = {
        "customer_id": customerId,
        "closed": 1, // ✅ Required in your API
      };

      final response = await THttpHelper.post(APIConstants.closeendpoint, body);

      // ✅ Check API response
      if (response != null &&
          response['status'] == 200 &&
          response['message'] == "Issue closed successfully") {
        final data = response['data'];
        // ✅ Update local conversation objects to reflect closed status
        if (conversationList.isNotEmpty) {
          final issue = conversationList[0]; // assuming single issue
          issue.conversationList.forEach((c) {
            c.closed = 1; // or "1" depending on your model
          });
          conversationList.refresh();
        }

        Get.snackbar(
          "Success",
          "Issue closed successfully",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.primary,
          colorText: TColors.white,
        );

        print("✅ Issue Closed: ${data['issue_id']}");
        print("📅 Closed Date: ${data['closed_date']}");

        // ✅ Refresh conversation list (if available)
        await conversationquery(refresh: true);
      } else {
        Get.snackbar(
          "Error",
          response?['message'] ?? "Failed to close the issue",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.red,
          colorText: TColors.white,
        );
      }
    } catch (e) {
      print("❌ Error while closing conversation: $e");
      Get.snackbar(
        "Error",
        "Something went wrong. Please try again.",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: TColors.red,
        colorText: TColors.white,
      );
    } finally {
      iscloseLoading.value = false;
    }
  }

  //querytour
  final querycardKey = GlobalKey();
  final statusKey = GlobalKey();
  final addKey = GlobalKey();

  var isQueryTouron = false.obs;
  Future<void> QueryTour(BuildContext context) async {
    final targets = QueryTourList.getTargets(
        querycardKey: querycardKey, statusKey: statusKey, addKey: addKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: TColors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.querytour, true);
        isQueryTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.querytour, true);
        isQueryTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //querydetailstour
  final categoryKey = GlobalKey();
  final priorityKey = GlobalKey();
  final issueKey = GlobalKey();
  final submitKey = GlobalKey();

  var isQuerydetailsTouron = false.obs;
  Future<void> QuerydetailsTour(BuildContext context) async {
    final targets = QueryTourdetailsList.getTargets(
        categorykey: categoryKey,
        priorityKey: priorityKey,
        issueKey: issueKey,
        submitKey: submitKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: TColors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.querydetailstour, true);
        isQuerydetailsTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.querydetailstour, true);
        isQuerydetailsTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //queryviewtour
  final responseKey = GlobalKey();

  var isQueryviewTouron = false.obs;
  Future<void> QueryviewTour(BuildContext context) async {
    final targets = QueryviewTourList.getTargets(responseKey: responseKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: TColors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.queryviewtour, true);
        isQueryviewTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.queryviewtour, true);
        isQueryviewTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
