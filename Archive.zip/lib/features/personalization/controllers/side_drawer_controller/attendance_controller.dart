import 'package:eapl_student_app/data/repository/attendance_repository.dart';
import 'package:eapl_student_app/features/apptour/side/attendence/attendencetour.dart';
import 'package:eapl_student_app/features/personalization/models/attendance_model.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../../../utils/http/http_client.dart';
import '../../../../utils/loaders/loaders.dart';
import '../../models/daily_streak_model.dart';
import 'course_controller.dart';

class AttendanceController extends GetxController {
  static AttendanceController get instance => Get.find();
  var wordCount = 0.obs;
  RxBool isList = false.obs;
  void updateWordCount(String text) {
    final words = text.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty);
    wordCount.value = words.length;
  }

  void resetFeedbackForm() {
    feedbackText.clear();
    ratings.value = 3.0;
    wordCount.value = 0;
  }

  final courseController = Get.find<CourseController>();

  void initData() async {
    await courseController.fetchCourses();
    if (courseController.coursesList.isNotEmpty) {
      await fetchDailyStreakController(
        courseId: courseController
            .coursesList[courseController.courseAttendanceIndex.value].courseSno
            .toString(),
      );
    }
  }

  var isDailyStreakLoading = false.obs;
  final attendanceRepository = Get.put(AttendanceRepository());
  final attendanceModel = <AttendanceModel>[].obs;
  final isLoading = false.obs;
  final isDialogLoading = false.obs;
  final presentAttendance = <DateTime>[].obs;
  RxDouble ratings = 3.0.obs;
  TextEditingController feedbackText = TextEditingController();
  final feedbackTopicList = <List<String?>>[].obs;

  Rx<CalendarFormat> calendarFormat = CalendarFormat.month.obs;
  Rx<DateTime> focusedDay = DateTime.now().obs;
  Rx<DateTime>? selectedDay = DateTime.now().obs;

  RxList<AttendanceModel> classCompleted = <AttendanceModel>[].obs;
  RxList<DateTime> upcomingClasses = <DateTime>[].obs;
  RxList<DateTime> absentClass = <DateTime>[].obs;
  RxList<AttendanceModel> absentAttendance = <AttendanceModel>[].obs;

  RxList<AttendanceModel> fillFeedback = <AttendanceModel>[].obs;
  RxList<AttendanceModel> completedFeedbackList = <AttendanceModel>[].obs;
  var dailyStreakModel = <DailyStreakModel>[].obs;
  var dailyAttendanceList = <DailyAttendanceTopicsModel>[].obs;
  RxList<DateTime> holidaylist = <DateTime>[].obs;

  List getEventsForDay(DateTime day) {
    if (upcomingClasses.contains(day)) {
      return ['scheduled'];
    } else if (absentClass.contains(day)) {
      return ['absent'];
    } else if (fillFeedback
        .any((a) => a.attDate == DateFormat("yyyy-MM-dd").format(day))) {
      return ['feedback'];
    } else if (classCompleted
        .any((a) => a.attDate == DateFormat("yyyy-MM-dd").format(day))) {
      return ['finished'];
    }
    return [];
  }

  @override
  void onInit() {
    super.onInit();
    initData();
  }

  Future<void> fetchAttendance({required String courseId}) async {
    try {
      isLoading.value = true;

      final fetchedCourses =
          await attendanceRepository.fetchAttendanceStatus(courseId);
      attendanceModel.assignAll(fetchedCourses);

      /*final present =
          attendanceModel.where((p) => p.attendance == 'P').toList();

      final absent = attendanceModel
          .where((p) => p.attendance == 'A')
          .map((e) => DateFormat("yyyy-MM-dd").parse(e.attDate))
          .toList();*/
      final present =
          attendanceModel.where((p) => p.attendance == 'P').toList();

      final absent = attendanceModel
          .where((p) => p.attendance == 'A')
          .map((e) => DateFormat("yyyy-MM-dd").parse(e.attDate))
          .toList();

      final absentModels =
          attendanceModel.where((p) => p.attendance == 'A').toList();

      absentAttendance.assignAll(absentModels);
      absentClass.assignAll(absent);

      final holidays = attendanceModel
          .where((p) => p.attendance == 'HD')
          .map((e) => DateFormat("yyyy-MM-dd").parse(e.attDate))
          .toList();

      final notFilledFeedback = attendanceModel
          .where((p) => p.attendance == 'P' && p.feedbackScore == 0)
          .toList();

      final completedFeedback = attendanceModel
          .where((p) => p.attendance == 'P' && p.feedbackScore != 0)
          .toList();

      fillFeedback.assignAll(notFilledFeedback);
      completedFeedbackList.assignAll(completedFeedback);
      absentClass.assignAll(absent);
      classCompleted.assignAll(present);
      holidaylist.assignAll(holidays); // ✅ Add this for calendar

      // ✅ Calculate Upcoming Classes (next 10 weekdays not already marked)
      final allAttendedDates = [
        ...present.map((e) => DateFormat("yyyy-MM-dd").parse(e.attDate)),
        ...absent
      ];
      allAttendedDates.sort();

      final now = DateTime.now();
      final upcoming = <DateTime>[];

      for (int i = 1; i <= 10; i++) {
        final futureDate = now.add(Duration(days: i));
        if (futureDate.weekday != DateTime.saturday &&
            futureDate.weekday != DateTime.sunday) {
          final normalized =
              DateTime(futureDate.year, futureDate.month, futureDate.day);
          if (!allAttendedDates.contains(normalized)) {
            upcoming.add(normalized);
          }
        }
      }

      upcomingClasses.assignAll(upcoming);

      // ✅ Print all dates for debugging
      printAllAttendanceDates();

      update();
      isLoading.value = false;
    } catch (error) {
      print("Attendance Error: ${error.toString()}");
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
    }
  }

  Future<void> fetchDailyStreakController({
    required String courseId,
    String date = '',
    bool isAlertDialog = false,
  }) async {
    try {
      if (isAlertDialog) {
        isDialogLoading.value = true;
      } else {
        isLoading.value = true;
      }

      final response =
          await attendanceRepository.fetchDailyStreak(courseId: courseId);
      dailyStreakModel.value = response;

      if (dailyStreakModel.isNotEmpty) {
        dailyAttendanceList
            .assignAll(dailyStreakModel.first.attendanceSyllabus);

        if (date != '') {
          feedbackTopicList.value = dailyAttendanceList
              .where((p) => p.date == date)
              .map((e) => e.topics)
              .toList();
        }
      } else {
        dailyAttendanceList.clear();
        feedbackTopicList.clear();
      }

      update();
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: e.toString());
    } finally {
      if (isAlertDialog) {
        isDialogLoading.value = false;
      } else {
        isLoading.value = false;
      }
    }
  }

/*  Future<void> addFeedback({required String attendanceId}) async {
    try {
      isDialogLoading.value = true;

      await attendanceRepository.addFeedback(
        attendanceId: attendanceId,
        feedbackScore: ratings.toInt().toString(),
        feedback: feedbackText.text,
      );

      // ✅ Mark feedback submitted for today
      final batchController = Get.find<BatchController>();
      batchController.markFeedbackSubmitted(attendanceId); // pass courseId

      WidgetsBinding.instance.addPostFrameCallback((_) {
        fetchAttendance(
            courseId:
                dailyStreakModel.first.coursesDetails.courseId.toString());
      });

      update();
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: e.toString());
      print("Error in addFeedback: ${e.toString()}");
    } finally {
      isLoading.value = false;
    }
  }*/
  Future<bool> addFeedback({
    required String attendanceId,
    required String feedbackScore,
    required String feedback,
  }) async {
    final req = {
      "attendance_id": attendanceId,
      "feedback_score": feedbackScore,
      "feedback": feedback,
    };

    try {
      isDialogLoading.value = true;
      final response =
          await THttpHelper.post(APIConstants.attendanceFeedbackEndPoint, req);
      print("Feedback response: $response");

      if (response != null && response['status'] == 200) {
        return true; // Success
      } else {
        // Show error message from API
        Get.snackbar(
          "Error",
          response?['message'] ?? "Failed to submit feedback",
          backgroundColor: TColors.red,
          colorText: TColors.white,
        );
        return false;
      }
    } catch (e) {
      Get.snackbar(
        "Error",
        "Something went wrong: $e",
        backgroundColor: TColors.red,
        colorText: TColors.white,
      );
      return false;
    } finally {
      isDialogLoading.value = false;
    }
  }

  // ✅ Prints all relevant attendance-related dates for debugging
  void printAllAttendanceDates() {
    print("🟥 ABSENT DATES:");
    for (var date in absentClass) {
      print("  - ${DateFormat('yyyy-MM-dd').format(date)}");
    }

    print("🟩 COMPLETED CLASSES:");
    for (var a in classCompleted) {
      print("  - ${a.attDate}");
    }

    print("🟨 FEEDBACK TO FILL:");
    for (var a in fillFeedback) {
      print("  - ${a.attDate}");
    }

    print("🟦 FEEDBACK COMPLETED:");
    for (var a in completedFeedbackList) {
      print("  - ${a.attDate}");
    }

    print("⬜ UPCOMING CLASSES:");
    for (var date in upcomingClasses) {
      print("  - ${DateFormat('yyyy-MM-dd').format(date)}");
    }

    print("⬜ Holidays:");
    for (var date in holidaylist) {
      print("  - ${DateFormat('yyyy-MM-dd').format(date)}");
    }
  }

/*  Future<List<String>> fetchAttendanceChapters(
      {required int batchId,
      required int courseId,
      required DateTime date,
      required int branchId}) async {
    final url = Uri.parse("https://erp.elysium.academy/api/attendance_chapter");
    final response = await http.post(url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "batch_id": batchId,
          "course_id": courseId,
          "att_date": DateFormat("yyyy-MM-dd").format(date),
          "branch_id": branchId
        }));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final chapters = data['data'] as List;
      // Extract only chapter names
      return chapters.map<String>((e) => e['chapter_name'] as String).toList();
    } else {
      throw Exception("Failed to load chapters");
    }
  }*/
  var ischapterLoading = false.obs;
  Future<List<String>> fetchAttendanceChapters({
    required int batchId,
    required int courseId,
    required DateTime date,
    required int branchId,
  }) async {
    try {
      ischapterLoading.value = true;
      // ✅ Prepare body data
      final body = {
        "batch_id": batchId,
        "course_id": courseId,
        "att_date": DateFormat("yyyy-MM-dd").format(date),
        "branch_id": branchId,
      };

      // ✅ Make POST request using THttpHelper
      final response =
          await THttpHelper.post(APIConstants.attendencechapterendpoint, body);

      // ✅ Handle and parse response
      if (response != null && response['data'] != null) {
        final List<dynamic> chapters = response['data'];
        return chapters
            .map<String>((e) => e['chapter_name']?.toString() ?? '')
            .where((name) => name.isNotEmpty)
            .toList();
      } else {
        return [];
      }
    } catch (e) {
      print("Error in fetchAttendanceChapters: $e");
      throw Exception("Failed to load chapters");
    } finally {
      ischapterLoading.value = false;
    }
  }

  //Attendencetour
  bool submittedKeyAssigned = false; // ✅ ensures only first match gets key
  bool pendingKeyAssigned = false;
  final attendencedropdownKey = GlobalKey();
  final attendencetabsKey = GlobalKey();
  final feedbackKey = GlobalKey();
  final notfeedbackKey = GlobalKey();
  var isAttendenceTouron = false.obs;
  Future<void> AttendenceTour(BuildContext context) async {
    final targets = AttendenceTourList.getTargets(
        attendencedropdownKey: attendencedropdownKey,
        attendencetabsKey: attendencetabsKey,
        feedbackKey: feedbackKey,
        notfeedbackKey: notfeedbackKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: TColors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.attendencetour, true);
        isAttendenceTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.attendencetour, true);
        isAttendenceTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
