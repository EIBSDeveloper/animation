/*import 'package:eapl_student_app/features/personalization/models/existing_course_model.dart';
import 'package:eapl_student_app/features/personalization/models/new_course_model.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../data/repository/course_repository.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../models/course_model.dart';

class CourseController extends GetxController {
  static CourseController get instance => Get.find();
  final CourseRepository courseRepository = Get.put(CourseRepository());

  // Observable list for courses
  var coursesList = <CourseDetailModel>[].obs;
  var newCourses = <NewCourseModel>[].obs;

  var isLoading = false.obs;
  var courseListIndex = 0.obs;
  var courseAttendanceIndex = 0.obs;
  var dailyStreakIndex = 0.obs;

  var isDownloaded = false.obs;
  var savedFilePath = ''.obs;
  var downloadProgress = 0.0.obs;
  RxBool isDownloading = false.obs;
  var isNewCourse = false.obs;
  var isExistingCourse = false.obs;

  void passIndex(int index) {
    // courseListIndex = index;
    update();
  }

  @override
  void onInit() {
    super.onInit();
    fetchNewCourses();
    fetchExistingCourse();
  }

  Future<void> fetchCourses({int? limit}) async {
    try {
      isLoading.value = true;
      final fetchedCourses = await courseRepository
          .fetchCourseDetails(GetStorage().read(TTexts.userID), limit: limit);
      coursesList.assignAll(fetchedCourses);
      update();
    } catch (error) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchNewCourses() async {
    try {
      isLoading.value = true;
      final fetchedNewCourses =
          await courseRepository.fetchNewCourseDetails(limit: 5);
      newCourses.assignAll(fetchedNewCourses);

      isLoading.value = false;
    } catch (error) {
      isLoading.value = false;
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
    }
  }

  /// Apply new Course
  var newCourseRegBtn;

  Future<void> registerNewCourse(int courseId, String courseName) async {
    try {
      isLoading.value = true;
      final requestBody = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": courseId
      };
      final response = await THttpHelper.post(
          APIConstants.newCourseRegisterEndPoint, requestBody);
      print(requestBody);
      print(response);

      /// To Store Course Id In Get Storage
      final storage = GetStorage();
      List register = storage.read('registeredCourse') ?? [];
      register.add(courseId);
      storage.write('registeredCourse', register.toSet().toList());
      newCourseRegBtn = "Pending";
      TSnackbar.successSnackbar(
          title: courseName, message: "Registered Successfully");
      isLoading.value = false;
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Try Again",
          message: "Something went wrong please try again later");
      print("registerNewCourse : Error :$e");
      isLoading.value = false;
    }
  }

  String getButtonText(int courseId) {
    final storage = GetStorage();
    List register = storage.read('registeredCourse') ?? [];
    return register.contains(courseId) ? "Pending" : "Register";
  }

  var existingCourseList = <ExistingCourseModel>[].obs;
  Future<void> fetchExistingCourse() async {
    try {
      isLoading.value = true;
      final response =
          await THttpHelper.get(APIConstants.existingCourseEndPoint);
      existingCourseList.value = (response["data"][0]["coursesDetails"] as List)
          .map((e) => ExistingCourseModel.fromJson(e))
          .toList();
      print(response);
    } catch (e) {
      print("fetchExistingCourse : Error : $e");
    }
  }
}*/
import 'package:eapl_student_app/features/apptour/bottom/dashboard/dashboardtour.dart';
import 'package:eapl_student_app/features/apptour/side/mycourses/mycoursetour.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/placement_controller.dart';
import 'package:eapl_student_app/features/personalization/models/existing_course_model.dart';
import 'package:eapl_student_app/features/personalization/models/interested/interestmodel.dart';
import 'package:eapl_student_app/features/personalization/models/new_course_model.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../data/repository/course_repository.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../../apptour/bottom/newlaunch/newlaunchtour.dart';
import '../../models/course_model.dart';
import '../../screens/side_drawer_menu/notifications/notification_controller.dart';
import 'batch_controller.dart';

class CourseController extends GetxController {
  static CourseController get instance => Get.find();
  final CourseRepository courseRepository = Get.put(CourseRepository());

  var coursesList = <CourseDetailModel>[].obs;

  var newCourses = <NewCourseModel>[].obs;
  var allNewCourses = <NewCourseModel>[];

  var existingCourseList = <ExistingCourseModel>[].obs;
  var allExistingCourses = <ExistingCourseModel>[];

  var intersestCourseList = <Interestmodel>[].obs;
  var allInterestCourses = <Interestmodel>[];

  var availableCourseTypes = <String>[].obs; // ✅ This is correct
  var selectedCourseType = ''.obs;
  var isLoading = false.obs;
  var iscourseLoading = false.obs;
  var courseListIndex = 0.obs;
  var courseAttendanceIndex = 0.obs;
  var dailyStreakIndex = 0.obs;

  var isDownloaded = false.obs;
  var savedFilePath = ''.obs;
  var downloadProgress = 0.0.obs;
  RxBool isDownloading = false.obs;

  var isNewCourse = false.obs;
  var isRegistered = false.obs; // 👈 declare here
  /// Initialization
  @override
  void onInit() {
    super.onInit();
    load();
  }

  /* Future<void> load() async {
    fetchCourses();
    fetchNewCourses();
    fetchExistingCourse();
    fetchinterestcourse();
    // Fetch placement interview data
    final controller = Get.find<PlacementController>();
    await controller.fetchPlacementinterview();
    // After courses are loaded, fetch batch details for each course
    final batchController = Get.put(BatchController(), permanent: true);

    for (var course in coursesList) {
      batchController.fetchBatchDetailsController(
          courseId: course.courseId.toString());
    }
  }*/
  Future<void> load() async {
    // 1️⃣ Fetch all courses sequentially (await if needed)
    await fetchCourses();
    await fetchNewCourses();
    await fetchExistingCourse();
    await fetchinterestcourse();

    // 2️⃣ Fetch placement interview data
    final placementController = Get.find<PlacementController>();
    await placementController.fetchPlacementinterview();

    // 3️⃣ After courses are loaded, fetch batch details for each course
    final batchController = Get.put(BatchController(), permanent: true);
    for (var course in coursesList) {
      await batchController.fetchBatchDetailsController(
        courseId: course.courseId.toString(),
      );
    }
  }

  /// Fetch All Courses (Unrelated to this feature, kept intact)
  Future<void> fetchCourses({int? limit}) async {
    try {
      iscourseLoading.value = true;
      final fetchedCourses = await courseRepository
          .fetchCourseDetails(GetStorage().read(TTexts.userID), limit: limit);
      coursesList.assignAll(fetchedCourses);
    } catch (error) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
    } finally {
      iscourseLoading.value = false;
    }
  }

  /// Fetch New Courses
  Future<void> fetchNewCourses() async {
    try {
      isLoading.value = true;

      final fetchedNewCourses = await courseRepository.fetchNewCourseDetails();

      allNewCourses = fetchedNewCourses;
      newCourses.assignAll(fetchedNewCourses);

      _updateCourseTypes();
    } catch (error) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
    } finally {
      isLoading.value = false;
    }
  }

  /// Fetch Existing Courses
  Future<void> fetchExistingCourse() async {
    try {
      isLoading.value = true;
      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };
      final response =
          await THttpHelper.post(APIConstants.existingCourseEndPoint, body);
      allExistingCourses = (response["data"][0]["coursesDetails"] as List)
          .map((e) => ExistingCourseModel.fromJson(e))
          .toList();
      existingCourseList.assignAll(allExistingCourses);
      _updateCourseTypes();
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  /// Extract Unique Course Types
  void _updateCourseTypes() {
    final allTypes = {
      ...allNewCourses.map((e) => e.courseTypeName),
      ...allExistingCourses.map((e) => e.courseTypeName),
    };

    // Filter out nulls safely
    availableCourseTypes.assignAll(allTypes.whereType<String>()); // ✅ Correct
  }

  /// Filter both course types by selected type
  void filterCoursesByType(String type) {
    selectedCourseType.value = type;

    if (type.isEmpty) {
      newCourses.assignAll(allNewCourses);
      existingCourseList.assignAll(allExistingCourses);
    } else {
      newCourses.assignAll(
          allNewCourses.where((course) => course.courseTypeName == type));
      existingCourseList.assignAll(
          allExistingCourses.where((course) => course.courseTypeName == type));
    }
  }

  /// Register New Course
  Future<void> registerNewCourse(NewCourseModel course) async {
    try {
      isLoading.value = true;

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": course.sno,
      };

      final response =
          await THttpHelper.post(APIConstants.newCourseRegisterEndPoint, body);

      print(body);
      print(response);

      // 🔥 mark as interested
      course.interested = 1;
      Get.back();
      Fluttertoast.showToast(
        msg: "${course.courseName} Added to Favourites",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM, // TOP, CENTER, BOTTOM
        backgroundColor: TColors.primary,
        textColor: TColors.white,
        fontSize: 16.0,
      );

      update(); // 🔄 refresh GetBuilder/Obx widgets
      final notificationController = Get.find<NotificationController>();
      await notificationController.fetchNotificationList();
      final appbarController = Get.find<AppbarController>();
      appbarController.incrementNotify();
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Try Again",
          message: "Something went wrong. Please try again later.");
      print("registerNewCourse : Error : $e");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> registerExistCourse(ExistingCourseModel existcourse) async {
    try {
      isLoading.value = true;

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": existcourse.sno,
      };

      final response = await THttpHelper.post(
          APIConstants.existCourseRegisterEndPoint, body);

      print(body);
      print(response);

      // 🔥 mark as interested
      existcourse.interested = 1;
      Get.back();
      Fluttertoast.showToast(
        msg: "${existcourse.courseName}  Added to Favourites",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM, // TOP, CENTER, BOTTOM
        backgroundColor: TColors.primary,
        textColor: TColors.white,
        fontSize: 16.0,
      );

      update(); // 🔄 refresh GetBuilder/Obx widgets
      final notificationController = Get.find<NotificationController>();
      await notificationController.fetchNotificationList();
      final appbarController = Get.find<AppbarController>();
      appbarController.incrementNotify();
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Try Again",
          message: "Something went wrong. Please try again later.");
      print("registerNewCourse : Error : $e");
    } finally {
      isLoading.value = false;
    }
  }

  var isinterestLoading = false.obs;
  Future<void> fetchinterestcourse() async {
    try {
      isinterestLoading.value = true;
      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };
      final response =
          await THttpHelper.post(APIConstants.interestedcourseendpoint, body);
      allInterestCourses = (response["data"][0]["coursesDetails"] as List)
          .map((e) => Interestmodel.fromJson(e))
          .toList();
      intersestCourseList.assignAll(allInterestCourses);
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    } finally {
      isinterestLoading.value = false;
    }
  }

  var isRemoveLoadingMap = <int, bool>{}.obs;
  Future<bool> removeInterestCourse(Interestmodel interestCourse) async {
    try {
      isRemoveLoadingMap[interestCourse.sno!] = true;
      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": interestCourse.sno,
      };

      final response =
          await THttpHelper.post(APIConstants.removecourseendpoint, body);

      if (response != null && response["status"] == "success") {
        Fluttertoast.showToast(
          msg: "Removed from favourites",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: TColors.primary,
          textColor: Colors.white,
          fontSize: 14.0,
        );
        fetchNewCourses();
        fetchExistingCourse();
        return true;
      } else {
        Fluttertoast.showToast(
          msg: response?["message"] ?? "Unable to remove course",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 14.0,
        );
        return false;
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Error: ${e.toString()}",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 14.0,
      );
      return false;
    } finally {
      isRemoveLoadingMap[interestCourse.sno!] = false;
    }
  }

/*  var isPaymentCourseLoading = false.obs;
  var comboList = <PaymentDetails>[].obs;

  Future<void> fetchCourseandPayments() async {
    try {
      isPaymentCourseLoading.value = true;

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };

      // THttpHelper.post returns Map<String, dynamic>
      final Map<String, dynamic> jsonResponse = await THttpHelper.post(
        APIConstants.comboendpoint,
        body,
      );

      // Check API status
      if (jsonResponse['status'] == 200) {
        // Extract payment_details
        final List<dynamic> paymentsJson =
            jsonResponse['data']['payment_details'];

        // Convert to PaymentDetails list
        comboList.value =
            paymentsJson.map((e) => PaymentDetails.fromJson(e)).toList();
      } else {
        comboList.clear();
        print("API returned status: ${jsonResponse['status']}");
      }
    } catch (e) {
      comboList.clear();
      print("Error fetching payments: $e");
    } finally {
      isPaymentCourseLoading.value = false;
    }
  }*/

  var selectedCourseTab = 0.obs; // 0: New, 1: Existing, 2: Interest
  RxDouble rating = 0.0.obs;
  var coursefeedbackWordCount = 0.obs;
  var iscourseRatingLoading = false.obs;

  void setRating(double value) {
    rating.value = value;
  }

  void resetRating() {
    rating.value = 0.0;
  }

  Future<void> courseRating({
    required int courseId,
    required String description,
    required CourseDetailModel courseModel, // ✅ pass course model to update
  }) async {
    try {
      iscourseRatingLoading.value = true;

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": courseId,
        "rating": rating.value.toInt(),
        "description": description,
      };

      print("📤 Sending Rating Request: $body");

      final response =
          await THttpHelper.post(APIConstants.courseratingendpoint, body);

      print("📥 Response: $response");

      if (response['success'] == true) {
        // ✅ Update local model
        courseModel.rating = rating.value as String;
        Get.back(); // 👈 this will close the rating dialog
        Get.snackbar("Success", response['message'],
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: TColors.primary,
            colorText: TColors.white);

        resetRating(); // optional reset for next dialog
      } else {
        Get.snackbar("Error", response['message'] ?? "Something went wrong",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: TColors.importantText,
            colorText: TColors.white);
      }
    } catch (e) {
      print("❌ Error in courseRating: $e");
      Get.snackbar("Error", e.toString(),
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.red,
          colorText: TColors.white);
    } finally {
      iscourseRatingLoading.value = false;
    }
  }

// new launch course
  final dropdownKey = GlobalKey();
  final newcourseKey = GlobalKey();
  final existcourseKey = GlobalKey();
  final existcoursecardKey = GlobalKey();

  var isnewLaunchTouron = false.obs;
  Future<void> newlaunchTour(BuildContext context) async {
    final targets = NewLaunchTourList.getTargets(
      dropdownKey: dropdownKey,
      newcourseKey: newcourseKey,
      existcourseKey: existcourseKey,
      existcoursecardKey: existcoursecardKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.newLaunchTour, true);
        isnewLaunchTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.newLaunchTour, true);
        isnewLaunchTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //new launch course details
  final existinterestKey = GlobalKey();
  var isnewLaunchDetailsTouron = false.obs;
  Future<void> newlaunchDetailsTour(BuildContext context) async {
    final targets =
        CourseDetailsTourList.getTargets(existinterestKey: existinterestKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.newLaunchdetailsTour, true);
        isnewLaunchDetailsTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.newLaunchdetailsTour, true);
        isnewLaunchDetailsTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //dashboardtour
  final courseKey = GlobalKey();
  final paymentKey = GlobalKey();

  var isDashboardTouron = false.obs;
  Future<void> DashboardTour(BuildContext context) async {
    final targets = DashboardTourList.getTargets(
      courseKey: courseKey,
      PaymentKey: paymentKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.dashboardtour, true);
        isDashboardTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.dashboardtour, true);
        isDashboardTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //mycoursetour
  final viewKey = GlobalKey();
  final ratingKey = GlobalKey();

  var isMycourseTouron = false.obs;
  Future<void> MycourseTour(BuildContext context) async {
    final targets = MycourseTourList.getTargets(
      viewKey: viewKey,
      ratingKey: ratingKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.mycoursetour, true);
        isMycourseTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.mycoursetour, true);
        isMycourseTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
