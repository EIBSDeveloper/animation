import 'package:eapl_student_app/data/repository/syllabus_repository.dart';
import 'package:eapl_student_app/features/personalization/models/syllabus_model/chapter_model.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/text_strings.dart';
import '../../../apptour/side/mycourses/mycoursetour.dart';
import '../../models/syllabus_model/section_and_topics_model.dart';

class SyllabusController extends GetxController {
  static SyllabusController get instance => Get.find();
  final SyllabusRepository syllabusRepository = Get.put(SyllabusRepository());

  // Observable list for courses
  var chapterList = <ChapterModel>[].obs;
  var sectionAndTopicList = <SectionModel>[].obs;
  var chapterDetails = <ChapterDetailModelForFetchTopics>[].obs;

  var chapterDetailList = Rxn<List<ChapterAndSectionModel>>();
  var isLoading = false.obs;

  Future<void> fetchChapter(int courseId) async {
    try {
      isLoading.value = true;
      final fetchChapterList =
          await syllabusRepository.fetchChapterList(courseId);
      chapterList.assignAll(fetchChapterList);
    } catch (error) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchSectionAndTopics(int chapterId) async {
    try {
      isLoading.value = true;
      final response =
          await syllabusRepository.fetchSectionAndTopicsList(chapterId);
      chapterDetailList.value = response;
      chapterDetails.assignAll(chapterDetailList.value!.first.chapterDetails);
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  //mycoursedetailstour
  final chapterKey = GlobalKey();

  var isMycoursedetailsTouron = false.obs;
  Future<void> MycoursedetailsTour(BuildContext context) async {
    final targets = MycoursedetailsTourList.getTargets(
      chapterkey: chapterKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.mycoursedetailstour, true);
        isMycoursedetailsTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.mycoursedetailstour, true);
        isMycoursedetailsTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //chapterdetailstour
  final chapterdetailsKey = GlobalKey();

  var ischapterdetailsTouron = false.obs;
  Future<void> ChapterdetailsTour(BuildContext context) async {
    final targets = ChapterdetailsTourList.getTargets(
      chapterdetailskey: chapterdetailsKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.chapterdetailstour, true);
        ischapterdetailsTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.chapterdetailstour, true);
        ischapterdetailsTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
