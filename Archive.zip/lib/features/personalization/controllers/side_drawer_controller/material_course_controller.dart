// import 'dart:io';
// import 'dart:nativewrappers/_internal/vm/lib/typed_data_patch.dart';
//
// import 'package:archive/archive.dart';
// import 'package:dio/dio.dart';
// import 'package:eapl_student_app/utils/loaders/loaders.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:open_file/open_file.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:permission_handler/permission_handler.dart';
//
// import '../../../../utils/constants/text_strings.dart';
// import '../../../../utils/http/api_constants.dart';
// import '../../../../utils/http/http_client.dart';
// import '../../models/course_material_model/course_material_doc_model.dart';
// import '../../models/course_material_model/course_material_model.dart';
// import '../../screens/side_drawer_menu/course_material/widget/material_view_screen.dart';
// import '../../screens/side_drawer_menu/course_material/widget/material_webview.dart';
//
// class CourseMaterialController extends GetxController {
//   static CourseMaterialController get instance => Get.find();
//
//   final isLoading = false.obs;
//   final courseListFolder = <CourseMaterialListNew>[].obs;
//   final courseMaterialList = Rxn<CourseMaterialListModel>();
//   var isDownloading = false.obs;
//   var savedFilePath = ''.obs;
//   var downloadProgressInMP = 0.0.obs;
//   @override
//   void onInit() {
//     super.onInit();
//   }
//
//   Future<void> fetchCourseListFolder() async {
//     try {
//       courseListFolder.clear();
//       final req = {"customer_id": GetStorage().read(TTexts.userID)};
//
//       isLoading.value = true;
//
//       final response =
//           await THttpHelper.post(APIConstants.courseMaterialsEndPoint, req);
//       if (response['data'] != []) {
//         courseListFolder.value = (response['data'] as List)
//             .map((e) => CourseMaterialListNew.fromJson(e))
//             .toList();
//       } else {
//         courseListFolder.value = <CourseMaterialListNew>[];
//       }
//     } catch (e) {
//       print('fetchCourseMaterialFolder :$e');
//     } finally {
//       isLoading.value = false;
//     }
//   }
//
//   Future<void> fetchMaterialList(
//       {required String courseId, required String materialTypeId}) async {
//     // try {
//     final req = {"course_id": courseId, "material_type_id": materialTypeId};
//
//     print("fetchMaterialList : $req");
//
//     isLoading.value = true;
//     final response =
//         await THttpHelper.post(APIConstants.courseMaterialListEndPoint, req);
//     print("fetchMaterialList response : $response");
//     courseMaterialList.value =
//         CourseMaterialListModel.fromJson(response['data']);
//
//     isLoading.value = false;
//     // } catch (e) {
//     //   print(e);
//     // } finally {
//     //   isLoading.value = false;
//     // }
//   }
// /// --- With add Permission add in android manifest file
//   // Future<void> downloadFile(BuildContext context, String url) async {
//   //   var status = await Permission.storage.request();
//   //
//   //   if (!status.isGranted) {
//   //     ScaffoldMessenger.of(context).showSnackBar(
//   //       const SnackBar(content: Text('Storage permission is required')),
//   //     );
//   //     return;
//   //   }
//   //
//   //   TSnackbar.successSnackbar(
//   //     title: "Your download is in progress",
//   //     message: "The file will open automatically once completed",
//   //   );
//   //
//   //   Directory? externalDir = await getExternalStorageDirectory();
//   //   if (externalDir == null) return;
//   //
//   //   String folderPath = '${externalDir.path}/EAPL';
//   //   Directory saveDir = Directory(folderPath);
//   //
//   //   if (!await saveDir.exists()) {
//   //     await saveDir.create(recursive: true);
//   //   }
//   //
//   //   String fileName = url.split('/').last;
//   //   String savePath = '${saveDir.path}/$fileName';
//   //
//   //   try {
//   //     Dio dio = Dio();
//   //
//   //     // Set download progress to 0 and start download
//   //     downloadProgressInMP.value = 0.0;
//   //     isDownloading.value = true;
//   //
//   //     await dio.download(
//   //       url,
//   //       savePath,
//   //       onReceiveProgress: (received, total) {
//   //         if (total != -1) {
//   //           downloadProgressInMP.value = received / total;
//   //         }
//   //       },
//   //     );
//   //
//   //     // Reset download flag after download completes
//   //     isDownloading.value = false;
//   //     savedFilePath.value = savePath;
//   //
//   //     openFile(savePath);
//   //     ScaffoldMessenger.of(context).showSnackBar(
//   //       SnackBar(
//   //         content: Text('File downloaded to $savePath'),
//   //         action: SnackBarAction(
//   //           label: 'View',
//   //           onPressed: () => openFile(savePath),
//   //         ),
//   //       ),
//   //     );
//   //   } catch (e) {
//   //     isDownloading.value = false;
//   //     ScaffoldMessenger.of(context).showSnackBar(
//   //       SnackBar(content: Text('Download failed: $e')),
//   //     );
//   //   }
//   // }
//   //
//   // Future<void> openFile(String filePath) async {
//   //   final result = await OpenFile.open(filePath);
//   //   ScaffoldMessenger.of(Get.context!).showSnackBar(
//   //     SnackBar(
//   //       content: Text(
//   //         result.type == ResultType.done
//   //             ? 'File opened successfully'
//   //             : 'Could not open file: ${result.message}',
//   //       ),
//   //     ),
//   //   );
//   // }
// /// --- Without add permission in the android manifest file
// //   Future<void> downloadFile(BuildContext context, String url) async {
// //     // Show download start notification
// //     TSnackbar.successSnackbar(
// //       title: "Your download is in progress",
// //       message: "The file will open automatically once completed",
// //     );
// //
// //     // Get the app's documents directory (no permissions needed)
// //     Directory? appDocDir = await getApplicationDocumentsDirectory();
// //     if (appDocDir == null) {
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         const SnackBar(content: Text('Could not access storage directory')),
// //       );
// //       return;
// //     }
// //
// //     // Create a subdirectory for EAPL
// //     String folderPath = '${appDocDir.path}/EAPL';
// //     Directory saveDir = Directory(folderPath);
// //
// //     if (!await saveDir.exists()) {
// //       await saveDir.create(recursive: true);
// //     }
// //
// //     // Extract file name from URL
// //     String fileName = url.split('/').last;
// //     String savePath = '${saveDir.path}/$fileName';
// //
// //     try {
// //       Dio dio = Dio();
// //
// //       // Set download progress to 0 and start download
// //       downloadProgressInMP.value = 0.0;
// //       isDownloading.value = true;
// //
// //       await dio.download(
// //         url,
// //         savePath,
// //         onReceiveProgress: (received, total) {
// //           if (total != -1) {
// //             downloadProgressInMP.value = received / total;
// //           }
// //         },
// //       );
// //
// //       // Reset download flag after download completes
// //       isDownloading.value = false;
// //       savedFilePath.value = savePath;
// //
// //       // Open the downloaded file
// //       await openFile(savePath);
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         SnackBar(
// //           content: Text('File downloaded to $savePath'),
// //           action: SnackBarAction(
// //             label: 'View',
// //             onPressed: () => openFile(savePath),
// //           ),
// //         ),
// //       );
// //     } catch (e) {
// //       isDownloading.value = false;
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         SnackBar(content: Text('Download failed: $e')),
// //       );
// //     }
// //   }
// //
// //   Future<void> openFile(String filePath) async {
// //     final result = await OpenFile.open(filePath);
// //     ScaffoldMessenger.of(Get.context!).showSnackBar(
// //       SnackBar(
// //         content: Text(
// //           result.type == ResultType.done
// //               ? 'File opened successfully'
// //               : 'Could not open file: ${result.message}',
// //         ),
// //       ),
// //     );
// //   }
//
//   // Future<void> downloadFile(BuildContext context, String url) async {
//   //   // Validate URL
//   //   if (!Uri.parse(url).isAbsolute) {
//   //     ScaffoldMessenger.of(context).showSnackBar(
//   //       const SnackBar(content: Text('Invalid URL provided')),
//   //     );
//   //     return;
//   //   }
//   //
//   //   // Show download start notification
//   //   TSnackbar.successSnackbar(
//   //     title: "Your download is in progress",
//   //     message: "The file will open in the app once completed",
//   //   );
//   //
//   //   try {
//   //     dio.Dio dioInstance = dio.Dio();
//   //
//   //     // Set download progress to 0 and start download
//   //     downloadProgressInMP.value = 0.0;
//   //     isDownloading.value = true;
//   //
//   //     // Download the file as bytes
//   //     dio.Response<List<int>> response = await dioInstance.get<List<int>>(
//   //       url,
//   //       options: dio.Options(responseType: dio.ResponseType.bytes),
//   //       onReceiveProgress: (received, total) {
//   //         if (total != -1) {
//   //           downloadProgressInMP.value = received / total;
//   //         }
//   //       },
//   //     );
//   //
//   //     // Check if the response is valid
//   //     if (response.statusCode != 200) {
//   //       throw dio.DioException(
//   //         requestOptions: response.requestOptions,
//   //         response: response,
//   //         error: 'Failed to download file: HTTP ${response.statusCode}',
//   //       );
//   //     }
//   //
//   //     // Get the app's temporary directory
//   //     Directory tempDir = await getTemporaryDirectory();
//   //     String fileName = url.split('/').last;
//   //     String tempPath = '${tempDir.path}/$fileName';
//   //
//   //     // Write bytes to a temporary file
//   //     File tempFile = File(tempPath);
//   //     await tempFile.writeAsBytes(response.data!);
//   //
//   //     // Reset download flag
//   //     isDownloading.value = false;
//   //     savedFilePath.value = tempPath;
//   //
//   //     // Check file extension
//   //     String extension = fileName.split('.').last.toLowerCase();
//   //
//   //     if (extension == 'pdf') {
//   //       // Navigate to PDF viewer for PDFs
//   //       Navigator.push(
//   //         context,
//   //         MaterialPageRoute(
//   //           builder: (context) => PdfViewerPage(filePath: tempPath),
//   //         ),
//   //       ).then((_) async {
//   //         // Delete the temporary file after viewing
//   //         if (await tempFile.exists()) {
//   //           await tempFile.delete();
//   //           savedFilePath.value = '';
//   //         }
//   //       });
//   //     } else {
//   //       // Open non-PDF files with external app
//   //       final result = await filex.OpenFilex.open(tempPath);
//   //       if (result.type != filex.ResultType.done) {
//   //         ScaffoldMessenger.of(context).showSnackBar(
//   //           SnackBar(content: Text('Could not open file: ${result.message}')),
//   //         );
//   //       }
//   //       // Delete the temporary file after opening
//   //       if (await tempFile.exists()) {
//   //         await tempFile.delete();
//   //         savedFilePath.value = '';
//   //       }
//   //     }
//   //
//   //     ScaffoldMessenger.of(context).showSnackBar(
//   //       const SnackBar(content: Text('File opened in app')),
//   //     );
//   //   } catch (e) {
//   //     isDownloading.value = false;
//   //     ScaffoldMessenger.of(context).showSnackBar(
//   //       SnackBar(content: Text('Failed to load file: $e')),
//   //     );
//   //   }
//   // }
//
//
//
//
//   var isProcessing = false.obs;
//   var currentFilePath = ''.obs;
//
//
// Future<void> viewFileInApp(BuildContext context, String url) async {
//   // Show processing notification
//   TSnackbar.successSnackbar(
//     title: "Processing file",
//     message: "Preparing file for in-app viewing",
//   );
//
//   // Extract file name and extension
//   String fileName = url.split('/').last;
//   String extension = fileName.split('.').last.toLowerCase();
//   const supportedTypes = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'zip'];
//
//   if (!supportedTypes.contains(extension)) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       const SnackBar(content: Text('Unsupported file type')),
//     );
//     return;
//   }
//
//   try {
//     Dio dio = Dio();
//     // FileViewerController controller = Get.find<FileViewerController>();
//
//     // Set processing state
//     downloadProgressInMP.value = 0.0;
//     isProcessing.value = true;
//
//     // For small files (<10MB), try memory-only streaming
//     bool useMemory = true;
//     Uint8List? fileBytes;
//
//     if (useMemory) {
//       Response response = await dio.get(
//         url,
//         options: Options(responseType: ResponseType.bytes),
//         onReceiveProgress: (received, total) {
//           if (total != -1) {
//             downloadProgressInMP.value = received / total;
//           }
//         },
//       );
//       fileBytes = response.data;
//     }
//
//     // Fallback to temporary storage for large files or ZIP extraction
//     String? tempPath;
//     if (fileBytes == null || extension == 'zip') {
//       Directory tempDir = await getTemporaryDirectory();
//       tempPath = '${tempDir.path}/$fileName';
//       await dio.download(
//         url,
//         tempPath,
//         onReceiveProgress: (received, total) {
//           if (total != -1) {
//             downloadProgressInMP.value = received / total;
//           }
//           }
//         },
//       );
//     }
//
//     // Reset processing state
//     isProcessing.value = false;
//
//     // Handle file based on type
//     if (extension == 'pdf') {
//       if (fileBytes != null) {
//         // Write to temp file for PDF viewer
//         tempPath = '${(await getTemporaryDirectory()).path}/$fileName';
//         await File(tempPath).writeAsBytes(fileBytes);
//       }
//       Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (context) => PDFViewerPage(filePath: tempPath!),
//         ),
//       );
//     } else if (['ppt', 'pptx', 'doc', 'docx'].contains(extension)) {
//       // Use WebView with Google Docs Viewer for PPT/Word
//       String viewerUrl = 'https://docs.google.com/gview?embedded=true&url=$url';
//       Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (context) => WebViewPage(url: viewerUrl),
//         ),
//       );
//     } else if (extension == 'zip') {
//       // Extract ZIP and display supported files
//       final zipBytes = fileBytes ?? await File(tempPath!).readAsBytes();
//       final archive = ZipDecoder().decodeBytes(zipBytes);
//
//       Directory tempDir = await getTemporaryDirectory();
//       for (final file in archive) {
//         if (file.isFile && file.name.toLowerCase().endsWith('.pdf')) {
//           final outputPath = '${tempDir.path}/${file.name}';
//           final outputFile = File(outputPath);
//           await outputFile.writeAsBytes(file.content as List<int>);
//           Navigator.push(
//             context,
//             MaterialPageRoute(
//               builder: (context) => PDFViewerPage(filePath: outputPath),
//             ),
//           );
//           break; // Display first PDF for simplicity
//         }
//       }
//       if (!archive.any((f) => f.isFile && f.name.toLowerCase().endsWith('.pdf'))) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('No supported files found in ZIP')),
//         );
//       }
//     }
//
//     // Clean up temporary file
//     if (tempPath != null) {
//       File(tempPath).delete().catchError((e) {
//         print('Error deleting temp file: $e');
//       });
//     }
//   } catch (e) {
//     isProcessing.value = false;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text('Failed to process file: $e')),
//     );
//   }
// }
//
//
//
//
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:dio/dio.dart' as dio;
import 'package:eapl_student_app/features/apptour/side/coursematerials/coursematerialstour.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../utils/constants/text_strings.dart';
import '../../../../utils/http/api_constants.dart';
import '../../../../utils/http/http_client.dart';
import '../../models/course_material_model/course_material_doc_model.dart';
import '../../models/course_material_model/course_material_model.dart';
import '../../screens/side_drawer_menu/course_material/widget/material_view_screen.dart';
import '../../screens/side_drawer_menu/course_material/widget/material_webview.dart';

class CourseMaterialController extends GetxController {
  static CourseMaterialController get instance => Get.find();

  final isLoading = false.obs;
  final courseListFolder = <CourseMaterialListNew>[].obs;
  final courseMaterialList = Rxn<CourseMaterialListModel>();
  var isDownloading = false.obs;
  var savedFilePath = ''.obs;
  var downloadProgressInMP = 0.0.obs;
  var isProcessing = false.obs;
  var currentFilePath = ''.obs;

  @override
  void onInit() {
    super.onInit();
  }

  Future<void> fetchCourseListFolder() async {
    try {
      courseListFolder.clear();
      final req = {"customer_id": GetStorage().read(TTexts.userID)};

      isLoading.value = true;

      final response =
          await THttpHelper.post(APIConstants.courseMaterialsEndPoint, req);
      if (response['data'] != []) {
        courseListFolder.value = (response['data'] as List)
            .map((e) => CourseMaterialListNew.fromJson(e))
            .toList();
      } else {
        courseListFolder.value = <CourseMaterialListNew>[];
      }
    } catch (e) {
      print('fetchCourseMaterialFolder :$e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchMaterialList(
      {required String courseId, required String materialTypeId}) async {
    final req = {"course_id": courseId, "material_type_id": materialTypeId};

    print("fetchMaterialList : $req");

    isLoading.value = true;
    final response =
        await THttpHelper.post(APIConstants.courseMaterialListEndPoint, req);
    print("fetchMaterialList response : $response");
    courseMaterialList.value =
        CourseMaterialListModel.fromJson(response['data']);

    isLoading.value = false;
  }

  Future<void> viewFileInApp(BuildContext context, String url) async {
    // Validate URL
    if (!Uri.parse(url).isAbsolute) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid URL provided')),
      );
      return;
    }

    // Show processing notification
    TSnackbar.successSnackbar(
      title: "Processing file",
      message: "Preparing file for in-app viewing",
    );

    // Extract file name and extension
    String fileName = url.split('/').last;
    String extension = fileName.split('.').last.toLowerCase();
    const supportedTypes = ['pdf', 'ppt', 'pptx', 'doc', 'docx', 'zip'];

    if (!supportedTypes.contains(extension)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unsupported file type')),
      );
      return;
    }

    try {
      dio.Dio dioInstance = dio.Dio();

      // Set processing state
      downloadProgressInMP.value = 0.0;
      isProcessing.value = true;

      // For small files (<10MB), try memory-only streaming
      bool useMemory = true;
      Uint8List? fileBytes;
      String? tempPath;

      if (useMemory) {
        dio.Response response = await dioInstance.get(
          url,
          options: dio.Options(responseType: dio.ResponseType.bytes),
          onReceiveProgress: (received, total) {
            if (total != -1) {
              downloadProgressInMP.value = received / total;
            }
          },
        );
        fileBytes = response.data;
      }

      // Fallback to temporary storage for large files or ZIP extraction
      if (fileBytes == null || extension == 'zip') {
        Directory tempDir = await getTemporaryDirectory();
        tempPath = '${tempDir.path}/$fileName';
        await dioInstance.download(
          url,
          tempPath,
          onReceiveProgress: (received, total) {
            if (total != -1) {
              downloadProgressInMP.value = received / total;
            }
          },
        );
      }

      // Reset processing state
      isProcessing.value = false;

      // Handle file based on type
      if (extension == 'pdf') {
        try {
          final dir = await getTemporaryDirectory();
          final tempPath = '${dir.path}/$fileName';

          final file = File(tempPath);
          await file.writeAsBytes(fileBytes!.toList());

          print('Temp PDF saved at: $tempPath');
          print('File exists: ${await file.exists()}');

          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => MaterialPDFViewScreen(filePath: tempPath),
            ),
          );

          if (await file.exists()) {
            await file.delete();
            print('Temp file deleted.');
          }
        } catch (e) {
          print('Error opening PDF: $e');
          TSnackbar.errorSnackbar(
              title: 'Error', message: 'Failed to open PDF file.');
        }

        // if (fileBytes != null) {
        //   // Write to temp file for PDF viewer
        //   tempPath = '${(await getTemporaryDirectory()).path}/$fileName';
        //   await File(tempPath).writeAsBytes(fileBytes);
        // }
        // if (tempPath == null) {
        //   throw Exception('No file path available for PDF');
        // }
        // currentFilePath.value = tempPath;
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (context) => MaterialViewScreen(filePath: tempPath),
        //   ),
        // ).then((_) async {
        //   // Clean up temporary file after viewing
        //   if (tempPath != null && await File(tempPath).exists()) {
        //     await File(tempPath).delete();
        //     currentFilePath.value = '';
        //   }
        // });
      } else if (['ppt', 'pptx', 'doc', 'docx'].contains(extension)) {
        // Use WebView with Google Docs Viewer for PPT/Word
        String viewerUrl =
            'https://docs.google.com/gview?embedded=true&url=$url';
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => MaterialWebView(url: viewerUrl),
          ),
        );
      } else if (extension == 'zip') {
        // Ensure we have file content
        final zipBytes = fileBytes ??
            (tempPath != null ? await File(tempPath).readAsBytes() : null);
        if (zipBytes == null) {
          throw Exception('No file content available for ZIP');
        }

        // Extract ZIP and display supported files
        final archive = ZipDecoder().decodeBytes(zipBytes);
        Directory tempDir = await getTemporaryDirectory();
        bool foundSupportedFile = false;
        for (final file in archive) {
          if (file.isFile && file.name.toLowerCase().endsWith('.pdf')) {
            final outputPath = '${tempDir.path}/${file.name}';
            final outputFile = File(outputPath);
            await outputFile.writeAsBytes(file.content as List<int>);
            currentFilePath.value = outputPath;
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    MaterialPDFViewScreen(filePath: outputPath),
              ),
            ).then((_) async {
              // Clean up extracted file
              if (await outputFile.exists()) {
                await outputFile.delete();
                currentFilePath.value = '';
              }
            });
            foundSupportedFile = true;
            break; // Display first PDF for simplicity
          }
        }
        if (!foundSupportedFile) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('No supported files found in ZIP')),
          );
        }
      }

      // Clean up temporary file (if not already handled by navigation)
      if (tempPath != null && await File(tempPath).exists()) {
        await File(tempPath).delete();
        currentFilePath.value = '';
      }
    } catch (e) {
      isProcessing.value = false;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to process file: $e')),
      );
      print("************************************* $e");
    }
  }

  //materialstour
  final materialKey = GlobalKey();
  var isMaterialTouron = false.obs;
  Future<void> MaterialTour(BuildContext context) async {
    final targets = MaterialTourList.getTargets(materialKey: materialKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.materialtour, true);
        isMaterialTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.materialtour, true);
        isMaterialTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //materialsdetailstour
  final materialdetailKey = GlobalKey();
  var isMaterialdetailTouron = false.obs;
  Future<void> MaterialdetailTour(BuildContext context) async {
    final targets =
        MaterialDetailTourList.getTargets(materialdetailKey: materialdetailKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.materialdetailtour, true);
        isMaterialdetailTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.materialdetailtour, true);
        isMaterialdetailTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //downloadtour
  final downloadKey = GlobalKey();
  var isdownloadTouron = false.obs;
  Future<void> DownloadTour(BuildContext context) async {
    final targets = downloadTourList.getTargets(downloadKey: downloadKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.downloadtour, true);
        isdownloadTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.downloadtour, true);
        isdownloadTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
