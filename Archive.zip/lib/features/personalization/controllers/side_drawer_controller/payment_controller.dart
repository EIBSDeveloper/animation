import 'package:eapl_student_app/features/apptour/side/payment/paymenttour.dart';
import 'package:eapl_student_app/features/personalization/models/payment_model.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../data/repository/payment_repository.dart';
import '../../models/payment_list_model.dart';
import '../../screens/razor_payment/razorpay_controller.dart';

class PaymentController extends GetxController
    with GetTickerProviderStateMixin {
  final PaymentRepository courseRepository = Get.put(PaymentRepository());

  // Observable list for courses
  var paymentCourseList = <CoursePaymentModel>[].obs;
  var paymentHistoryList = <PaymentHistoryModel>[].obs;
  var isLoading = false.obs;
  var balanceFee = 0.obs;
  var paidAmount = 0.obs;
  var totalAmount = 0.obs;
  var gstPercentageNew = 18.obs;
  var paymentMode = ["Credit/Debit Card", "UPI", "Net Banking"];
  var selectedPaymentMode = 'UPI'.obs;

  void setPaymentMode(String mode) {
    selectedPaymentMode.value = mode;
  }

  @override
  void onClose() {
    super.onClose();
  }

  @override
  void onInit() {
    super.onInit();
    fetchPayment();
    //fetchListOfPaymentData();
  }

  Future<void> fetchPayment() async {
    try {
      isLoading.value = true;
      final fetchedPayment = await courseRepository
          .fetchPaymentCourseWise(GetStorage().read(TTexts.userID));

      // ✅ Remove duplicates using Map by courseId
      final uniqueMap = <int, CoursePaymentModel>{};
      for (var course in fetchedPayment) {
        uniqueMap[course.courseId] = course; // only one per courseId
      }

      paymentCourseList.assignAll(uniqueMap.values.toList());
    } catch (error) {
      TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
    } finally {
      isLoading.value = false;
    }
  }

  /// ---- Payment list
  var paymentList = <PaymentList>[].obs;

  Future<void> fetchListOfPaymentData(int courseId) async {
    try {
      paymentList.clear();
      isLoading.value = true;
      final reqbody = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": courseId
      };
      final response =
          await THttpHelper.post(APIConstants.paymentListEndPoint, reqbody);

      print("************************* $reqbody");
      print("API Response: $response");

      //final list = response["payment_list"] as List;
      final list = (response["payment_list"] as List?) ?? [];
      if (response != null && response["payment_list"] != null) {
        balanceFee.value = response["Balance_fee"];
        paidAmount.value = response["Paid_fee"];
        totalAmount.value = response["Course_fee"];
        paymentList.value = list.map((e) => PaymentList.fromJson(e)).toList();
      } else {
        paymentList.clear(); // ✅ clear list if API gave null
        print("No payment list found in API response");
      }

      isLoading.value = false;
    } catch (e) {
      print("fetchListOfPaymentData : Error : $e");
      isLoading.value = false;
    }
  }

  Map<String, String> formatInK(dynamic numberInput) {
    double number;

    // Convert input to double safely
    if (numberInput is int) {
      number = numberInput.toDouble();
    } else if (numberInput is double) {
      number = numberInput;
    } else if (numberInput is String) {
      number = double.tryParse(numberInput.trim()) ?? 0;
    } else {
      number = 0;
    }

    String formatNumber(double n) {
      return n.truncateToDouble() == n
          ? n.toStringAsFixed(0)
          : n.toStringAsFixed(1);
    }

    if (number >= 10000000) {
      return {'value': formatNumber(number / 10000000), 'unit': 'cr'};
    } else if (number >= 100000) {
      return {'value': formatNumber(number / 100000), 'unit': 'l'};
    } else if (number >= 1000) {
      return {'value': formatNumber(number / 1000), 'unit': 'k'};
    }

    return {'value': formatNumber(number), 'unit': ''};
  }

  var selectedRedeemIds = <int>{}.obs;
  var totalRedeemValue = 0.obs;

  void toggleRedeemSelection(RedeemModel item) {
    if (selectedRedeemIds.contains(item.couponId)) {
      selectedRedeemIds.remove(item.couponId);
      totalRedeemValue.value -= item.redeemvalue;
    } else {
      selectedRedeemIds.add(item.couponId);
      totalRedeemValue.value += item.redeemvalue;
    }
  }

  void clearRedeemSelection() {
    selectedRedeemIds.clear();
    totalRedeemValue.value = 0;
  }

/*  Future<void> applyCoupon({
    required PaymentList payment, // pass the payment object here
  }) async {
    try {
      final customerId = GetStorage().read(TTexts.userID);
      final couponIds = selectedRedeemIds.toList();
      final couponAmount = totalRedeemValue.value;

      if (couponIds.isEmpty) {
        TSnackbar.errorSnackbar(
          title: "No Coupon Selected",
          message: "Please select a coupon first.",
        );
        return;
      }

      final body = {
        "customer_id": customerId,
        "payment_id":
            payment.sno, // use payment.sno instead of undefined paymentId
        "course_id": payment.courseId,
        "coupon_amount": couponAmount,
        "coupon_ids": couponIds,
      };

      print("📤 Sending Coupon Request: $body");

      final response =
          await THttpHelper.post(APIConstants.couponamountendpoint, body);

      print("✅ Coupon Response: $response");

      if (response["status"] == "success") {
        final data = response["data"];
        final originalAmount = data["original_amount"];
        final payableAmount = data["payable_amount"];

        // 🎉 Show success dialog
        Get.dialog(
          AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            title: const Text("Coupon Applied Successfully"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Original Amount: ₹$originalAmount",
                  style: const TextStyle(
                    decoration: TextDecoration.lineThrough,
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Payable Amount: ₹$payableAmount",
                  style: const TextStyle(
                    fontSize: 18,
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Get.back(); // close coupon dialog

                  // 3️⃣ Redirect to Razorpay
                  final razorController = Get.put(RazorPaymentController());
                  razorController.openCheckout(
                    payment, // pass the same payment object
                    Get.find<PaymentController>().selectedPaymentMode.value,
                    directAmount: payableAmount.toDouble(), // use API amount
                  );
                },
                child: const Text(
                  "Proceed to Pay",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              )
            ],
          ),
        );
      } else {
        TSnackbar.errorSnackbar(
            title: "Coupon Failed", message: response["message"]);
      }
    } catch (e) {
      print("❌ applyCoupon Error: $e");
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    }
  }*/
  Future<void> applyCoupon({
    required PaymentList payment, // pass the selected payment object
  }) async {
    try {
      final customerId = GetStorage().read(TTexts.userID);
      final couponIds = selectedRedeemIds.toList();
      final couponAmount = totalRedeemValue.value;

      if (couponIds.isEmpty) {
        TSnackbar.errorSnackbar(
          title: "No Coupon Selected",
          message: "Please select a coupon first.",
        );
        return;
      }

      final body = {
        "customer_id": customerId,
        "payment_id": payment.sno,
        "course_id": payment.courseId,
        "coupon_amount": couponAmount,
        "coupon_ids": couponIds,
      };

      print("📤 Sending Coupon Request: $body");

      final response =
          await THttpHelper.post(APIConstants.couponamountendpoint, body);

      print("✅ Coupon Response: $response");

      if (response["status"] == "success") {
        final data = response["data"];
        final originalAmount = data["original_amount"];
        final payableAmount = data["payable_amount"];

        // 🎉 Show success dialog
        /* Get.dialog(
          AlertDialog(
            backgroundColor: TColors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            title: const Text("Coupon Applied Successfully"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Original Amount: ₹$originalAmount",
                  style: const TextStyle(
                    decoration: TextDecoration.lineThrough,
                    color: Colors.red,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Payable Amount: ₹$payableAmount",
                  style: const TextStyle(
                    fontSize: 20,
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            actions: [
              */ /* TextButton(
                onPressed: () {
                  Get.back(); // close coupon dialog

                  // ✅ Open Razorpay checkout
                  final razorController = Get.put(RazorPaymentController());
                  razorController.openCheckout(
                    payment,
                    Get.find<PaymentController>().selectedPaymentMode.value,
                    directAmount: payableAmount.toDouble(),
                  );
                },
                child: const Text(
                  "Proceed to Pay",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              )*/ /*
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: TColors.primary, // Primary background
                  foregroundColor: Colors.white, // Text color
                  padding:
                      const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: () {
                  Get.back(); // close coupon dialog

                  // Redirect to Razorpay
                  final razorController = Get.put(RazorPaymentController());
                  razorController.openCheckout(
                    payment, // pass the same payment object
                    Get.find<PaymentController>().selectedPaymentMode.value,
                    directAmount: payableAmount.toDouble(), // use API amount
                  );
                },
                child: const Text(
                  "Pay",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        );*/
        Get.dialog(
          Dialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            backgroundColor: Colors.white,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  colors: [Color(0xFFF9F9F9), Color(0xFFFFFFFF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // 🟢 Success Icon
                  Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.green,
                    ),
                    padding: const EdgeInsets.all(12),
                    child: const Icon(
                      Icons.check_rounded,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 🎉 Title
                  const Text(
                    "Coupon Applied!",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // 💬 Description
                  Text(
                    "Your discount has been successfully applied.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[700],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // 💰 Amount Details
                  Column(
                    children: [
                      Text(
                        "Original Amount: ₹$originalAmount",
                        style: const TextStyle(
                          decoration: TextDecoration.lineThrough,
                          color: Colors.redAccent,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        "Payable Amount: ₹$payableAmount",
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // 💳 Pay Button
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: TColors.primary, // premium green
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 40),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      elevation: 4,
                    ),
                    onPressed: () {
                      Get.back();

                      final razorController = Get.put(RazorPaymentController());
                      razorController.openCheckout(
                        payment,
                        Get.find<PaymentController>().selectedPaymentMode.value,
                        directAmount: payableAmount.toDouble(),
                      );
                    },
                    child: const Text(
                      "Proceed to Pay",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
          ),
        );
      } else {
        TSnackbar.errorSnackbar(
            title: "Coupon Failed", message: response["message"]);
      }
    } catch (e) {
      print("❌ applyCoupon Error: $e");
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    }
  }

  //paymenttour
  final paymentcardKey = GlobalKey();

  var isPaymentTouron = false.obs;
  Future<void> PaymentTour(BuildContext context) async {
    final targets = PaymentTourList.getTargets(paymentcardKey: paymentcardKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.paymenttour, true);
        isPaymentTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.paymenttour, true);
        isPaymentTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //paymenthistorytour
  final payKey = GlobalKey();

  var isPaymenthistoryTouron = false.obs;
  Future<void> PaymenthistoryTour(BuildContext context) async {
    final targets = PaymenthistoryTourList.getTargets(paykey: payKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.paymenthistorytour, true);
        isPaymenthistoryTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.paymenthistorytour, true);
        isPaymenthistoryTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    // 👇 Wait until widget tree is ready before showing
    WidgetsBinding.instance.addPostFrameCallback((_) {
      tutorial.show(context: context);
    });
  }
}
