// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:razorpay_flutter/razorpay_flutter.dart';
//
// class RazorPaymentController extends GetxController {
//   late Razorpay _razorpay;
//   TextEditingController payAmount = TextEditingController();
//
//   @override
//   void onInit() {
//     super.onInit();
//     _razorpay = Razorpay();
//     _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
//     _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
//     _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
//   }
//
//   @override
//   void onClose() {
//     _razorpay.clear(); // Clear listeners
//     super.onClose();
//   }
//
//   // void openCheckout({bool useQR = false}) {
//   //   var options = {
//   //     'key': 'rzp_test_hLulq3XQwy8axr', // Replace with your Razorpay Test Key
//   //     // 'key': 'rzp_test_cjiZ7kyueJCUGb', // Replace with your Razorpay Test Key
//   //     'amount': double.parse(payAmount.text) *
//   //         100, // Amount in paise (e.g., 50000 = ₹500)
//   //     'currency': 'INR',
//   //     'name': 'Test App',
//   //     'description': 'Payment for the Test Product',
//   //     'prefill': {
//   //       'contact': '9876543210',
//   //       'email': 'test@example.com',
//   //     },
//   //     'external': {
//   //       'wallets': ['paytm'],
//   //     },
//   //     if (useQR) 'method': ['upi'], // Use UPI QR Code Payment
//   //   };
//   //
//   //   try {
//   //     _razorpay.open(options);
//   //   } catch (e) {
//   //     debugPrint('Error: $e');
//   //   }
//   // }
//   void openCheckout({bool useQR = false}) {
//     double amount;
//
//     try {
//       final cleanedText = payAmount.text.replaceAll(',', '').trim();
//       amount = double.parse(cleanedText) * 100;
//     } catch (e) {
//       debugPrint('Amount parsing error: $e');
//       // ScaffoldMessenger.of(context).showSnackBar(
//       //   const SnackBar(content: Text("Invalid amount entered")),
//       // );
//       return; // Stop execution if parsing fails
//     }
//
//     var options = {
//       'key': 'rzp_test_hLulq3XQwy8axr',
//       'amount': amount.toInt(), // Razorpay needs amount as an integer
//       'currency': 'INR',
//       'name': 'Test App',
//       'description': 'Payment for the Test Product',
//       'prefill': {
//         'contact': '9876543210',
//         'email': 'test@example.com',
//       },
//       'external': {
//         'wallets': ['paytm'],
//       },
//       if (useQR) 'method': ['upi'],
//     };
//
//     try {
//       _razorpay.open(options);
//     } catch (e) {
//       debugPrint('Razorpay open error: $e');
//     }
//   }
//
//
//   void _handlePaymentSuccess(PaymentSuccessResponse response) {
//     Get.snackbar("Payment Successful", "Payment ID: ${response.paymentId}",
//         snackPosition: SnackPosition.BOTTOM,
//         backgroundColor: Colors.green,
//         colorText: Colors.white);
//   }
//
//   void _handlePaymentError(PaymentFailureResponse response) {
//     Get.snackbar("Payment Failed",
//         "Error Code: ${response.code}\nMessage: ${response.message}",
//         snackPosition: SnackPosition.BOTTOM,
//         backgroundColor: Colors.red,
//         colorText: Colors.white);
//   }
//
//   void _handleExternalWallet(ExternalWalletResponse response) {
//     Get.snackbar("External Wallet", "Wallet: ${response.walletName}",
//         snackPosition: SnackPosition.BOTTOM,
//         backgroundColor: Colors.blue,
//         colorText: Colors.white);
//   }
// }
// lib/features/personalization/screens/razor_payment/razorpay_controller.dart

/// ============================= Both Phone Viewimport 'package:eapl_student_app/features/personalization/models/payment_list_model.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/payment_controller.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/image_strings.dart' show TImages;
import '../../../../utils/constants/text_strings.dart';
import '../../models/payment_list_model.dart';
import '../side_drawer_menu/notifications/notification_controller.dart';

class RazorPaymentController extends GetxController {
  late Razorpay _razorpay;
  final TextEditingController payAmount =
      TextEditingController(); // Default ₹500
  final TextEditingController paymentDescription =
      TextEditingController(); // Default ₹500
  var paymentCharCount = 0.obs;
  @override
  void onInit() {
    super.onInit();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void onClose() {
    _razorpay.clear();
    super.onClose();
  }

  late PaymentList currentPaymentValue;
  late String currentPaymentMode;

/*  void openCheckout(PaymentList paymentValues, String paymentMode,
      {bool useQR = false}) {
    double amount;

    try {
      final cleaned = payAmount.text.replaceAll(',', '').trim();
      amount = double.parse(cleaned) * 100;
    } catch (e) {
      Get.snackbar("Invalid Amount", "Please enter a valid number");
      return;
    }
    currentPaymentValue = paymentValues;
    currentPaymentMode = paymentMode;
    var options = {
      'key': 'rzp_test_hLulq3XQwy8axr',
      'amount': amount.toInt(),
      'currency': 'INR',
      'name': GetStorage().read(TTexts.userName),
      'description': paymentDescription.text,
      'prefill': {
        'contact': GetStorage().read(TTexts.userMobNo),
        'email': GetStorage().read(TTexts.userEmailId),
      },
      'external': {
        'wallets': ['paytm'],
      },
      if (useQR) 'method': ['upi'],
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('Error: $e');
    }
  }*/
  void openCheckout(PaymentList paymentValues, String paymentMode,
      {double? directAmount, bool useQR = false}) {
    double amount;

    try {
      if (directAmount != null) {
        amount = directAmount * 100; // convert to paise
      } else {
        final cleaned = payAmount.text.replaceAll(',', '').trim();
        amount = double.parse(cleaned) * 100;
      }
    } catch (e) {
      Get.snackbar("Invalid Amount", "Please enter a valid number");
      return;
    }

    currentPaymentValue = paymentValues;
    currentPaymentMode = paymentMode;

    var options = {
      'key': paymentValues.keyId, // 🔑 Dynamically from API/model
      'amount': amount.toInt(),
      'currency': 'INR',
      'name': GetStorage().read(TTexts.userName),
      'description': paymentDescription.text,
      'prefill': {
        'contact': GetStorage().read(TTexts.userMobNo),
        'email': GetStorage().read(TTexts.userEmailId),
      },
      'external': {
        'wallets': ['paytm'],
      },
      if (useQR) 'method': ['upi'],
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('Error: $e');
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    final paymentcontroller = Get.find<PaymentController>();
    final couponAmount = paymentcontroller.totalRedeemValue.value;
    final couponIds = paymentcontroller.selectedRedeemIds.toList();
    savePaymentData(
      currentPaymentValue,
      currentPaymentMode,
      response,
      couponAmount: couponAmount.toDouble(),
      couponIds: couponIds,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (Get.isDialogOpen == false) {
        Get.dialog(
          WillPopScope(
            onWillPop: () async => false,
            child: Dialog(
              backgroundColor: TColors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset(
                      TImages.paymentsuccess,
                      width: 150,
                      height: 150,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "Payment Successful!",
                      style: GoogleFonts.prompt(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: TColors.primary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Payment ID: ${response.paymentId}",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.prompt(
                        fontSize: 14,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          barrierDismissible: false,
        );

        Future.delayed(const Duration(seconds: 3), () {
          if (Get.isDialogOpen == true) {
            Get.back();
          }
        });

        Fluttertoast.showToast(
          msg: "Payment Successful! ID: ${response.paymentId}",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: TColors.primary,
          textColor: Colors.white,
          fontSize: 14.0,
        );
        // ✅ Refresh notifications
        try {
          final notificationController = Get.find<NotificationController>();
          await notificationController.fetchNotificationList();
          final paymentController = Get.find<PaymentController>();
          await paymentController
              .fetchListOfPaymentData(currentPaymentValue.courseId);
          final appbarController = Get.find<AppbarController>();
          appbarController.incrementNotify();
        } catch (e) {
          print("Error refreshing notifications: $e");
        }
      }
    });
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(
      msg: "Payment Failed",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 14.0,
    );

    print(response.message);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Get.snackbar("Wallet Selected", response.walletName ?? "Unknown");
  }

  Future<void> savePaymentData(
    PaymentList paymentValues,
    String paymentMode,
    PaymentSuccessResponse response, {
    double? couponAmount,
    List<int>? couponIds,
  }) async {
    try {
      print("******************* ${response.paymentId}");
      final reqBody = {
        "customer_id": GetStorage().read(TTexts.userID),
        "course_id": paymentValues.courseId,
        "payment_id": paymentValues.sno,
        "pay_mode": paymentMode,
        "pay_amount": payAmount.text,
        "coupon_amount": couponAmount ?? 0,
        "coupon_ids": couponIds ?? [],
        "transaction": {
          "payment_amount":
              (double.parse(payAmount.text.replaceAll(',', '').trim()))
                  .toStringAsFixed(2),
          "receipt_id": "",
          "Mobile No": GetStorage().read(TTexts.userMobNo),
          "Transaction ID": response.paymentId,
          "UPI ID": "",
          "Description": paymentDescription.text,
          "Other Attachment": ""
        }
      };
      final paymentSave =
          await THttpHelper.post(APIConstants.paymentSaveEndPoint, reqBody);
      payAmount.text = "";
      paymentDescription.text = "";

      //TSnackbar.successSnackbar(title: "Course payment paid successfully");
      // paymentController.clearPaymentData();
    } catch (e) {
      TSnackbar.errorSnackbar(title: "Payment Failed");
      print("savePaymentData : Error : $e");
    }
  }
}

/// ============================ weburl view and mobile view
// import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/payment_controller.dart';
// import 'package:eapl_student_app/features/personalization/models/payment_list_model.dart';
// import 'package:eapl_student_app/utils/http/api_constants.dart';
// import 'package:eapl_student_app/utils/http/http_client.dart';
// import 'package:eapl_student_app/utils/loaders/loaders.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:razorpay_flutter/razorpay_flutter.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// import '../../../../utils/constants/text_strings.dart';
//
// class RazorPaymentController extends GetxController {
//   late Razorpay _razorpay;
//   final TextEditingController payAmount = TextEditingController();
//   final TextEditingController paymentDescription = TextEditingController();
//   late PaymentList currentPaymentValue;
//   late String currentPaymentMode;
//
//   @override
//   void onInit() {
//     super.onInit();
//     _razorpay = Razorpay();
//     _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
//     _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
//     _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
//   }
//
//   @override
//   void onClose() {
//     _razorpay.clear();
//     super.onClose();
//   }
//
//   bool isTablet(BuildContext context) {
//     final double shortestSide = MediaQuery.of(context).size.shortestSide;
//     return shortestSide > 600;
//   }
//
//   String generateRazorpayCheckoutUrl(Map<String, dynamic> options) {
//     final key =  'rzp_test_hLulq3XQwy8axr';
//     final amount = options['amount'];
//     final currency = options['currency'];
//     final name = options['name'];
//     final description = options['description'];
//     final contact = options['prefill']['contact'];
//     final email = options['prefill']['email'];
//     return 'https://api.razorpay.com/v1/checkout/embedded?'
//         'key_id=$key&'
//         'amount=$amount&'
//         'currency=$currency&'
//         'name=$name&'
//         'description=$description&'
//         'prefill[contact]=$contact&'
//         'prefill[email]=$email&'
//         'callback_url=${Uri.encodeComponent('https://your-server.com/razorpay-callback')}&'
//         'redirect=true';
//   }
//
//   void openCheckout(PaymentList paymentValues, String paymentMode, {bool useQR = false}) async {
//     double amount;
//
//     try {
//       final cleaned = payAmount.text.replaceAll(',', '').trim();
//       amount = double.parse(cleaned) * 100;
//     } catch (e) {
//       Get.snackbar("Invalid Amount", "Please enter a valid number");
//       return;
//     }
//
//     currentPaymentValue = paymentValues;
//     currentPaymentMode = paymentMode;
//
//     var options = {
//       'key': 'rzp_test_hLulq3XQwy8axr',
//       'amount': amount.toInt(),
//       'currency': 'INR',
//       'name': GetStorage().read(TTexts.userName),
//       'description': paymentDescription.text,
//       'prefill': {
//         'contact': GetStorage().read(TTexts.userMobNo),
//         'email': GetStorage().read(TTexts.userEmailId),
//       },
//       'external': {
//         'wallets': ['paytm'],
//       },
//       if (useQR) 'method': ['upi'],
//       'modal': {
//         'backdropclose': false,
//         'escape': false,
//         'handleback': false,
//         'animation': true,
//       },
//       'theme': {
//         'color': '#3399cc',
//       },
//     };
//
//     try {
//       if (isTablet(Get.context!)) {
//         final checkoutUrl = generateRazorpayCheckoutUrl(options);
//         final uri = Uri.parse(checkoutUrl);
//         if (await canLaunchUrl(uri)) {
//           await launchUrl(uri, mode: LaunchMode.externalApplication);
//           await pollPaymentStatus(paymentValues, paymentMode);
//         } else {
//           Get.snackbar("Error", "Cannot launch browser");
//         }
//       } else {
//         _razorpay.open(options);
//       }
//     } catch (e) {
//       debugPrint('Error: $e');
//       Get.snackbar("Error", "Failed to open Razorpay checkout");
//     }
//   }
//
//   Future<void> pollPaymentStatus(PaymentList paymentValues, String paymentMode) async {
//     try {
//       // Replace with your server’s payment status endpoint
//       final response = await THttpHelper.get('https://your-server.com/check-payment?customer_id=${GetStorage().read(TTexts.userID)}');
//       if (response['status'] == 'success') {
//         savePaymentData(
//           paymentValues,
//           paymentMode,
//           PaymentSuccessResponse(response['payment_id'], response['order_id'], response['signature'], null),
//         );
//         Get.snackbar("Success", "Payment ID: ${response['payment_id']}");
//       } else {
//         Get.snackbar("Failed", "Payment failed or was cancelled");
//       }
//     } catch (e) {
//       debugPrint('Polling error: $e');
//       Get.snackbar("Error", "Failed to verify payment status");
//     }
//   }
//
//   void _handlePaymentSuccess(PaymentSuccessResponse response) {
//     savePaymentData(currentPaymentValue, currentPaymentMode, response);
//     Get.snackbar("Success", "Payment ID: ${response.paymentId}");
//   }
//
//   void _handlePaymentError(PaymentFailureResponse response) {
//     Get.snackbar("Failed", "${response.message}");
//   }
//
//   void _handleExternalWallet(ExternalWalletResponse response) {
//     Get.snackbar("Wallet Selected", response.walletName ?? "Unknown");
//   }
//
//   Future<void> savePaymentData(
//       PaymentList paymentValues,
//       String paymentMode,
//       PaymentSuccessResponse response,
//       ) async {
//     try {
//       final reqBody = {
//         "customer_id": GetStorage().read(TTexts.userID),
//         "course_id": paymentValues.courseId,
//         "payment_id": paymentValues.paymentId,
//         "pay_mode": paymentMode,
//         "pay_amount": payAmount.text,
//         "transaction": {
//           "payment_amount": (double.parse(payAmount.text.replaceAll(',', '').trim())).toStringAsFixed(2),
//           "receipt_id": "",
//           "Mobile No": GetStorage().read(TTexts.userMobNo),
//           "Transaction ID": response.paymentId,
//           "UPI ID": "",
//           "Description": paymentDescription.text,
//           "Other Attachment": ""
//         }
//       };
//       final paymentSave = await THttpHelper.post(APIConstants.paymentSaveEndPoint, reqBody);
//       payAmount.text = "";
//       paymentDescription.text = "";
//       TSnackbar.successSnackbar(title: "Course payment paid successfully");
//     } catch (e) {
//       TSnackbar.errorSnackbar(title: "Payment Failed");
//       print("savePaymentData : Error : $e");
//     }
//   }
// }
