// // import 'package:eapl_student_app/features/personalization/screens/razor_payment/razorpay_controller.dart';
// // import 'package:flutter/material.dart';
// // import 'package:get/get.dart';
// //
// // class PaymentPage extends StatelessWidget {
// //   final RazorPaymentController paymentController =
// //       Get.put(RazorPaymentController());
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text('Payment Page'),
// //       ),
// //       body: Center(
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           children: [
// //             ElevatedButton(
// //               onPressed: () => paymentController.openCheckout(),
// //               child: Text('Pay ₹500 (Card/UPI/Wallet)'),
// //             ),
// //             SizedBox(height: 20),
// //             ElevatedButton(
// //               onPressed: () => paymentController.openCheckout(
// //                 useQR: true,
// //               ),
// //               child: Text('Pay ₹500 via QR Code'),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
// // lib/features/personalization/screens/razor_payment/payment_page.dart
//
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get_storage/get_storage.dart';
// import '../../../../utils/constants/text_strings.dart';
// import 'razorpay_controller.dart';
// import 'package:flutter/services.dart';
//
// class PaymentPage extends StatelessWidget {
//   final RazorPaymentController paymentController =
//   Get.put(RazorPaymentController());
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Payment Page'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Center(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const Text(
//                 'Enter Amount (INR)',
//                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//               ),
//               const SizedBox(height: 10),
//               TextField(
//                 controller: paymentController.payAmount,
//                 keyboardType: TextInputType.numberWithOptions(decimal: true),
//                 inputFormatters: [
//                   FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
//                 ],
//                 decoration: const InputDecoration(
//                   border: OutlineInputBorder(),
//                   hintText: 'e.g. 500',
//                 ),
//               ),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: () => paymentController.openCheckout(customerName:  GetStorage().read(TTexts.userName), accountHolderMailId: GetStorage().read(TTexts.userEmailId), accountHolderPNo:  GetStorage().read(TTexts.userMobNo)),
//                 child: const Text('Pay with Razorpay (Card/UPI/Wallet)'),
//               ),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: () => paymentController.openCheckout(useQR: true,customerName:  GetStorage().read(TTexts.userName), accountHolderMailId: GetStorage().read(TTexts.userEmailId), accountHolderPNo:  GetStorage().read(TTexts.userMobNo) ),
//                 child: const Text('Pay with QR Code'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
