/*import 'package:eapl_student_app/common/widget/app_bar/appbar_controller.dart';
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';

import '../../../../../../utils/constants/path_provider.dart';
import '../../../../../common/widget/course/coursewithpaymentcard.dart';
import '../../../controllers/side_drawer_controller/batch_controller.dart';
import '../../../controllers/side_drawer_controller/course_controller.dart';
import '../../../controllers/side_drawer_controller/payment_controller.dart';
import '../../../models/payment_model.dart';
import '../../side_drawer_menu/daily_attendance/widget/studentfeedbackdialog.dart';

class DashBoard extends StatelessWidget {
  final courseController = Get.put(CourseController());
  DashBoard({super.key});

  @override
  Widget build(BuildContext context) {
    final appbarcontroller = Get.put(AppbarController());
    final batchController = Get.put(BatchController());
    final paymentController = Get.put(PaymentController());

    return RefreshIndicator(
      onRefresh: () => appbarcontroller.fetchPointsDetails(),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        child: Obx(
          () {
            if (courseController.iscourseLoading.value ||
                paymentController.isLoading.value) {
              return const TAnimationLoaderWidget(
                text: "Loading...",
                animation: TImages.pencilAnimation,
              );
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Reminder Banner
                Obx(() {
                  if (batchController.showReminder.value) {
                    return AnimatedOpacity(
                      opacity: batchController.blink.value ? 1.0 : 0.3,
                      duration: const Duration(milliseconds: 600),
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 12),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.redAccent),
                        ),
                        child: Column(
                          children: [
                            Text(
                              batchController.reminderMessage.value,
                              style: const TextStyle(
                                color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 8),
                            ElevatedButton.icon(
                              onPressed: () {
                                final attendance =
                                    batchController.alertAttendanceModel.value;
                                if (attendance != null) {
                                  Get.dialog(
                                    FeedbackDialog(
                                      date: attendance.attDate,
                                      attendanceModel: attendance,
                                    ),
                                    barrierDismissible: false,
                                  );
                                } else {
                                  Get.snackbar(
                                    "No Data",
                                    "No attendance details found for feedback.",
                                    backgroundColor: Colors.redAccent,
                                    colorText: Colors.white,
                                  );
                                }
                              },
                              icon: const Icon(Icons.feedback,
                                  color: Colors.white),
                              label: const Text("Add Feedback",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold)),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.redAccent,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                }),

                const SizedBox(height: 15),

                ///================= Body of the dashboard====================///
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Text("My Courses", style: AppTextStyles.title),
                        ),
                        const SizedBox(height: 10),
                        GridView.builder(
                          itemCount: courseController.coursesList.length,
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 1,
                            mainAxisExtent: THelperFunctions.screenWidth() > 600
                                ? 260
                                : 255,
                            mainAxisSpacing: TSizes.sm,
                            crossAxisSpacing: TSizes.gridViewSpacing,
                            childAspectRatio:
                                2.5, // Adjust ratio to fit content
                          ),
                          itemBuilder: (_, index) {
                            final course = courseController.coursesList[index];

                            // Find paymentModel for this course if exists
                            final payment = paymentController.paymentCourseList
                                .firstWhereOrNull(
                                    (p) => p.courseId == course.courseSno);

                            // If no payment found, provide default 0 values
                            final paymentModel = payment ??
                                CoursePaymentModel(
                                  courseId: course.courseSno,
                                  courseName: course.courseName,
                                  totalAmount: 0,
                                  paidAmount: 0,
                                  balanceFee: 0,
                                  customerId:
                                      0, // ✅ provide default value instead of null
                                  paymentHistory: [],
                                );

                            return CourseWithPaymentCard(
                              courseDetails: course,
                              paymentModel: paymentModel,
                            );
                          },
                        ),
                        SizedBox(height: TSizes.spaceBtwItems),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}*/

import 'package:eapl_student_app/common/widget/app_bar/appbar_controller.dart';
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';

import '../../../../../../utils/constants/path_provider.dart';
import '../../../controllers/side_drawer_controller/batch_controller.dart';
import '../../../controllers/side_drawer_controller/course_controller.dart';
import '../../../controllers/side_drawer_controller/payment_controller.dart';
import '../../../controllers/side_drawer_controller/placement_controller.dart';
import '../../side_drawer_menu/course/widget/course_list_card.dart';
import '../../side_drawer_menu/daily_attendance/widget/studentfeedbackdialog.dart';
import '../../side_drawer_menu/payment/widget/payment_list_cart.dart';
import '../../side_drawer_menu/placement/myjobcard.dart';

/*class DashBoard extends StatelessWidget {
  final courseController = Get.put(CourseController());
  DashBoard({super.key});

  @override
  Widget build(BuildContext context) {
    final appbarcontroller = Get.put(AppbarController());
    final batchController = Get.put(BatchController());
    final paymentController = Get.put(PaymentController());
    return RefreshIndicator(
      onRefresh: () {
        return appbarcontroller.fetchPointsDetails();
      },
      child: Container(
        margin: EdgeInsets.only(left: 6, right: 6),
        child: Obx(
          () {
            if (courseController.iscourseLoading.value == true ||
                paymentController.isLoading.value) {
              return const TAnimationLoaderWidget(
                text: "Loading...",
                animation: TImages.pencilAnimation,
              );
            }
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Obx(() {
                  if (batchController.showReminder.value) {
                    return AnimatedOpacity(
                      opacity: batchController.blink.value ? 1.0 : 0.3,
                      duration: const Duration(milliseconds: 600),
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 12),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.redAccent),
                        ),
                        child: Text(
                          batchController.reminderMessage.value,
                          style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                }),

                ///================= Body of the dashboard====================///
                SizedBox(
                  height: 15,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Row(
                            children: [
                              Text("My Courses", style: AppTextStyles.title),
                            ],
                          ),
                        ),

                        /// Course card

                        GridView.builder(
                          itemCount: courseController.coursesList.length,
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 1,
                                  mainAxisExtent:
                                      THelperFunctions.screenWidth() > 600
                                          ? 260
                                          : 160,
                                  mainAxisSpacing: TSizes.sm,
                                  crossAxisSpacing: TSizes.gridViewSpacing),
                          itemBuilder: (_, index) => CourseCard(
                            courseDetails: courseController.coursesList[index],
                            statusPercentage: 0.5,
                            statusText: 'On Hold',
                          ),
                        ),

                        SizedBox(height: TSizes.spaceBtwItems),
                        Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 5),
                              child: Row(
                                children: [
                                  Text("Payment Details",
                                      style: AppTextStyles.title),
                                ],
                              ),
                            ),
                            const SizedBox(height: TSizes.sm),

                            /// ✅ Conditional: Show List OR "No data" message
                            Obx(() {
                              final paymentList =
                                  paymentController.paymentCourseList;
                              if (paymentList.isEmpty) {
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 40.0),
                                  child: Center(
                                    child: Text(
                                      "No payment details found",
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium,
                                    ),
                                  ),
                                );
                              }

                              return Column(
                                children: [
                                  ...paymentList.map((payment) {
                                    return Padding(
                                      padding: const EdgeInsets.only(
                                          bottom: TSizes.sm),
                                      child: PaymentDetailCard(
                                          paymentModel: payment),
                                    );
                                  })
                                ],
                              );
                            }),

                            const SizedBox(height: TSizes.xs),
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              ],
            );
          },
        ),
      ),
    );
  }
}*/
class DashBoard extends StatelessWidget {
  final courseController = Get.put(CourseController());
  final paymentController = Get.put(PaymentController());

  DashBoard({super.key});

  @override
  Widget build(BuildContext context) {
    final appbarController = Get.put(AppbarController());
    final batchController = Get.put(BatchController());

    return RefreshIndicator(
      onRefresh: () => appbarController.fetchPointsDetails(),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        child: Obx(() {
          if (courseController.iscourseLoading.value ||
              paymentController.isLoading.value) {
            return const TAnimationLoaderWidget(
              text: "Loading...",
              animation: TImages.pencilAnimation,
            );
          }

          final courses = courseController.coursesList ?? [];
          final payments = paymentController.paymentCourseList ?? [];

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Reminder
                /*Obx(() {
                  if (batchController.showReminder.value) {
                    return AnimatedOpacity(
                      opacity: batchController.blink.value ? 1.0 : 0.3,
                      duration: const Duration(milliseconds: 600),
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.redAccent),
                        ),
                        child: Text(
                          batchController.reminderMessage.value,
                          style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                }),*/
                /// Reminder Banner
                Obx(() {
                  if (batchController.showReminder.value) {
                    return AnimatedOpacity(
                      opacity: batchController.blink.value ? 1.0 : 0.3,
                      duration: const Duration(milliseconds: 600),
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 12),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.redAccent),
                        ),
                        child: Column(
                          children: [
                            Text(
                              batchController.reminderMessage.value,
                              style: const TextStyle(
                                color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 8),
                            ElevatedButton.icon(
                              onPressed: () {
                                final attendance =
                                    batchController.alertAttendanceModel.value;
                                if (attendance != null) {
                                  Get.dialog(
                                    FeedbackDialog(
                                      date: attendance.attDate,
                                      attendanceModel: attendance,
                                    ),
                                    barrierDismissible: false,
                                  );
                                } else {
                                  Get.snackbar(
                                    "No Data",
                                    "No attendance details found for feedback.",
                                    backgroundColor: Colors.redAccent,
                                    colorText: Colors.white,
                                  );
                                }
                              },
                              icon: const Icon(Icons.feedback,
                                  color: Colors.white),
                              label: const Text("Add Feedback",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold)),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.redAccent,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                }),

                const SizedBox(height: 15),

                const SizedBox(height: 10),

                // Courses Title
                Padding(
                  padding: const EdgeInsets.only(left: 5),
                  child: Text("My Courses", style: AppTextStyles.title),
                ),
                const SizedBox(height: 8),

                // Courses Horizontal List
                SizedBox(
                  height: 160,
                  child: courses.isEmpty
                      ? Center(
                          child: Text(
                            "No courses found",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        )
                      : ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: courses.length,
                          itemBuilder: (_, index) {
                            final course = courses[index];
                            return Padding(
                              padding:
                                  const EdgeInsets.only(right: 16, left: 5),
                              child: SizedBox(
                                width: 360, // increased width of each card
                                child: CourseCard(
                                  courseDetails: course,
                                  statusPercentage: 0.5,
                                  statusText: 'On Hold',
                                ),
                              ),
                            );
                          },
                        ),
                ),
                const SizedBox(height: 20),

                // Payment Title
                Padding(
                  padding: const EdgeInsets.only(left: 5),
                  child: Text("Payment Details", style: AppTextStyles.title),
                ),
                const SizedBox(height: 8),

                // Payments Horizontal List
                SizedBox(
                  height: 185, // height of card container
                  child: payments.isEmpty
                      ? Center(
                          child: Text(
                            "No payment details found",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        )
                      : ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: payments.length,
                          itemBuilder: (_, index) {
                            final payment = payments[index];
                            return Padding(
                              padding:
                                  const EdgeInsets.only(right: 16, left: 5),
                              child: SizedBox(
                                width: 360, // same width as course cards
                                child: PaymentDetailCard(
                                  paymentModel: payment,
                                ),
                              ),
                            );
                          },
                        ),
                ),
                const SizedBox(height: 20),

                Padding(
                  padding: const EdgeInsets.only(left: 5),
                  child: Text("My Jobs", style: AppTextStyles.title),
                ),
                const SizedBox(height: 8),

                SizedBox(
                  height: 175, // height of each card
                  child: Obx(() {
                    final placementController = Get.find<PlacementController>();
                    final jobs = placementController.placementinterviewList;

                    if (placementController.isinterviewLoading.value) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (jobs.isEmpty) {
                      return Center(
                        child: Text(
                          "No jobs available",
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      );
                    }

                    return ListView.builder(
                      scrollDirection: Axis.horizontal, // horizontal scroll
                      itemCount: jobs.length,
                      itemBuilder: (context, index) {
                        final job = jobs[index];
                        return Padding(
                          padding: const EdgeInsets.only(right: 16, left: 5),
                          child: SizedBox(
                            width: 360, // same width as course cards
                            child: Myjobcard(
                              myplacement: job,
                              index: index,
                            ),
                          ),
                        );
                      },
                    );
                  }),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
