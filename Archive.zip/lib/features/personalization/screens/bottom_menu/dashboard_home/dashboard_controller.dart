// import 'package:eapl_student_app/utils/constants/path_provider.dart';
// import 'package:get_storage/get_storage.dart';
//
// import '../../../../../data/repository/course_repository.dart';
// import '../../../../../utils/constants/text_strings.dart';
// import '../../../../../utils/loaders/loaders.dart';
// import '../../../models/course_model.dart';
//
// class DashboardController extends GetxController {
//   var iscourseLoading = false.obs;
//   var dashcoursesList = <CourseDetailModel>[].obs;
//   final CourseRepository courseRepository = Get.put(CourseRepository());
//
//   @override
//   void onInit() {
//     super.onInit();
//     fetchCourses();
//   }
//
//   /// Fetch All Courses (Unrelated to this feature, kept intact)
//   Future<void> fetchCourses({int? limit}) async {
//     try {
//       iscourseLoading.value = true;
//       final fetchedCourses = await courseRepository
//           .fetchCourseDetails(GetStorage().read(TTexts.userID), limit: limit);
//       dashcoursesList.assignAll(fetchedCourses);
//     } catch (error) {
//       TSnackbar.errorSnackbar(title: "Oh Snap!", message: error.toString());
//     } finally {
//       iscourseLoading.value = false;
//     }
//   }
// }
