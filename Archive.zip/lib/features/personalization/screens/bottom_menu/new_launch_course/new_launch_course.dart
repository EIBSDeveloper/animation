import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/course_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/bottom_menu/new_launch_course/widget/existing_course_card.dart';
import 'package:eapl_student_app/features/personalization/screens/bottom_menu/new_launch_course/widget/interested_course_card.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../../utils/constants/path_provider.dart';
import '../../../../../utils/constants/text_strings.dart';
import 'widget/new_course_launches_card.dart';

class NewLaunch extends StatelessWidget {
  const NewLaunch({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CourseController());

    // Fetch data once the widget tree is built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.selectedCourseType.value = ''; // Clear filter
      controller.fetchNewCourses();
      controller.fetchExistingCourse();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      bool isTutorialShown = GetStorage().read(TTexts.newLaunchTour) ?? false;
      if (!controller.isnewLaunchTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 500));
        await controller.newlaunchTour(context);
      }
    });

    return RefreshIndicator(
      onRefresh: () async {
        controller.selectedCourseType.value = ''; // reset dropdown
        await controller.fetchNewCourses();
        await controller.fetchExistingCourse();
        await controller.fetchinterestcourse();
      },
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 12),
                        child: Text(
                          "Explore Courses",
                          style: GoogleFonts.prompt(
                            fontSize: 22, // font-size: 16px
                            fontWeight: FontWeight.bold, // font-weight: 500
                            fontStyle: FontStyle
                                .normal, // 'Medium' is actually weight 500, not a style
                            height: 1.0, // line-height: 100%
                            letterSpacing: 0.32, // 2% of 16px = 0.32
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  /// Filter Dropdown
                  Container(
                    key: controller.dropdownKey,
                    margin: const EdgeInsets.only(left: 12, right: 12),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: TColors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: TColors.primary, // ✅ Border with primary color
                        width: 1.2, // Adjust thickness if needed
                      ),
                    ),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    child: Obx(
                      () => Theme(
                        data: Theme.of(context).copyWith(
                          focusColor: TColors.primary,
                        ),
                        child: DropdownButton<String>(
                          value: controller.selectedCourseType.value.isEmpty
                              ? null
                              : controller.selectedCourseType.value,
                          isExpanded: true,
                          hint: Text(
                            "Course Category",
                            style: GoogleFonts.prompt(
                              fontSize: 16, // font-size: 16px
                              fontWeight: FontWeight.bold, // font-weight: 500
                              fontStyle: FontStyle
                                  .normal, // 'Medium' is actually weight 500, not a style
                              height: 1.0, // line-height: 100%
                              letterSpacing: 0.32, // 2% of 16px = 0.32
                            ),
                          ),
                          dropdownColor: TColors.white,
                          elevation: 0,
                          underline: const SizedBox(),
                          icon: const Icon(
                            // 👇 custom dropdown arrow
                            Icons.keyboard_arrow_down,
                            color: TColors.primary,
                          ),
                          items: [
                            DropdownMenuItem(
                              value: '',
                              child: Text(
                                "All",
                                style: GoogleFonts.prompt(
                                  color: Colors.white, // 👈 dropdown item color
                                ),
                              ),
                            ),
                            ...controller.availableCourseTypes
                                .map((type) => DropdownMenuItem(
                                      value: type,
                                      child: Text(
                                        type,
                                        style: GoogleFonts.prompt(
                                          color: Colors
                                              .black, // 👈 dropdown item color
                                        ),
                                      ),
                                    ))
                                .toList(),
                          ],
                          onChanged: (value) {
                            controller.filterCoursesByType(value ?? '');
                          },
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  /// Toggle between New / Existing / Interest Courses
                  Obx(() => Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ToggleButtons(
                            renderBorder: false,
                            fillColor: Colors.transparent,
                            splashColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            isSelected: [
                              controller.selectedCourseTab.value == 0,
                              controller.selectedCourseTab.value == 1,
                              controller.selectedCourseTab.value == 2,
                            ],
                            onPressed: (index) {
                              controller.selectedCourseTab.value = index;
                            },
                            children: [
                              /// 🟩 New Courses
                              Column(
                                key: controller.newcourseKey,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8),
                                    child: Text(
                                      "New Courses",
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: controller
                                                    .selectedCourseTab.value ==
                                                0
                                            ? TColors.primary
                                            : Colors.grey.shade400,
                                      ),
                                    ),
                                  ),
                                  if (controller.selectedCourseTab.value == 0)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      height: 4,
                                      width: 60,
                                      color: TColors.grey,
                                    ),
                                ],
                              ),

                              /// 🟦 Existing Courses
                              Column(
                                key: controller.existcourseKey,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8),
                                    child: Text(
                                      "Existing Courses",
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: controller
                                                    .selectedCourseTab.value ==
                                                1
                                            ? TColors.primary
                                            : Colors.grey.shade400,
                                      ),
                                    ),
                                  ),
                                  if (controller.selectedCourseTab.value == 1)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      height: 4,
                                      width: 60,
                                      color: TColors.grey,
                                    ),
                                ],
                              ),

                              /// 🟥 Favourites
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8),
                                    child: Text(
                                      "Favourites",
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: controller
                                                    .selectedCourseTab.value ==
                                                2
                                            ? TColors.primary
                                            : Colors.grey.shade400,
                                      ),
                                    ),
                                  ),
                                  if (controller.selectedCourseTab.value == 2)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      height: 4,
                                      width: 60,
                                      color: TColors.grey,
                                    ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      )),

                  const SizedBox(height: 20),

                  /// Courses Display
                  Obx(() {
                    int tab = controller.selectedCourseTab.value;
                    final courseList = tab == 0
                        ? controller.newCourses
                        : tab == 1
                            ? controller.existingCourseList
                            : controller.intersestCourseList;

                    return Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8.0, vertical: 12.0),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: controller.isLoading.value
                            ? const Padding(
                                padding: EdgeInsets.all(40.0),
                                child:
                                    TAnimationLoaderWidget(text: "Loading..."),
                              )
                            : courseList.isEmpty
                                ? const Center(
                                    child: Padding(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        "No courses found.",
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  )
                                : ListView.builder(
                                    shrinkWrap: true,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    itemCount: courseList.length,
                                    itemBuilder: (context, index) {
                                      if (tab == 0) {
                                        return NewCourseLaunchCard(
                                            newCourseModel:
                                                controller.newCourses[index]);
                                      } else if (tab == 1) {
                                        return ExistingCourseCard(
                                          key: index == 0
                                              ? controller.existcoursecardKey
                                              : null,
                                          existingCourse: controller
                                              .existingCourseList[index],
                                        );
                                      } else {
                                        return InterestCourseCard(
                                            interestCourse: controller
                                                .intersestCourseList[index]);
                                      }
                                    },
                                  ),
                      ),
                    );
                  }),

                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
