import 'package:eapl_student_app/features/personalization/models/existing_course_model.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../controllers/side_drawer_controller/course_controller.dart';

class ExistingCourseCard extends StatelessWidget {
  final ExistingCourseModel existingCourse;

  const ExistingCourseCard({super.key, required this.existingCourse});

  @override
  Widget build(BuildContext context) {
    final CourseController controller = Get.put(CourseController());
    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.only(bottom: 12, left: 5, right: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300, width: 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// ---- Top Row ----
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Thumbnail
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  shape: BoxShape.rectangle,
                ),
                child: ClipOval(
                  child: Image.network(
                    existingCourse.thumbnail ?? "",
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.school, size: 28, color: Colors.grey),
                  ),
                ),
              ),
              const SizedBox(width: 10),

              /// Course details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// Name
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            (existingCourse.courseName ?? ""),
                            style: GoogleFonts.prompt(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.normal,
                              height: 1.0,
                              letterSpacing: 0.32,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        SizedBox(width: 6),

                        // ❤️ Clickable heart icon for existing course
                        Obx(() {
                          bool isLoading = controller.isLoading.value;

                          return GestureDetector(
                            onTap: (existingCourse.interested == 1 || isLoading)
                                ? null
                                : () async {
                                    controller.isLoading.value = true;
                                    await controller
                                        .registerExistCourse(existingCourse);
                                    controller.load();
                                    controller.isLoading.value = false;
                                  },
                            child: isLoading
                                ? SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.red,
                                    ),
                                  )
                                : Icon(
                                    existingCourse.interested == 1
                                        ? Icons.favorite
                                        : Icons.favorite_outline_outlined,
                                    color: existingCourse.interested == 1
                                        ? Colors.red
                                        : Colors.black,
                                    size: 20,
                                  ),
                          );
                        }),
                      ],
                    ),

                    const SizedBox(height: 2),

                    /// Subcategory
                    Text(
                      existingCourse.courseSubcategoryName ?? "---",
                      style: GoogleFonts.prompt(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        fontStyle: FontStyle.normal,
                        height: 1.0,
                        letterSpacing: 0.32,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 15),

          Row(
            children: [
              /// Category
              Expanded(
                flex: 3,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.category,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        "${existingCourse.courseDuration} Days",
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
              ),

              /// Days
              Expanded(
                flex: 4,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.calender,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        existingCourse.courseTypeName ?? "",
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
              ),
              /*Row(
                children: List.generate(5, (index) {
                  return Icon(
                    index < 4
                        ? Icons.star
                        : Icons.star_border, // ✅ 4 stars filled
                    color: Colors
                        .orangeAccent, // you can use Colors.grey if you want
                    size: 18,
                  );
                }),
              ),*/
              RatingBarWidget(
                rating:
                    double.tryParse(existingCourse.averageRating ?? '0') ?? 0.0,
              ),
            ],
          ),

          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

class RatingBarWidget extends StatelessWidget {
  final double rating; // e.g., 4.5
  const RatingBarWidget({super.key, required this.rating});

  @override
  Widget build(BuildContext context) {
    int fullStars = rating.floor();
    bool hasHalfStar = (rating - fullStars) >= 0.5;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.green,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Rating number
          Text(
            rating.toStringAsFixed(1),
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(width: 6),
          // Stars
          Row(
            children: List.generate(5, (index) {
              if (index < fullStars) {
                return const Icon(Icons.star, color: Colors.yellow, size: 18);
              } else if (index == fullStars && hasHalfStar) {
                return const Icon(Icons.star_half,
                    color: Colors.yellow, size: 18);
              } else {
                return const Icon(Icons.star_border,
                    color: Colors.yellow, size: 18);
              }
            }),
          ),
        ],
      ),
    );
  }
}
