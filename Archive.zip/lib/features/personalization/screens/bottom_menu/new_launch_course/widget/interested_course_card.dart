import 'package:google_fonts/google_fonts.dart';

import '../../../../../../utils/constants/path_provider.dart';
import '../../../../controllers/side_drawer_controller/course_controller.dart';
import '../../../../models/interested/interestmodel.dart';
import 'existing_course_card.dart';

class InterestCourseCard extends StatelessWidget {
  final Interestmodel interestCourse;

  const InterestCourseCard({super.key, required this.interestCourse});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CourseController());

    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.only(bottom: 12, left: 5, right: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300, width: 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// ---- Top Row ----
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Thumbnail
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  shape: BoxShape.rectangle,
                ),
                child: ClipOval(
                  child: Image.network(
                    interestCourse.thumbnail ?? "",
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.school, size: 28, color: Colors.grey),
                  ),
                ),
              ),
              const SizedBox(width: 10),

              /// Course details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// Version + Name
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            (interestCourse.courseName ?? ""),
                            style: GoogleFonts.prompt(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.normal,
                              height: 1.0,
                              letterSpacing: 0.32,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        SizedBox(width: 6),
                        Obx(() {
                          final isLoading = controller
                                  .isRemoveLoadingMap[interestCourse.sno!] ??
                              false;
                          return isLoading
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child:
                                      CircularProgressIndicator(strokeWidth: 2),
                                )
                              : InkWell(
                                  onTap: () async {
                                    bool success = await controller
                                        .removeInterestCourse(interestCourse);
                                    if (success) {
                                      // Remove from list based on sno
                                      controller.intersestCourseList
                                          .removeWhere((course) =>
                                              course.sno == interestCourse.sno);
                                    }
                                  },
                                  child: const Icon(
                                    Icons.favorite,
                                    color: Colors.red,
                                    size: 20,
                                  ),
                                );
                        }),
                      ],
                    ),
                    const SizedBox(height: 2),

                    /// Subcategory
                    Text(
                      interestCourse.courseSubcategoryName ?? "",
                      style: GoogleFonts.prompt(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        height: 1.0,
                        letterSpacing: 0.32,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 15),

          /// ---- Bottom Row: Duration + Type + Rating ----
          Row(
            children: [
              /// Duration
              Expanded(
                flex: 3,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.category,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        "${interestCourse.courseDuration} Days",
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),

              /// Course Type
              Expanded(
                flex: 4,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.calender,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        interestCourse.courseTypeName ?? "",
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),

              /// Rating stars
              /*Row(
                children: List.generate(5, (index) {
                  return Icon(
                    index < 4
                        ? Icons.star
                        : Icons.star_border, // ✅ 4 stars filled
                    color: Colors
                        .orangeAccent, // you can use Colors.grey if you want
                    size: 18,
                  );
                }),
              ),*/
              RatingBarWidget(
                rating:
                    double.tryParse(interestCourse.averageRating ?? '0') ?? 0.0,
              ),
            ],
          ),

          const SizedBox(height: 6),
        ],
      ),
    );
  }
}
