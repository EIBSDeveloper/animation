import 'package:eapl_student_app/utils/constants/path_provider.dart';

import '../../../../controllers/side_drawer_controller/course_controller.dart';
import '../../../../models/new_course_model.dart';

class NewCourseDetailAlert extends StatelessWidget {
  const NewCourseDetailAlert({super.key, required this.newCourseModel});

  final NewCourseModel newCourseModel;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CourseController());

    return AlertDialog(
      backgroundColor: TColors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      titlePadding: const EdgeInsets.only(top: 16, left: 24, right: 24),
      contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),

      /// ✅ Title with Close Icon
      title: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              children: [
                Text(
                  newCourseModel.courseName,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleLarge!.copyWith(
                        color: TColors.importantText,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: TColors.light,
                    border: Border.all(color: TColors.primary),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    newCourseModel.courseCode,
                    style: Theme.of(context).textTheme.labelLarge!.copyWith(
                          color: TColors.primary,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
              ],
            ),
          ),

          /// ✅ X Icon Button
          IconButton(
            icon: const Icon(Icons.close, color: Colors.black),
            onPressed: () => Get.back(), // closes the dialog
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: TSizes.sm),

            /// Sub Category
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Sub Category: ",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                Expanded(
                  child: Text(
                    newCourseModel.courseSubcategoryName,
                    style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                          color: TColors.primary,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            /// Duration Grid
            IntrinsicHeight(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _DurationCard(
                      title: "Total\nDuration",
                      value: newCourseModel.courseDuration.toString()),
                  const VerticalDivider(thickness: 1),
                  _DurationCard(
                      title: "Theory\nClasses",
                      value: newCourseModel.courseTheoryHours.toString()),
                  const VerticalDivider(thickness: 1),
                  _DurationCard(
                      title: "Practical\nClasses",
                      value: newCourseModel.courseParticalHours.toString()),
                ],
              ),
            ),

            const SizedBox(height: 22),

            /// Scope and Outline
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: TColors.light,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade200,
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  )
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Future Scope",
                      style: Theme.of(context).textTheme.titleMedium!.copyWith(
                            color: TColors.primary,
                            fontWeight: FontWeight.bold,
                          )),
                  const SizedBox(height: 6),
                  Text(
                    newCourseModel.courseFutureScope ?? "---",
                    style: Theme.of(context)
                        .textTheme
                        .bodyMedium!
                        .copyWith(color: TColors.black),
                  ),
                  const Divider(height: 24),
                  Text("Course Outline",
                      style: Theme.of(context).textTheme.titleMedium!.copyWith(
                            color: TColors.primary,
                            fontWeight: FontWeight.bold,
                          )),
                  const SizedBox(height: 6),
                  Text(newCourseModel.courseDesc ?? "---"),
                ],
              ),
            ),
          ],
        ),
      ),

      /// Button
      actions: [
        /*Center(
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed:
                  (controller.getButtonText(newCourseModel.sno) == "Pending" ||
                          newCourseModel.interested != 0)
                      ? null
                      : () {
                          controller.registerNewCourse(
                              newCourseModel.sno, newCourseModel.courseName);
                          Get.back();
                        },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                backgroundColor:
                    controller.getButtonText(newCourseModel.sno) == "Pending"
                        ? TColors.grey
                        : TColors.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
              child: Text(
                newCourseModel.interested != 0
                    ? "Already Registered"
                    : controller.getButtonText(newCourseModel.sno),
                style: const TextStyle(fontSize: 18, color: TColors.white),
              ),
            ),
          ),
        ),*/

        GetBuilder<CourseController>(
          builder: (controller) {
            return Center(
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: (newCourseModel.interested == 1)
                      ? null // disable if already registered
                      : () async {
                          await controller.registerNewCourse(newCourseModel);
                          controller.load();
                        },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: newCourseModel.interested == 1
                        ? TColors.grey
                        : TColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  child: Text(
                    newCourseModel.interested == 1 ? "Registered" : "Register",
                    style: const TextStyle(fontSize: 18, color: TColors.white),
                  ),
                ),
              ),
            );
          },
        )
      ],
    );
  }
}

/*class widgetDuration extends StatelessWidget {
  const widgetDuration({
    super.key,
    required this.courseDuration,
    required this.durationName,
  });

  final String courseDuration;
  final String durationName;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          courseDuration,
          style: Theme.of(context)
              .textTheme
              .headlineMedium!
              .apply(color: TColors.importantText),
          textAlign: TextAlign.center,
        ),
        SizedBox(width: TSizes.xs),
        Flexible(
            child: Text(
          durationName,
          style: Theme.of(context)
              .textTheme
              .labelLarge!
              .apply(color: TColors.black, heightDelta: -0.4),
          textAlign: TextAlign.center,
        )),
      ],
    );
  }
}*/

class _DurationCard extends StatelessWidget {
  final String title;
  final String value;

  const _DurationCard({
    Key? key,
    required this.title,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: Theme.of(context).textTheme.headlineSmall!.copyWith(
                  color: TColors.importantText,
                  fontWeight: FontWeight.bold,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: Theme.of(context).textTheme.labelLarge!.copyWith(
                  color: TColors.darkGrey,
                  height: 1.2,
                ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
