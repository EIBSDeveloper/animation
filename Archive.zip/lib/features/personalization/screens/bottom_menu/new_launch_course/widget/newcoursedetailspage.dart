import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../../../../../../common/widget/app_bar/customheader.dart';
import '../../../../controllers/side_drawer_controller/course_controller.dart';
import '../../../../models/new_course_model.dart';

class NewCourseDetailPage extends StatelessWidget {
  final NewCourseModel newCourseModel;

  const NewCourseDetailPage({super.key, required this.newCourseModel});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CourseController());
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Course Details"),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Back button + title
                /* Transform.translate(
                  offset: const Offset(-5, 0), // move 8px left
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () => Navigator.pop(context),
                        child: const Icon(Icons.arrow_back, color: Colors.black),
                      ),
                      const SizedBox(width: 8),
                      Text("Course Details", style: AppTextStyles.title),
                    ],
                  ),
                ),*/
      
                SizedBox(
                  height: 10,
                ),
      
                Container(
                  height: 250, // set desired height
                  width: double
                      .infinity, // set desired width or fixed value like 350
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: TColors.sandal,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: TColors.grey)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      /// Course Title & Code
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "${newCourseModel.courseVersion}",
                            textAlign: TextAlign.center,
                            style: GoogleFonts.prompt(
                              fontSize: 16, // font-size: 16px
                              fontWeight: FontWeight.bold, // font-weight: 500
                              fontStyle: FontStyle
                                  .normal, // 'Medium' is actually weight 500, not a style
                              height: 1.0, // line-height: 100%
                              letterSpacing: 0.32, // 2% of 16px = 0.32
                            ),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Expanded(
                            child: Text(
                              newCourseModel.courseName,
                              maxLines: 1, // ✅ only one line
                              overflow:
                                  TextOverflow.ellipsis, // ✅ truncate with ...
                              style: GoogleFonts.prompt(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: TColors.primary,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              newCourseModel.courseCode,
                              style: GoogleFonts.prompt(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: TColors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
      
                      /// Subcategory
                      Row(
                        children: [
                          Image.asset(
                            TImages.category,
                            width: 25, // desired width
                            height: 25, // desired height
                            fit: BoxFit.contain,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            newCourseModel.courseSubcategoryName,
                            style: GoogleFonts.prompt(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                color: Colors.black),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
      
                      /// Duration Grid
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Expanded(
                            child: _DurationCard(
                              imagePath: TImages.theory,
                              label: "Theory  Class",
                              value: "${newCourseModel.courseParticalHours} Hrs",
                            ),
                          ),
                          const SizedBox(width: 8), // spacing between cards
                          Expanded(
                            child: _DurationCard(
                              imagePath: TImages.practical,
                              label: "Practical Class",
                              value: "${newCourseModel.courseTheoryHours} Hrs",
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _DurationCard(
                              imagePath: TImages.hrs,
                              label: "Total Duration",
                              value: "${newCourseModel.courseDuration} Hrs",
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
      
                /// Future Scope
                Text("Future Scope", style: AppTextStyles.title),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: TColors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: TColors.grey)),
                  child: Text(
                    newCourseModel.courseFutureScope ?? "---",
                    style: GoogleFonts.prompt(
                      fontSize: 14,
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
      
                /// Bottom Buttons
                /*Center(
                  child: Container(
                    height: 48, // set height
                    width: 180, // set width
                    decoration: BoxDecoration(
                      color: TColors.primary, // ✅ use your custom color
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: ElevatedButton(
                      onPressed: (newCourseModel.interested == 1)
                          ? null // disable if already registered
                          : () async {
                              await controller.registerNewCourse(newCourseModel);
                              controller.load();
                            },
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        backgroundColor: newCourseModel.interested == 1
                            ? TColors.grey
                            : TColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      child: Text(
                        newCourseModel.interested == 1
                            ? "Interested"
                            : "Interest",
                        style:
                            const TextStyle(fontSize: 18, color: TColors.white),
                      ),
                    ),
                  ),
                )*/
                /*Center(
                  child: Container(
                    height: 48,
                    width: 180,
                    child: Obx(() {
                      // Reactive variable in controller
                      bool isLoading = controller.isLoading.value;
      
                      return ElevatedButton(
                        onPressed: (newCourseModel.interested == 1 || isLoading)
                            ? null
                            : () async {
                                controller.isLoading.value = true; // show loader
                                await controller
                                    .registerNewCourse(newCourseModel);
                                controller.load();
                                controller.isLoading.value = false; // hide loader
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: newCourseModel.interested == 1
                              ? TColors.grey
                              : TColors.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: isLoading
                            ? LoadingAnimationWidget.waveDots(
                                color: TColors.white,
                                size: 35,
                              )
                            : Text(
                                newCourseModel.interested == 1
                                    ? "Interested"
                                    : "Interest",
                                style: const TextStyle(
                                    fontSize: 18, color: TColors.white),
                              ),
                      );
                    }),
                  ),
                )*/
                Center(
                  child: Container(
                    height: 48,
                    width: 180,
                    child: Obx(() {
                      bool isLoading = controller.isLoading.value;
      
                      return TextButton(
                        onPressed: (newCourseModel.interested == 1 || isLoading)
                            ? null
                            : () async {
                                controller.isLoading.value = true; // show loader
                                await controller
                                    .registerNewCourse(newCourseModel);
                                controller.load();
                                controller.isLoading.value = false; // hide loader
                              },
                        style: TextButton.styleFrom(
                          backgroundColor: newCourseModel.interested == 1
                              ? TColors.grey
                              : TColors.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: isLoading
                            ? LoadingAnimationWidget.waveDots(
                                color: Colors.white,
                                size: 35,
                              )
                            : Text(
                                newCourseModel.interested == 1
                                    ? "Interested"
                                    : "Interest",
                                style: GoogleFonts.prompt(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.white,
                                ),
                              ),
                      );
                    }),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DurationCard extends StatelessWidget {
  final String? imagePath;
  final String label;
  final String value;

  const _DurationCard({
    super.key,
    this.imagePath,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4), // small spacing
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black12.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (imagePath != null)
            Image.asset(imagePath!, width: 25, height: 25, fit: BoxFit.contain),
          const SizedBox(height: 6),
          Text(
            label,
            style: GoogleFonts.prompt(
              fontSize: 12,
              color: Colors.grey.shade700,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: GoogleFonts.prompt(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
