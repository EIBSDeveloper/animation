import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/image_strings.dart';
import '../../../../../../utils/constants/text_strings.dart';
import '../../../../controllers/side_drawer_controller/course_controller.dart';
import '../../../../models/existing_course_model.dart';

class ExistingCourseDetailPage extends StatelessWidget {
  final ExistingCourseModel existingCourse;
  final controller = Get.put(CourseController());
  ExistingCourseDetailPage({
    super.key,
    required this.existingCourse,
  });
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown =
          GetStorage().read(TTexts.newLaunchdetailsTour) ?? false;

      if (!controller.isnewLaunchDetailsTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 500));
        await controller.newlaunchDetailsTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.newLaunchdetailsTour, true);
        controller.isnewLaunchDetailsTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    //_showTourOnce(context); // only runs after first frame

    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Course Details"),
        ),
        backgroundColor: TColors.white,
        body: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /* /// Back button + title
              Transform.translate(
                offset: const Offset(-5, 0), // move 8px left(
                child: Row(
                  children: [
                    InkWell(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(Icons.arrow_back, color: Colors.black),
                    ),
                    const SizedBox(width: 8),
                    Text("Course Details", style: AppTextStyles.title),
                  ],
                ),
              ),*/
              const SizedBox(height: 20),
      
              /// Course info card
              Container(
                height: 250,
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: TColors.sandal,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: TColors.grey),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// Course Name + Code
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "${existingCourse.courseVersion}",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.prompt(
                            fontSize: 16, // font-size: 16px
                            fontWeight: FontWeight.bold, // font-weight: 500
                            fontStyle: FontStyle
                                .normal, // 'Medium' is actually weight 500, not a style
                            height: 1.0, // line-height: 100%
                            letterSpacing: 0.32, // 2% of 16px = 0.32
                          ),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Expanded(
                          child: Text(
                            existingCourse.courseName ?? "---",
                            maxLines: 1, // ✅ restrict to one line
                            overflow: TextOverflow
                                .ellipsis, // ✅ show ... if text is too long
                            style: GoogleFonts.prompt(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: TColors.primary,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            existingCourse.courseCode ?? "---",
                            style: GoogleFonts.prompt(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: TColors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
      
                    /// Subcategory
                    Row(
                      children: [
                        Image.asset(
                          TImages.category,
                          width: 25,
                          height: 25,
                          fit: BoxFit.contain,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          existingCourse.courseSubcategoryName ?? "---",
                          style: GoogleFonts.prompt(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
      
                    /// Duration Grid
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Expanded(
                          child: _DurationCard(
                            imagePath: TImages.hrs,
                            label: "Total Duration",
                            value: "${existingCourse.courseDuration} Hrs",
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _DurationCard(
                            imagePath: TImages.theory,
                            label: "Theory  Class",
                            value: "${existingCourse.courseParticalHours} Hrs",
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _DurationCard(
                            imagePath: TImages.practical,
                            label: "Practical Class",
                            value: "${existingCourse.courseTheoryHours} Hrs",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
      
              /// Future Scope
              Text("Future Scope", style: AppTextStyles.title),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: TColors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: TColors.grey),
                ),
                child: Text(
                  existingCourse.courseFutureScope ?? "---",
                  style: GoogleFonts.prompt(
                    fontSize: 14,
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
      
              const SizedBox(height: 20),
      
              /// Course Outline
              Text("Course Outline", style: AppTextStyles.title),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: TColors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: TColors.grey),
                ),
                child: Text(
                  existingCourse.courseDesc ?? "---",
                  style: GoogleFonts.prompt(
                    fontSize: 14,
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
      
              const SizedBox(height: 30),
      
              Center(
                child: Container(
                  height: 48,
                  width: 180,
                  child: Obx(() {
                    bool isLoading = controller.isLoading.value;
      
                    return TextButton(
                      onPressed: (existingCourse.interested == 1 || isLoading)
                          ? null
                          : () async {
                              controller.isLoading.value = true; // show loader
                              await controller
                                  .registerExistCourse(existingCourse);
                              controller.load();
                              controller.isLoading.value = false; // hide loader
                            },
                      style: TextButton.styleFrom(
                        backgroundColor: existingCourse.interested == 1
                            ? TColors.grey
                            : TColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: isLoading
                          ? LoadingAnimationWidget.waveDots(
                              color: Colors.white,
                              size: 35,
                            )
                          : Text(
                              existingCourse.interested == 1
                                  ? "Interested"
                                  : "Interest",
                              style: GoogleFonts.prompt(
                                fontSize: 18,
                                fontWeight: FontWeight.w400,
                                color: Colors.white,
                              ),
                            ),
                    );
                  }),
                ),
              ),
      
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}

class _DurationCard extends StatelessWidget {
  final String? imagePath;
  final String label;
  final String value;

  const _DurationCard({
    super.key,
    this.imagePath,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black12.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (imagePath != null)
            Image.asset(imagePath!, width: 25, height: 25, fit: BoxFit.contain),
          const SizedBox(height: 6),
          Text(
            label,
            style: GoogleFonts.prompt(
              fontSize: 12,
              color: Colors.grey.shade700,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: GoogleFonts.prompt(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
