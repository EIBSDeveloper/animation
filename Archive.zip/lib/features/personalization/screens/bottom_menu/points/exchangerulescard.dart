import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../utils/constants/colors.dart';

class RewardsCard extends StatelessWidget {
  const RewardsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: TColors.grey),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RewardRow(
              title: "01 Crown",
              trailing: "₹250 Cash",
              imagePath: TImages.crown,
            ),
            const SizedBox(height: 8),
            RewardRow(
              title: "05 Diamonds",
              trailing: "1 Crown",
              imagePath: TImages.diamond,
            ),
            const SizedBox(height: 8),
            RewardRow(
              title: "50 Coins",
              trailing: "1 Diamond",
              imagePath: TImages.coin,
            ),
          ],
        ),
      ),
    );
  }
}

class RewardRow extends StatelessWidget {
  final String imagePath; // image asset or network URL
  final String title;
  final String trailing;

  const RewardRow({
    super.key,
    required this.imagePath,
    required this.title,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 10, right: 10, top: 5),
      child: Row(
        children: [
          Image.asset(
            imagePath,
            width: 40,
            height: 40,
            fit: BoxFit.cover,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(title,
                style: GoogleFonts.prompt(
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                    fontSize: 18)),
          ),
          Text(trailing,
              style: GoogleFonts.prompt(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 18)),
        ],
      ),
    );
  }
}
