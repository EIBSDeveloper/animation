import 'package:flutter/material.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/sizes.dart';

class AlertForPointsScreens extends StatelessWidget {

  final Widget child;
  final String heading;
  // final  VoidCallback onPressed;

  const AlertForPointsScreens({
    super.key,
    required this.child,
    required this.heading,
    // required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: EdgeInsets.all(TSizes.md),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(heading,style: Theme.of(context).textTheme.titleMedium!.apply(color: TColors.primary),),
            SizedBox(height: TSizes.spaceBtwSections),
            child,

             ],
        ),
      ),
    );
  }
}
