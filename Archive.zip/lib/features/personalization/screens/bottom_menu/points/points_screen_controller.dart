/*
import 'package:eapl_student_app/utils/constants/path_provider.dart';

import '../../../../../common/widget/app_bar/appbar_controller.dart';

class PointsScreenController extends GetxController {
  final controller = Get.put((AppbarController));
  var coinPoints = 0.obs;
  var diamondPoints = 0.obs;

  void addItems(String currentValue, String type) {
    if (type == "coin") {
      if (coinPoints.value == 0) {
        coinPoints.value = int.tryParse(currentValue) ?? 0;
      }
      coinPoints.value++;
      print("Updated Points: ${coinPoints.value}");
    } else {
      if (diamondPoints.value == 0) {
        diamondPoints.value = int.tryParse(currentValue) ?? 0;
      }
      diamondPoints.value++;
      print("Updated Points: ${diamondPoints.value}");
    }
  }

  void subItems(String currentValue, String type) {
    if (type == "coin") {
      if (coinPoints.value == 0) {
        coinPoints.value = int.tryParse(currentValue) ?? 0;
      }
      coinPoints.value--;
      print("Updated Points: ${coinPoints.value}");
    } else {
      if (diamondPoints.value == 0) {
        diamondPoints.value = int.tryParse(currentValue) ?? 0;
      }
      diamondPoints.value--;
      print("Updated Points: ${diamondPoints.value}");
    }
  }

  // 0 = none, 1 = coin, 2 = diamond, 3 = crown
  var selectedIndex = 0.obs;

  void selectCoin() => selectedIndex.value = 1;
  void selectDiamond() => selectedIndex.value = 2;
  void selectCrown() => selectedIndex.value = 3;

  @override
  void onClose() {
    selectedIndex.value = 0; // reset when page closes
    super.onClose();
  }
}
*/
import 'package:eapl_student_app/features/apptour/bottom/exchange/exchangetour.dart';
import 'package:eapl_student_app/features/apptour/side/rewards/rewardstour.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../../utils/constants/text_strings.dart';

class PointsScreenController extends GetxController {
  // get existing AppbarController
  final appbarController = Get.find<AppbarController>();

  // optional point counters (you had these)
  var coinPoints = 0.obs;
  var diamondPoints = 0.obs;

  // selection state: 0 = none, 1 = coin, 2 = diamond, 3 = crown
  var selectedIndex = 0.obs;
  // textual type used by popup: 'coin'|'diamond'|'crown'
  var selectedType = ''.obs;
  // amount user chooses in popup (50/5 steps)
  var selectedAmount = 0.obs;

  // helper to reset (call when opening popup if you want)
  void resetSelection() {
    selectedIndex.value = 0;
    selectedType.value = '';
    selectedAmount.value = 0;
  }

  void selectCoin() {
    selectedIndex.value = 1;
    selectedType.value = 'coin';
    selectedAmount.value = 50; // default amount when selecting coin
  }

  void selectDiamond() {
    selectedIndex.value = 2;
    selectedType.value = 'diamond';
    selectedAmount.value = 5; // default amount for diamond
  }

  void selectCrown() {
    selectedIndex.value = 3;
    selectedType.value = 'crown';
    selectedAmount.value = 1; // optional default
  }

  @override
  void onClose() {
    resetSelection();
    super.onClose();
  }

  //exchange tour
  final ruleKey = GlobalKey();
  final coinKey = GlobalKey();
  final diamondKey = GlobalKey();
  final crownKey = GlobalKey();
  final operatorKey = GlobalKey();

  var isExchangeTouron = false.obs;
  Future<void> ExchangeTour(BuildContext context) async {
    final targets = ExchangeTourList.getTargets(
      ruleKey: ruleKey,
      coinKey: coinKey,
      diamondKey: diamondKey,
      crownKey: crownKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.exchangetour, true);
        isExchangeTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.exchangetour, true);
        isExchangeTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //rewardstour
  final rewardKey = GlobalKey();
  final exchangeKey = GlobalKey();

  var isRewardTouron = false.obs;
  Future<void> RewardTour(BuildContext context) async {
    final targets = RewardTourList.getTargets(
      rewardKey: rewardKey,
      exchangeKey: exchangeKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.rewardtour, true);
        isRewardTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.rewardtour, true);
        isRewardTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
