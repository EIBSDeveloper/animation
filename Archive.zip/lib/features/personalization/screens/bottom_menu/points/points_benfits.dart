/*import 'package:eapl_student_app/common/widget/points/point_button.dart';
import 'package:eapl_student_app/features/personalization/screens/bottom_menu/points/points_screen_controller.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';

class PointsBenfits extends StatelessWidget {
  const PointsBenfits({super.key});

  final double points_containers_width = 90;
  final double points_containers_height = 70;
  */ /*child: TitleWithGlassyTheme(
          centerTitle: true,
          title: "Buy Your Benefits",
          child: SingleChildScrollView(
              child: SizedBox(
                height: Get.height/1.4,
                width: double.infinity,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: controller.buyData.length,
                  itemBuilder: (context, index) {
                    final pointsBuyData = controller.buyData[index];
                    return InkWell(
                      onTap: (){
                        print("helllllllllllo $index");
                        benfitsDialog(context,pointsBuyData);
                      },
                      child: _buildPointsContainer(context,
                          pointsBuyData["image"]! == "coins"
                              ? TImages.coin
                              : pointsBuyData["image"]! == "heart"
                              ? TImages.heart
                              : pointsBuyData["image"]! == "crown"
                              ? TImages.crown
                              : TImages.diamond, pointsBuyData["title"]!, pointsBuyData["points"]!),
                    );
                  },),
              )),
                ),*/ /*
  @override
  Widget build(BuildContext context) {
    final controller = Get.put(PointsScreenController());
    return Scaffold(
      */ /* appBar: const CustomAppBar(),
      drawer: const SideMenuBar(),*/ /*
      body: SingleChildScrollView(
        child: Column(
          children: [
            /// 🌟 Rules Card
            _sectionCard(
              title: "📋 How to Earn Rewards",
              color: Colors.pink.shade50,
              children: [
                _ruleItem(Icons.login, "Daily Login", "+1 Coin"),
                _ruleItem(
                    Icons.feedback_outlined, "Attendance Feedback", "+2 Coins"),
                _ruleItem(Icons.payment, "Payment on Time", "+1 Diamond"),
                _ruleItem(Icons.person_add_alt_1, "Refer a Friend", "+1 Crown"),
                _ruleItem(Icons.share, "Share 1 Contact", "+2 Coins"),
              ],
            ),

            const SizedBox(height: 5),

            /// 🔁 Exchange Card
            _sectionCard(
              title: "💱 Exchange",
              color: Colors.yellow.shade200,
              children: [
                _exchangeItem(TImages.crown, "1 Crown", "₹250 Cash"),
                _exchangeItem(TImages.coin, "50 Coins", " 1 Diamond"),
                _exchangeItem(TImages.diamond, "5 Diamonds", " 1 Crown"),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Section Container
  Widget _sectionCard({
    required String title,
    required List<Widget> children,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(left: 20, right: 20, top: 15),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade50,
            blurRadius: 12,
            offset: const Offset(0, 6),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Text(title,
                style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: TColors.primary)),
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  /// Rule Item
  Widget _ruleItem(IconData icon, String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, color: Colors.deepPurple, size: 27),
          const SizedBox(width: 12),
          Expanded(
            child: Text(title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
          ),
          Text(value,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: TColors.red)),
        ],
      ),
    );
  }

  /// Exchange Item
  Widget _exchangeItem(String image, String left, String right) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Image.asset(image, width: 30, height: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Text(left,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.w500)),
          ),
          Text(right,
              style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue)),
        ],
      ),
    );
  }
}*/

import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/features/personalization/screens/bottom_menu/points/points_screen_controller.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../utils/constants/text_strings.dart';

class PointsBenfits extends StatelessWidget {
  final controller = Get.put(PointsScreenController());
  PointsBenfits({super.key});
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.rewardtour) ?? false;

      if (!controller.isRewardTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 1200));
        await controller.RewardTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.rewardtour, true);
        controller.isRewardTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    // controller.RewardTour(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey.shade100,
        body: Column(
          children: [
            CustomHeader(title: "Rewards"),
            _sectionCard(
              key: controller.rewardKey,
              title: "How to Earn Rewards",
              children: [
                _animatedItem(
                    0, _ruleItem(TImages.login, "Daily Login", "+1 Coin")),
                _animatedItem(1,
                    _ruleItem(TImages.daily, "Attendance Feedback", "+2 Coins")),
                _animatedItem(2,
                    _ruleItem(TImages.payment, "Payment on Time", "+1 Diamond")),
                _animatedItem(
                  3,
                  _ruleItem(
                    TImages.referrel,
                    "Converted referrel",
                    "+1 Crown",
                    iconColor: TColors.primary, // ✅ only this icon is orange
                  ),
                ),
                _animatedItem(
                    4, _ruleItem(TImages.share, "Refer a Friend", "+2 Coins")),
              ],
            ),
            const SizedBox(height: 20),
            _sectionCard(
              key: controller.exchangeKey,
              title: " Exchange",
              children: [
                _animatedItem(
                    2, _exchangeItem(TImages.coin, "50 Coins", "01 Diamond")),
                _animatedItem(
                    1, _exchangeItem(TImages.diamond, "05 Diamonds", "01 Crown")),
                _animatedItem(
                    0, _exchangeItem(TImages.crown, "01 Crown", "₹250 Cash")),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Section Card → White + Shadow
  Widget _sectionCard({
    required String title,
    required List<Widget> children,
    Key? key,
  }) {
    return Container(
      key: key,
      margin: EdgeInsets.only(left: 10, right: 10, top: 10),
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: TColors.grey)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Text(title,
                style: GoogleFonts.prompt(
                    color: TColors.primary,
                    fontSize: 22,
                    fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 18),
          ...children,
        ],
      ),
    );
  }

  /// Animation wrapper (staggered fade-slide)
  Widget _animatedItem(int index, Widget child) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + (index * 120)),
      builder: (context, value, _) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
    );
  }

  /// Rule Item
  Widget _ruleItem(String image, String title, String value,
      {Color? iconColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            image,
            width: 28,
            height: 28,
            fit: BoxFit.contain,
            color: iconColor,
            colorBlendMode: BlendMode.srcIn, // ensures the color applies
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.prompt(
                fontWeight: FontWeight.w400,
                fontSize: 16,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(
            width: 120, // 🔹 keeps all values aligned
            child: Padding(
              padding: const EdgeInsets.only(left: 15),
              child: Text(
                value,
                textAlign: TextAlign.left,
                style: GoogleFonts.prompt(
                  color: Colors.black,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Exchange Item
  Widget _exchangeItem(String image, String left, String right) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            image,
            width: 30,
            height: 30,
            fit: BoxFit.contain,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              left,
              style: GoogleFonts.prompt(
                fontWeight: FontWeight.w400,
                fontSize: 16,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(
            width: 120, // 🔹 same width as ruleItem
            child: Padding(
              padding: const EdgeInsets.only(left: 15),
              child: Text(
                right,
                textAlign: TextAlign.left,
                style: GoogleFonts.prompt(
                  color: Colors.black,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/*void benfitsDialog(BuildContext context, pointsBuyData) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text(
          pointsBuyData["title"]!,
          style: Theme.of(context)
              .textTheme
              .headlineSmall!
              .apply(color: TColors.primary),
          textAlign: TextAlign.center,
        ),
        content: Text(
          pointsBuyData["subtitle"]!,
          style: Theme.of(context)
              .textTheme
              .headlineSmall!
              .apply(color: TColors.black),
          textAlign: TextAlign.center,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        backgroundColor: TColors.white,
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TCustomGardientButton(onPressed: () {}, label: "Buy"),
            ],
          )
        ],
      );
    },
  );
}*/
/*
Widget _buildPointsContainer(
    BuildContext context, String imagePath, String text, String points) {
  bool isWideScreen = THelperFunctions.screenWidth() > 600;

  return Column(
    children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Flexible(
            child: SizedBox(
                width: THelperFunctions.screenWidth() / 1.52,
                child: Text(text)),
          ),
          SizedBox(
            // height: isWideScreen?140:points_containers_height,
            height: isWideScreen ? 90 : points_containers_height,
            width: isWideScreen ? 90 : points_containers_width,
            child: Stack(
              alignment: Alignment.centerLeft,
              children: <Widget>[
                Positioned(
                  bottom: isWideScreen ? 5 : 2,
                  right: isWideScreen ? 5 : 2,
                  child: Container(
                    height: 25,
                    width: 50,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: TColors.primary),
                    ),
                    padding: const EdgeInsets.all(2.0),
                    margin: const EdgeInsets.all(2.0),
                    child: Center(
                        child: Text(
                          points,
                          style: Theme.of(context).textTheme.labelLarge,
                        )),
                  ),
                ),
                Image(
                  image: AssetImage(imagePath),
                  width: isWideScreen ? 70 : 45,
                  height: isWideScreen ? 70 : 45,
                ),
              ],
            ),
          ),
        ],
      ),
      SizedBox(height: TSizes.xs),
      Divider(
        color: TColors.darkGrey,
        indent: 10,
        endIndent: 10,
      ),
      SizedBox(height: TSizes.xs)
    ],
  );
}*/
