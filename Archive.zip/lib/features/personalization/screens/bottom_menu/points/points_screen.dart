import 'package:eapl_student_app/features/personalization/screens/bottom_menu/points/points_screen_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/bottom_menu/points/redeemcontroller.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../../common/widget/points/points_card.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../controllers/bottom_bar_controller/exchangecontroller.dart';
import '../../../models/appbar_points_model.dart';
import 'exchangerulescard.dart';

class PointsScreen extends StatelessWidget {
  final controller = Get.put(AppbarController());
  final selectioncontroller = Get.put(PointsScreenController());
  PointsScreen({super.key});

  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.exchangetour) ?? false;

      if (!selectioncontroller.isExchangeTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 500));
        await selectioncontroller.ExchangeTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.exchangetour, true);
        selectioncontroller.isExchangeTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);

    // Reset selection every time page rebuilds
    selectioncontroller.selectedIndex.value = 0;
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 15,
        ),
        Center(
            child: Text(
          "Redeem Points",
          style: GoogleFonts.prompt(
              color: TColors.primary,
              fontSize: 22,
              fontWeight: FontWeight.bold),
        )),
        SizedBox(height: TSizes.md),

        /// points card
        Obx(() {
          final selected = selectioncontroller.selectedIndex.value;

          final points = controller.appBarPointsList.isNotEmpty
              ? controller.appBarPointsList.first
              : AppBarPointsModel(
                  coinsValue: 0,
                  diamondValue: 0,
                  heartScore: 0,
                  crownValue: 0,
                  cusName: '',
                  notifycount: 0,
                );

          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Coin
              PointsCard(
                key: selectioncontroller.coinKey,
                points: points.coinsValue.toString(),
                total: 250,
                pointsImage: TImages.coin,
                isSelected: selected == 1,
                onTap: () => selectioncontroller.selectCoin(),
              ),

              // Diamond
              PointsCard(
                key: selectioncontroller.diamondKey,
                points: points.diamondValue.toString(),
                total: 5,
                pointsImage: TImages.diamond,
                // highlight diamond when coin or diamond selected (coin->diamond pair, diamond->crown pair)
                isSelected: selected == 1 || selected == 2,
                onTap: () => selectioncontroller.selectDiamond(),
              ),

              // Crown
              PointsCard(
                key: selectioncontroller.crownKey,
                points: points.crownValue.toString(),
                total: 1,
                pointsImage: TImages.crown,
                isSelected: selected == 2 || selected == 3,
                onTap: () => selectioncontroller.selectCrown(),
              ),
            ],
          );
        }),

        SizedBox(
          height: 10,
        ),
        Center(
            child: Text(
          "Exchange Rules",
          style: GoogleFonts.prompt(
              color: TColors.primary,
              fontSize: 22,
              fontWeight: FontWeight.bold),
        )),
        RewardsCard(key: selectioncontroller.ruleKey),
        SizedBox(
          height: 5,
        ),
        /*Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TCustomGardientButton(
                  onPressed: () {
                    final points = controller.appBarPointsList.isNotEmpty
                        ? controller.appBarPointsList.first
                        : AppBarPointsModel(
                            coinsValue: 0,
                            diamondValue: 0,
                            heartScore: 0,
                            crownValue: 0,
                            cusName: '',
                            notifycount: 0);
                    showBuyDialog(
                        context, points.crownValue); // pass actual crown count
                  },
                  label: 'Buy',
                ),
                TCustomGardientButton(
                  onPressed: () {
                    final points = controller.appBarPointsList.isNotEmpty
                        ? controller.appBarPointsList.first
                        : AppBarPointsModel(
                            coinsValue: 0,
                            diamondValue: 0,
                            heartScore: 0,
                            crownValue: 0,
                            cusName: '',
                            notifycount: 0);
                    pointsExchangePopup(context, points);
                  },
                  label: 'Exchange',
                ),
              ],
            ),
            SizedBox(
              height: TSizes.lg,
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: TColors.primary,
                foregroundColor: TColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              ),
              onPressed: () {
                final redeemController = Get.put(RedeemController());
                redeemController.fetchRedeemList(); // ✅ fetch when sheet opens

                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true, // ✅ full height scrollable
                  backgroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  builder: (context) {
                    return DraggableScrollableSheet(
                      expand: false,
                      initialChildSize: 0.6, // sheet opens 60% height
                      minChildSize: 0.4, // can shrink to 40%
                      maxChildSize: 0.95, // can expand almost full screen
                      builder: (context, scrollController) {
                        return Column(
                          children: [
                            // Header with title + close btn
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 12),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    "Available Coupons",
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 22),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.close,
                                        color: Colors.black),
                                    onPressed: () => Navigator.pop(context),
                                  ),
                                ],
                              ),
                            ),

                            // Coupon list with scrolling
                            Expanded(
                              child: Obx(() {
                                if (redeemController.isredeemLoading.value) {
                                  return const Center(
                                      child: CircularProgressIndicator());
                                }

                                if (redeemController.redeemList.isEmpty) {
                                  return const Center(
                                      child: Text("No Coupons Available"));
                                }

                                return Container(
                                  margin: EdgeInsets.only(
                                      left: 10, right: 10, top: 5),
                                  child: ListView.builder(
                                    controller:
                                        scrollController, // ✅ smooth drag
                                    itemCount:
                                        redeemController.redeemList.length,
                                    itemBuilder: (context, index) {
                                      final coupon =
                                          redeemController.redeemList[index];
                                      return _buildCouponCard(
                                        coupon.couponCode,
                                        coupon.redeemValue,
                                        coupon.status,
                                      );
                                    },
                                  ),
                                );
                              }),
                            ),

                            // Bottom close button
                            Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: TextButton(
                                style: TextButton.styleFrom(
                                  backgroundColor: Colors.red,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                onPressed: () => Navigator.pop(context),
                                child: const Text(
                                  "Close",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
              child: const Text(
                "Redeem Cards",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: TSizes.lg,
            )
          ],
        ),*/
        /*Obx(() {
          final selected = selectioncontroller.selectedIndex.value;

          if (selected == 1 || selected == 2) {
            // Coin or Diamond selected → show only Exchange
            return Center(
              child: TCustomGardientButton(
                onPressed: () {
                  final points = controller.appBarPointsList.isNotEmpty
                      ? controller.appBarPointsList.first
                      : AppBarPointsModel(
                          coinsValue: 0,
                          diamondValue: 0,
                          heartScore: 0,
                          crownValue: 0,
                          cusName: '',
                          notifycount: 0);
                  pointsExchangePopup(context, points);
                },
                label: "Exchange",
              ),
            );
          } else if (selected == 3) {
            // Crown selected → show Buy + Redeem
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TCustomGardientButton(
                  onPressed: () {
                    final points = controller.appBarPointsList.isNotEmpty
                        ? controller.appBarPointsList.first
                        : AppBarPointsModel(
                            coinsValue: 0,
                            diamondValue: 0,
                            heartScore: 0,
                            crownValue: 0,
                            cusName: '',
                            notifycount: 0);
                    showBuyDialog(context, points.crownValue);
                  },
                  label: "Buy",
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: TColors.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 14),
                  ),
                  onPressed: () {
                    final redeemController = Get.put(RedeemController());
                    redeemController
                        .fetchRedeemList(); // ✅ fetch when sheet opens

                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true, // ✅ full height scrollable
                      backgroundColor: Colors.white,
                      shape: const RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.vertical(top: Radius.circular(20)),
                      ),
                      builder: (context) {
                        return DraggableScrollableSheet(
                          expand: false,
                          initialChildSize: 0.6, // sheet opens 60% height
                          minChildSize: 0.4, // can shrink to 40%
                          maxChildSize: 0.95, // can expand almost full screen
                          builder: (context, scrollController) {
                            return Column(
                              children: [
                                // Header with title + close btn
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 12),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text(
                                        "Available Coupons",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 22),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.close,
                                            color: Colors.black),
                                        onPressed: () => Navigator.pop(context),
                                      ),
                                    ],
                                  ),
                                ),

                                // Coupon list with scrolling
                                Expanded(
                                  child: Obx(() {
                                    if (redeemController
                                        .isredeemLoading.value) {
                                      return const Center(
                                          child: CircularProgressIndicator());
                                    }

                                    if (redeemController.redeemList.isEmpty) {
                                      return const Center(
                                          child: Text("No Coupons Available"));
                                    }

                                    return Container(
                                      margin: EdgeInsets.only(
                                          left: 10, right: 10, top: 5),
                                      child: ListView.builder(
                                        controller:
                                            scrollController, // ✅ smooth drag
                                        itemCount:
                                            redeemController.redeemList.length,
                                        itemBuilder: (context, index) {
                                          final coupon = redeemController
                                              .redeemList[index];
                                          return _buildCouponCard(
                                            coupon.couponCode,
                                            coupon.redeemValue,
                                            coupon.status,
                                          );
                                        },
                                      ),
                                    );
                                  }),
                                ),

                                // Bottom close button
                                Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: TextButton(
                                    style: TextButton.styleFrom(
                                      backgroundColor: Colors.red,
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 16, vertical: 12),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text(
                                      "Close",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },
                    );
                  },
                  child: Text("Redeem Cards"),
                ),
              ],
            );
          } else {
            // No selection → nothing
            return SizedBox.shrink();
          }
        }),*/
        Obx(() {
          final selected = selectioncontroller.selectedIndex.value;

          if (selected == 1 || selected == 2) {
            // Coin or Diamond → Exchange
            return Center(
              child: PrimaryButton(
                label: "Exchange",
                onPressed: () {
                  final points = controller.appBarPointsList.isNotEmpty
                      ? controller.appBarPointsList.first
                      : AppBarPointsModel(
                          coinsValue: 0,
                          diamondValue: 0,
                          heartScore: 0,
                          crownValue: 0,
                          cusName: '',
                          notifycount: 0,
                        );
                  pointsExchangePopup(context, points);
                },
              ),
            );
          } else if (selected == 3) {
            // Crown → Buy + Redeem
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                PrimaryButton(
                  label: "Buy",
                  onPressed: () {
                    final points = controller.appBarPointsList.isNotEmpty
                        ? controller.appBarPointsList.first
                        : AppBarPointsModel(
                            coinsValue: 0,
                            diamondValue: 0,
                            heartScore: 0,
                            crownValue: 0,
                            cusName: '',
                            notifycount: 0,
                          );
                    showBuyDialog(context, points.crownValue);
                  },
                ),
                PrimaryButton(
                  label: "Redeem",
                  onPressed: () {
                    final redeemController = Get.put(RedeemController());
                    redeemController.fetchRedeemList();

                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.white,
                      shape: const RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.vertical(top: Radius.circular(20)),
                      ),
                      builder: (context) {
                        return DraggableScrollableSheet(
                          expand: false,
                          initialChildSize: 0.6,
                          minChildSize: 0.4,
                          maxChildSize: 0.95,
                          builder: (context, scrollController) {
                            return Column(
                              children: [
                                // header
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 12),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Available Coupons",
                                        style: GoogleFonts.prompt(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 22),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.close,
                                            color: Colors.black),
                                        onPressed: () => Navigator.pop(context),
                                      ),
                                    ],
                                  ),
                                ),

                                // list
                                Expanded(
                                  child: Obx(() {
                                    if (redeemController
                                        .isredeemLoading.value) {
                                      return const Center(
                                          child: CircularProgressIndicator());
                                    }
                                    if (redeemController.redeemList.isEmpty) {
                                      return const Center(
                                          child: Text("No Coupons Available"));
                                    }
                                    return ListView.builder(
                                      controller: scrollController,
                                      itemCount:
                                          redeemController.redeemList.length,
                                      itemBuilder: (context, index) {
                                        final coupon =
                                            redeemController.redeemList[index];
                                        return _buildCouponCard(
                                          coupon.couponCode,
                                          coupon.redeemValue,
                                          coupon.status,
                                        );
                                      },
                                    );
                                  }),
                                ),

                                // close button
                                Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: PrimaryButton(
                                    label: "Close",
                                    onPressed: () => Navigator.pop(context),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },
                    );
                  },
                ),
              ],
            );
          } else {
            return const SizedBox.shrink();
          }
        })
      ],
    );
  }
}

/// 🔹 Coupon Card Widget

Widget _buildCouponCard(String couponCode, int redeemValue, int status) {
  final bool isActive = status == 0;

  return Container(
    margin: EdgeInsets.only(left: 15, right: 15, top: 5),
    height: 120,
    width: 350,
    decoration: BoxDecoration(
        color: isActive ? TColors.white : Colors.grey.shade300,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: TColors.grey)),
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Cashback text
          Text(
            "₹$redeemValue CashBack",
            style: GoogleFonts.prompt(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: isActive ? TColors.primary : Colors.black45,
            ),
          ),
          const SizedBox(height: 6),

          // Coupon row with fixed trailing widget
          Row(
            children: [
              Expanded(
                child: Text(
                  "Code: $couponCode",
                  style: GoogleFonts.prompt(
                    fontSize: 16,
                    color: isActive ? TColors.black : Colors.black45,
                  ),
                ),
              ),
              // ✅ Always keep space for trailing widget
              isActive
                  ? IconButton(
                      icon: const Icon(Icons.copy, color: TColors.primary),
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: couponCode));
                        Fluttertoast.showToast(
                          msg: "Copied: $couponCode ✅",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: TColors.primary,
                          textColor: Colors.white,
                          fontSize: 14.0,
                        );
                      },
                    )
                  : const SizedBox(width: 48, height: 48),
              // placeholder (same as IconButton)
            ],
          ),
        ],
      ),
    ),
  );
}

/*void pointsExchangePopup(BuildContext context, AppBarPointsModel points) {
  final controller = Get.put(ExchangeController());
  controller.reset(); // 🔄 Reset on open

  Future<void> _exchangePoints() async {
    int coin = 0, diamond = 0, crown = 0;

    final type = controller.selectedType.value;
    final amount = controller.selectedAmount.value; // This is now 50, 100, etc.

    if (type == 'coin' && -amount <= points.coinsValue) {
      coin = -amount;
      diamond = amount ~/ 50; // Example: 100 coins => 2 diamonds
    } else if (type == 'diamond' && -amount <= points.diamondValue) {
      diamond = -amount;
      crown = amount ~/ 5; // Example: 10 diamonds => 2 crowns
    } else {
      Get.snackbar("Invalid", "Insufficient $type for exchange",
          backgroundColor: Colors.red, colorText: Colors.white);
      return;
    }

    final userId =
        int.tryParse(GetStorage().read(TTexts.userID).toString()) ?? 0;
    // 🔍 Debug print here BEFORE calling API
    print("Calling exchange with:");
    print("coin: $coin, diamond: $diamond, crown: $crown");
    controller.exchangepoints(
      customerId: userId,
      coin: coin,
      diamond: diamond,
      crown: crown,
    );
    // ✅ Refresh UI after dialog closes
    await Get.find<AppbarController>().fetchPointsDetails();

    // ✅ Hide loading and close dialog
    controller.isexchangeloading.value = false;
    Get.back();

    // ✅ Show success after close
    Future.delayed(Duration(milliseconds: 300), () {
      Get.snackbar("Success", "Points exchanged successfully!",
          backgroundColor: TColors.primary, colorText: Colors.white);
    });
  }

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
          backgroundColor: TColors.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(),
              Center(
                child: Text("Exchange",
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(color: TColors.primary)),
              ),
              InkWell(onTap: () => Get.back(), child: const Icon(Icons.close))
            ],
          ),
          content: GetX<ExchangeController>(
            builder: (ctrl) {
              // Determine target based on selected type
              String targetImage;
              String targetType;
              String targetValue;

              if (ctrl.selectedType.value == 'coin') {
                targetImage = TImages.diamond;
                targetType = 'diamond';
                targetValue = "${points.diamondValue}";
              } else if (ctrl.selectedType.value == 'diamond') {
                targetImage = TImages.crown;
                targetType = 'crown';
                targetValue = "${points.crownValue}";
              } else {
                targetImage = TImages.diamond;
                targetType = 'diamond';
                targetValue = "${points.diamondValue}";
              }

              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Exchange row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Source container
                      _buildPointsExchangeContainer(
                        context,
                        ctrl.selectedType.value == 'diamond'
                            ? TImages.diamond
                            : TImages.coin,
                        ctrl.selectedType.value == 'diamond'
                            ? "${points.diamondValue}"
                            : "${points.coinsValue}",
                        ctrl.selectedType.value == 'diamond'
                            ? "diamond"
                            : "coin",
                        ctrl,
                      ),
                      const SizedBox(width: 8),

                      // Animated exchange arrow
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 500),
                        transitionBuilder: (child, animation) =>
                            ScaleTransition(scale: animation, child: child),
                        child: ctrl.selectedType.value.isEmpty
                            ? const SizedBox(key: ValueKey('empty'), width: 28)
                            : Icon(
                                Icons.double_arrow_sharp,
                                key: ValueKey(ctrl.selectedType.value),
                                color: TColors.primary,
                                size: 28,
                              ),
                      ),
                      const SizedBox(width: 8),

                      // Target container
                      _buildPointsExchangeContainer(
                        context,
                        targetImage,
                        targetValue,
                        targetType,
                        ctrl,
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: ctrl.selectedType.value == 'coin'
                        ? Text("50 Coins = 1 Diamond",
                            key: const ValueKey('coin'),
                            style: TextStyle(color: TColors.primary))
                        : ctrl.selectedType.value == 'diamond'
                            ? Text("5 Diamonds = 1 Crown",
                                key: const ValueKey('diamond'),
                                style: TextStyle(color: TColors.primary))
                            : Text("Select a point type to exchange",
                                key: const ValueKey('default'),
                                style: const TextStyle(color: Colors.grey)),
                  ),

                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        onPressed: ctrl.selectedType.value.isNotEmpty &&
                                ctrl.selectedAmount.value > 0
                            ? () {
                                final step =
                                    ctrl.selectedType.value == 'coin' ? 50 : 5;
                                ctrl.selectedAmount.value -= step;
                              }
                            : null,
                        icon: Icon(Icons.remove_circle_outline,
                            color: TColors.primary),
                      ),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 12),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: TColors.primary.withOpacity(0.1),
                        ),
                        child: Text(
                          '${ctrl.selectedAmount.value}',
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                      IconButton(
                        onPressed: ctrl.selectedType.value.isNotEmpty
                            ? () {
                                final step =
                                    ctrl.selectedType.value == 'coin' ? 50 : 5;
                                final max = ctrl.selectedType.value == 'coin'
                                    ? points.coinsValue
                                    : points.diamondValue;

                                if (ctrl.selectedAmount.value + step <= max) {
                                  ctrl.selectedAmount.value += step;
                                } else {
                                  Get.snackbar(
                                    "Limit Reached",
                                    "You only have $max ${ctrl.selectedType.value}s",
                                    backgroundColor: Colors.red,
                                    colorText: Colors.white,
                                  );
                                }
                              }
                            : null,
                        icon: Icon(Icons.add_circle_outline,
                            color: TColors.primary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TCustomGardientButton(
                    onPressed: () async {
                      final type = controller.selectedType.value;
                      final amount = controller.selectedAmount.value;

                      if (type == 'coin') {
                        if (amount < 50) {
                          Get.snackbar("Invalid", "Minimum 50 Coins required",
                              backgroundColor: Colors.red,
                              colorText: Colors.white);
                          return;
                        }
                        if (amount > points.coinsValue) {
                          Get.snackbar("Invalid",
                              "You only have ${points.coinsValue} Coins",
                              backgroundColor: Colors.red,
                              colorText: Colors.white);
                          return;
                        }
                      } else if (type == 'diamond') {
                        if (amount < 5) {
                          Get.snackbar("Invalid", "Minimum 5 Diamonds required",
                              backgroundColor: Colors.red,
                              colorText: Colors.white);
                          return;
                        }
                        if (amount > points.diamondValue) {
                          Get.snackbar("Invalid",
                              "You only have ${points.diamondValue} Diamonds",
                              backgroundColor: Colors.red,
                              colorText: Colors.white);
                          return;
                        }
                      } else {
                        Get.snackbar("Invalid", "Please select a point type",
                            backgroundColor: TColors.primary,
                            colorText: Colors.white);
                        return;
                      }

                      // ✅ Call async method inside sync wrapper
                      await _exchangePoints();
                    },
                    label: "Done",
                  ),
                ],
              );
            },
          ));
    },
  );
}

Widget _buildPointsExchangeContainer(BuildContext context, String imagePath,
    String value, String type, ExchangeController controller) {
  return Flexible(
    child: GestureDetector(
      onTap: () => controller.selectedType.value = type,
      child: AspectRatio(
        aspectRatio: 0.7, // Makes container perfectly square
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(
              color: controller.selectedType.value == type
                  ? TColors.primary
                  : Colors.grey.shade300,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(12),
            color: controller.selectedType.value == type
                ? TColors.primary.withOpacity(0.1)
                : Colors.white,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(imagePath, width: 40, height: 40),
              const SizedBox(height: 8),
              Text(
                value,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                type.capitalize!,
                style:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

InkWell buttonIncrDecrButton(
    PointsScreenController controller, VoidCallback onTap, String symbol) {
  bool isTablet = THelperFunctions.screenWidth() > 600;
  return InkWell(
    onTap: onTap,
    child: Container(
      height: isTablet ? 40 : 25,
      width: isTablet ? 40 : 25,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        color: TColors.absentOrLeave,
      ),
      child: Center(
          child: Text(
        symbol,
        style: isTablet
            ? Theme.of(Get.context!)
                .textTheme
                .labelLarge!
                .copyWith(fontSize: 29, fontWeight: FontWeight.w400)
            : Theme.of(Get.context!).textTheme.labelLarge,
      )),
    ),
  );
}*/
// call this with pointsExchangePopup(context, points);
void pointsExchangePopup(BuildContext context, AppBarPointsModel points) {
  final pointsCtrl = Get.find<PointsScreenController>();
  // ensure ExchangeController exists for the API call
  final exchangeCtrl = Get.put(ExchangeController());
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    final isTutorialShown =
        GetStorage().read(TTexts.exchangedialogtour) ?? false;

    if (!exchangeCtrl.isExchangeDialogTouron.value && !isTutorialShown) {
      await Future.delayed(const Duration(milliseconds: 500));
      await exchangeCtrl.ExchangeDialogTour(context);

      // ✅ Mark it as shown
      GetStorage().write(TTexts.exchangedialogtour, true);
      exchangeCtrl.isExchangeDialogTouron.value = true;
    }
  });

  // If nothing selected, default to coin selection
  if (pointsCtrl.selectedIndex.value == 0) {
    pointsCtrl.selectCoin();
  }
  // ensure amount defaulted on open
  if (pointsCtrl.selectedAmount.value == 0) {
    pointsCtrl.selectedAmount.value = (pointsCtrl.selectedType.value == 'coin')
        ? 50
        : (pointsCtrl.selectedType.value == 'diamond')
            ? 5
            : 1;
  }

  Future<void> _exchangePoints() async {
    int coin = 0, diamond = 0, crown = 0;
    final type = pointsCtrl.selectedType.value;
    final amount = pointsCtrl.selectedAmount.value;

    // Validate & prepare request payload (source negative to deduct)
    if (type == 'coin') {
      if (amount < 50 || amount > points.coinsValue) {
        Get.snackbar("Invalid",
            "Enter valid amount. You have ${points.coinsValue} Coins",
            backgroundColor: Colors.red, colorText: Colors.white);
        return;
      }
      coin = -amount;
      diamond = amount ~/ 50; // 50 coins => 1 diamond
    } else if (type == 'diamond') {
      if (amount < 5 || amount > points.diamondValue) {
        Get.snackbar("Invalid",
            "Enter valid amount. You have ${points.diamondValue} Diamonds",
            backgroundColor: Colors.red, colorText: Colors.white);
        return;
      }
      diamond = -amount;
      crown = amount ~/ 5; // 5 diamonds => 1 crown
    } else {
      Get.snackbar("Invalid", "Cannot exchange this type",
          backgroundColor: Colors.red, colorText: Colors.white);
      return;
    }

    final userId =
        int.tryParse(GetStorage().read(TTexts.userID).toString()) ?? 0;

    // Call your existing API method on exchangeCtrl
    await exchangeCtrl.exchangepoints(
      customerId: userId,
      coin: coin,
      diamond: diamond,
      crown: crown,
    );

    // refresh points shown in app bar
    await Get.find<AppbarController>().fetchPointsDetails();

    // reset loading and close dialog
    exchangeCtrl.isexchangeloading.value = false;
    Get.back();

    Future.delayed(const Duration(milliseconds: 300), () {
      Get.snackbar("Success", "Points exchanged successfully!",
          backgroundColor: TColors.primary, colorText: Colors.white);
    });
  }

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: TColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(),
            Center(
              child: Text("Exchange",
                  style: GoogleFonts.prompt(
                      color: TColors.primary,
                      fontWeight: FontWeight.bold,
                      fontSize: 22)),
            ),
            InkWell(onTap: () => Get.back(), child: const Icon(Icons.close))
          ],
        ),
        content: GetX<PointsScreenController>(
          builder: (ctrl) {
            // map source and target based on selection
            String sourceImage, targetImage;
            String sourceValue, targetValue;
            String sourceType, targetType;

            if (ctrl.selectedType.value == 'coin') {
              sourceImage = TImages.coin;
              targetImage = TImages.diamond;
              sourceValue = "${points.coinsValue}";
              targetValue = "${points.diamondValue}";
              sourceType = "coin";
              targetType = "diamond";
            } else if (ctrl.selectedType.value == 'diamond') {
              sourceImage = TImages.diamond;
              targetImage = TImages.crown;
              sourceValue = "${points.diamondValue}";
              targetValue = "${points.crownValue}";
              sourceType = "diamond";
              targetType = "crown";
            } else {
              // fallback
              sourceImage = TImages.coin;
              targetImage = TImages.diamond;
              sourceValue = "${points.coinsValue}";
              targetValue = "${points.diamondValue}";
              sourceType = "coin";
              targetType = "diamond";
            }

            // step amount and max per type
            final step = ctrl.selectedType.value == 'coin' ? 50 : 5;
            final maxAvailable = ctrl.selectedType.value == 'coin'
                ? points.coinsValue
                : points.diamondValue;

            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Exchange visual row
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildPointsExchangeContainer(
                        context, sourceImage, sourceValue, sourceType, ctrl),
                    const SizedBox(width: 8),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 500),
                      transitionBuilder: (child, animation) =>
                          ScaleTransition(scale: animation, child: child),
                      child: ctrl.selectedType.value.isEmpty
                          ? const SizedBox(key: ValueKey('empty'), width: 28)
                          : Icon(Icons.double_arrow_sharp,
                              key: ValueKey(ctrl.selectedType.value),
                              color: TColors.primary,
                              size: 28),
                      /* Image.asset(
                              TImages.exchange, // 🔹 your arrow image path
                              key: ValueKey(ctrl.selectedType.value),
                              width: 25,
                              height: 25,
                              color: TColors
                                  .primary, // optional: tint with theme color
                            ),*/
                    ),
                    const SizedBox(width: 8),
                    _buildPointsExchangeContainer(
                        context, targetImage, targetValue, targetType, ctrl),
                  ],
                ),

                const SizedBox(height: 16),

                // Conversion text
                /*AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: ctrl.selectedType.value == 'coin'
                      ? Text("50 Coins = 1 Diamond",
                          key: const ValueKey('coin'),
                          style: TextStyle(color: TColors.primary))
                      : ctrl.selectedType.value == 'diamond'
                          ? Text("5 Diamonds = 1 Crown",
                              key: const ValueKey('diamond'),
                              style: TextStyle(color: TColors.primary))
                          : Text("Select a point type to exchange",
                              key: const ValueKey('default'),
                              style: const TextStyle(color: Colors.grey)),
                ),
*/
                const SizedBox(height: 16),

                // Increment / Decrement controls
                /*Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Minus Button (-)
                    GestureDetector(
                      onTap: ctrl.selectedType.value.isNotEmpty &&
                              ctrl.selectedAmount.value > 0
                          ? () {
                              if (ctrl.selectedAmount.value - step >= step) {
                                ctrl.selectedAmount.value -= step;
                              } else {
                                ctrl.selectedAmount.value =
                                    step; // prevent below min
                              }
                            }
                          : null,
                      child: Container(
                        width: 40,
                        height: 40,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: TColors.Bottomcolor, // 🔹 secondary bg
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          "-",
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),

                    // Value Display
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 12),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: TColors.primary.withOpacity(0.1),
                      ),
                      child: Text(
                        '${ctrl.selectedAmount.value}',
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),

                    // Plus Button (+)
                    GestureDetector(
                      onTap: ctrl.selectedType.value.isNotEmpty
                          ? () {
                              if (ctrl.selectedAmount.value + step <=
                                  maxAvailable) {
                                ctrl.selectedAmount.value += step;
                              } else {
                                Get.snackbar(
                                  "Limit Reached",
                                  "You only have $maxAvailable ${ctrl.selectedType.value}s",
                                  backgroundColor: Colors.red,
                                  colorText: Colors.white,
                                );
                              }
                            }
                          : null,
                      child: Container(
                        width: 40,
                        height: 40,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: TColors.primary, // 🔹 primary bg
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          "+",
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),*/

                const SizedBox(height: 20),

                // Done button
                /*TCustomGardientButton(
                  onPressed: () async {
                    if (ctrl.selectedType.value.isEmpty) {
                      Get.snackbar("Invalid", "Please select a point type",
                          backgroundColor: TColors.primary,
                          colorText: Colors.white);
                      return;
                    }
                    await _exchangePoints();
                  },
                  label: "Done",
                ),*/

                /* GestureDetector(
                  onTap: () async {
                    if (ctrl.selectedType.value.isEmpty) {
                      Get.snackbar("Invalid", "Please select a point type",
                          backgroundColor: TColors.primary,
                          colorText: Colors.white);
                      return;
                    }
                    await _exchangePoints();
                  },
                  child: Container(
                    height: 48, // 🔹 set your desired height
                    width: 150, // 🔹 or fixed width like 200
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: TColors.primary,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "Exchange",
                      style: GoogleFonts.prompt(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),*/

                /*GestureDetector(
                  onTap: () async {
                    if (ctrl.selectedType.value.isEmpty) {
                      Get.snackbar(
                        "Invalid",
                        "Please select a point type",
                        backgroundColor: TColors.primary,
                        colorText: Colors.white,
                      );
                      return;
                    }

                    // Perform exchange
                    await _exchangePoints(); // no assignment needed since function returns void

                    // Show success popup
                    Get.dialog(
                      Dialog(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        backgroundColor: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              /// 🔹 Close Icon (top-right)
                              Align(
                                alignment: Alignment.topRight,
                                child: IconButton(
                                  icon: const Icon(Icons.close,
                                      color: Colors.black),
                                  onPressed: () => Get.back(),
                                ),
                              ),

                              /// 🔹 Exchange Success Image
                              Image.asset(
                                TImages.exchangesuccess, // your success image
                                width: 150,
                                height: 150,
                                fit: BoxFit.contain,
                              ),
                              const SizedBox(height: 20),

                              /// 🔹 Success Text
                              Text(
                                "Exchange Successful!",
                                textAlign: TextAlign.center,
                                style: GoogleFonts.prompt(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: TColors.primary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      barrierDismissible:
                          false, // cannot close by tapping outside
                    );

                    /// 🔹 Auto close after 5 seconds
                    Future.delayed(const Duration(seconds: 5), () {
                      if (Get.isDialogOpen ?? false) Get.back();
                    });
                  },
                  child: Container(
                    height: 48,
                    width: 150,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: TColors.primary,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "Exchange",
                      style: GoogleFonts.prompt(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),*/
                Obx(() {
                  return GestureDetector(
                    onTap: exchangeCtrl.isexchangeloading.value
                        ? null // disable tap while loading
                        : () async {
                            if (ctrl.selectedType.value.isEmpty) {
                              Get.snackbar(
                                "Invalid",
                                "Please select a point type",
                                backgroundColor: TColors.primary,
                                colorText: Colors.white,
                              );
                              return;
                            }

                            // Call API via ExchangeController
                            await _exchangePoints();
                          },
                    child: Container(
                      key: exchangeCtrl.exchangebuttonKey,
                      height: 48,
                      width: 150,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: exchangeCtrl.isexchangeloading.value
                            ? TColors.primary.withOpacity(
                                0.6) // slightly faded when disabled
                            : TColors.primary,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: exchangeCtrl.isexchangeloading.value
                          ? LoadingAnimationWidget.waveDots(
                              color: Colors.white,
                              size: 35,
                            )
                          : Text(
                              "Exchange",
                              style: GoogleFonts.prompt(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  );
                })
              ],
            );
          },
        ),
      );
    },
  );
}

/*Widget _buildPointsExchangeContainer(
  BuildContext context,
  String imagePath,
  String value,
  String type,
  PointsScreenController controller,
) {
  return Flexible(
    child: GestureDetector(
      onTap: () {
        // allow user to toggle selection from popup as well
        if (type == 'coin') {
          controller.selectCoin();
        } else if (type == 'diamond') {
          controller.selectDiamond();
        } else if (type == 'crown') {
          controller.selectCrown();
        }
      },
      child: SizedBox(
        width: 140, // 🔹 fixed width
        height: 160, // 🔹 fixed height
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(
              color: controller.selectedType.value == type
                  ? TColors.grey
                  : Colors.grey.shade300,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(12),
            color: controller.selectedType.value == type
                ? TColors.primary.withOpacity(0.1)
                : Colors.white,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(imagePath, width: 40, height: 40),
              const SizedBox(height: 8),
              Text(
                value,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                type.capitalize!,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}*/
/*Widget _buildPointsExchangeContainer(
  BuildContext context,
  String imagePath,
  String value,
  String type,
  PointsScreenController controller,
) {
  return Flexible(
    child: GestureDetector(
      onTap: () {
        if (type == 'coin') {
          controller.selectCoin();
        } else if (type == 'diamond') {
          controller.selectDiamond();
        } else if (type == 'crown') {
          controller.selectCrown();
        }
      },
      child: SizedBox(
        width: 140,
        height: 180, // increased to fit counter row safely
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(
              color: controller.selectedType.value == type
                  ? TColors.primary
                  : Colors.grey.shade300,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(12),
            color: controller.selectedType.value == type
                ? TColors.primary.withOpacity(0.08)
                : Colors.white,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(imagePath, width: 40, height: 40),
              const SizedBox(height: 6),
              Text(
                value,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                type.capitalize!,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Spacer(),
              // 🔹 Increment/Decrement row
              Obx(() {
                // decide step size dynamically
                final step = controller.selectedType.value == 'coin' ? 50 : 5;
                final maxAvailable = controller.selectedType.value == 'coin'
                    ? int.tryParse(value) ?? 0
                    : int.tryParse(value) ?? 0;

                return FittedBox(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Minus
                      GestureDetector(
                        onTap: controller.selectedType.value.isNotEmpty &&
                                controller.selectedAmount.value > 0
                            ? () {
                                if (controller.selectedAmount.value - step >=
                                    step) {
                                  controller.selectedAmount.value -= step;
                                } else {
                                  controller.selectedAmount.value = step;
                                }
                              }
                            : null,
                        child: Container(
                          width: 28,
                          height: 28,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: TColors.Bottomcolor,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            "-",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),

                      // Value
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          color: TColors.primary.withOpacity(0.1),
                        ),
                        child: Text(
                          '${controller.selectedAmount.value}',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                      // Plus
                      GestureDetector(
                        onTap: controller.selectedType.value.isNotEmpty
                            ? () {
                                if (controller.selectedAmount.value + step <=
                                    maxAvailable) {
                                  controller.selectedAmount.value += step;
                                } else {
                                  Get.snackbar(
                                    "Limit Reached",
                                    "You only have $maxAvailable ${controller.selectedType.value}s",
                                    backgroundColor: Colors.red,
                                    colorText: Colors.white,
                                  );
                                }
                              }
                            : null,
                        child: Container(
                          width: 28,
                          height: 28,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: TColors.primary,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            "+",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    ),
  );
}*/
Widget _buildPointsExchangeContainer(
  BuildContext context,
  String imagePath,
  String value,
  String type,
  PointsScreenController controller,
) {
  return Flexible(
    child: GestureDetector(
      onTap: () {
        if (type == 'coin') {
          controller.selectCoin(); // highlight coin + diamond
        } else if (type == 'diamond') {
          controller.selectDiamond(); // highlight diamond + crown
        } else if (type == 'crown') {
          controller.selectCrown(); // only crown
        }
      },
      child: SizedBox(
        width: 140,
        height: 180,
        child: Obx(() {
          final selectedType = controller.selectedType.value;
          final selectedAmount = controller.selectedAmount.value;

          // 🔹 conversion logic
          int convertedValue = 0;
          if (selectedType == 'coin' && type == 'diamond') {
            convertedValue = (selectedAmount / 50).floor();
          } else if (selectedType == 'diamond' && type == 'crown') {
            convertedValue = (selectedAmount / 5).floor();
          }

          return AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(
                color: (selectedType == type ||
                        (selectedType == 'coin' && type == 'diamond') ||
                        (selectedType == 'diamond' && type == 'crown'))
                    ? TColors.grey
                    : Colors.grey.shade300,
                width: 2,
              ),
              borderRadius: BorderRadius.circular(12),
              color: (selectedType == type ||
                      (selectedType == 'coin' && type == 'diamond') ||
                      (selectedType == 'diamond' && type == 'crown'))
                  ? TColors.white
                  : Colors.white,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(imagePath, width: 40, height: 40),
                const SizedBox(height: 6),
                Text(
                  value,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  type.capitalize!,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),

                // 🔹 show counter only for main selected
                if (selectedType == type)
                  FittedBox(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Minus
                        GestureDetector(
                          onTap: selectedAmount > 0
                              ? () {
                                  final step = type == 'coin' ? 50 : 5;
                                  if (selectedAmount - step >= step) {
                                    controller.selectedAmount.value -= step;
                                  } else {
                                    controller.selectedAmount.value = step;
                                  }
                                }
                              : null,
                          child: Container(
                            width: 28,
                            height: 28,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: TColors.Bottomcolor,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              "-",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),

                        // Value
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 8),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            color: TColors.primary.withOpacity(0.1),
                          ),
                          child: Text(
                            '${controller.selectedAmount.value}',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),

                        // Plus
                        GestureDetector(
                          onTap: () {
                            final step = type == 'coin' ? 50 : 5;
                            final maxAvailable = int.tryParse(value) ?? 0;

                            if (controller.selectedAmount.value + step <=
                                maxAvailable) {
                              controller.selectedAmount.value += step;
                            } else {
                              Get.snackbar(
                                "Limit Reached",
                                "You only have $maxAvailable $type(s)",
                                backgroundColor: Colors.red,
                                colorText: Colors.white,
                              );
                            }
                          },
                          child: Container(
                            width: 28,
                            height: 28,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: TColors.primary,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              "+",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                else if (convertedValue > 0)
                  // 🔹 Show calculated value for secondary
                  Text(
                    "$convertedValue ${type.capitalize}", // 👉 shows "1 Diamond" / "2 Diamond" / "1 Crown"
                    style: GoogleFonts.prompt(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),
                  ),
              ],
            ),
          );
        }),
      ),
    ),
  );
}

void showBuyDialog(BuildContext context, int userCrowns) {
  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: "BuyDialog",
    pageBuilder: (_, __, ___) => Container(),
    transitionBuilder: (context, animation, secondaryAnimation, child) {
      return FadeTransition(
        opacity: animation,
        child: ScaleTransition(
          scale: CurvedAnimation(parent: animation, curve: Curves.easeOutBack),
          child: _buildAnimatedBuyDialog(context, userCrowns),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 400),
  );
}

Widget _buildAnimatedBuyDialog(BuildContext context, int availableCrowns) {
  int selectedCrowns = 0;

  return StatefulBuilder(
    builder: (context, setState) {
      final cashValue = selectedCrowns * 250; // 👈 Cash based on crowns

      return Center(
        child: Material(
          color: Colors.transparent,
          child: Stack(
            children: [
              // Dialog Container
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 24),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.25),
                      blurRadius: 25,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(height: 10),
                    Image.asset(TImages.crown, height: 60, width: 60),
                    const SizedBox(height: 16),

                    const Text("Crown Exchange",
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87)),
                    const SizedBox(height: 8),

                    Text("You have $availableCrowns 👑",
                        style: const TextStyle(
                            fontSize: 18,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500)),
                    const SizedBox(height: 20),

                    // Crown Selector
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          onPressed: selectedCrowns > 1
                              ? () => setState(() => selectedCrowns--)
                              : null,
                          icon:
                              const Icon(Icons.remove_circle_outline, size: 30),
                        ),
                        Text("$selectedCrowns",
                            style: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w600)),
                        IconButton(
                          onPressed: selectedCrowns < availableCrowns
                              ? () => setState(() => selectedCrowns++)
                              : null,
                          icon: const Icon(Icons.add_circle_outline, size: 30),
                        ),
                      ],
                    ),

                    const SizedBox(height: 8),

                    Text("Get ₹$cashValue Cash",
                        style: const TextStyle(
                            fontSize: 18,
                            color: TColors.red,
                            fontWeight: FontWeight.bold)),

                    const SizedBox(height: 28),

                    // Redeem Button
                    /* SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: selectedCrowns > 0
                            ? () {
                                // Confirmation Popup
                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      backgroundColor: Colors.white,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      title: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text("Confirm Redemption",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold)),
                                          IconButton(
                                            icon: const Icon(Icons.close,
                                                color: Colors.black87),
                                            onPressed: () =>
                                                Navigator.pop(context),
                                          ),
                                        ],
                                      ),
                                      content: Text(
                                          "Are you sure you want to redeem $selectedCrowns crown(s) for ₹$cashValue ?"),
                                      actions: [
                                        ElevatedButton(
                                          onPressed: () =>
                                              Navigator.pop(context),
                                          style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.red,
                                              foregroundColor: Colors.white),
                                          child: const Text("No"),
                                        ),
                                        ElevatedButton(
                                          onPressed: () async {
                                            Get.back();
                                            Get.back(); // ✅ Close confirmation & main dialog

                                            final redeemController =
                                                Get.find<RedeemController>();

                                            final result =
                                                await redeemController
                                                    .redeemAdd(cashValue);

                                            if (result != null &&
                                                result["status"] == true) {
                                              // Refresh points after redeem
                                              await Get.find<AppbarController>()
                                                  .fetchPointsDetails();

                                              final safeContext = Get.context!;
                                              showDialog(
                                                context: safeContext,
                                                builder: (BuildContext
                                                    dialogContext) {
                                                  return AlertDialog(
                                                    backgroundColor:
                                                        Colors.white,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              16),
                                                    ),
                                                    title: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        const Text(
                                                            "Redeem Success",
                                                            style: TextStyle(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Colors
                                                                    .green)),
                                                        IconButton(
                                                          icon: const Icon(
                                                              Icons.close,
                                                              color: Colors
                                                                  .black87),
                                                          onPressed: () =>
                                                              Navigator.pop(
                                                                  dialogContext),
                                                        ),
                                                      ],
                                                    ),
                                                    content: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        const Text(
                                                            "Your coupon code:",
                                                            style: TextStyle(
                                                                fontSize: 16)),
                                                        const SizedBox(
                                                            height: 10),
                                                        Container(
                                                          padding:
                                                              const EdgeInsets
                                                                  .symmetric(
                                                                  horizontal:
                                                                      12,
                                                                  vertical: 8),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors
                                                                .grey.shade200,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        8),
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                result["coupon_code"] ??
                                                                    "",
                                                                style:
                                                                    const TextStyle(
                                                                  fontSize: 18,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                              ),
                                                              IconButton(
                                                                icon: const Icon(
                                                                    Icons.copy,
                                                                    color: Colors
                                                                        .blue),
                                                                onPressed: () {
                                                                  Clipboard.setData(
                                                                      ClipboardData(
                                                                          text: result["coupon_code"] ??
                                                                              ""));
                                                                  ScaffoldMessenger.of(
                                                                          safeContext)
                                                                      .showSnackBar(
                                                                    const SnackBar(
                                                                      content: Text(
                                                                          "Coupon code copied!"),
                                                                    ),
                                                                  );
                                                                },
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              );
                                            }
                                          },
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: TColors.primary,
                                          ),
                                          child: const Text("Yes"),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              }
                            : null, // ❌ Disabled when crowns = 0
                        style: ElevatedButton.styleFrom(
                          backgroundColor: selectedCrowns > 0
                              ? TColors.primary
                              : Colors.grey.shade50, // Grey when disabled
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Text("Redeem"),
                      ),
                    ),*/
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          if (selectedCrowns <= 0) {
                            // ⚠️ Show snackbar when no crowns selected
                            Fluttertoast.showToast(
                              msg: "Please select at least 1 crown to proceed",
                              toastLength: Toast.LENGTH_LONG,
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: TColors.primary,
                              textColor: Colors.white,
                              fontSize: 16.0,
                            );
                            return;
                          }

                          // ✅ Show confirmation popup when crowns > 0
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                backgroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                title: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text("Confirm Redemption",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold)),
                                    IconButton(
                                      icon: const Icon(Icons.close,
                                          color: Colors.black87),
                                      onPressed: () => Navigator.pop(context),
                                    ),
                                  ],
                                ),
                                content: Text(
                                    "Are you sure you want to redeem $selectedCrowns crown(s) for ₹$cashValue ?"),
                                actions: [
                                  ElevatedButton(
                                    onPressed: () => Navigator.pop(context),
                                    style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.red,
                                        foregroundColor: Colors.white),
                                    child: const Text("No"),
                                  ),
                                  ElevatedButton(
                                    onPressed: () async {
                                      Get.back();
                                      Get.back(); // ✅ Close confirmation & main dialog

                                      final redeemController =
                                          Get.find<RedeemController>();
                                      final result = await redeemController
                                          .redeemAdd(cashValue, selectedCrowns);

                                      if (result != null &&
                                          result["status"] == true) {
                                        // Refresh points after redeem
                                        await Get.find<AppbarController>()
                                            .fetchPointsDetails();

                                        final safeContext = Get.context!;
                                        showDialog(
                                          context: safeContext,
                                          builder:
                                              (BuildContext dialogContext) {
                                            return AlertDialog(
                                              backgroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(16),
                                              ),
                                              title: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text("Redeem Success",
                                                      style: GoogleFonts.prompt(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color:
                                                              TColors.primary)),
                                                  IconButton(
                                                    icon: const Icon(
                                                        Icons.close,
                                                        color: Colors.black87),
                                                    onPressed: () =>
                                                        Navigator.pop(
                                                            dialogContext),
                                                  ),
                                                ],
                                              ),
                                              content: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Text("Your coupon code:",
                                                      style: GoogleFonts.prompt(
                                                          fontSize: 16)),
                                                  const SizedBox(height: 10),
                                                  Container(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                        horizontal: 12,
                                                        vertical: 8),
                                                    decoration: BoxDecoration(
                                                      color:
                                                          Colors.grey.shade200,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Text(
                                                          result["coupon_code"] ??
                                                              "",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 18,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        IconButton(
                                                          icon: const Icon(
                                                              Icons.copy,
                                                              color: TColors
                                                                  .primary),
                                                          onPressed: () {
                                                            Clipboard.setData(
                                                                ClipboardData(
                                                                    text: result[
                                                                            "coupon_code"] ??
                                                                        ""));
                                                            Fluttertoast
                                                                .showToast(
                                                              msg:
                                                                  "Coupon code copied!",
                                                              toastLength: Toast
                                                                  .LENGTH_SHORT,
                                                              gravity:
                                                                  ToastGravity
                                                                      .BOTTOM,
                                                              backgroundColor:
                                                                  TColors
                                                                      .primary,
                                                              textColor:
                                                                  Colors.white,
                                                              fontSize: 16.0,
                                                            );
                                                          },
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        );
                                      }
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: TColors.primary,
                                    ),
                                    child: const Text("Yes"),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: selectedCrowns > 0
                              ? TColors.primary
                              : Colors.grey, // Grey when disabled
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text("Redeem"),
                      ),
                    )
                  ],
                ),
              ),

              // ❌ Close Icon (Main Dialog)
              Positioned(
                top: 15,
                right: 40,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: const CircleAvatar(
                    radius: 16,
                    backgroundColor: Colors.black54,
                    child: Icon(Icons.close, color: Colors.white, size: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
