import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/http/api_constants.dart';
import '../../../models/redeemmodel.dart';
import '../../side_drawer_menu/notifications/notification_controller.dart';

class RedeemController extends GetxController {
  //add redeem
  var isredeemaddLoading = false.obs;

  Future<Map<String, dynamic>?> redeemAdd(
      int redeemValue, int crownCount) async {
    try {
      isredeemaddLoading.value = true;

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
        "is_merge": 0,
        "redeem_value": redeemValue,
        "crown_count": crownCount
      };

      print("🔵 Redeem API Request Body: $body");

      final response =
          await THttpHelper.post(APIConstants.redeemaddendpoint, body);

      print("🟢 Redeem API Raw Response: $response");

      if (response["status"] == true) {
        print("✅ Redeem Success - Coupon Code: ${response['coupon_code']}");
        print("✅ Redeem Message: ${response['message']}");
        // 🔄 Refresh points after successful redeem
        await Get.find<AppbarController>().fetchPointsDetails();
        final notificationController = Get.find<NotificationController>();
        await notificationController.fetchNotificationList();
        final appbarController = Get.find<AppbarController>();
        appbarController.incrementNotify();
        return response;
      } else {
        print("⚠️ Redeem Failed - Response: $response");
      }

      return null;
    } catch (e) {
      print("❌ Redeem API Error: $e");
      return null;
    } finally {
      isredeemaddLoading.value = false;
      print("🔄 Redeem API Completed");
    }
  }

  //redeem list
  var isredeemLoading = false.obs;
  var redeemList = <RedeemModel>[].obs;

  Future<void> fetchRedeemList() async {
    try {
      isredeemLoading(true);

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };

      final response = await THttpHelper.post(
        APIConstants.redeemlistendpoint,
        body,
      );

      if (response != null && response['status'] == true) {
        // ✅ Map API data to model
        redeemList.value = (response['data'] as List)
            .map((e) => RedeemModel.fromJson(e))
            .toList();
      } else {
        redeemList.clear();
        print("No data found: ${response?['message']}");
      }
    } catch (e) {
      redeemList.clear();
      print("Error fetching redeem list: $e");
    } finally {
      isredeemLoading(false);
    }
  }
}
