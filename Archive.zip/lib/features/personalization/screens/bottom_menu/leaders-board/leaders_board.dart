import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../common/widget/images/t_circular_image.dart';
import '../../../../../utils/constants/path_provider.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../controllers/bottom_bar_controller/points_controller.dart';

class LeaderBoard extends StatelessWidget {
  const LeaderBoard({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(PointsController());
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.fetchLeaderBoard();

      // ✅ Run tutorial only once
      final isTutorialShown = GetStorage().read(TTexts.leadertour) ?? false;
      if (!controller.isLeaderboardTouron.value && !isTutorialShown) {
        Future.delayed(const Duration(milliseconds: 500), () async {
          await controller.LeaderboardTour(context);
          GetStorage().write(TTexts.leadertour, true);
          controller.isLeaderboardTouron.value = true;
        });
      }
    });

    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Leaderboard"),
        ),
        body: Container(
          margin: EdgeInsets.only(left: 15, right: 15, top: 5),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 10),
                            Obx(() {
                              if (controller.isLoading.value) {
                                return const TAnimationLoaderWidget();
                              }
      
                              final current = controller.currentUser.value;
      
                              return Column(
                                children: [
                                  /// 👤 Current User Card
                                  if (current != null)
                                    Container(
                                      key: controller.yourpointskey,
                                      margin:
                                          const EdgeInsets.symmetric(vertical: 8),
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: Color(0xFFEFBF04),
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(color: TColors.grey),
                                      ),
                                      child: ListTile(
                                        leading: TCircularImage(
                                          padding: 1,
                                          image: GetStorage()
                                                  .read(TTexts.profileURL)
                                                  .isNotEmpty
                                              ? GetStorage()
                                                  .read(TTexts.profileURL)
                                              : TImages.profileImage,
                                          width: 50,
                                          height: 50,
                                          isNetworkImage: GetStorage()
                                                  .read(TTexts.profileURL)
                                                  .isEmpty
                                              ? false
                                              : true,
                                        ),
                                        title: Text(
                                          current.cusName,
                                          style: GoogleFonts.prompt(
                                            fontSize: 18,
                                            color: TColors.primary,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        subtitle: Text(
                                          "Your points: ${current.pointsScore}",
                                          style: GoogleFonts.prompt(
                                            fontSize: 16,
                                            color: TColors.primary,
                                            fontWeight: FontWeight.normal,
                                          ),
                                        ),
                                        /*trailing: Container(
                                          margin: EdgeInsets.only(right: 3),
                                          width: 45, // 🔹 Smaller points circle
                                          height: 45,
                                          decoration: BoxDecoration(
                                            color: TColors.primary,
                                            border: Border.all(
                                              color: TColors.secondary,
                                              width: 2,
                                            ),
                                            shape: BoxShape.circle,
                                          ),
                                          alignment: Alignment.center,
                                          child: Text(
                                            current.pointsScore.toString(),
                                            style: GoogleFonts.prompt(
                                              fontSize:
                                                  16, // adjust text size to fit circle
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),*/
                                        trailing: (current.rank == 1 ||
                                                current.rank == 2 ||
                                                current.rank == 3)
                                            ? CircleAvatar(
                                                radius: 30,
                                                backgroundColor:
                                                    Colors.transparent,
                                                child: Image.asset(
                                                  current.rank == 1
                                                      ? TImages.gold
                                                      : current.rank == 2
                                                          ? TImages.silver
                                                          : TImages.bronze,
                                                ),
                                              )
                                            : Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                width: 45,
                                                height: 45,
                                                decoration: BoxDecoration(
                                                  color: TColors.primary,
                                                  border: Border.all(
                                                    color: TColors.secondary,
                                                    width: 2,
                                                  ),
                                                  shape: BoxShape.circle,
                                                ),
                                                alignment: Alignment.center,
                                                child: Center(
                                                  child: Text(
                                                    current.rank.toString(),
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                      ),
                                    ),
      
                                  /// 🏆 Leaderboard List
                                  ListView.builder(
                                    shrinkWrap: true,
                                    physics: const NeverScrollableScrollPhysics(),
                                    itemCount: controller.leaderBoardList.length,
                                    itemBuilder: (context, index) {
                                      final item =
                                          controller.leaderBoardList[index];
                                      return Container(
                                        key: index == 0
                                            ? controller
                                                .otherpointsKey // ✅ only first item gets key
                                            : null,
                                        margin: const EdgeInsets.symmetric(
                                            vertical: 6, horizontal: 10),
                                        padding: const EdgeInsets.all(12),
                                        decoration: BoxDecoration(
                                            color: TColors.white,
                                            borderRadius:
                                                BorderRadius.circular(6),
                                            border:
                                                Border.all(color: TColors.grey)),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Flexible(
                                              child: Row(
                                                children: [
                                                  const SizedBox(width: 10),
                                                  CircleAvatar(
                                                    radius: 25,
                                                    backgroundImage: (item.sno
                                                                    .toString() ==
                                                                GetStorage()
                                                                    .read(TTexts
                                                                        .userID)
                                                                    .toString() &&
                                                            item.cusPic != null &&
                                                            item.cusPic
                                                                .isNotEmpty)
                                                        ? NetworkImage(item
                                                            .cusPic) // ✅ show API image for current user
                                                        : AssetImage(TImages
                                                                .profileImage)
                                                            as ImageProvider, // others use default
                                                  ),
                                                  const SizedBox(width: 10),
                                                  Flexible(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          item.cusName,
                                                          style:
                                                              GoogleFonts.prompt(
                                                                  color: TColors
                                                                      .primaryblue,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  fontSize: 18),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                        ),
                                                        Text(
                                                          'Points: ${item.pointsScore}', // added "Points:" before the score
                                                          style:
                                                              GoogleFonts.prompt(
                                                                  color: TColors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  fontSize: 12),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
      
                                            /// 🥇🥈🥉 Badges / Rank
                                            if (index == 0 ||
                                                index == 1 ||
                                                index == 2)
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    right: 5),
                                                child: CircleAvatar(
                                                  radius: 30,
                                                  backgroundColor:
                                                      Colors.transparent,
                                                  child: Image.asset(
                                                    index == 0
                                                        ? TImages.gold
                                                        : index == 1
                                                            ? TImages.silver
                                                            : TImages.bronze,
                                                  ),
                                                ),
                                              )
                                            else
                                              Container(
                                                margin:
                                                    EdgeInsets.only(right: 10),
                                                width:
                                                    45, // 🔹 Smaller points circle
                                                height: 45,
                                                decoration: BoxDecoration(
                                                  color: TColors.primary,
                                                  border: Border.all(
                                                    color: TColors.secondary,
                                                    width: 2,
                                                  ),
                                                  shape: BoxShape.circle,
                                                ),
                                                alignment: Alignment.center,
                                                child: Center(
                                                  child: Text(
                                                    item.rank.toString(),
                                                    style: const TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ],
                              );
                            }),
                          ],
                        ),
                      ),
                      const SizedBox(height: TSizes.sm),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
