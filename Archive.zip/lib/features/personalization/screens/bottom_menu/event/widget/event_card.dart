import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:intl/intl.dart';

import '../../../../models/event_model.dart';
import '../event_controller.dart';
import 'eventbookingpage.dart';
import 'eventviewdialog.dart';

class EventCard extends StatelessWidget {
  final EventModel event;

  const EventCard({super.key, required this.event});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(EventController());
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: TColors.grey),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// 🔹 Top Row (Image + Title + Location + Status)
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 7),
                width: 40, // set width
                height: 40, // set height
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3), // rounded corners
                  image: DecorationImage(
                    image: AssetImage(TImages.eventImage),
                    fit: BoxFit.contain,
                  ),
                ),
              ),

              const SizedBox(width: 10),

              /// Title + Location
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          truncateEventName(event.eventName),
                          style: AppTextStyles.heading,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),

                        /// ✅ Availability only for non-completed
                        if (event.booked == 0 && event.status != 4)
                          Padding(
                            padding: const EdgeInsets.only(right: 15),
                            child: Text(
                              isAvailable(event.remainingParticipants)
                                  ? "Available"
                                  : "Not Available",
                              style: TextStyle(
                                color: isAvailable(event.remainingParticipants)
                                    ? Colors.green
                                    : Colors.red,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Image.asset(
                          TImages.mode,
                          width: 25,
                          height: 25,
                          fit: BoxFit.contain,
                        ),
                        const SizedBox(width: 4),
                        Text(event.eventType ?? "",
                            style: AppTextStyles.subheading),

                        /// Show remaining days only for upcoming events
                        if ((event.status != 4) &&
                            (event.booked == 0 || event.booked == 1)) ...[
                          const SizedBox(width: 10),
                          Image.asset(
                            TImages.days,
                            width: 22,
                            height: 22,
                            fit: BoxFit.contain,
                          ),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(
                              '${event.daysremaining} day${event.daysremaining == 1 ? '' : 's'}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              softWrap: false,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              /// 📅 Date + Time
              Expanded(
                flex: 3,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.calender,
                      width: 22,
                      height: 22,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text(
                        formatDate(event.eventDate),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    if ((event.start_time != null &&
                            event.start_time!.isNotEmpty) &&
                        (event.end_time != null &&
                            event.end_time!.isNotEmpty)) ...[
                      const SizedBox(width: 5),
                      Image.asset(
                        TImages.time,
                        width: 22,
                        height: 22,
                        fit: BoxFit.contain,
                      ),
                      const SizedBox(width: 5),
                      Flexible(
                        child: Text(
                          "${formatTime(event.start_time)}",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          softWrap: false,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(width: 10),
                  ],
                ),
              ),

              /// 🎟 Button (fixed width, same alignment style as rating)
              ConstrainedBox(
                constraints: const BoxConstraints(
                  minWidth: 90, // ensures consistency
                  minHeight: 36,
                ),
                child: ElevatedButton(
                  onPressed: () {
                    if (event.status == 4) {
                      // Completed button -> no action
                    } else {
                      if (event.booked == 0) {
                        Get.to(() => EventBookingPage(event: event));
                      } else {
                        showEventDetailsDialog(context, event);
                      }
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: event.status == 4
                        ? Colors.green // Completed button green
                        : event.remainingParticipants == "0" &&
                                event.booked != 1
                            ? Colors.grey[300] // Sold out
                            : TColors.primary, // default
                    foregroundColor: Colors.white, // text color always white
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    minimumSize: const Size(90, 36),
                  ),

                  /* child: Text(
                    event.status == 4
                        ? "Completed"
                        : event.remainingParticipants == "0" &&
                                event.booked != 1
                            ? "Sold Out"
                            : event.booked == 0
                                ? "Book Now"
                                : "View",
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),*/
                  child: Text(
                    // Dynamic button text based on tab and event
                    controller.selectedTab.value == 2
                        ? "Completed" // Completed tab
                        : controller.selectedTab.value == 1
                            ? "View" // Booked tab
                            : event.booked == 0
                                ? "Book Now" // Upcoming tab, not booked
                                : "Booked", // Upcoming tab, already booked
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

String truncateEventName(String name) {
  final words = name.split(' ');
  if (words.length <= 2) {
    return name; // return as is
  } else {
    final firstTwo = words.take(2).join(' ');
    final third = words[2];
    final partialThird = third.length > 3 ? third.substring(0, 2) : third;
    return "$firstTwo $partialThird...";
  }
}

bool isAvailable(String? remaining) {
  if (remaining == null) return false;
  remaining = remaining.trim();
  if (remaining == "Unlimited") return true;
  final number = int.tryParse(remaining);
  return number != null && number > 0;
}

// Convert "10:00:00" -> "10:00 AM"
String formatTime(String? time) {
  if (time == null || time.trim().isEmpty) return "--";
  try {
    final parsed = DateFormat("HH:mm:ss").parse(time.trim());
    return DateFormat.jm().format(parsed);
  } catch (e) {
    print("Time parse error: $e for input '$time'");
    return "--";
  }
}

// Convert date string to formatted date
String formatDate(String date) {
  try {
    final DateTime parsedDate = DateTime.parse(date);
    return DateFormat("dd MMM yyyy").format(parsedDate);
    // Example: 05 Sep 2025
  } catch (e) {
    return date; // fallback in case of error
  }
}
