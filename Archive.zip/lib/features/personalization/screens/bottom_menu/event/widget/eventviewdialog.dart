import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../../../../utils/constants/apptextstyles.dart';
import '../../../../../../utils/constants/path_provider.dart';
import '../../../../models/event_model.dart';

void showEventDetailsDialog(BuildContext context, EventModel event) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: TColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.all(16),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Event Image + Name + Amount
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 9),
                    width: 30, // set width
                    height: 30, // set height
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(3), // rounded corners
                      image: DecorationImage(
                        image: AssetImage(TImages.eventImage),
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Text(
                              event.eventName
                                  .split(' ')
                                  .first, // only first word
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: AppTextStyles.heading,
                            ),
                          ),
                        ),

                        /// Close Icon
                        InkWell(
                          onTap: () => Navigator.pop(context),
                          child: const Icon(
                            Icons.close,
                            color: Colors.black,
                            size: 24,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              /// Date + Time
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    iconDetailRow(
                        TImages.calender, "${formatDate(event.eventDate)}"),
                    SizedBox(
                      width: 5,
                    ),
                    if ((event.start_time != null &&
                            event.start_time!.isNotEmpty) &&
                        (event.end_time != null && event.end_time!.isNotEmpty))
                      iconDetailRow(
                        TImages.time,
                        "${formatTime(event.start_time)} to ${formatTime(event.end_time)}",
                      ),
                  ],
                ),
              ),

              const SizedBox(height: 15),

              /// Address
              iconDetailRowMultiLine(
                  TImages.location, event.eventAddress ?? "Not Available"),

              const SizedBox(height: 15),

              /// Speaker
              iconDetailRow(
                  TImages.speaker, "Speaker : ${event.eventSpeaker ?? "N/A"}"),

              const SizedBox(height: 15),

              /// E-Certificate + Mode
              Row(
                children: [
                  iconDetailRow(
                      TImages.certificate, event.eventCertificate ?? ""),
                  const SizedBox(width: 16),
                  iconDetailRow(TImages.mode, event.eventType ?? ""),
                ],
              ),

              const SizedBox(height: 20),

              /// About Workshop Description
              Text("About Workshop Description",
                  style: GoogleFonts.prompt(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.32,
                  )),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: TColors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: TColors.grey),
                ),
                child: Text(
                  event.eventDescription ??
                      "In today’s connected world, cyber threats are growing at an unprecedented rate.",
                  style: GoogleFonts.prompt(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    height: 1.5,
                    letterSpacing: 0.32,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

/// Icon + Text Row
Widget iconDetailRow(String imagePath, String text) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Image.asset(
        imagePath,
        width: 25,
        height: 25,
        fit: BoxFit.contain,
      ),
      const SizedBox(width: 8),
      Text(
        text,
        style: GoogleFonts.prompt(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          fontStyle: FontStyle.normal,
          height: 1.0,
          letterSpacing: 0.32,
        ),
      )
    ],
  );
}

Widget iconDetailRowMultiLine(String imagePath, String text) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.start, // aligns text top with icon
    children: [
      Image.asset(
        imagePath,
        width: 25,
        height: 25,
        fit: BoxFit.contain,
      ),
      const SizedBox(width: 8),
      Expanded(
        child: Text(
          text,
          style: GoogleFonts.prompt(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            fontStyle: FontStyle.normal,
            height: 1.5,
            letterSpacing: 0.32,
          ),
        ),
      ),
    ],
  );
}

bool isAvailable(String? remaining) {
  if (remaining == null) return false;
  remaining = remaining.trim();
  if (remaining == "Unlimited") return true;
  final number = int.tryParse(remaining);
  return number != null && number > 0;
}

// Convert "10:00:00" -> "10:00 AM"
String formatTime(String? time) {
  if (time == null || time.trim().isEmpty) return "--"; // fallback
  try {
    final parsed = DateFormat("HH:mm:ss").parse(time.trim());
    return DateFormat.jm().format(parsed); // 12-hour format like 10:00 AM
  } catch (e) {
    print("Time parse error: $e for input '$time'");
    return "--";
  }
}

String formatDate(String date) {
  try {
    final DateTime parsedDate = DateTime.parse(date);
    return DateFormat("dd MMM yyyy").format(parsedDate);
    // Example: 05 Sep 2025
  } catch (e) {
    return date; // fallback in case of error
  }
}
