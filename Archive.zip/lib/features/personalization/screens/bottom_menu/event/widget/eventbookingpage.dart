import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../../utils/constants/apptextstyles.dart';
import '../../../../../../utils/constants/text_strings.dart';
import '../../../../models/event_model.dart';
import '../event_controller.dart';
import 'event_card.dart';

class EventBookingPage extends StatelessWidget {
  final EventModel event;
  final controller = Get.put(EventController());
  EventBookingPage({
    super.key,
    required this.event,
  });
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown =
          GetStorage().read(TTexts.eventdetailstour) ?? false;

      if (!controller.isEventdetailsTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 500));
        await controller.EventdetailsTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.eventdetailstour, true);
        controller.isEventdetailsTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
   
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          isMenuNeed: false,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Back button + title
              Transform.translate(
                offset: const Offset(-5, 0), // move 8px left(
                child: Row(
                  children: [
                    InkWell(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(Icons.arrow_back, color: Colors.black),
                    ),
                    const SizedBox(width: 8),
                    Text("Tech Event Details", style: AppTextStyles.title),
                  ],
                ),
              ),
              const SizedBox(height: 20),
      
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// Event Image + Name + Fee
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        /// Image Placeholder
                        const CircleAvatar(
                          radius: 30,
                          backgroundImage: AssetImage(TImages.eventImage),
                        ),
                        const SizedBox(width: 10),
      
                        /// Event Name + Amount
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              /// Event Name (single line)
                              Flexible(
                                child: Align(
                                  alignment: Alignment
                                      .centerLeft, // keep it left-aligned horizontally
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        top:
                                            20), // adjust top value to move down slightly
                                    child: Text(
                                      event.eventName,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyles.heading,
                                    ),
                                  ),
                                ),
                              ),
      
                              /// Amount Box
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: TColors.primary),
                                ),
                                child: Text(
                                  event.eventAmount == 0
                                      ? "Free"
                                      : "₹ ${event.eventAmount}",
                                  style: const TextStyle(
                                      fontSize: 14, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
      
                    const SizedBox(height: 16),
      
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Date + Time in a single row
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 15),
                              child: _iconDetailRow(
                                  TImages.calender,
                                  "${formatDate(
                                    event.eventDate,
                                  )}"),
                            ),
                            if ((event.start_time != null &&
                                    event.start_time!.isNotEmpty) &&
                                (event.end_time != null &&
                                    event.end_time!.isNotEmpty))
                              _iconDetailRow(
                                TImages.time,
                                "${formatTime(event.start_time)} to ${formatTime(event.end_time)}",
                              ),
                          ],
                        ),
      
                        const SizedBox(height: 15),
      
                        // Address row
                        Padding(
                          padding: const EdgeInsets.only(left: 15),
                          child: _iconDetailRowMultiLine(
                            TImages.location,
                            event.eventAddress ?? "Not Available",
                          ),
                        ),
      
                        const SizedBox(height: 15),
      
                        // Speaker row
                        Padding(
                          padding: const EdgeInsets.only(left: 15),
                          child: _iconDetailRow(
                            TImages.speaker,
                            "Speaker : ${event.eventSpeaker}",
                          ),
                        ),
      
                        const SizedBox(height: 15),
      
                        // E-Certificate + Mode in single row
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 15),
                              child: _iconDetailRow(
                                TImages.certificate,
                                event.eventCertificate ?? "", // fallback if null
                              ),
                            ),
                            const SizedBox(width: 16),
                            _iconDetailRow(
                              TImages.mode,
                              event.eventType ?? "", // fallback if null
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
      
              /// About Workshop Description
              Text("About Workshop Description",
                  style: GoogleFonts.prompt(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.normal,
                    height: 1.0,
                    letterSpacing: 0.32,
                  )),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                    color: TColors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: TColors.grey)),
                child: Text(
                  event.eventDescription ??
                      "In today’s connected world, cyber threats are growing at an unprecedented rate. From phishing scams to ransomware attacks, no individual or organization is completely safe.",
                  style: GoogleFonts.prompt(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    fontStyle: FontStyle.normal,
                    height: 1.5,
                    letterSpacing: 0.32,
                  ),
                ),
              ),
      
              const SizedBox(height: 24),
      
              /// Buttons
              /*Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    //key: controller.bookKey,
                    width: 150, // adjust width as needed
                    child: ElevatedButton(
                      onPressed: () async {
                        await controller.bookEvent(event.eventId);
                        // ✅ Show success dialog
                        Get.dialog(
                          Dialog(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            backgroundColor: Colors.white,
                            child: Padding(
                              padding: const EdgeInsets.all(20),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  /// 🔹 Close Icon (top-right)
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: IconButton(
                                      icon: const Icon(Icons.close,
                                          color: Colors.black),
                                      onPressed: () => Get.back(),
                                    ),
                                  ),
      
                                  /// 🔹 Success Image
                                  Image.asset(
                                    TImages.success, // replace with your asset
                                    width: 150,
                                    height: 150,
                                    fit: BoxFit.contain,
                                  ),
                                  const SizedBox(height: 20),
      
                                  /// 🔹 Success Text
                                  Text(
                                    "Successfully Booked!",
                                    textAlign: TextAlign.center,
                                    style: GoogleFonts.prompt(
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        color: TColors.primary),
                                  )
                                ],
                              ),
                            ),
                          ),
                          barrierDismissible:
                              false, // disable tap outside to close
                        );
                        // ✅ Auto-close after 5 seconds
                        Future.delayed(const Duration(seconds: 5), () {
                          if (Get.isDialogOpen ?? false) {
                            Get.back(); // close dialog automatically
                          }
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: TColors.primary,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Obx(
                        () => controller.isBookLoading.value
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                "Book Now",
                                style: GoogleFonts.prompt(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  fontStyle: FontStyle.normal,
                                  height: 1.0,
                                  letterSpacing: 0.32,
                                ),
                              ),
                      ),
                    ),
                  ),
                ],
              ),*/
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 150,
                    child: Obx(() {
                      final isLoading = controller.isBookLoading.value;
                      final isBooked = event.booked == 1; // check if booked
      
                      return ElevatedButton(
                        onPressed: isBooked || isLoading
                            ? null // disable if already booked or loading
                            : () async {
                                await controller.bookEvent(event.eventId);
      
                                // ✅ Mark as booked locally so button text changes
                                event.booked.value = 1;
                                controller.eventData.refresh();
      
                                // ✅ Show success dialog
                                Get.dialog(
                                  Dialog(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    backgroundColor: Colors.white,
                                    child: Padding(
                                      padding: const EdgeInsets.all(20),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Align(
                                            alignment: Alignment.topRight,
                                            child: IconButton(
                                              icon: const Icon(Icons.close,
                                                  color: Colors.black),
                                              onPressed: () => Get.back(),
                                            ),
                                          ),
                                          Image.asset(
                                            TImages.success,
                                            width: 150,
                                            height: 150,
                                            fit: BoxFit.contain,
                                          ),
                                          const SizedBox(height: 20),
                                          Text(
                                            "Successfully Booked!",
                                            textAlign: TextAlign.center,
                                            style: GoogleFonts.prompt(
                                              fontSize: 22,
                                              fontWeight: FontWeight.bold,
                                              color: TColors.primary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  barrierDismissible: false,
                                );
      
                                // Auto-close after 5 seconds
                                Future.delayed(const Duration(seconds: 5), () {
                                  if (Get.isDialogOpen ?? false) {
                                    Get.back();
                                  }
                                });
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              isBooked ? Colors.green : TColors.primary,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: isLoading
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                isBooked ? "Booked" : "Book Now",
                                style: GoogleFonts.prompt(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                      );
                    }),
                  ),
                ],
              ),
      
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  /// Icon + Text Row
  Widget _iconDetailRow(String imagePath, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Image.asset(
          imagePath,
          width: 25,
          height: 25,
          fit: BoxFit.contain,
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: GoogleFonts.prompt(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            fontStyle: FontStyle.normal,
            height: 1.0,
            letterSpacing: 0.32,
          ),
        )
      ],
    );
  }

  Widget _iconDetailRowMultiLine(String imagePath, String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start, // aligns text top with icon
      children: [
        Image.asset(
          imagePath,
          width: 25,
          height: 25,
          fit: BoxFit.contain,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: GoogleFonts.prompt(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              fontStyle: FontStyle.normal,
              height: 1.5,
              letterSpacing: 0.32,
            ),
          ),
        ),
      ],
    );
  }
}
