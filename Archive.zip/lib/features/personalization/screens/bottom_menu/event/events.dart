import 'package:eapl_student_app/features/personalization/screens/bottom_menu/event/event_controller.dart';
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:eapl_student_app/utils/constants/sizes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/animation_loaders.dart';
import 'widget/event_card.dart';

class EventPage extends StatelessWidget {
  final controller = Get.put(EventController());

  EventPage({super.key});
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.eventtour) ?? false;

      if (!controller.isEventTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.EventTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.eventtour, true);
        controller.isEventTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    return Container(
      margin: const EdgeInsets.only(left: 5, right: 5, top: 15),
      child: RefreshIndicator(
        onRefresh: controller.fetchEventDetails,
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// Heading
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child:
                          Text("Apply Tech Events", style: AppTextStyles.title),
                    ),
                    const SizedBox(height: TSizes.sm),

                    /// Tabs - Live, Booked, Completed
                    Obx(() => Row(
                          key: controller.tabKey,
                          children: [
                            ToggleButtons(
                              renderBorder: false,
                              fillColor: Colors.transparent,
                              splashColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              isSelected: [
                                controller.selectedTab.value == 0,
                                controller.selectedTab.value == 1,
                                controller.selectedTab.value == 2,
                              ],
                              onPressed: (index) =>
                                  controller.selectedTab.value = index,
                              children: [
                                _buildTab("Upcoming",
                                    controller.selectedTab.value == 0),
                                _buildTab("Booked",
                                    controller.selectedTab.value == 1),
                                _buildTab("Completed",
                                    controller.selectedTab.value == 2),
                              ],
                            ),
                          ],
                        )),
                    const SizedBox(height: TSizes.sm),

                    /// Event List (Filtered)
                    Obx(() {
                      if (controller.isLoading.value) {
                        return const TAnimationLoaderWidget(
                          text: "Loading...",
                          animation: TImages.pencilAnimation,
                        );
                      }

                      // ✅ Filtering rules:
                      // Live     -> show ALL events
                      // Booked   -> booked == 1
                      // Completed-> status == 4
                      final filtered = controller.eventData.where((event) {
                        if (controller.selectedTab.value == 0) {
                          return event.status !=
                              4 /*&& event.booked == 0*/; // Live = all
                        } else if (controller.selectedTab.value == 1) {
                          return event.booked == 1 &&
                              event.status != 4; // Booked
                        } else {
                          return event.status == 4 &&
                              event.booked == 1; // Completed
                        }
                      }).toList();

                      if (filtered.isEmpty) {
                        return const Padding(
                          padding: EdgeInsets.all(20.0),
                          child: Center(
                            child: Text(
                              "No data found",
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w500),
                            ),
                          ),
                        );
                      }

                      return ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: filtered.length,
                        itemBuilder: (_, index) => EventCard(
                            key: index == 0
                                ? controller.eventcardKey
                                : ValueKey(filtered[index]),
                            event: filtered[index]),
                      );
                    }),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Tab Builder
  Widget _buildTab(String title, bool isSelected) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            title,
            style: GoogleFonts.prompt(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              height: 1.0,
              letterSpacing: 0.32,
              color: isSelected ? TColors.primary : Colors.grey.shade400,
            ),
          ),
        ),
        if (isSelected)
          Container(
            margin: const EdgeInsets.only(top: 4),
            height: 4,
            width: 80,
            color: TColors.grey,
          ),
      ],
    );
  }
}
