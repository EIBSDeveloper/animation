/*
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/loaders.dart';
import '../../../models/event_model.dart';

class EventController extends GetxController {
  @override
  void onInit() {
    super.onInit();
    fetchEventDetails();
  }

// Active tab index (0 = Live, 1 = Booked, 2 = Completed)
  var selectedTab = 0.obs;
  RxBool isLoading = false.obs;
  var eventData = <EventModel>[].obs;
  Future<void> fetchEventDetails() async {
    try {
      isLoading.value = true;
      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
      };
      final response = await THttpHelper.post(APIConstants.eventEndPoint, body);
      if (response["status"] == 200) {
        eventData.value = (response["event_list"] as List)
            .map((e) => EventModel.fromJson(e))
            .toList();
        print("fetchEventDetails : ${eventData.value.first.eventName}");
      } else {
        TSnackbar.errorSnackbar(
            title: "Oh Snap!", message: "unable to load the event Data");
        print(" fetchEventDetails : unable to load the event Data");
      }
      isLoading.value = false;
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap!", message: "unable to load the event Data");
      print("onError fetchEventDetails :$e");
      isLoading.value = false;
    }
  }

  var isBookLoading = false.obs;
  Future<void> bookEvent(int eventId) async {
    try {
      isBookLoading.value = true;
      print("📡 Booking process started for eventId: $eventId");

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
        "event_id": eventId,
      };
      print("📦 Request Body: $body");

      final response =
          await THttpHelper.post(APIConstants.bookeventendpoint, body);

      print("✅ API Response: $response");

      if (response != null && response['status'] == true) {
        final index = eventData.indexWhere((e) => e.eventId == eventId);
        if (index != -1) {
          eventData[index].booked = 1;
          eventData.refresh();
          print(
              "🎉 Event $eventId marked as booked locally in eventData list.");
        } else {
          print("⚠️ Event $eventId not found in eventData list.");
        }

        Get.back();
        print("🔙 Dialog closed after successful booking.");

        Get.snackbar(
          "Success",
          response['message'] ?? "Event booked successfully!",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: TColors.primary,
          colorText: Colors.white,
          duration: const Duration(seconds: 2),
        );
        print("📢 Success Snackbar shown to user.");
      } else {
        print("❌ Booking failed or already booked. Response: $response");

        Get.snackbar(
          "Notice",
          response['message'] ?? "Something went wrong",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.orange,
          colorText: Colors.white,
          duration: const Duration(seconds: 2),
        );
        print("📢 Notice Snackbar shown to user.");
      }
    } catch (e, stackTrace) {
      print("🔥 Exception while booking eventId $eventId: $e");
      print("📌 StackTrace: $stackTrace");

      Get.snackbar(
        "Error",
        "Something went wrong: $e",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
        duration: const Duration(seconds: 2),
      );
      print("📢 Error Snackbar shown to user.");
    } finally {
      isBookLoading.value = false;
      print("🔚 Booking process ended for eventId: $eventId");
    }
  }
}
*/
import 'package:eapl_student_app/features/apptour/bottom/events/eventstour.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/loaders.dart';
import '../../../models/event_model.dart';

class EventController extends GetxController {
  final selectedTab = 0.obs; // 0 = Live, 1 = Booked, 2 = Completed
  final isLoading = false.obs;
  final isBookLoading = false.obs;
  final eventData = <EventModel>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchEventDetails();
  }

  Future<void> fetchEventDetails() async {
    try {
      isLoading.value = true;

      final body = {"customer_id": GetStorage().read(TTexts.userID)};
      final response = await THttpHelper.post(APIConstants.eventEndPoint, body);

      final ok = (response?['status'] == 200) || (response?['status'] == true);
      if (!ok) {
        TSnackbar.errorSnackbar(
            title: "Oh Snap!", message: "Unable to load event data");
        eventData.clear();
        return;
      }

      final List list = (response?["event_list"] as List?) ??
          (response?["data"] as List?) ??
          (response?["events"] as List?) ??
          [];

      eventData.value = list
          .map((e) => EventModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap!", message: "Unable to load the event data");
      eventData.clear();
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> bookEvent(int eventId) async {
    try {
      isBookLoading.value = true;

      final body = {
        "customer_id": GetStorage().read(TTexts.userID),
        "event_id": eventId,
      };

      final response =
          await THttpHelper.post(APIConstants.bookeventendpoint, body);

      if (response != null &&
          (response['status'] == true || response['status'] == 200)) {
        final index = eventData.indexWhere((e) => e.eventId == eventId);
        if (index != -1) {
          eventData[index].booked.value = 1;
          eventData.refresh();
        }
        Get.back();
        Fluttertoast.showToast(
          msg: response['message'] ?? "Event booked successfully!",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: TColors.primary, // or any color you want
          textColor: Colors.white,
          fontSize: 16.0,
        );
      } else {
        Get.snackbar(
          "Notice",
          response?['message'] ?? "Something went wrong",
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } catch (e) {
      Get.snackbar(
        "Error",
        "Something went wrong: $e",
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isBookLoading.value = false;
    }
  }

  //eventstour
  final tabKey = GlobalKey();
  final eventcardKey = GlobalKey();

  var isEventTouron = false.obs;
  Future<void> EventTour(BuildContext context) async {
    final targets =
        EventsTourList.getTargets(tabKey: tabKey, eventcardKey: eventcardKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.eventtour, true);
        isEventTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.eventtour, true);
        isEventTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }

  //eventsdetailstour
  final bookKey = GlobalKey();

  var isEventdetailsTouron = false.obs;
  Future<void> EventdetailsTour(BuildContext context) async {
    final targets = EventsdetailsTourList.getTargets(bookKey: bookKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.eventdetailstour, true);
        isEventdetailsTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.eventdetailstour, true);
        isEventdetailsTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
