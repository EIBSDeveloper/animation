/*
 * Project Name:eapl_Mobile_app
 * Created by KARTHICK DINESH A
 * Copyrights(c) 2024. All Rights reserved
 * Last modified 6/19/24, 3:22 PM
 */
import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:eapl_student_app/utils/constants/sizes.dart';
import 'package:flutter/material.dart';

import '../../../../../../utils/helpers/helper_functions.dart';

class RatingBar extends StatelessWidget {
  final double rating;
  final ValueChanged<double> onRatingChanged;
  final Color activeColor;
  final double iconSize = TSizes.iconXLg;
  final double notSelectericonSize = TSizes.iconLg;

  RatingBar({super.key, required this.rating, required this.onRatingChanged, required this.activeColor});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Text(
        //   "Your FeedBack",
        //   style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.primary),
        // ),
        const SizedBox(height: 8),
        Container(
          // width: THelperFunctions.screenWidth(),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              rating==1.0?Image(image: const AssetImage(TImages.rat_1),width: iconSize,height: iconSize):Image(image: const AssetImage(TImages.rat_1),width: notSelectericonSize,height: notSelectericonSize),
              const SizedBox(width: TSizes.sm),
              rating==2.0?Image(image: const AssetImage(TImages.rat_2),width: iconSize,height: iconSize):Image(image: const AssetImage(TImages.rat_2),width: notSelectericonSize,height: notSelectericonSize),
              const SizedBox(width: TSizes.sm),
              rating==3.0?Image(image: const AssetImage(TImages.rat_3),width: iconSize,height: iconSize):Image(image: const AssetImage(TImages.rat_3),width: notSelectericonSize,height: notSelectericonSize),
              const SizedBox(width: TSizes.sm),
              rating==4.0?Image(image: const AssetImage(TImages.rat_4),width: iconSize,height: iconSize):Image(image: const AssetImage(TImages.rat_4),width: notSelectericonSize,height: notSelectericonSize),
              const SizedBox(width: TSizes.sm),
              rating==5.0?Image(image: const AssetImage(TImages.rat_5),width: iconSize,height: iconSize):Image(image: const AssetImage(TImages.rat_5),width: notSelectericonSize,height: notSelectericonSize),
            //    rating==1.0?Icon(Icons.sentiment_very_dissatisfied, color: Colors.red,size: iconSize,):Icon(Icons.sentiment_very_dissatisfied, color: Colors.red,size: notSelectericonSize,),
            //   SizedBox(width: TSizes.sm),
            //   rating==2.0?Icon(Icons.sentiment_dissatisfied, color: Colors.orange,size: iconSize): Icon(Icons.sentiment_dissatisfied, color: Colors.orange,size: notSelectericonSize),
            //   SizedBox(width: TSizes.sm),
            //   rating==3.0?Icon(Icons.sentiment_neutral, color: Colors.yellow,size: iconSize):Icon(Icons.sentiment_neutral, color: Colors.yellow,size: notSelectericonSize),
            //   SizedBox(width: TSizes.sm),
            //   rating==4.0?Icon(Icons.sentiment_satisfied, color: Colors.lightGreen,size: iconSize):Icon(Icons.sentiment_satisfied, color: Colors.lightGreen,size: notSelectericonSize),
            //   SizedBox(width: TSizes.sm),
            //   rating==5.0?Icon(Icons.sentiment_very_satisfied, color: Colors.green,size: iconSize):Icon(Icons.sentiment_very_satisfied, color: Colors.green,size: notSelectericonSize  ),
            ],
          ),
        ),
        SizedBox(
          width: THelperFunctions.screenWidth()/1.5,
          child: Slider(
            value: rating,
            min: 1.0,
            max: 5.0,
            divisions: 4,
            activeColor: activeColor,
            // label: rating.toString(),
            onChanged: onRatingChanged,
          ),
        ),
      ],
    );
  }
}
