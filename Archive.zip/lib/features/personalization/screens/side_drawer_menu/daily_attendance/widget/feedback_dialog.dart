/*
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/attendance_controller.dart';
import 'package:eapl_student_app/features/personalization/models/attendance_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/daily_attendance/widget/report_ratings.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/image_strings.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../../../utils/loaders/animation_loaders.dart';

class StudentFeedbackDialog extends StatelessWidget {
  StudentFeedbackDialog(
      {super.key, required this.date, required this.attendanceModel});

  final String date;
  final AttendanceModel attendanceModel;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(AttendanceController());
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.fetchDailyStreakController(
          courseId: attendanceModel.courseId.toString(),
          date: attendanceModel.attDate,
          isAlertDialog: true);
    });

    // double rating = 3.0;
    Color activeColor = Colors.red;

    */
/*return Dialog(
      child: Container(
        margin: const EdgeInsets.all(TSizes.md),
        child: SingleChildScrollView(
          child: Obx(
            () {
              if (controller.isDialogLoading.value == true) {
                return const TAnimationLoaderWidget(
                  text: "Loading...",
                  animation: TImages.pencilAnimation,
                );
              }
              if (controller.dailyAttendanceList.isEmpty) {
                return const Center(child: Text("There is No Class Details"));
              }
              return Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  /// Date
                  Card(
                    color: Colors.red,
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Text(
                        '$date',
                        style: Theme.of(context)
                            .textTheme
                            .bodyMedium!
                            .apply(color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: TSizes.xs),

                  /// Topic Covered
                  Text("Topic Covered",
                      style: Theme.of(context).textTheme.bodyLarge),
                  const SizedBox(height: TSizes.sm),
                  controller.feedbackTopicList.isNotEmpty
                      ? ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: controller.feedbackTopicList[0]?.length,
                          itemBuilder: (BuildContext context, int index) {
                            return Text(
                              ' * ${controller.feedbackTopicList[0]?[index]}',
                              style: Theme.of(context)
                                  .textTheme
                                  .labelLarge!
                                  .apply(color: TColors.primary),
                            );
                          },
                        )
                      : Text(
                          "No topics available",
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),

                  const SizedBox(height: TSizes.md),

                  RatingBar(
                    rating: controller.ratings.value,
                    onRatingChanged: (newRating) {
                      controller.ratings.value = newRating;
                      activeColor = controller.ratings.value == 1.0
                          ? Colors.red
                          : controller.ratings.value == 2.0
                              ? Colors.orange
                              : controller.ratings.value == 3.0
                                  ? Colors.yellow
                                  : controller.ratings.value == 4.0
                                      ? Colors.lightGreen
                                      : Colors.green;
                    },
                    activeColor: activeColor,
                  ),
                  const SizedBox(height: TSizes.sm),
                  TextFormField(
                      controller: controller.feedbackText,
                      decoration: InputDecoration(
                          hintText: "Share your thoughts about today’s Class",
                          hintStyle: Theme.of(context).textTheme.bodySmall),
                      maxLines: 3),
                  const SizedBox(height: TSizes.md),

                  Center(
                    child: ElevatedButton(
                        onPressed: () {
                          controller.addFeedback(
                              attendanceId: attendanceModel.sno.toString());
                          Get.back();
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: TColors.importantText,
                            side:
                                const BorderSide(color: TColors.importantText)),
                        child: const Text("Submit")),
                  )
                ],
              );
            },
          ),
        ),
      ),
    );*/ /*

    return WillPopScope(
      onWillPop: () async {
        controller.resetFeedbackForm(); // 🧹 Clear text/rating
        return true;
      },
      child: Dialog(
        child: Stack(
          children: [
            Container(
              margin: EdgeInsets.all(TSizes.md),
              child: SingleChildScrollView(
                child: Obx(() {
                  if (controller.isDialogLoading.value == true) {
                    return const TAnimationLoaderWidget(
                      text: "Loading...",
                      animation: TImages.pencilAnimation,
                    );
                  }
                  if (controller.dailyAttendanceList.isEmpty) {
                    return const Center(
                        child: Text("There is No Class Details"));
                  }

                  final feedbackText = controller.feedbackText;

                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      /// Date Card
                      Card(
                        color: Colors.red,
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Text(
                            '$date',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium!
                                .apply(color: Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(height: TSizes.xs),

                      /// Topic Covered
                      Text("Topic Covered",
                          style: Theme.of(context).textTheme.bodyLarge),
                      const SizedBox(height: TSizes.sm),
                      controller.feedbackTopicList.isNotEmpty
                          ? ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: controller.feedbackTopicList[0].length,
                              itemBuilder: (BuildContext context, int index) {
                                return Text(
                                  ' * ${controller.feedbackTopicList[0][index]}',
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelLarge!
                                      .apply(color: TColors.primary),
                                );
                              },
                            )
                          : Text(
                              "No topics available",
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),

                      const SizedBox(height: TSizes.md),

                      /// Rating Bar
                      */
/* RatingBar(
                        rating: controller.ratings.value,
                        onRatingChanged: (newRating) {
                          controller.ratings.value = newRating;
                          activeColor = newRating == 1.0
                              ? Colors.red
                              : newRating == 2.0
                                  ? Colors.orange
                                  : newRating == 3.0
                                      ? Colors.yellow
                                      : newRating == 4.0
                                          ? Colors.lightGreen
                                          : Colors.green;
                        },
                        activeColor: activeColor,
                      ),*/ /*

                      RatingBar(
                        rating: controller.ratings.value < 1.0
                            ? 1.0
                            : controller.ratings.value,
                        onRatingChanged: (newRating) {
                          controller.ratings.value = newRating;
                          activeColor = newRating == 1.0
                              ? Colors.red
                              : newRating == 2.0
                                  ? Colors.orange
                                  : newRating == 3.0
                                      ? Colors.yellow
                                      : newRating == 4.0
                                          ? Colors.lightGreen
                                          : Colors.green;
                        },
                        activeColor: activeColor,
                      ),

                      const SizedBox(height: TSizes.sm),

                      /// Feedback Description Field
                      TextFormField(
                        controller: controller.feedbackText,
                        decoration: InputDecoration(
                          hintText: "Share your thoughts about today’s Class",
                          hintStyle: Theme.of(context).textTheme.bodySmall,
                        ),
                        maxLines: 3,
                        onChanged: (value) {
                          controller.updateWordCount(value);
                        },
                      ),

                      // Word count display
                      Align(
                        alignment: Alignment.centerRight,
                        child: Obx(() => Text(
                              '${controller.wordCount.value}/50',
                              style: Theme.of(context).textTheme.labelSmall,
                            )),
                      ),

                      const SizedBox(height: TSizes.md),

                      /// Submit Button
                      */
/* Center(
                        child: ElevatedButton(
                          onPressed: () {
                            final text = controller.feedbackText.text.trim();

                            if (text.isEmpty) {
                              Get.snackbar(
                                "Feedback Required",
                                "Please enter your thoughts about today’s class.",
                                backgroundColor: Colors.red,
                                colorText: Colors.white,
                              );
                              return;
                            }
                            controller.addFeedback(
                                attendanceId: attendanceModel.sno.toString());
                            controller
                                .resetFeedbackForm(); // 💡 Clear fields after submission
                            Get.back();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: TColors.importantText,
                            side:
                                const BorderSide(color: TColors.importantText),
                          ),
                          child: const Text("Submit"),
                        ),
                      ),*/ /*

                      Center(
                        child: ElevatedButton(
                          onPressed: () async {
                            final text = controller.feedbackText.text.trim();

                            if (text.isEmpty) {
                              Get.snackbar(
                                "Feedback Required",
                                "Please enter your thoughts about today’s class.",
                                backgroundColor: Colors.red,
                                colorText: Colors.white,
                              );
                              return;
                            }

                            // 1. Submit Feedback
                            await controller.addFeedback(
                              attendanceId: attendanceModel.sno.toString(),
                            );

                            // 2. Reset form fields
                            controller.resetFeedbackForm();

                            // 3. Refresh Points after submission
                            Get.find<AppbarController>().fetchPointsDetails();

                            // 4. Close the dialog/screen

                            */
/*Future.delayed(const Duration(milliseconds: 200),
                                () {
                              Get.back();
                            });*/ /*

                            if (Get.isDialogOpen ?? false) {
                              Get.back();
                            }

                            // 5. Optional: Show success message
                            Get.snackbar(
                              "Success",
                              "Feedback submitted! You earned 2 coins.",
                              backgroundColor: Colors.green,
                              colorText: Colors.white,
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: TColors.importantText,
                            side:
                                const BorderSide(color: TColors.importantText),
                          ),
                          child: const Text("Submit"),
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ),

            /// ❌ X Close Button
            Positioned(
              right: 0,
              child: IconButton(
                icon: const Icon(Icons.close),
                onPressed: () {
                  controller.resetFeedbackForm();
                  Get.back(); // Close the dialog
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
*/
