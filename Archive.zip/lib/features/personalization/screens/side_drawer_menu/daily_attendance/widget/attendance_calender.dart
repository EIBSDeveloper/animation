/*import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/daily_attendance/widget/studentfeedbackdialog.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../../../../common/widget/custom_calender/calender_box_style.dart';
import '../../../../../../utils/constants/path_provider.dart';

class CustomCalendar extends StatelessWidget {
  final Rx<DateTime> focusedDay;
  final Rx<DateTime?> selectedDay;
  final Rx<CalendarFormat> calendarFormat;
  final Function(DateTime, DateTime) onDaySelected;
  final Function(DateTime) onPageChanged;
  final List<dynamic> Function(DateTime) eventLoader;
  final dynamic controller;
  final AvailableGestures availableGestures;

  const CustomCalendar({
    Key? key,
    required this.focusedDay,
    required this.selectedDay,
    required this.calendarFormat,
    required this.onDaySelected,
    required this.onPageChanged,
    required this.eventLoader,
    required this.controller,
    required this.availableGestures,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(TSizes.sm),
      decoration: BoxDecoration(
        color: TColors.lightimportant.withOpacity(0.9),
        borderRadius: BorderRadius.circular(7.0),
        border: Border.all(color: TColors.grey),
      ),
      child: Obx(() {
        if (controller.isLoading.value == true) {
          return const TAnimationLoaderWidget(
            text: "Loading...",
            animation: TImages.pencilAnimation,
          );
        }
        return Column(
          children: [
            TableCalendar(
              pageAnimationEnabled: true,
              pageJumpingEnabled: true,
              firstDay: DateTime.utc(1998, 02, 26),
              lastDay: DateTime.utc(2100, 02, 26),
              focusedDay: focusedDay.value,
              calendarFormat: calendarFormat.value,
              selectedDayPredicate: (day) {
                return isSameDay(selectedDay.value, day);
              },
              onDaySelected: onDaySelected,
              onPageChanged: onPageChanged,
              availableGestures: availableGestures, // 👈 Disable swipe scroll
              calendarStyle: const CalendarStyle(
                weekendTextStyle: TextStyle(color: Colors.red),
                holidayTextStyle: TextStyle(color: Colors.red),
              ),
              headerStyle: const HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,
                decoration: BoxDecoration(color: Colors.transparent),
                titleTextStyle: TextStyle(
                  color: TColors.primary,
                  fontWeight: FontWeight.bold,
                  fontSize: 18.0,
                ),
                leftChevronIcon:
                    Icon(Icons.chevron_left, color: TColors.primary),
                rightChevronIcon:
                    Icon(Icons.chevron_right, color: TColors.primary),
              ),
              daysOfWeekStyle: const DaysOfWeekStyle(
                dowTextFormatter: null, // optional: use default formatting
                weekdayStyle: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  overflow: TextOverflow.visible,
                ),
                weekendStyle: TextStyle(
                  color: Colors.red,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  overflow: TextOverflow.visible,
                ),
              ),

              // eventLoader: eventLoader,
              calendarBuilders: CalendarBuilders(
                defaultBuilder: (context, date, _) {
                  for (var attendanceModel in controller.fillFeedback) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                          date: date,
                          message: "Need To Fill FeedBack",
                          backgroundColor: TColors.needToFillFeedback,
                          onTap: () {
                            Get.dialog(FeedbackDialog(
                              date: '${date.day}-${date.month}-${date.year}',
                              attendanceModel: attendanceModel,
                            ));
                          });
                    }
                  }
                  for (var attendanceModel
                      in controller.completedFeedbackList) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Completed Class",
                        backgroundColor: TColors.classCompleted,
                        onTap: () {
                          Get.dialog(
                            Dialog(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8)),
                              child: Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const SizedBox(
                                            height: 24), // Space for X icon
                                        Text(
                                          'Already Feedback Submitted for this date',
                                          style: TextStyle(fontSize: 16),
                                          textAlign: TextAlign.center,
                                        ),
                                        const SizedBox(height: 16),
                                      ],
                                    ),
                                  ),

                                  /// X Icon Positioned
                                  Positioned(
                                    right: 0,
                                    top: 0,
                                    child: IconButton(
                                      icon: const Icon(Icons.close,
                                          color: Colors.grey),
                                      onPressed: () {
                                        Get.back(); // Closes the dialog
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    }
                  }

                  for (var attendanceModel in controller.classCompleted) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Completed Class",
                        backgroundColor: TColors.classCompleted,
                        onTap: () {
                          Get.dialog(AlertDialog(
                            title: Text(
                                'Already Feedback Submitted for this date'),
                          ));
                        },
                      );
                    }
                  }

                  for (var completedDate in controller.absentClass) {
                    if (isSameDay(completedDate, date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Absent Classes",
                        backgroundColor: TColors.absentOrLeave,
                        onTap: () {
                          Get.dialog(AlertDialog(
                            title: Text(
                                '${date.day}-${date.month}-${date.year}- Absent/Leave'),
                          ));
                        },
                      );
                    }
                  }

                  if (controller.upcomingClasses.contains(date)) {
                    return CalenderBoxStyle(
                      date: date,
                      message: "Upcoming Classes",
                      backgroundColor: TColors.upcomingClasses,
                      onTap: () {
                        Get.dialog(AlertDialog(
                          title: Text('${date.day}-${date.month}-${date.year}'),
                        ));
                      },
                    );
                  }

                  return null;
                },
                todayBuilder: (context, date, _) {
                  return CalenderBoxStyle(
                    date: date,
                    message: "Today",
                    backgroundColor: controller.absentClass.contains(date)
                        ? TColors.absentOrLeave
                        : controller.fillFeedback.contains(date)
                            ? TColors.needToFillFeedback
                            : controller.classCompleted.value.contains(date)
                                ? TColors.classCompleted
                                : controller.upcomingClasses.contains(date)
                                    ? TColors.upcomingClasses
                                    : Colors.green,
                    onTap: () {
                      if (controller.absentClass.contains(date)) {
                        Get.dialog(AlertDialog(
                          title: Text('${date.day}-${date.month}-${date.year}'),
                        ));
                      }
                      if (controller.classCompleted.value.contains(date)) {
                        Get.dialog(AlertDialog(
                          title: Text('${date.day}-${date.month}-${date.year}'),
                        ));
                      }
                    },
                  );
                },
                selectedBuilder: (context, date, _) {
                  return CalenderBoxStyle(
                    date: date,
                    message: '',
                    backgroundColor: controller.absentClass.contains(date)
                        ? TColors.absentOrLeave
                        : controller.fillFeedback.contains(date)
                            ? TColors.needToFillFeedback
                            : controller.classCompleted.value.contains(date)
                                ? TColors.classCompleted
                                : controller.upcomingClasses.contains(date)
                                    ? TColors.upcomingClasses
                                    : Colors.green,
                    onTap: () {},
                  );
                },
                markerBuilder: (context, date, events) {
                  return Container(
                    width: 0,
                    height: 0,
                    decoration: const BoxDecoration(
                      color: Colors.transparent,
                      shape: BoxShape.circle,
                    ),
                  );
                },
              ),
            ),
            Divider(
              indent: 10,
              endIndent: 10,
            )
          ],
        );
      }),
    );
  }
}*/
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/attendance_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/daily_attendance/widget/studentfeedbackdialog.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../../../../utils/constants/path_provider.dart';
import '../../../../models/attendance_model.dart';

class CustomCalendar extends StatelessWidget {
  final Rx<DateTime> focusedDay;
  final Rx<DateTime?> selectedDay;
  final Rx<CalendarFormat> calendarFormat;
  final Function(DateTime, DateTime) onDaySelected;
  final Function(DateTime) onPageChanged;
  final List<dynamic> Function(DateTime) eventLoader;
  final dynamic controller;
  final AvailableGestures availableGestures;

  const CustomCalendar({
    Key? key,
    required this.focusedDay,
    required this.selectedDay,
    required this.calendarFormat,
    required this.onDaySelected,
    required this.onPageChanged,
    required this.eventLoader,
    required this.controller,
    required this.availableGestures,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(TSizes.sm),
      decoration: BoxDecoration(
          color: TColors.white,
          borderRadius: BorderRadius.circular(7.0),
          border: Border.all(color: TColors.grey),
          boxShadow: [
            BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.3),
              blurRadius: 2,
              spreadRadius: 0,
              offset: Offset(
                0,
                1,
              ),
            ),
            BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.15),
              blurRadius: 6,
              spreadRadius: 2,
              offset: Offset(
                0,
                2,
              ),
            ),
          ]),
      child: Obx(() {
        if (controller.isLoading.value == true) {
          return const TAnimationLoaderWidget(
            text: "Loading...",
            animation: TImages.pencilAnimation,
          );
        }

        return Column(
          children: [
            TableCalendar(
              pageAnimationEnabled: true,
              pageJumpingEnabled: true,
              firstDay: DateTime.utc(1998, 02, 26),
              lastDay: DateTime.utc(2100, 02, 26),
              focusedDay: focusedDay.value,
              calendarFormat: calendarFormat.value,
              selectedDayPredicate: (day) => isSameDay(selectedDay.value, day),
              onDaySelected: onDaySelected,
              onPageChanged: onPageChanged,
              availableGestures: availableGestures,
              calendarStyle: const CalendarStyle(
                weekendTextStyle: TextStyle(color: Colors.black),
                holidayTextStyle: TextStyle(color: Colors.black),
              ),
              headerStyle: const HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,
                decoration: BoxDecoration(color: Colors.transparent),
                titleTextStyle: TextStyle(
                  color: TColors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 18.0,
                ),
                leftChevronIcon:
                    Icon(Icons.chevron_left, color: TColors.primary),
                rightChevronIcon:
                    Icon(Icons.chevron_right, color: TColors.primary),
              ),
              daysOfWeekStyle: const DaysOfWeekStyle(
                dowTextFormatter: null,
                weekdayStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  overflow: TextOverflow.visible,
                ),
                weekendStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  overflow: TextOverflow.visible,
                ),
              ),
              /*calendarBuilders: CalendarBuilders(
                defaultBuilder: (context, date, _) {
                  for (var attendanceModel in controller.fillFeedback) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Need To Fill FeedBack",
                        backgroundColor: TColors.needToFillFeedback,
                        onTap: () {
                          Get.dialog(FeedbackDialog(
                            date: '${date.day}-${date.month}-${date.year}',
                            attendanceModel: attendanceModel,
                          ));
                        },
                      );
                    }
                  }
                  for (var attendanceModel
                      in controller.completedFeedbackList) {
                    if (isSameDay(
                      DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                      date,
                    )) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Completed Class",
                        backgroundColor: TColors.classCompleted,
                        onTap: () {
                          // ✅ Instead of showing a simple dialog, call your widget
                          showDialog(
                            context: context,
                            builder: (context) => SubmittedFeedbackDialog(
                              attendanceModel: attendanceModel,
                            ),
                          );
                        },
                      );
                    }
                  }

                  for (var attendanceModel in controller.classCompleted) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Completed Class",
                        backgroundColor: TColors.classCompleted,
                        onTap: () {
                          Get.dialog(AlertDialog(
                            title: Text(
                                'Already Feedback Submitted for this date'),
                          ));
                        },
                      );
                    }
                  }

                  for (var completedDate in controller.absentClass) {
                    if (isSameDay(completedDate, date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Absent Classes",
                        backgroundColor: TColors.absentOrLeave,
                        onTap: () {
                          Get.dialog(AlertDialog(
                            title: Text(
                                '${date.day}-${date.month}-${date.year}- Absent/Leave'),
                          ));
                        },
                      );
                    }
                  }

                  if (controller.upcomingClasses
                      .any((d) => isSameDay(d, date))) {
                    return CalenderBoxStyle(
                      date: date,
                      message: "Upcoming Classes",
                      backgroundColor: TColors.upcomingClasses,
                      onTap: () {
                        Get.dialog(AlertDialog(
                          title: Text('${date.day}-${date.month}-${date.year}'),
                        ));
                      },
                    );
                  }

                  return null;
                },
                todayBuilder: (context, date, _) {
                  return CalenderBoxStyle(
                    date: date,
                    message: "Today",
                    backgroundColor: controller.absentClass
                            .any((d) => isSameDay(d, date))
                        ? TColors.absentOrLeave
                        : controller.fillFeedback.any((d) => isSameDay(
                                DateFormat("yyyy-MM-dd").parse(d.attDate),
                                date))
                            ? TColors.needToFillFeedback
                            : controller.classCompleted.any((d) => isSameDay(
                                    DateFormat("yyyy-MM-dd").parse(d.attDate),
                                    date))
                                ? TColors.classCompleted
                                : controller.upcomingClasses
                                        .any((d) => isSameDay(d, date))
                                    ? TColors.upcomingClasses
                                    : Colors.green,
                    onTap: () {
                      Get.dialog(AlertDialog(
                        title: Text('${date.day}-${date.month}-${date.year}'),
                      ));
                    },
                  );
                },
                selectedBuilder: (context, date, _) {
                  return CalenderBoxStyle(
                    date: date,
                    message: '',
                    backgroundColor: controller.absentClass
                            .any((d) => isSameDay(d, date))
                        ? TColors.absentOrLeave
                        : controller.fillFeedback.any((d) => isSameDay(
                                DateFormat("yyyy-MM-dd").parse(d.attDate),
                                date))
                            ? TColors.needToFillFeedback
                            : controller.classCompleted.any((d) => isSameDay(
                                    DateFormat("yyyy-MM-dd").parse(d.attDate),
                                    date))
                                ? TColors.classCompleted
                                : controller.upcomingClasses
                                        .any((d) => isSameDay(d, date))
                                    ? TColors.upcomingClasses
                                    : Colors.green,
                    onTap: () {},
                  );
                },
                markerBuilder: (context, date, events) {
                  return Container(
                    width: 0,
                    height: 0,
                    decoration: const BoxDecoration(
                      color: Colors.transparent,
                      shape: BoxShape.circle,
                    ),
                  );
                },
              ),*/
              // 📌 Your Calendar Code
              calendarBuilders: CalendarBuilders(
                defaultBuilder: (context, date, _) {
                  /* for (var attendanceModel in controller.fillFeedback) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Need To Fill FeedBack",
                        backgroundColor: TColors.primary,
                        onTap: () {
                          */ /*Get.dialog(
                            FeedbackDialog(
                              date: '${date.day}-${date.month}-${date.year}',
                              attendanceModel: attendanceModel,
                            ),
                          );*/ /*
                          // ✅ Check for future date
                          final today = DateTime.now();
                          final todayDateOnly =
                              DateTime(today.year, today.month, today.day);
                          final attendanceDate = DateFormat("yyyy-MM-dd")
                              .parse(attendanceModel.attDate);

                          if (attendanceDate.isAfter(todayDateOnly)) {
                            Fluttertoast.showToast(
                              msg: "Cannot add feedback for future dates",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: TColors.primary,
                              textColor: Colors.white,
                              fontSize: 14.0,
                            );

                            return;
                          }
                          Get.dialog(
                            FeedbackDialog(
                              date: DateFormat("yyyy-MM-dd")
                                  .format(date), // 2025-02-14
                              attendanceModel: attendanceModel,
                            ),
                          );
                        },
                      );
                    }
                  }*/
                  // Loop through attendance records needing feedback
                  for (var attendanceModel in controller.fillFeedback) {
                    final attendanceDate =
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate);

                    if (isSameDay(attendanceDate, date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Need To Fill FeedBack",
                        backgroundColor: TColors.primary,
                        onTap: () {
                          final today = DateTime.now();
                          final todayDateOnly =
                              DateTime(today.year, today.month, today.day);

                          // ✅ Allow feedback only for today
                          if (!isSameDay(attendanceDate, todayDateOnly)) {
                            Fluttertoast.showToast(
                              msg: "Feedback can be added only for today",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              backgroundColor: TColors.primary,
                              textColor: Colors.white,
                              fontSize: 14.0,
                            );
                            return;
                          }

                          Get.dialog(
                            FeedbackDialog(
                              date: DateFormat("yyyy-MM-dd").format(date),
                              attendanceModel: attendanceModel,
                            ),
                          );
                        },
                      );
                    }
                  }

                  /*  for (var attendanceModel
                      in controller.completedFeedbackList) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Completed Class",
                        backgroundColor: TColors.classCompleted,
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) => SubmittedFeedbackDialog(
                              attendanceModel: attendanceModel,
                            ),
                          );
                        },
                      );
                    }
                  }*/
                  // ✅ Holiday check first
                  if (controller.holidaylist.any((d) => isSameDay(d, date))) {
                    return CalenderBoxStyle(
                      date: date,
                      message: "Holiday",
                      backgroundColor: Colors.red, // Red for holiday
                      onTap: () {
                        Get.dialog(AlertDialog(
                          title: Text(
                              '${date.day}-${date.month}-${date.year} is a Holiday'),
                        ));
                      },
                    );
                  }
/*                  for (var attendanceModel in controller.classCompleted) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Completed Class",
                        backgroundColor: TColors.green,
                        onTap: () {
                          Get.dialog(
                            const AlertDialog(
                              backgroundColor: TColors.white,
                              title: Column(
                                children: [
                                  Text('Present'),
                                  Text(
                                      'Already Feedback Submitted for this date'),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    }
                  }

                  for (var completedDate in controller.absentClass) {
                    if (isSameDay(completedDate, date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Absent Classes",
                        backgroundColor: TColors.red,
                        onTap: () {
                          Get.dialog(
                            AlertDialog(
                              title: Text(
                                  '${date.day}-${date.month}-${date.year} - Absent/Leave'),
                            ),
                          );
                        },
                      );
                    }
                  }*/
                  for (var attendanceModel in controller.classCompleted) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Completed Class",
                        backgroundColor: TColors.green,
                        onTap: () async {
                          final dateTime = DateFormat("yyyy-MM-dd")
                              .parse(attendanceModel.attDate);
                          Get.dialog(
                            const Center(child: CircularProgressIndicator()),
                            barrierDismissible: false,
                          );
                          // Fetch chapters dynamically
                          final chapters =
                              await controller.fetchAttendanceChapters(
                            batchId: attendanceModel.batchId,
                            courseId: attendanceModel.courseId,
                            date: dateTime,
                            branchId: attendanceModel.branchId,
                          );
                          Get.back();

                          // Show dialog with bullet list
                          Get.dialog(
                            AlertDialog(
                              backgroundColor: TColors.white,
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Completed Chapters'),
                                  GestureDetector(
                                      onTap: () {
                                        Get.back();
                                      },
                                      child: Icon(Icons.close))
                                ],
                              ),
                              content: SizedBox(
                                width: double.maxFinite,
                                child: chapters.isNotEmpty
                                    ? ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: chapters.length,
                                        itemBuilder: (context, index) {
                                          return Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              const Text("• ",
                                                  style: TextStyle(
                                                      fontSize: 18,
                                                      height: 1.5)), // bullet
                                              Expanded(
                                                child: Text(
                                                  chapters[index],
                                                  style: TextStyle(
                                                      fontSize: 16,
                                                      color: TColors.primary),
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      )
                                    : const Center(
                                        child: Text(
                                          'No chapters found',
                                          style: TextStyle(
                                              fontSize: 16, color: Colors.grey),
                                        ),
                                      ),
                              ),
                            ),
                          );
                        },
                      );
                    }
                  }

                  for (var attendanceModel in controller.absentAttendance) {
                    if (isSameDay(
                        DateFormat("yyyy-MM-dd").parse(attendanceModel.attDate),
                        date)) {
                      return CalenderBoxStyle(
                        date: date,
                        message: "Absent Classes",
                        backgroundColor: TColors.red,
                        onTap: () async {
                          final dateTime = DateFormat("yyyy-MM-dd")
                              .parse(attendanceModel.attDate);

                          // ✅ Show loading dialog while fetching
                          Get.dialog(
                            const Center(child: CircularProgressIndicator()),
                            barrierDismissible: false,
                          );

                          final chapters =
                              await controller.fetchAttendanceChapters(
                            batchId: attendanceModel.batchId,
                            courseId: attendanceModel.courseId,
                            date: dateTime,
                            branchId: attendanceModel.branchId,
                          );

                          Get.back(); // ✅ Close loading spinner

                          // ✅ Show results in dialog
                          Get.dialog(
                            AlertDialog(
                              backgroundColor: TColors.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Absent Chapters',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  GestureDetector(
                                      onTap: () {
                                        Get.back();
                                      },
                                      child: Icon(Icons.close))
                                ],
                              ),
                              content: SizedBox(
                                width: double.maxFinite,
                                child: chapters.isNotEmpty
                                    ? ListView.separated(
                                        shrinkWrap: true,
                                        itemCount: chapters.length,
                                        separatorBuilder: (_, __) =>
                                            const SizedBox(height: 4),
                                        itemBuilder: (context, index) {
                                          return Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              const Text("• ",
                                                  style: TextStyle(
                                                      fontSize: 16,
                                                      color: TColors.primary)),
                                              Expanded(
                                                child: Text(
                                                  chapters[index],
                                                  style: const TextStyle(
                                                      fontSize: 15),
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      )
                                    : const Center(
                                        child: Text(
                                          "No chapters found",
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.grey),
                                        ),
                                      ),
                              ),
                            ),
                          );
                        },
                      );
                    }
                  }

/*                  if (controller.upcomingClasses
                      .any((d) => isSameDay(d, date))) {
                    return CalenderBoxStyle(
                      date: date,
                      message: "Upcoming Classes",
                      backgroundColor: TColors.upcomingClasses,
                      onTap: () {
                        Get.dialog(
                          AlertDialog(
                            title:
                                Text('${date.day}-${date.month}-${date.year}'),
                          ),
                        );
                      },
                    );
                  }

                  return null;*/
                },
                todayBuilder: (context, date, _) {
                  return CalenderBoxStyle(
                    date: date,
                    message: "Today",
                    backgroundColor: Colors.white, // keep white but with border
                    borderColor:
                        Colors.green, // ✅ Highlight today with border ring
                    textColor: Colors.green,
                    onTap: () {
                      Get.dialog(
                        AlertDialog(
                          title: Text('${date.day}-${date.month}-${date.year}'),
                        ),
                      );
                    },
                  );
                },
                selectedBuilder: (context, date, _) {
                  return CalenderBoxStyle(
                    date: date,
                    message: '',
                    backgroundColor: Colors.orangeAccent.shade200,
                    textColor: Colors.white,
                    onTap: () {},
                  );
                },
                markerBuilder: (context, date, events) {
                  return Container(
                    width: 0,
                    height: 0,
                    color: Colors.transparent,
                  );
                },
              ),
            ),
            const Divider(indent: 10, endIndent: 10),
          ],
        );
      }),
    );
  }

  /// ✅ Utility to compare only date (ignores time)
  bool isSameDay(DateTime? a, DateTime? b) {
    if (a == null || b == null) return false;
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }
}

class SubmittedFeedbackDialog extends StatelessWidget {
  final AttendanceModel attendanceModel;

  const SubmittedFeedbackDialog({super.key, required this.attendanceModel});

  @override
  Widget build(BuildContext context) {
    final AttendanceController controller = Get.put(AttendanceController());
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 8,
      backgroundColor: Colors.white,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Center(
                      child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text(
                      "Submitted Feedback",
                      style: TextStyle(
                          fontSize: 18,
                          color: TColors.primary,
                          fontWeight: FontWeight.bold),
                    ),
                  )),
                  // ✅ Day Container (Reduced Width)
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Color.fromRGBO(60, 64, 67, 0.3),
                            blurRadius: 2,
                            offset: Offset(0, 1),
                          ),
                        ],
                      ),
                      child: RichText(
                        text: TextSpan(
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                          children: [
                            const TextSpan(
                              text: "Day ",
                              style: TextStyle(color: Colors.black87),
                            ),
                            TextSpan(
                              text: "${attendanceModel.dayCount}",
                              style: TextStyle(
                                color: TColors.red,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  // ✅ Date & Attendance in ONE container
                  _buildContainer(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Text(
                              "Date: ",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: Colors.black87,
                              ),
                            ),
                            Expanded(
                              child: Text(
                                attendanceModel.attDate ?? "No date",
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Text(
                              "Attendance: ",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: Colors.black87,
                              ),
                            ),
                            Expanded(
                              child: Text(
                                attendanceModel.attendance.isNotEmpty
                                    ? attendanceModel.attendance
                                    : "No attendance found",
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 15),

                  // ✅ Topics Covered in separate container
                  _buildContainer(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Topics Covered",
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        controller.feedbackTopicList.isNotEmpty &&
                                controller.feedbackTopicList[0].isNotEmpty
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: controller.feedbackTopicList[0]
                                    .map((topic) => Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 4),
                                          child: Text("• $topic",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium!
                                                  .copyWith(
                                                      color: TColors.primary)),
                                        ))
                                    .toList(),
                              )
                            : Center(
                                child: Text("No topics found",
                                    style:
                                        Theme.of(context).textTheme.bodyMedium),
                              ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15),

                  // ✅ Feedback Score
                  _buildContainer(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Feedback Score",
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          attendanceModel.feedbackScore != null &&
                                  attendanceModel.feedbackScore! > 0
                              ? "${attendanceModel.feedbackScore} / 5"
                              : "No rating given",
                          style: const TextStyle(
                              fontSize: 15, color: Colors.black87),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15),

                  // ✅ Feedback Description
                  _buildContainer(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Feedback",
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          attendanceModel.feedback != null &&
                                  attendanceModel.feedback!.isNotEmpty
                              ? attendanceModel.feedback!
                              : "No feedback submitted",
                          style: const TextStyle(
                              fontSize: 15, color: Colors.black87),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 🔹 Close Button (Top Right)
          Positioned(
            right: 15,
            top: 15,
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Icon(Icons.close, color: Colors.black87, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  /// 🔹 Reusable Container Style
  Widget _buildContainer({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Color.fromRGBO(60, 64, 67, 0.3),
            blurRadius: 2,
            spreadRadius: 0,
            offset: Offset(0, 1),
          ),
          BoxShadow(
            color: Color.fromRGBO(60, 64, 67, 0.15),
            blurRadius: 6,
            spreadRadius: 2,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: child,
    );
  }
}

// 📌 Custom Circle Day Widget
class CalenderBoxStyle extends StatelessWidget {
  final DateTime date;
  final String message;
  final Color backgroundColor;
  final Color? textColor;
  final Color? borderColor;
  final VoidCallback onTap;

  const CalenderBoxStyle({
    Key? key,
    required this.date,
    required this.message,
    required this.backgroundColor,
    this.textColor,
    this.borderColor,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          shape: BoxShape.circle, // ✅ Circle shape
          color: backgroundColor,
          border: borderColor != null
              ? Border.all(color: borderColor!, width: 2)
              : null,
        ),
        alignment: Alignment.center,
        child: Text(
          '${date.day}',
          style: TextStyle(
            fontSize: 14,
            color: textColor ?? Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
