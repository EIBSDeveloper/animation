import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../../common/widget/course/course_detail_card.dart';
import '../../../../../../utils/constants/apptextstyles.dart';
import '../../../../controllers/side_drawer_controller/batch_controller.dart';
import '../../../../models/course_model.dart';

class CourseBatchDetailsCard extends StatelessWidget {
  const CourseBatchDetailsCard({super.key, required this.courseModel});

  final CourseDetailModel courseModel;

  @override
  Widget build(BuildContext context) {
    final batchController = Get.put(BatchController());
    WidgetsBinding.instance.addPostFrameCallback((_) {
      batchController.fetchBatchDetailsController(
          courseId: courseModel.courseSno.toString());
    });

    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: TColors.sandal,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: TColors.grey)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Course Header: Version, Name, Code
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                courseModel.courseVersion ?? "---",
                style: GoogleFonts.prompt(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                child: Text(
                  courseModel.courseName ?? "---",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.prompt(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: TColors.primary,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  courseModel.courseCode ?? "---",
                  style: GoogleFonts.prompt(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: TColors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          /// Subcategory
          Row(
            children: [
              Image.asset(
                TImages.category,
                width: 25,
                height: 25,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 4),
              Text(
                courseModel.courseSubcategoryName ?? "---",
                style: GoogleFonts.prompt(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          /// Duration Grid
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: _DurationCard(
                  imagePath: TImages.theory,
                  label: "Theory Class",
                  value: "${courseModel.courseTheoryHours ?? "---"} Hrs",
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _DurationCard(
                  imagePath: TImages.practical,
                  label: "Practical Class",
                  value: "${courseModel.coursePracticalHours ?? "---"} Hrs",
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _DurationCard(
                  imagePath: TImages.hrs,
                  label: "Total Duration",
                  value: "${courseModel.courseDuration ?? "---"} Hrs",
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          /// Course Duration
          Obx(() {
            final batchDetail = batchController.batchDetails.value;

            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Course Duration: ",
                  style: AppTextStyles.heading,
                ),
                Row(
                  children: [
                    Image.asset(
                      TImages.days,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      batchDetail != null && batchDetail.slotTypeDays.isNotEmpty
                          ? "${batchDetail.slotTypeDays.first} - ${batchDetail.slotTypeDays.last}"
                          : "---",
                      style: AppTextStyles.heading,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis, // <-- adds "..."
                    ),
                  ],
                ),
              ],
            );
          }),
          const SizedBox(height: 10),

          /// Course Dates
          Row(
            children: [
              Image.asset(
                TImages.calender,
                width: 25,
                height: 25,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 6),
              Text(
                "${formatDate(courseModel.startDate)} to ${formatDate(courseModel.endDate)}",
                style: AppTextStyles.heading,
              ),
            ],
          ),
          const SizedBox(height: 10),

          /// Course Time
          Obx(() {
            final batchDetail = batchController.batchDetails.value;

            if (batchDetail == null) return SizedBox.shrink();

            return Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset(
                  TImages.time,
                  width: 25,
                  height: 25,
                  fit: BoxFit.contain,
                ),
                const SizedBox(width: 6),
                Text(
                  "${batchDetail.startTime.substring(0, 5)} - ${batchDetail.endTime.substring(0, 5)}",
                  style: AppTextStyles.heading,
                ),
              ],
            );
          }),
        ],
      ),
    );
  }
}

/// Small reusable widget for duration
class _DurationCard extends StatelessWidget {
  final String imagePath;
  final String label;
  final String value;

  const _DurationCard({
    Key? key,
    required this.imagePath,
    required this.label,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: TColors.grey.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            imagePath,
            width: 25,
            height: 25,
            fit: BoxFit.contain,
          ),
          const SizedBox(height: 6),
          Text(
            label,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: TColors.black,
            ),
          ),
        ],
      ),
    );
  }
}
