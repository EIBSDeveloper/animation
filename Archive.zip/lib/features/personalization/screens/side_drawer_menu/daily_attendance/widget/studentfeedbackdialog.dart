import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../../../../common/widget/app_bar/appbar_controller.dart';
import '../../../../../../utils/constants/apptextstyles.dart';
import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/image_strings.dart';
import '../../../../../../utils/loaders/animation_loaders.dart';
import '../../../../controllers/side_drawer_controller/attendance_controller.dart';
import '../../../../controllers/side_drawer_controller/batch_controller.dart';
import '../../../../models/attendance_model.dart';
import '../../notifications/notification_controller.dart';
import 'report_ratings.dart';

class FeedbackDialog extends StatefulWidget {
  final String date;
  final AttendanceModel attendanceModel;

  const FeedbackDialog({
    super.key,
    required this.date,
    required this.attendanceModel,
  });

  @override
  State<FeedbackDialog> createState() => _FeedbackDialogState();
}

class _FeedbackDialogState extends State<FeedbackDialog> {
  late final AttendanceController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.find<AttendanceController>();

    /*Future.microtask(() {
      controller.fetchDailyStreakController(
        courseId: widget.attendanceModel.courseId.toString(),
        date: widget.attendanceModel.attDate,
        isAlertDialog: true,
      );
    });*/
  }

  @override
  Widget build(BuildContext context) {
    Color activeColor = Colors.red;
    DateTime parsedDate = DateTime.parse(widget.date); // works fine
    return Dialog(
      backgroundColor: Colors.white, // Premium white background
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Obx(() {
        if (controller.isDialogLoading.value) {
          return const Padding(
            padding: EdgeInsets.all(24.0),
            child: TAnimationLoaderWidget(
              text: "Loading...",
              animation: TImages.pencilAnimation,
            ),
          );
        }

        if (controller.dailyAttendanceList.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(24.0),
            child: Center(child: Text("There are no class details")),
          );
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Close Button (Top-right)
              Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  icon: const Icon(Icons.close, color: Colors.black54),
                  onPressed: () {
                    controller.resetFeedbackForm();
                    Get.back();
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    TImages.calender,
                    height: 25,
                    width: 25,
                    fit: BoxFit.contain,
                  ),

                  const SizedBox(width: 8),

                  /// Date Text
                  Text(
                    DateFormat(
                      "dd MMM - yyyy",
                    ).format(parsedDate),
                    style: AppTextStyles.title,
                    textAlign: TextAlign.center, // displays "14 Feb - 2025"
                  )
                ],
              ),

              const SizedBox(height: 35),

              /// Topics Covered
              Center(
                child: Text("Topics Covered",
                    style: GoogleFonts.prompt(
                        fontWeight: FontWeight.w500,
                        color: TColors.primary,
                        fontSize: 18)),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: TColors.lightprimary,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: controller.feedbackTopicList.isNotEmpty &&
                        controller.feedbackTopicList[0].isNotEmpty
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: controller.feedbackTopicList[0]
                            .map((topic) => Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 4),
                                  child: Text("• $topic",
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium!
                                          .copyWith(color: TColors.primary)),
                                ))
                            .toList(),
                      )
                    : Center(
                        child: Text("No topics found",
                            style: Theme.of(context).textTheme.bodyMedium),
                      ),
              ),
              const SizedBox(height: 35),

              /// Rating Section
              Center(
                child: Text("Your Feedback",
                    style: GoogleFonts.prompt(
                        fontWeight: FontWeight.w500,
                        color: TColors.primary,
                        fontSize: 18)),
              ),
              const SizedBox(height: 12),
              RatingBar(
                rating: controller.ratings.value < 1.0
                    ? 1.0
                    : controller.ratings.value,
                onRatingChanged: (newRating) {
                  controller.ratings.value = newRating;
                  setState(() {
                    activeColor = newRating == 1.0
                        ? Colors.red
                        : newRating == 2.0
                            ? Colors.orange
                            : newRating == 3.0
                                ? Colors.yellow
                                : newRating == 4.0
                                    ? Colors.lightGreen
                                    : Colors.green;
                  });
                },
                activeColor: activeColor,
              ),
              const SizedBox(height: 20),

              /// Feedback Text
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: TColors.lightprimary,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TextFormField(
                  controller: controller.feedbackText,
                  maxLines: 4,
                  onChanged: controller.updateWordCount,
                  decoration: const InputDecoration(
                    hintText: "Share your thoughts about today’s class...",
                    border: InputBorder.none, // no border
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    focusedErrorBorder: InputBorder.none,
                    filled: true,
                    fillColor: Colors.transparent, // container handles bg
                    contentPadding:
                        EdgeInsets.zero, // padding already in container
                  ),
                ),
              ),

              Align(
                alignment: Alignment.centerRight,
                child: Obx(() => Text(
                      '${controller.wordCount.value}/50',
                      style: Theme.of(context)
                          .textTheme
                          .labelSmall!
                          .copyWith(color: Colors.grey.shade600),
                    )),
              ),
              const SizedBox(height: 24),

              /// Submit Button
              Center(
                child: SizedBox(
                  width: 200,
                  child: ElevatedButton.icon(
                    label: Text("Submit",
                        style: GoogleFonts.prompt(
                            fontWeight: FontWeight.w500,
                            color: TColors.white,
                            fontSize: 18)),
                    /*onPressed: () async {
                      final text = controller.feedbackText.text.trim();
                      if (text.isEmpty) {
                        Get.snackbar("Feedback Required",
                            "Please enter your thoughts about today’s class.",
                            backgroundColor: Colors.red,
                            colorText: Colors.white);
                        return;
                      }

                      await controller.addFeedback(
                          attendanceId: widget.attendanceModel.sno.toString());
                      controller.resetFeedbackForm();
                      Get.find<AppbarController>().fetchPointsDetails();
                      // ✅ Hide the feedback alert banner after feedback submission
                      final batchController = Get.find<BatchController>();
                      batchController.showReminder.value = false;
                      batchController.alertAttendanceModel.value = null;
                      Get.back();
                      Get.snackbar(
                          "Success", "Feedback submitted! You earned 2 coins.",
                          backgroundColor: TColors.primary,
                          colorText: Colors.white);
                      final notificationController =
                          Get.find<NotificationController>();
                      await notificationController.fetchNotificationList();
                      // 🔥 instantly increment AppBar badge
                      final appbarController = Get.find<AppbarController>();
                      appbarController.incrementNotify();
                    },*/
                    onPressed: () async {
                      final text = controller.feedbackText.text.trim();
                      if (text.isEmpty) {
                        Get.snackbar(
                          "Feedback Required",
                          "Please enter your thoughts about today’s class.",
                          backgroundColor: Colors.red,
                          colorText: Colors.white,
                        );
                        return;
                      }

                      // ✅ Use attendance_id from selected alert
                      final attendanceId = widget.attendanceModel.sno
                          .toString(); // this comes from alertAttendanceModel

                      final success = await controller.addFeedback(
                        attendanceId: attendanceId,
                        feedbackScore:
                            controller.ratings.value.toInt().toString(),
                        feedback: text,
                      );

                      if (success) {
                        controller.resetFeedbackForm();
                        Get.find<AppbarController>().fetchPointsDetails();

                        final batchController = Get.find<BatchController>();
                        batchController
                            .markFeedbackSubmitted(attendanceId); // hide banner

                        Get.back();
                        Get.snackbar(
                          "Success",
                          "Feedback submitted! You earned 2 coins.",
                          backgroundColor: TColors.primary,
                          colorText: Colors.white,
                        );

                        final notificationController =
                            Get.find<NotificationController>();
                        await notificationController.fetchNotificationList();
                        Get.find<AppbarController>().incrementNotify();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: TColors.primary,
                      minimumSize: const Size.fromHeight(50),
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
