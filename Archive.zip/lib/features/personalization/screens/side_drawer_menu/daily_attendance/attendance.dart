import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/attendance_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/daily_attendance/widget/attendance_calender.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/daily_attendance/widget/studentfeedbackdialog.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/apptextstyles.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/animation_loaders.dart';
import '../../../controllers/side_drawer_controller/course_controller.dart';

class AttendancePage extends StatelessWidget {
  AttendanceController controller = Get.put(AttendanceController());
  AttendancePage({super.key});

  // final CourseDetailModel courseModel;
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.attendencetour) ?? false;

      if (!controller.isAttendenceTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.AttendenceTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.attendencetour, true);
        controller.isAttendenceTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    final courseController = Get.put(CourseController());

    WidgetsBinding.instance.addPostFrameCallback((_) {
      courseController.fetchCourses();

      // Put your logic here that updates the UI or performs navigation
      controller.fetchAttendance(
          courseId: courseController
              .coursesList[courseController.courseAttendanceIndex.value]
              .courseSno
              .toString()); // Example of UI update
    });
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            CustomHeader(title: "Daily Attendance"),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    const SizedBox(
                      height: 10,
                    ),
                    Obx(
                      () => Container(
                        key: controller.attendencedropdownKey,
                        width: 380,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: TColors.grey)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<int>(
                            value: courseController.courseAttendanceIndex.value,
                            isExpanded: true,
                            dropdownColor:
                                Colors.white, // Dropdown menu background
                            icon: const Icon(Icons.keyboard_arrow_down,
                                color: TColors.primary),
                            style: GoogleFonts.prompt(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                            onChanged: (int? index) {
                              if (index != null) {
                                courseController.courseAttendanceIndex.value =
                                    index;
                                controller.fetchAttendance(
                                    courseId: courseController
                                        .coursesList[courseController
                                            .courseAttendanceIndex.value]
                                        .courseSno
                                        .toString());
                              }
                            },
                            items: List.generate(
                              courseController.coursesList.length,
                              (index) => DropdownMenuItem<int>(
                                value: index,
                                child: Text(
                                  courseController.coursesList[index].courseName,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    /* Obx(() => Container(
                          margin: EdgeInsets.only(left: 8, right: 8),
                          child: CourseDetailsCard(
                              courseModel: courseController.coursesList[
                                  courseController.courseAttendanceIndex.value]),
                        )),*/
      
                    /// Batch Details
                    /* Obx(
                      () {
                        return BatchDetailsCard(
                          courseId: courseController
                              .coursesList[
                                  courseController.courseAttendanceIndex.value]
                              .courseSno
                              .toString(),
                        );
                      },
                    ),*/
      
                    /* Obx(() {
                      final courseModel = courseController.coursesList[
                          courseController.courseAttendanceIndex.value];
                      return CourseBatchDetailsCard(courseModel: courseModel);
                    }),*/
                    SizedBox(
                      height: 10,
                    ),
                    Column(
                      key: controller.attendencetabsKey,
                      children: [
                        // Your existing Class Attendance / Feedback tabs
                        Obx(() {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            child: Row(
                              children: [
                                // Class Attendance Tab
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => controller.isList.value = true,
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              TImages.calender,
                                              width: 25,
                                              height: 25,
                                              fit: BoxFit.contain,
                                            ),
                                            SizedBox(width: 6),
                                            Text(
                                              "Class Attendance",
                                              style: GoogleFonts.prompt(
                                                fontWeight:
                                                    controller.isList.value
                                                        ? FontWeight.bold
                                                        : FontWeight.normal,
                                                color: controller.isList.value
                                                    ? Colors.black
                                                    : Colors.grey,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 4),
                                        Container(
                                          height: 3,
                                          width: 180,
                                          decoration: BoxDecoration(
                                            color: controller.isList.value
                                                ? Colors.grey.shade300
                                                : Colors.transparent,
                                            borderRadius:
                                                BorderRadius.circular(2),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
      
                                // Feedback Tab
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => controller.isList.value = false,
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              TImages.feed,
                                              width: 25,
                                              height: 25,
                                              fit: BoxFit.contain,
                                            ),
                                            SizedBox(width: 6),
                                            Text(
                                              "Feedback",
                                              style: GoogleFonts.prompt(
                                                fontWeight:
                                                    controller.isList.value
                                                        ? FontWeight.normal
                                                        : FontWeight.bold,
                                                color: controller.isList.value
                                                    ? Colors.grey
                                                    : Colors.black,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 4),
                                        Container(
                                          height: 3,
                                          width: 120,
                                          decoration: BoxDecoration(
                                            color: controller.isList.value
                                                ? Colors.transparent
                                                : Colors.grey.shade300,
                                            borderRadius:
                                                BorderRadius.circular(2),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 25),
                          child: Obx(() {
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                if (controller.isList.value) ...[
                                  // Attendance View
                                  /*   _legendItem(
                                      color: TColors.importantText,
                                      label: "Holiday"),
                                  const SizedBox(width: 20),*/
                                  _legendItem(
                                      color: TColors.green, label: "Present"),
                                  const SizedBox(width: 20),
                                  _legendItem(
                                      color: TColors.red, label: "Absent"),
                                ] else ...[
                                  // Feedback View
                                  _legendItem(
                                      color: TColors.primary, label: "Feedback"),
                                  const SizedBox(width: 20),
                                  _legendItem(
                                      color: TColors.Bottomcolor,
                                      label: "Not Given Feedback"),
                                ],
                              ],
                            );
                          }),
                        ),
                      ],
                    ),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7.0),
                      ),
                      child: Obx(() {
                        if (controller.isLoading.value) {
                          return const TAnimationLoaderWidget(
                            text: "Loading...",
                            animation: TImages.pencilAnimation,
                          );
                        }
      
                        // Show Calendar for Attendance tab
                        if (controller.isList.value) {
                          return CustomCalendar(
                            focusedDay: controller.focusedDay,
                            selectedDay: controller.selectedDay!,
                            calendarFormat: controller.calendarFormat,
                            onDaySelected: (selectedDay, focusedDay) {
                              controller.selectedDay!.value = selectedDay;
                              controller.focusedDay.value = focusedDay;
                            },
                            onPageChanged: (focusedDay) {
                              controller.focusedDay.value = focusedDay;
                            },
                            eventLoader: controller.getEventsForDay,
                            controller: controller,
                            availableGestures: AvailableGestures
                                .none, // 👈 This disables swipe scrolling
                          );
                        }
                        controller.submittedKeyAssigned = false;
                        controller.pendingKeyAssigned = false;
                        return GridView.builder(
                          padding: const EdgeInsets.all(16),
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: controller.attendanceModel.length,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 5,
                            mainAxisSpacing: 12,
                            crossAxisSpacing: 12,
                            childAspectRatio: 1,
                          ),
                          itemBuilder: (context, index) {
                            final e = controller.attendanceModel[index];
                            final date = DateTime.parse(e.attDate);
                            final month = DateFormat("MMM").format(date);
                            final day = DateFormat("dd").format(date);
      
                            final bool feedbackFilled =
                                e.feedback != null && e.feedback!.isNotEmpty;
      
                            return GestureDetector(
                              onTap: () {
                                final today = DateTime.now();
                                final todayDateOnly =
                                    DateTime(today.year, today.month, today.day);
                                final dateOnly =
                                    DateTime(date.year, date.month, date.day);
      
                                // ✅ Allow feedback only for current date
                                if (dateOnly.isAtSameMomentAs(todayDateOnly)) {
                                  if (!feedbackFilled) {
                                    showDialog(
                                      context: context,
                                      builder: (_) => FeedbackDialog(
                                        date: e.attDate,
                                        attendanceModel: e,
                                      ),
                                    );
                                  } else {
                                    showDialog(
                                      context: context,
                                      builder: (_) => SubmittedFeedbackDialog(
                                        attendanceModel: e,
                                      ),
                                    );
                                  }
                                } else {
                                  Fluttertoast.showToast(
                                    msg: "Feedback can be added only for today",
                                    toastLength: Toast.LENGTH_SHORT,
                                    gravity: ToastGravity.BOTTOM,
                                    backgroundColor: TColors.primary,
                                    textColor: Colors.white,
                                    fontSize: 14.0,
                                  );
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: feedbackFilled
                                      ? TColors.primary
                                      : TColors.Bottomcolor,
                                ),
                                alignment: Alignment.center,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      month,
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Text(
                                      day,
                                      style: GoogleFonts.prompt(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      }),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Helper widget for legend item
  Widget _legendItem({required Color color, required String label}) {
    return Row(
      children: [
        Container(
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: AppTextStyles.heading,
        ),
      ],
    );
  }
}
