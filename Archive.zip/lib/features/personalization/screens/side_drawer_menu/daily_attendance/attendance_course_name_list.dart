import 'package:eapl_student_app/common/widget/background/background_theme.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/course_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../common/widget/app_bar/appbar.dart';
import '../../../../../common/widget/course/course_name_list_card.dart';
import '../../../../../common/widget/menu/side_drawer_menu/side_menu.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/loaders/animation_loaders.dart';

class AttendanceCourseNameList extends StatelessWidget {
  const AttendanceCourseNameList({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final courseController = CourseController.instance;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      courseController.fetchCourses();
    });
    return SafeArea(
      child: Scaffold(
        drawer: SideMenuBar(),
        appBar: CustomAppBar(),
        body: OurBackgroundTheme(
          child: Obx(
            () {
              if (courseController.isLoading.value == true) {
                return const TAnimationLoaderWidget(
                    text: "Loading...", animation: TImages.pencilAnimation);
              }
              return Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ///================= Body of the dashboard====================///
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Course List",
                            style: Theme.of(context).textTheme.headlineSmall,
                          ),
                          ListView.builder(
                            itemCount: courseController.coursesList.length,
                            physics: const NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemBuilder: (_, index) {
                              return CourseNameListCard(
                                courseModel: courseController.coursesList[index],
                                onTap: () {
                                  // Get.to(() => AttendancePage(courseModel: courseController.coursesList[index],));
                                },
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
