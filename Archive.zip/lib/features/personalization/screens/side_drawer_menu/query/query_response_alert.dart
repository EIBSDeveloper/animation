/*
import '../../../../../utils/constants/path_provider.dart';
import '../../../models/query_or_complaint_model.dart';

class QueryResponseAlert extends StatelessWidget {
  final QueryOrComplaintModel queryModel;
  final VoidCallback? onClosed; // callback to update status

  const QueryResponseAlert(
      {super.key, required this.queryModel, this.onClosed});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: TColors.sandal,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: 60), // space for image
                Text("${queryModel.cusName}..!!",
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge!
                        .apply(color: TColors.primary)),
                const SizedBox(height: 10),
                Text(
                  queryModel.description ?? 'There is no response',
                  textAlign: TextAlign.justify,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    if (onClosed != null) onClosed!(); // call controller
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: TColors.primary,
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                  child: const Text("Ok"),
                ),
              ],
            ),
          ),
          Positioned(
            top: -90,
            child: Image.asset(
              'assets/image/alert/query.png',
              height: 130,
              width: 130,
            ),
          ),
        ],
      ),
    );
  }
}
*/
