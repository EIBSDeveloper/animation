/*
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:flutter/services.dart';
import 'package:get_storage/get_storage.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../../utils/constants/text_strings.dart';
import '../../../../../../utils/validators/validation.dart';
import '../../../../controllers/side_drawer_controller/query_or_complaint_controller.dart';

class Addquerypage extends StatelessWidget {
  Addquerypage({super.key});

  final QueryOrComplaintController controller =
      Get.put(QueryOrComplaintController());
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown =
          GetStorage().read(TTexts.querydetailstour) ?? false;

      if (!controller.isQuerydetailsTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.QuerydetailsTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.querydetailstour, true);
        controller.isQuerydetailsTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    //controller.QuerydetailsTour(context);
    return Scaffold(
      body: PopScope(
        onPopInvoked: (didPop) {
          if (didPop) controller.clearform();
        },
        child: Column(
          children: [
            /// 🔹 Custom Header
            CustomHeader(title: "Add Query"),
            const SizedBox(height: 20),

            /// 🔹 Full Page Form
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Form(
                  key: controller.addFormQuery,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // --- Category Radio Group ---
                      */
/* Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(
                            bottom: TSizes.spaceBtwInputFields),
                        decoration: BoxDecoration(
                          color: TColors.sandal,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: TColors.grey),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 22),
                              child: Row(
                                children: [
                                  Image.asset(
                                    TImages.category,
                                    height: 25,
                                    width: 25,
                                    fit: BoxFit.contain,
                                  ),
                                  SizedBox(
                                    width: 8,
                                  ),
                                  Text("Select Category",
                                      style: AppTextStyles.heading),
                                  const Text("*",
                                      style: TextStyle(color: Colors.red)),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),
                            // --- Category Radio Group ---
                            Obx(() => Column(
                                  children:
                                      controller.queryCategory.map((value) {
                                    return RadioListTile<String>(
                                      title: Text(
                                        value,
                                        style: AppTextStyles.subheading,
                                      ),
                                      value: value,
                                      groupValue: controller.selectedCategorys
                                          .value, // ✅ use .value
                                      activeColor: TColors.primary,
                                      onChanged: (newValue) {
                                        controller.selectedCategorys.value =
                                            newValue;
                                      },
                                    );
                                  }).toList(),
                                )),
                          ],
                        ),
                      ),*/ /*


                      // --- Priority Radio Group ---
                      */
/*Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(
                            bottom: TSizes.spaceBtwInputFields),
                        decoration: BoxDecoration(
                          color: TColors.sandal,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: TColors.grey),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 22),
                              child: Row(
                                children: [
                                  Image.asset(
                                    TImages.priority,
                                    height: 25,
                                    width: 25,
                                    fit: BoxFit.contain,
                                  ),
                                  SizedBox(
                                    width: 8,
                                  ),
                                  Text("Select Priority",
                                      style: AppTextStyles.heading),
                                  const Text("*",
                                      style: TextStyle(color: Colors.red)),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),
                            // --- Priority Radio Group ---
                            Obx(() => Padding(
                                  padding: const EdgeInsets.only(left: 15),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children:
                                        controller.queryPriority.map((value) {
                                      return Expanded(
                                        child: RadioListTile<String>(
                                          title: Text(
                                            value,
                                            style: AppTextStyles.subheading,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          value: value,
                                          groupValue: controller
                                              .selectedPrioritys.value,
                                          activeColor: TColors.primary,
                                          contentPadding: EdgeInsets
                                              .zero, // ✅ no extra left-right padding
                                          dense: true, // ✅ compact
                                          visualDensity: const VisualDensity(
                                            horizontal:
                                                -2, // ✅ reduce gap between button & text
                                            vertical:
                                                -2, // ✅ makes tile more compact
                                          ),
                                          onChanged: (newValue) {
                                            controller.selectedPrioritys.value =
                                                newValue!;
                                          },
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                )),
                          ],
                        ),
                      ),*/ /*

                      // --- Category Radio Group ---
                      Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(
                            bottom: TSizes.spaceBtwInputFields),
                        decoration: BoxDecoration(
                          color: TColors.sandal,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: TColors.grey),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 22),
                              child: Row(
                                children: [
                                  Image.asset(
                                    TImages.category,
                                    height: 25,
                                    width: 25,
                                    fit: BoxFit.contain,
                                  ),
                                  SizedBox(width: 8),
                                  Text("Select Category",
                                      style: AppTextStyles.heading),
                                  const Text("*",
                                      style: TextStyle(color: Colors.red)),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),

                            /// ✅ Validator added
                            FormField<String>(
                              validator: (_) {
                                if (controller.selectedCategorys.value ==
                                        null ||
                                    controller
                                        .selectedCategorys.value!.isEmpty) {
                                  return "Category is required";
                                }
                                return null;
                              },
                              builder: (field) => Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start, // ✅ aligns left
                                children: [
                                  */
/* Obx(() => Column(
                                        children: controller.queryCategory
                                            .map((value) {
                                          return RadioListTile<String>(
                                            title: Text(
                                              value,
                                              style: AppTextStyles.subheading,
                                            ),
                                            value: value,
                                            groupValue: controller
                                                .selectedCategorys.value,
                                            activeColor: TColors.primary,
                                            onChanged: (newValue) {
                                              controller.selectedCategorys
                                                  .value = newValue;
                                              field.didChange(newValue);
                                            },
                                          );
                                        }).toList(),
                                      )),*/ /*

                                  Obx(() => Column(
                                        children: controller.queryCategory
                                            .asMap() // ✅ gives us index + value
                                            .entries
                                            .map((entry) {
                                          final index = entry.key;
                                          final value = entry.value;

                                          return RadioListTile<String>(
                                            key: index == 0
                                                ? controller.categoryKey
                                                : null, // ✅ key only for first radio
                                            title: Text(
                                              value,
                                              style: AppTextStyles.subheading,
                                            ),
                                            value: value,
                                            groupValue: controller
                                                .selectedCategorys.value,
                                            activeColor: TColors.primary,
                                            onChanged: (newValue) {
                                              controller.selectedCategorys
                                                  .value = newValue;
                                              field.didChange(newValue);
                                            },
                                          );
                                        }).toList(),
                                      )),
                                  if (field.hasError)
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 16, top: 4),
                                      child: Text(field.errorText!,
                                          style: const TextStyle(
                                              color: TColors.error,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold)),
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // --- Priority Radio Group ---
                      Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(
                            bottom: TSizes.spaceBtwInputFields),
                        decoration: BoxDecoration(
                          color: TColors.sandal,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: TColors.grey),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 22),
                              child: Row(
                                children: [
                                  Image.asset(
                                    TImages.priority,
                                    height: 25,
                                    width: 25,
                                    fit: BoxFit.contain,
                                  ),
                                  SizedBox(width: 8),
                                  Text("Select Priority",
                                      style: AppTextStyles.heading),
                                  const Text("*",
                                      style: TextStyle(color: Colors.red)),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),

                            /// ✅ Validator added
                            FormField<String>(
                              validator: (_) {
                                if (controller.selectedPrioritys.value ==
                                        null ||
                                    controller
                                        .selectedPrioritys.value!.isEmpty) {
                                  return "Priority is required";
                                }
                                return null;
                              },
                              builder: (field) => Padding(
                                padding: const EdgeInsets.only(left: 15),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start, // ✅ aligns left
                                  children: [
                                    */
/* Obx(() => Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: controller.queryPriority
                                              .map((value) {
                                            return Expanded(
                                              child: RadioListTile<String>(
                                                title: Text(
                                                  value,
                                                  style:
                                                      AppTextStyles.subheading,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                                value: value,
                                                groupValue: controller
                                                    .selectedPrioritys.value,
                                                activeColor: TColors.primary,
                                                contentPadding: EdgeInsets.zero,
                                                dense: true,
                                                visualDensity:
                                                    const VisualDensity(
                                                        horizontal: -2,
                                                        vertical: -2),
                                                onChanged: (newValue) {
                                                  controller.selectedPrioritys
                                                      .value = newValue!;
                                                  field.didChange(newValue);
                                                },
                                              ),
                                            );
                                          }).toList(),
                                        )),*/ /*

                                    Obx(() => Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: controller.queryPriority
                                              .asMap() // ✅ gives us index + value
                                              .entries
                                              .map((entry) {
                                            final index = entry.key;
                                            final value = entry.value;

                                            return Expanded(
                                              child: RadioListTile<String>(
                                                key: index == 0
                                                    ? controller.priorityKey
                                                    : null, // ✅ tutorial key for first radio
                                                title: Text(
                                                  value,
                                                  style:
                                                      AppTextStyles.subheading,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                                value: value,
                                                groupValue: controller
                                                    .selectedPrioritys.value,
                                                activeColor: TColors.primary,
                                                contentPadding: EdgeInsets.zero,
                                                dense: true,
                                                visualDensity:
                                                    const VisualDensity(
                                                        horizontal: -2,
                                                        vertical: -2),
                                                onChanged: (newValue) {
                                                  controller.selectedPrioritys
                                                      .value = newValue!;
                                                  field.didChange(newValue);
                                                },
                                              ),
                                            );
                                          }).toList(),
                                        )),
                                    if (field.hasError)
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 16, top: 4),
                                        child: Text(field.errorText!,
                                            style: const TextStyle(
                                                color: TColors.error,
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold)),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // --- Issue TextField ---
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 35),
                            child: Row(
                              children: [
                                Image.asset(
                                  TImages.issue,
                                  height: 25,
                                  width: 25,
                                  fit: BoxFit.contain,
                                ),
                                SizedBox(
                                  width: 8,
                                ),
                                Text("Issue", style: AppTextStyles.heading),
                                const Text("*",
                                    style: TextStyle(color: Colors.red)),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            key: controller.issueKey,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            margin: const EdgeInsets.only(
                                bottom: TSizes.spaceBtwInputFields),
                            decoration: BoxDecoration(
                              color: TColors.sandal,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: TColors.grey),
                            ),
                            child: TextFormField(
                              validator: (value) =>
                                  TValidator.validateEmptyField("Issue", value),
                              controller: controller.issueController,
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[a-zA-Z\s]')),
                              ],
                              maxLines: 3,
                              onChanged: (value) {
                                final words =
                                    value.trim().split(RegExp(r'\s+'));
                                controller.wordCount.value = words
                                    .where((word) => word.isNotEmpty)
                                    .length;

                                if (controller.wordCount.value > 100) {
                                  final trimmedWords =
                                      words.take(100).join(' ');
                                  controller.issueController.text =
                                      trimmedWords;
                                  controller.issueController.selection =
                                      TextSelection.fromPosition(
                                    TextPosition(offset: trimmedWords.length),
                                  );
                                  controller.wordCount.value = 100;
                                }
                              },
                              decoration: InputDecoration(
                                hintText: "Describe your Query",
                                hintStyle: AppTextStyles.subheading,
                                enabledBorder: InputBorder.none,
                                focusedBorder: InputBorder.none,
                                errorBorder: InputBorder.none,
                                focusedErrorBorder: InputBorder.none,
                                filled: true,
                                fillColor: TColors
                                    .sandal, // ✅ TextFormField background sandal
                              ),
                            ),
                          ),
                          Obx(
                            () => Align(
                              alignment: Alignment.centerRight,
                              child: Padding(
                                padding: const EdgeInsets.only(right: 16.0),
                                child: Text(
                                  "${controller.wordCount.value}/100",
                                  style: TextStyle(
                                      fontSize: 12, color: Colors.grey[600]),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      // --- Attachments Section ---
                      Center(
                        child: Container(
                          width: 120,
                          height: 120,
                          margin: const EdgeInsets.only(
                              bottom: TSizes.spaceBtwInputFields),
                          decoration: BoxDecoration(
                            color: TColors.sandal,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: TColors.grey),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              Get.bottomSheet(
                                Container(
                                  color: Colors.white,
                                  child: Wrap(
                                    children: [
                                      ListTile(
                                        leading: const Icon(Icons.camera),
                                        title: const Text('Take Photo'),
                                        onTap: () {
                                          controller.pickAttachment(
                                              ImageSource.camera);
                                          Get.back();
                                        },
                                      ),
                                      ListTile(
                                        leading:
                                            const Icon(Icons.photo_library),
                                        title:
                                            const Text('Choose from Gallery'),
                                        onTap: () {
                                          controller.pickAttachment(
                                              ImageSource.gallery);
                                          Get.back();
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                            child: Obx(() {
                              if (controller.attachment.value != null) {
                                return ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.file(
                                    controller.attachment.value!,
                                    fit: BoxFit.cover,
                                  ),
                                );
                              } else {
                                return const Center(
                                    child: Icon(Iconsax.gallery_add, size: 40));
                              }
                            }),
                          ),
                        ),
                      ),

                      // --- Submit Button ---
                      Center(
                        child: SizedBox(
                          width: 200,
                          child: Obx(() => ElevatedButton(
                                key: controller.submitKey,
                                onPressed: controller.isLoading.value
                                    ? null // disable button when loading
                                    : () {
                                        controller.addquery();
                                      },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: TColors.primary,
                                  elevation: 4,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10)),
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 14),
                                ),
                                child: controller.isLoading.value
                                    ? SizedBox(
                                        height: 24,
                                        child: LoadingAnimationWidget.waveDots(
                                          color: Colors.white,
                                          size: 35,
                                        ),
                                      )
                                    : Text("Submit",
                                        style: AppTextStyles.heading),
                              )),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
*/
