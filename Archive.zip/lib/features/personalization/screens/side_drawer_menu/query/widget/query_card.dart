/*import 'package:eapl_student_app/features/personalization/models/query_or_complaint_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../../utils/constants/colors.dart';
import '../view_query.dart';

class QueryCard extends StatelessWidget {
  const QueryCard({
    super.key,
    required this.queryModel,
  });

  final QueryOrComplaintModel queryModel;

  @override
*/ /*  Widget build(BuildContext context) {
    DateTime dateFromDatabase = DateTime.parse(queryModel.createdDate);
    String createdDate = DateFormat("dd-MM-yyyy").format(dateFromDatabase);

    return GestureDetector(
      onTap: () => Get.to(() => ViewQuery(
            queryModel: queryModel,
          )),
      child: Container(
        padding: EdgeInsets.all(TSizes.sm),
        margin: EdgeInsets.symmetric(vertical: TSizes.xs),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 9,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(createdDate,
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .apply(color: TColors.primary)),
                      Container(
                        padding:
                            const EdgeInsets.symmetric(horizontal: TSizes.xs),
                        decoration: BoxDecoration(
                          color: TColors.buttonSecondary,
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        child: Text(queryModel.issueStatus == 0
                            ? "Open"
                            : queryModel.issueStatus == 2
                                ? "Closed"
                                : "Pending"),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text("Category   ",
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .apply(color: TColors.black)),
                      Text(queryModel.category,
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .apply(color: TColors.importantText)),
                    ],
                  ),
                  Row(
                    children: [
                      Text("Issue          ",
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .apply(color: TColors.black)),
                      SizedBox(
                          width: THelperFunctions.screenWidth() / 1.9,
                          child: Text(
                            queryModel.issue,
                            style: Theme.of(context).textTheme.bodyLarge!.apply(
                                  color: TColors.importantText,
                                ),
                            overflow: TextOverflow.ellipsis,
                          )),
                    ],
                  ),
                  Row(
                    children: [
                      Text("Priority      ",
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .apply(color: TColors.black)),
                      SizedBox(
                          width: THelperFunctions.screenWidth() / 1.9,
                          child: Text(
                            queryModel.priorityLevel,
                            style: Theme.of(context).textTheme.bodyLarge!.apply(
                                  color: TColors.importantText,
                                ),
                            overflow: TextOverflow.ellipsis,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(flex: 1, child: Icon(Icons.arrow_forward_ios))
          ],
        ),
      ),
    );
  }*/ /*
  Widget build(BuildContext context) {
    DateTime dateFromDatabase = DateTime.parse(queryModel.createdDate);
    String createdDate = DateFormat("dd-MM-yyyy").format(dateFromDatabase);

    return GestureDetector(
      onTap: () => Get.to(() => ViewQuery(queryModel: queryModel)),
      child: Container(
        padding: const EdgeInsets.all(16.0),
        margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Color.fromRGBO(60, 64, 67, 0.3),
                blurRadius: 2,
                spreadRadius: 0,
                offset: Offset(
                  0,
                  1,
                ),
              ),
              BoxShadow(
                color: Color.fromRGBO(60, 64, 67, 0.15),
                blurRadius: 6,
                spreadRadius: 2,
                offset: Offset(
                  0,
                  2,
                ),
              ),
            ]),
        child: Row(
          children: [
            Expanded(
              flex: 9,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Top Row: Date & Status
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.calendar_today,
                              size: 16, color: Colors.grey),
                          const SizedBox(width: 6),
                          Text(
                            createdDate,
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium!
                                .copyWith(color: TColors.primary),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: queryModel.issueStatus == 0
                              ? Colors.orange.shade100
                              : queryModel.issueStatus == 2
                                  ? Colors.green.shade100
                                  : Colors.yellow.shade100,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          queryModel.issueStatus == 0
                              ? "Open"
                              : queryModel.issueStatus == 2
                                  ? "Closed"
                                  : "Pending",
                          style: TextStyle(
                            color: queryModel.issueStatus == 0
                                ? Colors.orange
                                : queryModel.issueStatus == 2
                                    ? Colors.green
                                    : Colors.amber[900],
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  /// Category
                  Row(
                    children: [
                      const Icon(Icons.category,
                          size: 18, color: Colors.black54),
                      const SizedBox(width: 6),
                      Text("Category: ",
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium!
                              .copyWith(fontWeight: FontWeight.w500)),
                      Expanded(
                        child: Text(queryModel.category,
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium!
                                .copyWith(color: TColors.importantText),
                            overflow: TextOverflow.ellipsis),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  /// Issue
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.report_problem,
                          size: 18, color: Colors.black54),
                      const SizedBox(width: 6),
                      Text("Issue: ",
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium!
                              .copyWith(fontWeight: FontWeight.w500)),
                      Expanded(
                        child: Text(
                          queryModel.issue,
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium!
                              .copyWith(color: TColors.importantText),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  /// Priority
                  Row(
                    children: [
                      const Icon(Icons.priority_high,
                          size: 18, color: Colors.black54),
                      const SizedBox(width: 6),
                      Text("Priority: ",
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium!
                              .copyWith(fontWeight: FontWeight.w500)),
                      Text(queryModel.priorityLevel,
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium!
                              .copyWith(color: TColors.importantText)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}*/

/*class QueryCard extends StatelessWidget {
  const QueryCard({super.key, required this.queryModel, this.statusKey});
  final QueryOrComplaintModel queryModel;
  final statusKey;

  @override
  Widget build(BuildContext context) {
    DateTime dateFromDatabase = DateTime.parse(queryModel.createdDate);
    String createdDate = DateFormat("dd MMM yyyy").format(dateFromDatabase);

    return GestureDetector(
      onTap: () => Get.to(() => ViewQuery(queryModel: queryModel)),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
            color: TColors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: TColors.grey)),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Date & Status Row (same as before)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Image.asset(
                            TImages.calender,
                            height: 25,
                            width: 25,
                            fit: BoxFit.contain,
                          ),
                          const SizedBox(width: 8),
                          Text(createdDate,
                              style: GoogleFonts.prompt(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  color: Colors.black)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),

                  // Category Row
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        TImages.category,
                        height: 25,
                        width: 25,
                        fit: BoxFit.contain,
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        width: 80, // fixed width for label
                        child: Text(
                          "Topic:",
                          style: GoogleFonts.prompt(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.black),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          queryModel.category,
                          style: GoogleFonts.prompt(
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              color: Colors.black),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),

                  // Issue Row
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        TImages.issue,
                        height: 25,
                        width: 25,
                        fit: BoxFit.contain,
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        width: 80,
                        child: Text(
                          "Issue:",
                          style: GoogleFonts.prompt(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.black),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          queryModel.issue,
                          style: GoogleFonts.prompt(
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              color: Colors.black),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),

                  // Priority Row
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset(
                        TImages.priority,
                        height: 25,
                        width: 25,
                        fit: BoxFit.contain,
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        width: 80,
                        child: Text(
                          "Priority:",
                          style: GoogleFonts.prompt(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.black),
                        ),
                      ),
                      Text(
                        queryModel.priorityLevel,
                        style: GoogleFonts.prompt(
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            color: Colors.black),
                      ),
                      const Spacer(),
                      Text(
                        queryModel.issueStatus == 0
                            ? "Open"
                            : queryModel.issueStatus == 1
                                ? "Pending"
                                : "Closed",
                        key: statusKey, // ✅ tutorial key for index 0 status
                        style: GoogleFonts.prompt(
                          color: TColors.primary, // primary color for all text
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}*/
