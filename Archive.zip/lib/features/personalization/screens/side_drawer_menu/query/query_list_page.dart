/*
import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/query_or_complaint_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/query/widget/addquerypage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../models/query/conversationmodel.dart';
import 'widget/query_card.dart';

class QueryList extends StatelessWidget {
  final controller = Get.put(QueryOrComplaintController());

  QueryList({super.key});

  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.querytour) ?? false;

      if (!controller.isQueryTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.QueryTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.querytour, true);
        controller.isQueryTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);

    return RefreshIndicator(
      onRefresh: () async {
        final selectedTab = controller.selectedQueryTab.value;

        if (selectedTab == 3) {
          // Conversation tab → refresh conversation list
          await controller.conversationquery(refresh: true);
        } else {
          // Other tabs → refresh query list
          await controller.fetchQueryOrComplaintList();
        }
      },
      child: Scaffold(
        body: Column(
          children: [
            CustomHeader(title: "My Queries"),
            SizedBox(height: 10),
            Obx(() => Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ToggleButtons(
                      renderBorder: false,
                      fillColor: Colors.transparent,
                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      isSelected: [
                        controller.selectedQueryTab.value == 0, // Open
                        controller.selectedQueryTab.value == 1, // Pending
                        controller.selectedQueryTab.value == 2, // Closed
                        controller.selectedQueryTab.value == 3, // Conversation
                      ],
                      onPressed: (index) {
                        controller.selectedQueryTab.value = index;
                      },
                      children: [
                        /// Open
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Text(
                                "Open",
                                style: GoogleFonts.prompt(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: controller.selectedQueryTab.value == 0
                                      ? TColors.primary
                                      : Colors.grey.shade300,
                                ),
                              ),
                            ),
                            if (controller.selectedQueryTab.value == 0)
                              Container(
                                margin: const EdgeInsets.only(top: 4),
                                height: 5,
                                width: 60,
                                color: TColors.grey,
                              ),
                          ],
                        ),

                        /// Pending
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                "Pending",
                                style: GoogleFonts.prompt(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: controller.selectedQueryTab.value == 1
                                      ? TColors.primary
                                      : Colors.grey.shade300,
                                ),
                              ),
                            ),
                            if (controller.selectedQueryTab.value == 1)
                              Container(
                                margin: const EdgeInsets.only(top: 4),
                                height: 5,
                                width: 60,
                                color: TColors.grey,
                              ),
                          ],
                        ),

                        /// Closed
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                "Closed",
                                style: GoogleFonts.prompt(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: controller.selectedQueryTab.value == 2
                                      ? TColors.primary
                                      : Colors.grey.shade300,
                                ),
                              ),
                            ),
                            if (controller.selectedQueryTab.value == 2)
                              Container(
                                margin: const EdgeInsets.only(top: 4),
                                height: 5,
                                width: 60,
                                color: TColors.grey,
                              ),
                          ],
                        ),

                        /// Conversation
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                "Conversation",
                                style: GoogleFonts.prompt(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: controller.selectedQueryTab.value == 3
                                      ? TColors.primary
                                      : Colors.grey.shade300,
                                ),
                              ),
                            ),
                            if (controller.selectedQueryTab.value == 3)
                              Container(
                                margin: const EdgeInsets.only(top: 4),
                                height: 5,
                                width: 60,
                                color: TColors.grey,
                              ),
                          ],
                        ),
                      ],
                    ),
                  ],
                )),

            /// Tab View
            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) {
                  return const Center(child: CircularProgressIndicator());
                }

                switch (controller.selectedQueryTab.value) {
                  case 0: // Open
                    final openList = controller.queryModelList
                        .where((q) => q.issueStatus == 0)
                        .toList();
                    if (openList.isEmpty)
                      return const Center(child: Text("No Open Queries"));
                    return ListView.builder(
                      itemCount: openList.length,
                      itemBuilder: (context, index) => Container(
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          child: QueryCard(queryModel: openList[index])),
                    );

                  case 1: // Pending
                    final pendingList = controller.queryModelList
                        .where((q) => q.issueStatus == 1)
                        .toList();
                    if (pendingList.isEmpty)
                      return const Center(child: Text("No Pending Queries"));
                    return ListView.builder(
                      itemCount: pendingList.length,
                      itemBuilder: (context, index) => Container(
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          child: QueryCard(queryModel: pendingList[index])),
                    );

                  case 2: // Closed
                    final closedList = controller.queryModelList
                        .where((q) => q.issueStatus == 2)
                        .toList();
                    if (closedList.isEmpty)
                      return const Center(child: Text("No Closed Queries"));
                    return ListView.builder(
                      itemCount: closedList.length,
                      itemBuilder: (context, index) => Container(
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          child: QueryCard(queryModel: closedList[index])),
                    );

                  case 3: // Conversation
                    if (controller.conversationList.isEmpty) {
                      return const Center(child: Text("No conversations yet"));
                    }
                    return ListView.builder(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      itemCount: controller.conversationList.length,
                      itemBuilder: (context, index) {
                        final issue = controller.conversationList[index];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            ...issue.conversationList
                                .map((c) => ChatBubble(conversation: c))
                                .toList(),
 const Divider(),

                          ],
                        );
                      },
                    );

                  default:
                    return const SizedBox();
                }
              }),
            ),
          ],
        ),
        floatingActionButton: Align(
          alignment: Alignment.bottomRight,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 30.0, right: 20.0),
            child: FloatingActionButton(
              key: controller.addKey,
              onPressed: () {
                Get.to(() => Addquerypage());
              },
              backgroundColor: TColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(50.0),
              ),
              child: const Icon(Icons.add, color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}

class ChatBubble extends StatelessWidget {
  final Conversation conversation;

  const ChatBubble({super.key, required this.conversation});

  @override
  Widget build(BuildContext context) {
    final isStudent = conversation.sender.toLowerCase() == 'student';

    return Align(
      alignment: isStudent ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 14),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color:
              isStudent ? TColors.primary.withOpacity(0.15) : Colors.grey[200],
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
            bottomLeft: isStudent ? Radius.circular(16) : Radius.circular(4),
            bottomRight: isStudent ? Radius.circular(4) : Radius.circular(16),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 4,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
              isStudent ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (conversation.name.isNotEmpty)
              Text(
                conversation.name,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: Colors.black87,
                ),
              ),
            if (conversation.name.isNotEmpty) SizedBox(height: 4),
            Text(
              conversation.message,
              style: TextStyle(fontSize: 14, color: Colors.black87),
            ),
            if (conversation.attachment != null &&
                conversation.attachment != 'null') ...[
              SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  conversation.attachment!,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, progress) {
                    if (progress == null) return child;
                    return SizedBox(
                      height: 150,
                      child: Center(
                        child: CircularProgressIndicator(
                          value: progress.expectedTotalBytes != null
                              ? progress.cumulativeBytesLoaded /
                                  progress.expectedTotalBytes!
                              : null,
                        ),
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => Container(
                    height: 150,
                    color: Colors.grey[300],
                    child: Center(
                      child: Text(
                        "Attachment not found",
                        style: TextStyle(color: Colors.grey[700]),
                      ),
                    ),
                  ),
                ),
              ),
            ],
            SizedBox(height: 4),
            Text(
              conversation.timestamp,
              style: TextStyle(fontSize: 10, color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }
}
*/
import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/query_or_complaint_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../models/query/conversationmodel.dart';

class QueryList extends StatelessWidget {
  final controller = Get.put(QueryOrComplaintController());
  final ScrollController _scrollController = ScrollController();

  QueryList({super.key});

  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.querytour) ?? false;

      if (!controller.isQueryTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.QueryTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.querytour, true);
        controller.isQueryTouron.value = true;
      }
      // ✅ Call markseen API whenever page opens
      await controller.markseen();
      // ✅ Refresh conversation list after marking seen
      await controller.conversationquery(refresh: true);
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);

    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            const CustomHeader(title: "My Queries"),
            const SizedBox(height: 10),
      
            /// Conversation Chat List
            Expanded(
              child: RefreshIndicator(
                onRefresh: () => controller.conversationquery(refresh: true),
                child: Obx(() {
                  if (controller.isLoading.value) {
                    return const Center(child: CircularProgressIndicator());
                  }
      
                  if (controller.conversationList.isEmpty) {
                    return const Center(
                      child: Text(
                        "No conversations yet",
                        style: TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                    );
                  }
      
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (_scrollController.hasClients) {
                      _scrollController
                          .jumpTo(_scrollController.position.maxScrollExtent);
                    }
                  });
      
                  return ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    itemCount: controller.conversationList.length,
                    itemBuilder: (context, index) {
                      final issue = controller.conversationList[index];
      
                      // ✅ Find index of last staff message in this issue’s conversation list
                      final lastStaffIndex =
                          issue.conversationList.lastIndexWhere(
                        (msg) => msg.sender.toLowerCase() == 'staff',
                      );
      
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: issue.conversationList.map((c) {
                          final isLastStaff =
                              issue.conversationList.indexOf(c) == lastStaffIndex;
                          return ChatBubble(
                            conversation: c,
                            isLast: !c.sender.toLowerCase().contains('student') &&
                                isLastStaff,
                            onClose: isLastStaff
                                ? () => controller.closeconversation()
                                : null,
                          );
                        }).toList(),
                      );
                    },
                  );
                }),
              ),
            ),
      
            // Chat Input Field (replaces FAB)
          ],
        ),
        bottomNavigationBar: SafeArea(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller.messageController,
                    decoration: InputDecoration(
                      hintText: 'Type your message...',
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide:
                            BorderSide(color: Colors.grey.shade300, width: 1),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide:
                            BorderSide(color: Colors.grey.shade300, width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide:
                            BorderSide(color: Colors.grey.shade400, width: 1.5),
                      ),
                      fillColor: Colors.grey.shade100,
                      filled: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                InkWell(
                  onTap: () async {
                    await controller.sendMessage();
                    await Future.delayed(const Duration(milliseconds: 300));
                    if (_scrollController.hasClients) {
                      _scrollController.animateTo(
                        _scrollController.position.maxScrollExtent,
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOut,
                      );
                    }
                  },
                  child: CircleAvatar(
                    radius: 24,
                    backgroundColor: TColors.primary,
                    child: const Icon(Icons.send, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/*
class ChatBubble extends GetView<QueryOrComplaintController> {
  final Conversation conversation;
  final VoidCallback? onClose;
  final bool isLast; // ✅ To show close button only for last staff message

  const ChatBubble({
    super.key,
    required this.conversation,
    this.onClose,
    this.isLast = false, // default false
  });

  @override
  Widget build(BuildContext context) {
    final isStudent = conversation.sender.toLowerCase() == 'student';

    final bgColor = isStudent ? TColors.primary : Colors.green.shade300;
    final textColor = isStudent ? Colors.white : Colors.black87;

    return Align(
      alignment: isStudent ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.40),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: isStudent
                ? const Radius.circular(16)
                : const Radius.circular(4),
            bottomRight: isStudent
                ? const Radius.circular(4)
                : const Radius.circular(16),
          ),
        ),
        child: Column(
          crossAxisAlignment:
              isStudent ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (conversation.name.isNotEmpty)
              Text(
                conversation.name,
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: isStudent
                        ? Color(0xff5DFE13)
                        : Color(0xff790CE8) // ✅ dynamic color
                    ),
              ),

            if (conversation.name.isNotEmpty) const SizedBox(height: 4),
            Text(
              conversation.message,
              style: TextStyle(
                  fontSize: 18, color: textColor, fontWeight: FontWeight.w500),
            ),
            if (conversation.attachment != null &&
                conversation.attachment != 'null') ...[
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  conversation.attachment!,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, progress) {
                    if (progress == null) return child;
                    return SizedBox(
                      height: 150,
                      child: Center(
                        child: CircularProgressIndicator(
                          value: progress.expectedTotalBytes != null
                              ? progress.cumulativeBytesLoaded /
                                  progress.expectedTotalBytes!
                              : null,
                        ),
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => Container(
                    height: 150,
                    color: Colors.grey[300],
                    child: const Center(
                      child: Text(
                        "Attachment not found",
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 4),
            // Timestamp + Seen Icon for staff messages only
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  conversation.timestamp,
                  style: TextStyle(fontSize: 10, color: textColor),
                ),
                const SizedBox(width: 4),
                // ✅ Show eye icon only for student messages that have been seen by staff
                if (isStudent && conversation.seen)
                  Icon(
                    Icons.remove_red_eye,
                    size: 13,
                    color: Colors.white,
                  ),
              ],
            ),

            // ✅ Show "Close" button only for last staff message
            if (!isStudent && isLast) ...[
              const Divider(color: Colors.white, thickness: 1),
              Obx(() {
                // Show loading while closing the issue
                if (controller.iscloseLoading.value) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: SizedBox(
                        height: 20,
                        width: 20,
                        child:
                            CircularProgressIndicator(color: TColors.primary),
                      ),
                    ),
                  );
                }

                // Check if issue is closed
                else if (conversation.closed == 2) {
                  // ✅ check for closed
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        "Solved",
                        style: TextStyle(
                          color: Colors.redAccent,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                }

                // Issue is not closed → show "Solve issue?" button
                else {
                  return GestureDetector(
                    onTap: () async {
                      bool? confirm = await Get.dialog<bool>(
                        AlertDialog(
                          backgroundColor: TColors.white,
                          title: const Text("Confirm"),
                          content:
                              const Text("Do you want to solve this issue?"),
                          actions: [
                            // ❌ No button
                            SizedBox(
                              height: 40,
                              child: OutlinedButton(
                                onPressed: () => Get.back(result: false),
                                style: OutlinedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  side: BorderSide.none,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  shadowColor: Colors.grey.withOpacity(0.5),
                                  elevation: 3,
                                ),
                                child: const Text(
                                  "No",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(width: 10),

                            // ✅ Yes button
                            SizedBox(
                              height: 40,
                              child: ElevatedButton(
                                onPressed: () => Get.back(result: true),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: TColors.primary,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                ),
                                child: const Text(
                                  "Yes",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );

                      // If Yes → call controller to close issue
                      if (confirm == true) {
                        await controller.closeconversation();
                      }
                    },
                    child: const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Text(
                          "Solve issue ?",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  );
                }
              }),
            ],
          ],
        ),
      ),
    );
  }
}*/
class ChatBubble extends GetView<QueryOrComplaintController> {
  final Conversation conversation;
  final VoidCallback? onClose;
  final bool isLast;

  const ChatBubble({
    super.key,
    required this.conversation,
    this.onClose,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    final isStudent = conversation.sender.toLowerCase() == 'student';
    final theme = Theme.of(context);

    // 💬 Premium background gradients
    final bgGradient = LinearGradient(
      colors: isStudent
          ? [
              const Color(0xFF4CAF50), // green gradient for student (sender)
              const Color(0xFF2E7D32),
            ]
          : [
              const Color(0xFFE0E0E0), // light grey-white for staff
              const Color(0xFFFAFAFA),
            ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );

    final textColor = isStudent ? Colors.white : Colors.black87;

    return Align(
      alignment: isStudent ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          gradient: bgGradient,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: isStudent
                ? const Radius.circular(18)
                : const Radius.circular(5),
            bottomRight: isStudent
                ? const Radius.circular(5)
                : const Radius.circular(18),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 6,
              offset: const Offset(2, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
              isStudent ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // 🧍‍♂️ Sender name
            if (conversation.name.isNotEmpty)
              Text(
                conversation.name,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                  color: isStudent
                      ? const Color(0xFFB2FF59)
                      : const Color(0xFF673AB7),
                ),
              ),
            if (conversation.name.isNotEmpty) const SizedBox(height: 4),

            // 💬 Message text
            Text(
              conversation.message,
              style: TextStyle(
                fontSize: 16,
                color: textColor,
                height: 1.3,
              ),
            ),

            // 📎 Image attachment (if any)
            if (conversation.attachment != null &&
                conversation.attachment != 'null') ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  conversation.attachment!,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, progress) {
                    if (progress == null) return child;
                    return Container(
                      height: 150,
                      alignment: Alignment.center,
                      child: CircularProgressIndicator(
                        value: progress.expectedTotalBytes != null
                            ? progress.cumulativeBytesLoaded /
                                progress.expectedTotalBytes!
                            : null,
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => Container(
                    height: 150,
                    color: Colors.grey[200],
                    alignment: Alignment.center,
                    child: const Text(
                      "⚠️ Attachment not found",
                      style: TextStyle(color: Colors.black54),
                    ),
                  ),
                ),
              ),
            ],

            const SizedBox(height: 4),

            // ⏰ Timestamp + Seen
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment:
                  isStudent ? MainAxisAlignment.end : MainAxisAlignment.start,
              children: [
                Text(
                  conversation.timestamp,
                  style: TextStyle(
                    fontSize: 10,
                    color: textColor.withOpacity(0.8),
                  ),
                ),
                const SizedBox(width: 4),
                if (isStudent && conversation.seen)
                  const Icon(
                    Icons.done_all,
                    size: 14,
                    color: Colors.lightBlueAccent,
                  ),
              ],
            ),

            // 🟢 Close issue (only for staff, last message)
            if (!isStudent && isLast) ...[
              const SizedBox(height: 6),
              Divider(color: Colors.grey.shade400, thickness: 0.6),
              const SizedBox(height: 6),
              Obx(() {
                if (controller.iscloseLoading.value) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Color(0xFF673AB7),
                        ),
                      ),
                    ),
                  );
                } else if (conversation.closed == 2) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 6),
                      child: Text(
                        "✅ Solved",
                        style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  );
                } else {
                  return GestureDetector(
                    onTap: () async {
                      bool? confirm = await Get.dialog<bool>(
                        AlertDialog(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          title: const Text(
                            "Confirm",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          content: const Text(
                              "Do you want to mark this issue solved?"),
                          actionsAlignment: MainAxisAlignment.spaceEvenly,
                          actions: [
                            OutlinedButton(
                              onPressed: () => Get.back(result: false),
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: Colors.grey),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: const Text("No",
                                  style: TextStyle(color: Colors.black54)),
                            ),
                            ElevatedButton(
                              onPressed: () => Get.back(result: true),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF4CAF50),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: const Text(
                                "Yes",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      );
                      if (confirm == true) {
                        await controller.closeconversation();
                      }
                    },
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text(
                          "🛠 Solve issue?",
                          style: TextStyle(
                            color: theme.colorScheme.primary,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ),
                  );
                }
              }),
            ],
          ],
        ),
      ),
    );
  }
}
