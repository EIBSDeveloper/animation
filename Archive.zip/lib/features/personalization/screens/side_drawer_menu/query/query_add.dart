/*
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:eapl_student_app/utils/constants/sizes.dart';
import 'package:eapl_student_app/utils/helpers/helper_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../../utils/validators/validation.dart';
import '../../../controllers/side_drawer_controller/query_or_complaint_controller.dart';

class AddQuery extends StatelessWidget {
  AddQuery({Key? key}) : super(key: key);

  final QueryOrComplaintController controller =
      Get.put(QueryOrComplaintController());

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (didPop) {
        if (didPop) controller.resetForm();
      },
      child: SizedBox(
        width: THelperFunctions.screenWidth() / 1,
        child: AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
                14), // 👈 Reduce from default (e.g., 12) to 6
          ),
          backgroundColor: Colors.white,
          //shadowColor: Colors.white,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(width: 24), // Placeholder to center title
              Text("New Query", style: AppTextStyles.title),
              IconButton(
                icon: const Icon(Icons.close, color: TColors.black),
                onPressed: () {
                  controller.resetForm();
                  Get.back(); // Close the dialog
                },
              ),
            ],
          ),

          content: SingleChildScrollView(
            child: Form(
              key: controller.addFormQuery,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // --- Category Dropdown ---

                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    margin: const EdgeInsets.only(
                        bottom: TSizes.spaceBtwInputFields),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: TColors.grey)),
                    child: DropdownButtonFormField<String>(
                      dropdownColor: Colors.white,
                      validator: (value) =>
                          TValidator.validateEmptyField("Category", value),
                      style: Theme.of(context).textTheme.labelLarge,
                      value: controller.selectedCategory,
                      decoration: InputDecoration(
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        focusedErrorBorder: InputBorder.none,
                        filled: true,
                        fillColor:
                            Colors.white, // ✅ Ensures inner area is white
                        label: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "Select Category ",
                              style: AppTextStyles.subheading,
                            ),
                            const Text("*",
                                style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                      items: controller.queryCategory
                          .map<DropdownMenuItem<String>>(
                            (String value) => DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      onChanged: (newValue) {
                        controller.selectedCategory = newValue;
                      },
                    ),
                  ),

                  // --- Priority Dropdown ---

                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    margin: const EdgeInsets.only(
                        bottom: TSizes.spaceBtwInputFields),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: TColors.grey)),
                    child: DropdownButtonFormField<String>(
                      dropdownColor: Colors.white,
                      validator: (value) =>
                          TValidator.validateEmptyField("Priority", value),
                      style: Theme.of(context).textTheme.labelLarge,
                      value: controller.selectedPriority,
                      decoration: InputDecoration(
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        focusedErrorBorder: InputBorder.none,
                        filled: true,
                        fillColor: Colors.white,
                        label: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "Select Priority ",
                              style: AppTextStyles.subheading,
                            ),
                            const Text("*",
                                style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                      items: controller.queryPriority
                          .map<DropdownMenuItem<String>>(
                            (String value) => DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      onChanged: (newValue) {
                        controller.selectedPriority = newValue;
                      },
                    ),
                  ),

                  // --- Issue TextField ---
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        margin: const EdgeInsets.only(
                            bottom: TSizes.spaceBtwInputFields),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: TColors.grey)),
                        child: TextFormField(
                          validator: (value) =>
                              TValidator.validateEmptyField("Issue", value),
                          controller: controller.issueController,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(
                                RegExp(r'[a-zA-Z\s]')),
                          ],
                          maxLines: 3,
                          onChanged: (value) {
                            final words = value.trim().split(RegExp(r'\s+'));
                            controller.wordCount.value =
                                words.where((word) => word.isNotEmpty).length;

                            if (controller.wordCount.value > 100) {
                              final trimmedWords = words.take(100).join(' ');
                              controller.issueController.text = trimmedWords;
                              controller.issueController.selection =
                                  TextSelection.fromPosition(
                                TextPosition(offset: trimmedWords.length),
                              );
                              controller.wordCount.value = 100;
                            }
                          },
                          decoration: InputDecoration(
                            hintText: "Describe your Query",
                            hintStyle: AppTextStyles.subheading,
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            errorBorder: InputBorder.none,
                            focusedErrorBorder: InputBorder.none,
                            filled: true,
                            fillColor: Colors.white,
                          ),
                        ),
                      ),
                      Obx(() => Align(
                            alignment: Alignment.centerRight,
                            child: Padding(
                              padding: const EdgeInsets.only(right: 16.0),
                              child: Text(
                                "${controller.wordCount.value}/100",
                                style: TextStyle(
                                    fontSize: 12, color: Colors.grey[600]),
                              ),
                            ),
                          )),
                    ],
                  ),

                  // --- Attachments Section ---
                  Container(
                    width: 100,
                    height: 100,
                    margin: const EdgeInsets.only(
                        bottom: TSizes.spaceBtwInputFields),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: TColors.grey)),
                    child: GestureDetector(
                      onTap: () {
                        Get.bottomSheet(
                          Container(
                            color: Colors.white,
                            child: Wrap(
                              children: [
                                ListTile(
                                  leading: const Icon(Icons.camera),
                                  title: const Text('Take Photo'),
                                  onTap: () {
                                    controller
                                        .pickAttachment(ImageSource.camera);
                                    Get.back();
                                  },
                                ),
                                ListTile(
                                  leading: const Icon(Icons.photo_library),
                                  title: const Text('Choose from Gallery'),
                                  onTap: () {
                                    controller
                                        .pickAttachment(ImageSource.gallery);
                                    Get.back();
                                  },
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                      child: Obx(() {
                        if (controller.attachment.value != null) {
                          return ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.file(
                              controller.attachment.value!,
                              fit: BoxFit.cover,
                            ),
                          );
                        } else {
                          return const Center(
                              child: Icon(Iconsax.gallery_add, size: 40));
                        }
                      }),
                    ),
                  ),

                  // --- Submit Button ---
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        controller.addQueryOrComplaintList();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: TColors.primary,
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: Text("Submit", style: AppTextStyles.heading),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
*/
