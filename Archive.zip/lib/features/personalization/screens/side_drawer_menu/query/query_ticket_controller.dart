import 'package:eapl_student_app/utils/constants/path_provider.dart';

class QueryTicketController extends GetxController{

}