/*
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/query/query_response_alert.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../data/repository/query_or_complaints_repository.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../models/query_or_complaint_model.dart';

class ViewQuery extends StatelessWidget {
  final QueryOrComplaintModel queryModel;
  final QueryOrComplaintRepository controller =
      Get.put(QueryOrComplaintRepository());

  ViewQuery({super.key, required this.queryModel}) {
    controller.initQuery(queryModel); // Initialize reactive model
  }

  @override
  Widget build(BuildContext context) {
    DateTime dateFromDatabase = DateTime.parse(queryModel.createdDate);
    String createdDate = DateFormat("dd-MM-yyyy").format(dateFromDatabase);

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(150),
        child: CustomHeader(title: "Query Details"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(vertical: 12),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: TColors.sandal,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: TColors.grey),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildRow(TImages.calender, "Date", createdDate),
                  _buildRow(TImages.category, "Category", queryModel.category),
                  _buildRow(
                      TImages.priority, "Priority", queryModel.priorityLevel),
                  _buildRow(TImages.issue, "Issue", queryModel.issue,
                      isMultiline: true),
                  const SizedBox(height: 20),
                  // Attachment section
                  _buildAttachment(queryModel),
                  const SizedBox(height: 22),

                  /// Status Row - reactive
                  */
/* Obx(() {
                    final q = controller.rxQueryModel.value;
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 130,
                          child: Row(
                            children: [
                              Image.asset(
                                TImages.status,
                                height: 25,
                                width: 25,
                                fit: BoxFit.contain,
                                color: TColors.primary,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                "Status:",
                                style: GoogleFonts.prompt(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Text(
                            q.issueStatus == 0
                                ? "Open"
                                : q.issueStatus == 2
                                    ? "Closed"
                                    : "Pending",
                            style: GoogleFonts.prompt(
                              color: Colors.black87,
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        if (q.issueStatus == 1)
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: TColors.primary,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              elevation: 4,
                            ),
                            onPressed: () => Get.dialog(
                              QueryResponseAlert(
                                queryModel: q,
                                onClosed: controller.closeQueryResponseTicket,
                              ),
                            ),
                            child: const Text(
                              "Response",
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ),
                      ],
                    );
                  }),*/ /*

                  Obx(() {
                    final q = controller.rxQueryModel.value;
                    final hasResponse =
                        (q.description != null && q.description!.isNotEmpty);

                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 130,
                          child: Row(
                            children: [
                              Image.asset(
                                TImages.status,
                                height: 25,
                                width: 25,
                                fit: BoxFit.contain,
                                color: TColors.primary,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                "Status:",
                                style: GoogleFonts.prompt(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Text(
                            q.issueStatus == 0
                                ? "Open"
                                : q.issueStatus == 2
                                    ? "Closed"
                                    : "Pending",
                            style: GoogleFonts.prompt(
                              color: Colors.black87,
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                            ),
                          ),
                        ),

                        // ✅ Show Response button ONLY if issueStatus == 1 AND response exists
                        if (q.issueStatus == 1 && hasResponse)
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: TColors.primary,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              elevation: 4,
                            ),
                            onPressed: () => Get.dialog(
                              QueryResponseAlert(
                                queryModel: q,
                                onClosed: controller.closeQueryResponseTicket,
                              ),
                            ),
                            child: const Text(
                              "Response",
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ),
                      ],
                    );
                  })
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(String imagePath, String label, String value,
      {bool isMultiline = false, double imageSize = 25}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        crossAxisAlignment:
            isMultiline ? CrossAxisAlignment.start : CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: 130,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  imagePath,
                  width: imageSize,
                  height: imageSize,
                  fit: BoxFit.contain,
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    "$label:",
                    style: GoogleFonts.prompt(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: GoogleFonts.prompt(
                color: Colors.black87,
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAttachment(QueryOrComplaintModel q) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Image.asset(
              TImages.attachment,
              height: 25,
              width: 25,
              fit: BoxFit.contain,
              color: TColors.primary,
            ),
            const SizedBox(width: 5),
            Text(
              "Attachment",
              style: GoogleFonts.prompt(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        q.attachmentUrl != null && q.attachmentUrl!.isNotEmpty
            ? Padding(
                padding: const EdgeInsets.only(left: 130),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    q.attachmentUrl!,
                    width: 140,
                    height: 140,
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Container(
                        width: 140,
                        height: 140,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: TColors.primary,
                          ),
                        ),
                      );
                    },
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.error, color: Colors.red, size: 44),
                  ),
                ),
              )
            : Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: TColors.darkGrey),
                ),
                child: const Icon(Iconsax.gallery_add, size: 44),
              ),
      ],
    );
  }
}
*/
