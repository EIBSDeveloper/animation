import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../../../../utils/constants/path_provider.dart';
import '../../../../controllers/side_drawer_controller/course_controller.dart';
import '../../../../models/course_model.dart';
import '../current_course_details_view.dart';

/*class CourseCard extends StatelessWidget {
  final double statusPercentage;
  final String statusText;
  final CourseDetailModel courseDetails;
  final Key? viewKey;
  final Key? ratingKey;
  CourseCard({
    super.key,
    required this.statusPercentage,
    required this.statusText,
    required this.courseDetails,
    this.viewKey,
    this.ratingKey,
  });
  final controller = Get.put(CourseController());
  @override
  Widget build(BuildContext context) {
    double progress =
        double.tryParse(courseDetails.courseCompletePercentage ?? "0.0") ?? 0.0;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300, width: 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// 1. Title Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                courseDetails.courseName ?? "---", // default if null
                style: GoogleFonts.prompt(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                getDisplayStatus(courseDetails.statuslabel),
                style: GoogleFonts.prompt(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: getStatusColor(courseDetails.statuslabel),
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
          const SizedBox(height: 15),

          /// 2. Progress Row
          Row(
            children: [
              /// Progress Bar
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: progress / 100,
                    minHeight: 6,
                    backgroundColor: Colors.grey.shade300,
                    valueColor: AlwaysStoppedAnimation<Color>(TColors.primary),
                  ),
                ),
              ),
              const SizedBox(width: 10),

              /// Percentage
              Text(
                "${progress.toStringAsFixed(0)}%",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(width: 10),

              /// View Details Button (fixed h & w)
              SizedBox(
                key: viewKey,
                height: 30,
                width: 100,
                child: ElevatedButton(
                  onPressed: () {
                    Get.to(
                      () =>
                          CurrentCourseDetailsView(courseModel: courseDetails),
                      transition: Transition.cupertino,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: TColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    padding: EdgeInsets.zero,
                    elevation: 0,
                  ),
                  child: Text(
                    'View Details',
                    style: GoogleFonts.prompt(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: TColors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),

          /// 3. Info Row
          Row(
            children: [
              /// Category
              Expanded(
                flex: 3,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.calender,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                        child: Text(
                      courseDetails.endDate != null
                          ? "${DateFormat('d MMM yyyy').format(DateTime.tryParse(courseDetails.endDate!) ?? DateTime.now())}"
                          : "---",
                      overflow: TextOverflow.ellipsis,
                    )),
                  ],
                ),
              ),

              /// Days
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.days,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        'Days: ${courseDetails.remainingdays ?? "0"}',
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
              ),

              /// Rating or Rating Button (fixed size, same as "View Details")
              Row(
                children: List.generate(5, (index) {
                  return Icon(
                    index < 4
                        ? Icons.star
                        : Icons.star_border, // ✅ 4 stars filled
                    color: Colors
                        .orangeAccent, // you can use Colors.grey if you want
                    size: 18,
                  );
                }),
              ),
            ],
          )
        ],
      ),
    );
  }

// Map API status to display text
  String getDisplayStatus(String? status) {
    if (status == null) return "";
    switch (status.toLowerCase()) {
      case "complete":
        return "Completed";
      case "on progress":
        return "On Progress";
      case "not yet started":
        return "Not Yet Started";
      default:
        return status; // fallback, display as-is
    }
  }

// Get color based on API status
  Color getStatusColor(String? status) {
    if (status == null) return Colors.black;
    switch (status.toLowerCase()) {
      case "complete":
        return Colors.green;
      case "on progress":
        return Colors.orange;
      case "not yet started":
        return Colors.red;
      default:
        return Colors.black;
    }
  }
}*/
class CourseCard extends StatelessWidget {
  final double statusPercentage;
  final String statusText;
  final CourseDetailModel courseDetails;
  final Key? viewKey;
  final Key? ratingKey;

  CourseCard({
    super.key,
    required this.statusPercentage,
    required this.statusText,
    required this.courseDetails,
    this.viewKey,
    this.ratingKey,
  });

  final controller = Get.put(CourseController());

  @override
  Widget build(BuildContext context) {
    double progress =
        double.tryParse(courseDetails.courseCompletePercentage ?? "0.0") ?? 0.0;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300, width: 0.8),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// 1. Title Row
          Row(
            children: [
              /// Course Name (single line)
              Expanded(
                child: Text(
                  (courseDetails.courseName != null &&
                          courseDetails.courseName!.isNotEmpty)
                      ? courseDetails.courseName!
                      : "---",
                  style: GoogleFonts.prompt(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1, // single line
                  overflow: TextOverflow.ellipsis, // shows "..." if too long
                  softWrap: false,
                ),
              ),

              const SizedBox(width: 8),

              /// Status Label (single line)
              Text(
                getDisplayStatus(courseDetails.statuslabel),
                style: GoogleFonts.prompt(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: getStatusColor(courseDetails.statuslabel),
                ),
                maxLines: 1,
                overflow: TextOverflow.visible,
                softWrap: false,
                textAlign: TextAlign.right,
              ),
            ],
          ),

          const SizedBox(height: 15),

          /// 2. Progress Row
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              /// Progress Bar
              Expanded(
                flex: 3,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: progress / 100,
                    minHeight: 6,
                    backgroundColor: Colors.grey.shade300,
                    valueColor: AlwaysStoppedAnimation<Color>(TColors.primary),
                  ),
                ),
              ),
              const SizedBox(width: 10),

              /// Percentage (single line, auto width)
              ConstrainedBox(
                constraints: const BoxConstraints(minWidth: 30),
                child: Text(
                  "${progress.toStringAsFixed(0)}%",
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  textAlign: TextAlign.right,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  softWrap: false, // ensures single line
                ),
              ),

              const SizedBox(width: 10),

              /// View Details Button
              SizedBox(
                key: viewKey,
                height: 30,
                width: 100,
                child: ElevatedButton(
                  onPressed: () {
                    Get.to(
                      () =>
                          CurrentCourseDetailsView(courseModel: courseDetails),
                      transition: Transition.cupertino,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: TColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    padding: EdgeInsets.zero,
                    elevation: 0,
                  ),
                  child: Text(
                    'View Details',
                    style: GoogleFonts.prompt(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: TColors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 15),

          /// 3. Info Row
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              /// End Date
              Expanded(
                flex: 3,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset(
                      TImages.calender,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        courseDetails.endDate != null
                            ? "${DateFormat('d MMM yyyy').format(DateTime.tryParse(courseDetails.endDate!) ?? DateTime.now())}"
                            : "---",
                        softWrap: true,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 5),

              /// Days
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.days,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        'Days: ${courseDetails.remainingdays ?? "0"}',
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        softWrap: true,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 5),

              /// Rating Stars
              RatingBarWidget(
                rating: double.tryParse(courseDetails.rating ?? '0') ?? 0.0,
              ),
            ],
          ),
        ],
      ),
    );
  }

  String getDisplayStatus(String? status) {
    if (status == null) return "";
    switch (status.toLowerCase()) {
      case "complete":
        return "Completed";
      case "on progress":
        return "On Progress";
      case "not yet started":
        return "Not Yet Started";
      default:
        return status;
    }
  }

  Color getStatusColor(String? status) {
    if (status == null) return Colors.black;
    switch (status.toLowerCase()) {
      case "complete":
        return Colors.green;
      case "on progress":
        return Colors.orange;
      case "not yet started":
        return Colors.red;
      default:
        return Colors.black;
    }
  }
}

class RatingBarWidget extends StatelessWidget {
  final double rating; // e.g., 4.5
  const RatingBarWidget({super.key, required this.rating});

  @override
  Widget build(BuildContext context) {
    int fullStars = rating.floor();
    bool hasHalfStar = (rating - fullStars) >= 0.5;

    return SizedBox(
      height: 30,
      width: 100, // same width as button
      child: Container(
        decoration: BoxDecoration(
          color: Colors.green,
          borderRadius: BorderRadius.circular(6),
        ),
        alignment: Alignment.center, // center content
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Rating number
            Text(
              rating.toStringAsFixed(1),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
            const SizedBox(width: 2), // smaller spacing
            // Stars
            ...List.generate(5, (index) {
              if (index < fullStars) {
                return const Icon(Icons.star, color: Colors.yellow, size: 14);
              } else if (index == fullStars && hasHalfStar) {
                return const Icon(Icons.star_half,
                    color: Colors.yellow, size: 14);
              } else {
                return const Icon(Icons.star_border,
                    color: Colors.yellow, size: 14);
              }
            }),
          ],
        ),
      ),
    );
  }
}
