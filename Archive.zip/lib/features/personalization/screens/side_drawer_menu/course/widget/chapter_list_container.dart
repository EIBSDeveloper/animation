/*class ChapterListContainer extends StatelessWidget {
  const ChapterListContainer({
    super.key,
    required this.backgroundColor,
    required this.chapterNumber,
    required this.chapterModel,
    required this.chapters, // new argument 1
    required this.chapterKey, // new argument 2
    this.onTap, // new argument 3 (optional callback)
  });

  final ChapterModel chapterModel;
  final Color backgroundColor;
  final String chapterNumber;

  // ✅ New fields
  final List<ChapterModel> chapters;
  final GlobalKey chapterKey;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap ??
          () {
            Get.to(() => CurrentChapterView(
                  chapterId: chapterModel.chapterId,
                  chapterCount: chapterNumber,
                ));
          },
      child: Container(
        width: double.infinity,
        margin: EdgeInsets.only(top: 7),
        padding: const EdgeInsets.all(TSizes.md),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            const BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.3),
              blurRadius: 2,
              spreadRadius: 0,
              offset: Offset(0, 1),
            ),
            const BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.15),
              blurRadius: 6,
              spreadRadius: 2,
              offset: Offset(0, 2),
            ),
          ],
          borderRadius: BorderRadius.circular(14),
        ),
        child: IntrinsicHeight(
          child: Row(
            children: [
              Text(
                chapterNumber.length == 1 ? "0$chapterNumber" : chapterNumber,
                style: Theme.of(context)
                    .textTheme
                    .headlineLarge!
                    .apply(color: TColors.primary),
              ),
              const SizedBox(width: TSizes.sm),
              const VerticalDivider(color: TColors.darkerGrey, width: 0.5),
              const SizedBox(width: TSizes.sm),
              Expanded(
                child: Text(
                  chapterModel.chapterName,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodyLarge!
                      .apply(color: TColors.black),
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded),
            ],
          ),
        ),
      ),
    );
  }
}*/

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../models/syllabus_model/chapter_model.dart';
import '../current_chapter_view.dart';

class ChapterListContainer extends StatelessWidget {
  const ChapterListContainer({
    super.key,
    required this.chapterNumber,
    required this.chapterModel,
    required this.chapters,
    required this.chapterKey,
    this.onTap,
  });

  final ChapterModel chapterModel;
  final String chapterNumber;
  final List<ChapterModel> chapters;
  final GlobalKey chapterKey;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    // Map chapter status to a background color
    Color statusColor() {
      switch (chapterModel.chapterstatus.toLowerCase()) {
        case 'completed':
          return Colors.green.shade100;
        case 'in progress':
          return TColors.primary.withOpacity(0.2);
        case 'not yet started':
          return Colors.grey.shade200;
        default:
          return Colors.white;
      }
    }

    return GestureDetector(
      onTap: onTap ??
          () {
            Get.to(() => CurrentChapterView(
                  chapterId: chapterModel.chapterId,
                  chapterCount: chapterNumber,
                ));
          },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 7),
        padding: const EdgeInsets.all(TSizes.md),
        decoration: BoxDecoration(
          color: statusColor(),
          boxShadow: const [
            BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.3),
              blurRadius: 2,
              offset: Offset(0, 1),
            ),
            BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.15),
              blurRadius: 6,
              offset: Offset(0, 2),
            ),
          ],
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IntrinsicHeight(
              child: Row(
                children: [
                  Text(
                    chapterNumber.length == 1
                        ? "0$chapterNumber"
                        : chapterNumber,
                    style: Theme.of(context)
                        .textTheme
                        .headlineLarge!
                        .apply(color: TColors.primary),
                  ),
                  const SizedBox(width: TSizes.sm),
                  const VerticalDivider(color: TColors.darkerGrey, width: 0.5),
                  const SizedBox(width: TSizes.sm),
                  Expanded(
                    child: Text(
                      chapterModel.chapterName,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .bodyLarge!
                          .apply(color: TColors.black),
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded),
                ],
              ),
            ),

            const SizedBox(height: 6),

            // ✅ Material Icons Row
            Row(
              children: [
                if (chapterModel.hasStudyDoc)
                  Row(
                    children: const [
                      Icon(Icons.menu_book, size: 18, color: Colors.blue),
                      SizedBox(width: 4),
                      Text('Study Doc', style: TextStyle(fontSize: 12)),
                      SizedBox(width: 12),
                    ],
                  ),
                if (chapterModel.hasPpt)
                  Row(
                    children: const [
                      Icon(Icons.slideshow, size: 18, color: Colors.orange),
                      SizedBox(width: 4),
                      Text('PPT', style: TextStyle(fontSize: 12)),
                      SizedBox(width: 12),
                    ],
                  ),
                if (chapterModel.hasLabCode)
                  Row(
                    children: const [
                      Icon(Icons.code, size: 18, color: Colors.green),
                      SizedBox(width: 4),
                      Text('Lab Code', style: TextStyle(fontSize: 12)),
                      SizedBox(width: 12),
                    ],
                  ),
                if (chapterModel.hasPdf)
                  Row(
                    children: const [
                      Icon(Icons.picture_as_pdf, size: 18, color: Colors.red),
                      SizedBox(width: 4),
                      Text('PDF', style: TextStyle(fontSize: 12)),
                    ],
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

//newcode
/*class ChapterListContainer extends StatelessWidget {
  const ChapterListContainer({
    super.key,
    required this.chapterNumber,
    required this.chapterModel,
    required this.chapters,
    required this.chapterKey,
    this.onTap,
  });

  final ChapterModel chapterModel;
  final String chapterNumber;
  final List<ChapterModel> chapters;
  final GlobalKey chapterKey;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    // Map chapter status to a background color
    Color statusColor() {
      switch (chapterModel.chapterstatus.toLowerCase()) {
        case 'completed':
          return Colors.green.shade100; // light green
        case 'in progress':
          return TColors.primary.withOpacity(0.2); // light primary
        case 'not yet started':
          return Colors.grey.shade200; // light grey
        default:
          return Colors.white;
      }
    }

    return GestureDetector(
      onTap: onTap ??
          () {
            Get.to(() => CurrentChapterView(
                  chapterId: chapterModel.chapterId,
                  chapterCount: chapterNumber,
                ));
          },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 7),
        padding: const EdgeInsets.all(TSizes.md),
        decoration: BoxDecoration(
          color: statusColor(),
          boxShadow: [
            const BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.3),
              blurRadius: 2,
              spreadRadius: 0,
              offset: Offset(0, 1),
            ),
            const BoxShadow(
              color: Color.fromRGBO(60, 64, 67, 0.15),
              blurRadius: 6,
              spreadRadius: 2,
              offset: Offset(0, 2),
            ),
          ],
          borderRadius: BorderRadius.circular(14),
        ),
        child: IntrinsicHeight(
          child: Row(
            children: [
              Text(
                chapterNumber.length == 1 ? "0$chapterNumber" : chapterNumber,
                style: Theme.of(context)
                    .textTheme
                    .headlineLarge!
                    .apply(color: TColors.primary),
              ),
              const SizedBox(width: TSizes.sm),
              const VerticalDivider(color: TColors.darkerGrey, width: 0.5),
              const SizedBox(width: TSizes.sm),
              Expanded(
                child: Text(
                  chapterModel.chapterName,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodyLarge!
                      .apply(color: TColors.black),
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded),
            ],
          ),
        ),
      ),
    );
  }
}*/
