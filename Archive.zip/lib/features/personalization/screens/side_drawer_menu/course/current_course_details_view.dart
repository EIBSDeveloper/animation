import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/common/widget/course/course_detail_card.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/syllabus_controller.dart';
import 'package:eapl_student_app/features/personalization/models/course_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/course/widget/chapter_list_container.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../utils/constants/apptextstyles.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/animation_loaders.dart';

class CurrentCourseDetailsView extends StatelessWidget {
  const CurrentCourseDetailsView({super.key, required this.courseModel});

  final CourseDetailModel courseModel;

  @override
  Widget build(BuildContext context) {
    final syllabusController = Get.put(SyllabusController());
    syllabusController.fetchChapter(courseModel.courseSno);

    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Course Details"),
        ),
        body: Obx(() {
          if (syllabusController.isLoading.value) {
            return const TAnimationLoaderWidget(
              text: "Loading...",
              animation: TImages.pencilAnimation,
            );
          }
      
          // ✅ Show tutorial only once
          if (!syllabusController.isMycoursedetailsTouron.value &&
              syllabusController.chapterList.isNotEmpty) {
            WidgetsBinding.instance.addPostFrameCallback((_) async {
              final isTutorialShown =
                  GetStorage().read(TTexts.mycoursedetailstour) ?? false;
              if (!isTutorialShown) {
                await Future.delayed(const Duration(milliseconds: 700));
                syllabusController.MycoursedetailsTour(context);
              }
            });
          }
      
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              /// ================== Course Title ====================
              CourseDetailsCard(courseModel: courseModel),
      
              const SizedBox(height: 15),
              Text("List of Chapters", style: AppTextStyles.title),
              const SizedBox(height: 12),
      
              ...syllabusController.chapterList.asMap().entries.map((entry) {
                final index = entry.key;
                final chapter = entry.value;
                final chapterNumber = (index + 1).toString();
                return ChapterListContainer(
                  chapterModel: chapter,
                  chapterNumber: chapterNumber,
                  //backgroundColor: Colors.white,
                  chapters: syllabusController.chapterList,
                  chapterKey: syllabusController.chapterKey,
                );
              }).toList(),
      
              const SizedBox(height: 50), // optional bottom padding
            ],
          );
        }),
      ),
    );
  }
}
