import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/course_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/helpers/helper_functions.dart';
import '../../../../../utils/loaders/animation_loaders.dart';
import 'widget/course_list_card.dart';

class CourseList extends StatelessWidget {
  final courseController = CourseController.instance;
  CourseList({super.key});
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.mycoursetour) ?? false;

      if (!courseController.isMycourseTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await courseController.MycourseTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.mycoursetour, true);
        courseController.isMycourseTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      courseController.fetchCourses();
    });
    return SafeArea(
      child: Scaffold(
        body: Obx(
          () {
            if (courseController.isLoading.value) {
              return const TAnimationLoaderWidget(
                text: "Loading...",
                animation: TImages.pencilAnimation,
              );
            }
            return Column(
              children: [
                CustomHeader(title: "My courses"),
      
                // Expanded GridView
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.symmetric(
                        horizontal: TSizes.sm, vertical: TSizes.sm),
                    itemCount: courseController.coursesList.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 1,
                      mainAxisExtent:
                          THelperFunctions.screenWidth() > 600 ? 270 : 150,
                      mainAxisSpacing: TSizes.sm,
                      crossAxisSpacing: TSizes.gridViewSpacing,
                    ),
                    itemBuilder: (_, index) {
                      final isFirst = index == 0;
                      return CourseCard(
                        courseDetails: courseController.coursesList[index],
                        statusPercentage: 0.6,
                        statusText: 'On Progress',
                        viewKey: isFirst ? courseController.viewKey : null,
                        ratingKey: isFirst ? courseController.ratingKey : null,
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
