import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/syllabus_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/apptextstyles.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/animation_loaders.dart';

class CurrentChapterView extends StatelessWidget {
  const CurrentChapterView({
    super.key,
    required this.chapterId,
    required this.chapterCount,
  });

  final int chapterId;
  final String chapterCount;

  @override
  Widget build(BuildContext context) {
    final syllabusController = SyllabusController.instance;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      syllabusController.fetchSectionAndTopics(chapterId);
    });

    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Course Details"),
        ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          child: Obx(() {
            if (syllabusController.isLoading.value) {
              return const Center(
                child: TAnimationLoaderWidget(
                  text: "Loading...",
                  animation: TImages.pencilAnimation,
                ),
              );
            }
      
            if (syllabusController.chapterDetails.isEmpty) {
              return const Center(child: Text("There is no Data"));
            }
            if (!syllabusController.ischapterdetailsTouron.value &&
                syllabusController.chapterDetails.isNotEmpty) {
              WidgetsBinding.instance.addPostFrameCallback((_) async {
                final isShown =
                    GetStorage().read(TTexts.chapterdetailstour) ?? false;
                if (!isShown) {
                  await Future.delayed(const Duration(milliseconds: 700));
                  syllabusController.ChapterdetailsTour(context);
                }
              });
            }
            final chapter = syllabusController.chapterDetails.first;
      
            return SingleChildScrollView(
              padding: const EdgeInsets.all(TSizes.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Title + Chapter count
                  Transform.translate(
                    offset: const Offset(-5, 0), // move 8px left(
                    child: Row(
                      children: [
                        /*InkWell(
                          onTap: () => Navigator.pop(context),
                          child:
                              const Icon(Icons.arrow_back, color: Colors.black),
                        ),*/
                        const SizedBox(width: 8),
                        Text(
                            "Chapter ${chapterCount.length == 1 ? "0$chapterCount" : chapterCount}",
                            style: AppTextStyles.title),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
      
                  /// Duration Grid
                  Container(
                    key: syllabusController.chapterdetailsKey,
                    height: 200,
                    width: 380,
                    decoration: BoxDecoration(
                        color: TColors.sandal,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: TColors.grey)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 15, left: 15),
                              child: Text(
                                chapter.courseChapterName,
                                style: AppTextStyles.heading,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _DurationCard(
                              imagePath: TImages.theory,
                              label: "Theory Class",
                              value:
                                  "${chapter.courseChapterTheoryHours ?? 0} Hrs",
                            ),
                            const SizedBox(width: 8),
                            _DurationCard(
                              imagePath: TImages.practical,
                              label: "Practical Class",
                              value:
                                  "${chapter.courseChapterPracticalHours ?? 0} Hrs",
                            ),
                            const SizedBox(width: 8),
                          ],
                        ),
                      ],
                    ),
                  ),
      
                  const SizedBox(height: 20),
      
                  /// Sections & Topics (Always Expanded)
                  ...syllabusController.chapterDetailList.value!.first.sections
                      .map(
                    (section) => Container(
                      margin: const EdgeInsets.only(bottom: TSizes.md),
                      padding: const EdgeInsets.all(TSizes.md),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: TColors.grey)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          /// Section Title
                          Text(
                            section.sectionName,
                            style: GoogleFonts.prompt(
                                color: TColors.primary,
                                fontWeight: FontWeight.bold,
                                fontSize: 18),
                          ),
                          const SizedBox(height: 10),
      
                          /// Topics (always visible)
                          /* Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: section.topics
                                .map(
                                  (topic) => Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 6.0),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.circle,
                                            size: 8, color: TColors.primary),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(topic.topicName,
                                              style: AppTextStyles.subheading),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                .toList(),
                          ),*/
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: section.topics
                                .map(
                                  (topic) => Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 6.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        // Row for bullet + topic name
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const Icon(Icons.circle,
                                                size: 10, color: TColors.primary),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Text(
                                                topic.topicName,
                                                style: AppTextStyles.heading,
                                              ),
                                            ),
                                          ],
                                        ),
                                        // Description aligned under the name (not under the bullet)
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left:
                                                  16.0), // indent same as text start
                                          child: Text(
                                              topic.topicdescription ?? "",
                                              style: GoogleFonts.prompt(
                                                  fontWeight: FontWeight.w500)),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                .toList(),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}

/// Small reusable widget for duration
class _DurationCard extends StatelessWidget {
  final String imagePath;
  final String label;
  final String value;

  const _DurationCard({
    Key? key,
    required this.imagePath,
    required this.label,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: TColors.grey.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            imagePath,
            width: 30,
            height: 30,
            fit: BoxFit.contain,
          ),
          const SizedBox(height: 6),
          Text(
            label,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: TColors.black,
            ),
          ),
        ],
      ),
    );
  }
}
