// import 'package:eapl_student_app/utils/constants/path_provider.dart';
// import 'package:eapl_student_app/utils/validators/validation.dart';
//
// import '../../../controllers/side_drawer_controller/refferal_controller.dart';
//
// class ReferralPage extends StatelessWidget {
//   final ReferralController controller = Get.put(ReferralController());
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: const SideMenuBar(),
//       appBar: const CustomAppBar(),
//       body: Obx(
//         () => SingleChildScrollView(
//           padding: const EdgeInsets.all(20.0),
//           child: controller.isLoading.value
//               ? Center(
//                   child: TAnimationLoaderWidget(
//                     text: "Loading...",
//                     animation: TImages.pencilAnimation,
//                   ),
//                 )
//               : Form(
//                   key: controller.referralFormKey,
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "Referral",
//                             style: Theme.of(context)
//                                 .textTheme
//                                 .headlineMedium
//                                 ?.copyWith(fontWeight: FontWeight.bold),
//                           ),
//                           TextButton.icon(
//                             onPressed: controller.fetchContacts,
//                             icon: Icon(Icons.sync, color: Colors.blueAccent),
//                             label: Text(
//                               "Sync Contacts",
//                               style: TextStyle(color: Colors.blueAccent),
//                             ),
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 20),
//                       TextFormField(
//                         validator: (value) =>
//                             TValidator.validateEmptyField("Name", value),
//                         controller: controller.nameController,
//                         decoration: InputDecoration(
//                           labelText: "Full Name",
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10.0),
//                           ),
//                           prefixIcon: Icon(
//                             Icons.person,
//                             color: Colors.black,
//                           ),
//                         ),
//                       ),
//                       const SizedBox(height: 15),
//                       TextFormField(
//                         maxLength: 10,
//                         validator: (value) =>
//                             TValidator.validatePhoneNumber(value),
//                         controller: controller.mobileController,
//                         keyboardType: TextInputType.phone,
//                         decoration: InputDecoration(
//                           counterText: '',
//                           labelText: "Mobile Number",
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10.0),
//                           ),
//                           prefixIcon: Icon(Icons.phone, color: Colors.black),
//                         ),
//                       ),
//                       const SizedBox(height: 30),
//                       SizedBox(
//                         width: double.infinity,
//                         child: ElevatedButton(
//                           onPressed: controller.addReferral,
//                           style: ElevatedButton.styleFrom(
//                             padding: EdgeInsets.symmetric(vertical: 15),
//                             textStyle: TextStyle(fontSize: 16),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(10.0),
//                             ),
//                           ),
//                           child: Text("Refer Now"),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//         ),
//       ),
//     );
//   }
// }
import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../utils/constants/text_strings.dart';
import '../../../controllers/side_drawer_controller/refferal_controller.dart';

class ReferralPage extends StatefulWidget {
  @override
  State<ReferralPage> createState() => _ReferralPageState();
}

class _ReferralPageState extends State<ReferralPage> {
  final ReferralController controller = Get.put(ReferralController());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.fetchContacts();
    Future.delayed(Duration.zero, () {
      Get.find<ReferralController>().resetSearch();
    });

    /// 👇 Listen to loading changes
    ever(controller.isLoading, (loading) {
      if (loading == false &&
          controller.filteredContacts.isNotEmpty &&
          !controller.isReferrelTouron.value) {
        _showTourOnce(context);
      }
    });
  }

  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.referreltour) ?? false;

      if (!controller.isReferrelTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 900));
        await controller.ReferrelTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.referreltour, true);
        controller.isReferrelTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) => SafeArea(
      child: Scaffold(
        body: Container(
          child: Column(
            children: [
              const CustomHeader(title: "Referrels"),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Obx(() => controller.isLoading.value
                          ? const Center(
                              child: TAnimationLoaderWidget(
                                text: "Loading...",
                                animation: TImages.pencilAnimation,
                              ),
                            )
                          : Padding(
                              padding: const EdgeInsets.all(20.0),
                              child: Form(
                                key: controller.referralFormKey,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    /*Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "Refer Your Friend",
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleMedium
                                              ?.copyWith(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 20),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: TextButton(
                                            key: controller
                                                .selectallKey, // ✅ tutorial key for Select All
                                            onPressed: controller.toggleSelectAll,
                                            style: TextButton.styleFrom(
                                              elevation:
                                                  4, // controls the shadow intensity
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 14, vertical: 8),
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        8), // optional
                                              ),
                                            ),
                                            child: Icon(
                                              !controller.selectAll.value
                                                  ? Icons.checklist
                                                  : Icons.check_circle,
                                              color: controller.selectAll.value
                                                  ? Colors.green
                                                  : Colors.grey,
                                              size: 35,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),*/
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Refer Your Friend",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleMedium
                                                  ?.copyWith(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 20,
                                                  ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: TextButton(
                                                key: controller.selectallKey,
                                                onPressed:
                                                    controller.toggleSelectAll,
                                                style: TextButton.styleFrom(
                                                  elevation: 4,
                                                  padding:
                                                      const EdgeInsets.symmetric(
                                                          horizontal: 14,
                                                          vertical: 8),
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(8),
                                                  ),
                                                ),
                                                child: Icon(
                                                  !controller.selectAll.value
                                                      ? Icons.checklist
                                                      : Icons.check_circle,
                                                  color:
                                                      controller.selectAll.value
                                                          ? Colors.green
                                                          : Colors.grey,
                                                  size: 35,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            Image.asset(
                                              TImages.coin, // your coin image
                                              width: 25,
                                              height: 25,
                                              fit: BoxFit.contain,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              "Get a coin",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.copyWith(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 18,
                                                  ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 20),
                                    Container(
                                      key: controller.referrelsearchKey,
                                      height: 60,
                                      width: 350,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border:
                                            Border.all(color: TColors.primary),
                                        color: Colors.white,
                                      ),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(12),
                                        child: TextFormField(
                                          onChanged: controller.onSearchChanged,
                                          decoration: const InputDecoration(
                                            hintText: "Search by name or number",
                                            hintStyle: TextStyle(
                                                fontSize: 18, color: Colors.grey),
                                            prefixIcon: Icon(Icons.search,
                                                color: Colors.grey),
                                            border: InputBorder.none,
                                            enabledBorder: InputBorder.none,
                                            focusedBorder: InputBorder.none,
                                            errorBorder: InputBorder.none,
                                            disabledBorder: InputBorder.none,
                                            focusedErrorBorder: InputBorder.none,
                                            contentPadding: EdgeInsets.symmetric(
                                                vertical: 18, horizontal: 12),
                                            filled: true,
                                            fillColor: Colors
                                                .white, // optional: keep white background
                                          ),
                                        ),
                                      ),
                                    ),
                                    Obx(() {
                                      final List<Map<String, String>> contacts =
                                          controller.filteredContacts;
                                      final RxSet<int> selected = controller.selectedIndexes;
      
                                      return controller.isLoading.value
                                          ? const Center(
                                              child: CircularProgressIndicator())
                                          : contacts.isEmpty
                                              ? const Center(
                                                  child: Text(
                                                      "No contact synced yet"))
                                              : Column(
                                                  children: [
                                                    ListView.builder(
                                                      shrinkWrap:
                                                          true, // ✅ Important
                                                      physics:
                                                          const NeverScrollableScrollPhysics(), // ✅ Disable internal scroll
                                                      itemCount: contacts.length,
                                                      itemBuilder:
                                                          (context, index) {
                                                        final Map<String, String> contact =
                                                            contacts[index];
      
                                                        return GestureDetector(
                                                          key: index == 0
                                                              ? controller
                                                                  .selectKey
                                                              : null, // ✅ tutorial key for first contact
                                                          onTap: () => controller
                                                              .toggleContactSelection(
                                                                  index),
                                                          child: Obx(() {
                                                            final bool isSelected =
                                                                controller
                                                                    .selectedIndexes
                                                                    .contains(
                                                                        index);
                                                            return Container(
                                                              margin:
                                                                  const EdgeInsets
                                                                      .symmetric(
                                                                vertical: 6,
                                                              ),
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(12),
                                                              decoration:
                                                                  BoxDecoration(
                                                                color:
                                                                    Colors.white,
                                                                border: Border.all(
                                                                    color: TColors
                                                                        .grey),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12),
                                                              ),
                                                              child: Row(
                                                                children: [
                                                                  Expanded(
                                                                    child: Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                          contact['name'] ??
                                                                              '',
                                                                          style: GoogleFonts
                                                                              .prompt(
                                                                            fontSize:
                                                                                16,
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            color:
                                                                                TColors.primary,
                                                                          ),
                                                                        ),
                                                                        const SizedBox(
                                                                            height:
                                                                                4),
                                                                        Text(
                                                                          contact['number'] ??
                                                                              '',
                                                                          style: GoogleFonts
                                                                              .prompt(
                                                                            fontSize:
                                                                                14,
                                                                            color:
                                                                                Colors.black,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Icon(
                                                                    isSelected
                                                                        ? Icons
                                                                            .check_circle
                                                                        : Icons
                                                                            .circle_outlined,
                                                                    color: isSelected
                                                                        ? Colors
                                                                            .green
                                                                        : Colors
                                                                            .grey,
                                                                  ),
                                                                ],
                                                              ),
                                                            );
                                                          }),
                                                        );
                                                      },
                                                    ),
                                                  ],
                                                );
                                    })
                                  ],
                                ),
                              ),
                            )),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        /* floatingActionButton: Obx(() {
          final hasSelection = controller.selectedIndexes.isNotEmpty;
          return hasSelection
              ? FloatingActionButton(
                  backgroundColor: TColors.primary,
                  onPressed:
                      hasSelection ? controller.submitSelectedContactsBulk : null,
                  child: Image.asset(
                    'assets/icon/refer.png', // update this path to match your project structure
                    height: 24,
                    width: 24,
                    color:
                        Colors.white, // optional: tint image white like the icon
                  ),
                  tooltip: "Submit Selected Contacts",
                )
              : Container();
        }),*/
        floatingActionButton: Obx(() {
          final bool hasSelection = controller.selectedIndexes.isNotEmpty;
          return hasSelection
              ? Container(
                  width: 130, // ✅ make it wider to fit both text and icon
                  height: 56,
                  child: FloatingActionButton(
                    backgroundColor: TColors.primary,
                    onPressed: hasSelection
                        ? controller.submitSelectedContactsBulk
                        : null,
                    tooltip: "Submit Selected Contacts",
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "Refer ",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        Image.asset(
                          'assets/icon/refer.png',
                          height: 25,
                          width: 25,
                          color: Colors.white,
                          fit: BoxFit.contain,
                        ),
                      ],
                    ),
                  ),
                )
              : const SizedBox.shrink();
        }),
      ),
    );
}
