import 'package:eapl_student_app/features/personalization/models/daily_streak_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/sizes.dart';

/// custom containers for daily streak chapter
class ContainerForDailyStreak extends StatelessWidget {
  const ContainerForDailyStreak({
    super.key,
    required this.backgroundColor,
    required this.chapterNumber,
    required this.onTap,
    required this.dailyModel,
  });

  final DailyAttendanceTopicsModel dailyModel;
  final Color backgroundColor;
  final String chapterNumber;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 10.0,
        child: Container(
          padding: const EdgeInsets.all(TSizes.sm),
          decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(10.0)),
          child: Row(
            children: [
              Text(
                chapterNumber.length == 1 ? "0$chapterNumber" : chapterNumber,
                style: Theme.of(context)
                    .textTheme
                    .headlineLarge!
                    .apply(color: TColors.importantText),
              ),
              const SizedBox(width: TSizes.xs),
              const VerticalDivider(color: TColors.darkerGrey, width: 0.5),
              const SizedBox(width: TSizes.sm),
              /*Expanded(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: dailyModel.topics.length,
                  itemBuilder: (BuildContext context, int index) {
                    final topic = dailyModel.topics[index];
                    print("88888888888888888: $topic");
                    if (topic == '') {
                      return SizedBox();
                    } else {
                      return buildTopics(context, topic!);
                    }
                  },
                ),
              ),*/
              Expanded(
                child: ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: dailyModel.topics.length,
                  itemBuilder: (BuildContext context, int index) {
                    final topic = dailyModel.topics[index];
                    if (topic == '') {
                      return SizedBox();
                    } else {
                      return buildTopics(context, topic!);
                    }
                  },
                ),
              ),

              const VerticalDivider(color: TColors.darkerGrey, width: 0.5),

              ///  Attendance Image
              SizedBox(width: TSizes.xs),
              SvgPicture.asset(
                  dailyModel.attendance == 'P'
                      ? TImages.present
                      : dailyModel.attendance == 'A'
                          ? TImages.absent
                          : TImages.leave,
                  width: 50,
                  height: 50),
            ],
          ),
        ),
      ),
    );
  }

  Row buildTopics(BuildContext context, String topics) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          // flex: 1,
          child: Text(
            topics.isEmpty ? '---' : topics,
            style: Theme.of(context)
                .textTheme
                .bodySmall!
                .apply(color: TColors.black),
          ),
        ),

        /// Theory icon
        Row(
          children: [
            buildTAndPIcon(context, 'T', TColors.primary),
            buildTAndPIcon(context, 'P', TColors.importantText),
          ],
        ),

        /// Practical Icon
      ],
    );
  }

  Container buildTAndPIcon(
      BuildContext context, String value, Color backgroundColor) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: TSizes.sm),
      padding: EdgeInsets.all(TSizes.xs),
      decoration: BoxDecoration(color: backgroundColor, shape: BoxShape.circle),
      child: Text(
        value,
        style: Theme.of(context)
            .textTheme
            .labelSmall!
            .apply(color: TColors.white, fontWeightDelta: 2),
      ),
    );
  }
}
