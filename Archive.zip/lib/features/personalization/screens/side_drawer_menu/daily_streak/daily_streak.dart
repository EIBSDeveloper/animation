import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/attendance_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../common/widget/background/background_theme.dart';
import '../../../../../common/widget/course/course_detail_card.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../controllers/side_drawer_controller/course_controller.dart';
import 'custom_daily_streak_container.dart';

class DailyStreak extends StatelessWidget {
  const DailyStreak({super.key});
  @override
  Widget build(BuildContext context) {
    final courseController = Get.put(CourseController());

    final controller = Get.put(AttendanceController());
    /*WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      courseController.fetchCourses();

      controller.fetchDailyStreakController(
          courseId: courseController
              .coursesList[courseController.courseAttendanceIndex.value]
              .courseSno
              .toString());
    });*/
    Future.microtask(() async {
      await courseController.fetchCourses();

      /// Ensure the list is not empty before accessing
      if (courseController.coursesList.isNotEmpty) {
        await controller.fetchDailyStreakController(
          courseId: courseController
              .coursesList[courseController.courseAttendanceIndex.value]
              .courseSno
              .toString(),
        );
      }
    });

    /*return Scaffold(
      drawer: const SideMenuBar(),
      appBar: const CustomAppBar(),
      body: OurBackgroundTheme(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    SizedBox(
                      width: THelperFunctions.screenWidth(),
                      height: 40,
                      child: ListView.separated(
                        itemCount: courseController.coursesList.length,
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                        separatorBuilder: (BuildContext context, int index) =>
                            SizedBox(width: 10),
                        itemBuilder: (_, index) {
                          return InkWell(
                            onTap: () {
                              courseController.dailyStreakIndex.value = index;

                              print(
                                  "index $index -- dailyStreakIndex :${courseController.dailyStreakIndex.value}");
                              controller.fetchDailyStreakController(
                                  courseId: courseController
                                      .coursesList[courseController
                                          .dailyStreakIndex.value]
                                      .courseSno
                                      .toString());
                            },
                            child: Obx(
                              () => Container(
                                width: 200,
                                decoration: BoxDecoration(
                                    color: courseController
                                                .dailyStreakIndex.value ==
                                            index
                                        ? TColors.classCompleted
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(2),
                                    border: Border.all(color: TColors.grey)),
                                padding: const EdgeInsets.all(2),
                                margin: const EdgeInsets.all(TSizes.xs),
                                child: Center(
                                  child: Text(
                                    courseController
                                        .coursesList[index].courseName,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: courseController
                                                    .dailyStreakIndex.value ==
                                                index
                                            ? TColors.white
                                            : Colors.black),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Obx(
                () => Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ///================== Course Title Card====================///
                    CourseDetailsCard(
                        courseModel: courseController.coursesList[
                            courseController.dailyStreakIndex.value]),

                    const SizedBox(height: TSizes.xs),
                    Row(
                      children: [
                        Text(
                          "Start Date : ",
                          style: Theme.of(context).textTheme.labelLarge,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          (courseController
                                      .coursesList[courseController
                                          .dailyStreakIndex.value]
                                      .startDate ??
                                  "--")
                              .toString(),
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .apply(color: TColors.primary),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          "End Date   : ",
                          style: Theme.of(context).textTheme.labelLarge,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          (courseController
                                      .coursesList[courseController
                                          .dailyStreakIndex.value]
                                      .endDate ??
                                  "--")
                              .toString(),
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .apply(color: TColors.primary),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                    const SizedBox(height: TSizes.sm),
                  ],
                ),
              ),
              Obx(
                () {
                  if (controller.isDialogLoading.value == true) {
                    return const TAnimationLoaderWidget(
                      text: "Loading...",
                      animation: TImages.pencilAnimation,
                    );
                  }
                  if (controller.dailyAttendanceList.isEmpty) {
                    return const Center(
                        child: Text("There is No Class Details"));
                  }
                  return GlassyContainer(
                    // height: THelperFunctions.screenHeight() / 1.8,
                    child: Column(children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text("Days",
                              style: Theme.of(context).textTheme.bodyLarge),
                          Text("Topics Covered",
                              style: Theme.of(context).textTheme.bodyLarge),
                          Text("Attendance",
                              style: Theme.of(context).textTheme.bodyLarge),
                        ],
                      ),
                      ListView.separated(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: controller.dailyAttendanceList.length,
                        itemBuilder: (context, index) {
                          final attendance =
                              controller.dailyAttendanceList[index];
                          // if (attendance.topics.isNotEmpty) {
                          return ContainerForDailyStreak(
                            chapterNumber: "${index + 1}",
                            backgroundColor: TColors.white,
                            onTap: () {},
                            dailyModel: attendance,
                          );
                          */ /*} else {
                            SizedBox();
                          }*/ /*
                        },
                        separatorBuilder: (context, index) {
                          return SizedBox(height: 2);
                        },
                      )
                    ]),
                  );
                },
              )
            ],
          ),
        ),
      ),
    );*/
    return SafeArea(
      child: Scaffold(
        /*drawer: const SideMenuBar(),
        appBar: const CustomAppBar(),*/
        body: OurBackgroundTheme(
          // child: Column(
          //   mainAxisSize: MainAxisSize.max,
          //   children: [
          //     /// ===== Horizontal Course List ===== ///
          //     /* SingleChildScrollView(
          //       scrollDirection: Axis.horizontal,
          //       child: Row(
          //         children: [
          //           SizedBox(
          //             width: THelperFunctions.screenWidth(),
          //             height: 40,
          //             child: ListView.separated(
          //               itemCount: courseController.coursesList.length,
          //               scrollDirection: Axis.horizontal,
          //               shrinkWrap: true,
          //               physics: const BouncingScrollPhysics(),
          //               separatorBuilder: (BuildContext context, int index) =>
          //                   const SizedBox(width: 10),
          //               itemBuilder: (_, index) {
          //                 return InkWell(
          //                   onTap: () {
          //                     courseController.dailyStreakIndex.value = index;
          //                     controller.fetchDailyStreakController(
          //                       courseId: courseController
          //                           .coursesList[
          //                               courseController.dailyStreakIndex.value]
          //                           .courseSno
          //                           .toString(),
          //                     );
          //                   },
          //                   child: Obx(
          //                     () => Container(
          //                       width: 200,
          //                       decoration: BoxDecoration(
          //                         color:
          //                             courseController.dailyStreakIndex.value ==
          //                                     index
          //                                 ? TColors.classCompleted
          //                                 : Colors.white,
          //                         borderRadius: BorderRadius.circular(2),
          //                         border: Border.all(color: TColors.grey),
          //                       ),
          //                       padding: const EdgeInsets.all(2),
          //                       margin: EdgeInsets.all(TSizes.xs),
          //                       child: Center(
          //                         child: Text(
          //                           courseController
          //                               .coursesList[index].courseName,
          //                           overflow: TextOverflow.ellipsis,
          //                           style: TextStyle(
          //                             color: courseController
          //                                         .dailyStreakIndex.value ==
          //                                     index
          //                                 ? TColors.white
          //                                 : Colors.black,
          //                           ),
          //                         ),
          //                       ),
          //                     ),
          //                   ),
          //                 );
          //               },
          //             ),
          //           ),
          //         ],
          //       ),
          //     ),*/
          //     SingleChildScrollView(
          //       scrollDirection: Axis.horizontal,
          //       child: Obx(
          //         () => Row(
          //           children: List.generate(
          //             courseController.coursesList.length,
          //             (index) => GestureDetector(
          //               onTap: () {
          //                 courseController.dailyStreakIndex.value = index;
          //                 controller.fetchDailyStreakController(
          //                   courseId: courseController
          //                       .coursesList[index].courseSno
          //                       .toString(),
          //                 );
          //               },
          //               child: Container(
          //                 width: 200,
          //                 margin: const EdgeInsets.symmetric(horizontal: 5),
          //                 decoration: BoxDecoration(
          //                   color:
          //                       courseController.dailyStreakIndex.value == index
          //                           ? TColors.classCompleted
          //                           : Colors.white,
          //                   borderRadius: BorderRadius.circular(2),
          //                   border: Border.all(color: TColors.grey),
          //                 ),
          //                 child: Center(
          //                   child: Text(
          //                     courseController.coursesList[index].courseName,
          //                     overflow: TextOverflow.ellipsis,
          //                     style: TextStyle(
          //                       color: courseController.dailyStreakIndex.value ==
          //                               index
          //                           ? TColors.white
          //                           : Colors.black,
          //                     ),
          //                   ),
          //                 ),
          //               ),
          //             ),
          //           ),
          //         ),
          //       ),
          //     ),
          //
          //     /// ===== Course Details (Fixed Header) ===== ///
          //     Expanded(
          //       child: SingleChildScrollView(
          //         child: Column(
          //           children: [
          //             Obx(() => Column(
          //                   crossAxisAlignment: CrossAxisAlignment.start,
          //                   children: [
          //                     CourseDetailsCard(
          //                       courseModel: courseController.coursesList[
          //                           courseController.dailyStreakIndex.value],
          //                     ),
          //                     const SizedBox(height: TSizes.xs),
          //                     Row(
          //                       children: [
          //                         Text("Start Date : ",
          //                             style:
          //                                 Theme.of(context).textTheme.labelLarge),
          //                         Text(
          //                           (courseController
          //                                       .coursesList[courseController
          //                                           .dailyStreakIndex.value]
          //                                       .startDate ??
          //                                   "--")
          //                               .toString(),
          //                           style: Theme.of(context)
          //                               .textTheme
          //                               .bodyLarge!
          //                               .apply(color: TColors.primary),
          //                         ),
          //                       ],
          //                     ),
          //                     Row(
          //                       children: [
          //                         Text("End Date   : ",
          //                             style:
          //                                 Theme.of(context).textTheme.labelLarge),
          //                         Text(
          //                           (courseController
          //                                       .coursesList[courseController
          //                                           .dailyStreakIndex.value]
          //                                       .endDate ??
          //                                   "--")
          //                               .toString(),
          //                           style: Theme.of(context)
          //                               .textTheme
          //                               .bodyLarge!
          //                               .apply(color: TColors.primary),
          //                         ),
          //                       ],
          //                     ),
          //                     const SizedBox(height: TSizes.sm),
          //                   ],
          //                 )),
          //             Obx(() {
          //               if (controller.isDialogLoading.value == true) {
          //                 return TAnimationLoaderWidget(
          //                   text: "Loading...",
          //                   animation: TImages.pencilAnimation,
          //                 );
          //               }
          //               if (controller.dailyAttendanceList.isEmpty) {
          //                 return const Center(
          //                     child: Text("There is No Class Details"));
          //               }
          //               return Container(
          //                 margin: const EdgeInsets.only(bottom: 8),
          //                 decoration: BoxDecoration(
          //                   color: TColors.lightimportant.withOpacity(0.85),
          //                   borderRadius: BorderRadius.circular(5),
          //                   border: Border.all(
          //                       color: TColors.importantText.withOpacity(0.85)),
          //                 ),
          //                 child: Column(
          //                   children: [
          //                     Row(
          //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
          //                       children: [
          //                         Text("Days",
          //                             style:
          //                                 Theme.of(context).textTheme.bodyLarge),
          //                         Text("Topics Covered",
          //                             style:
          //                                 Theme.of(context).textTheme.bodyLarge),
          //                         Text("Attendance",
          //                             style:
          //                                 Theme.of(context).textTheme.bodyLarge),
          //                       ],
          //                     ),
          //                     const SizedBox(height: 5),
          //                     ...List.generate(
          //                         controller.dailyAttendanceList.length, (index) {
          //                       final attendance =
          //                           controller.dailyAttendanceList[index];
          //                       return Padding(
          //                         padding: const EdgeInsets.only(bottom: 5),
          //                         child: ContainerForDailyStreak(
          //                           chapterNumber: "${index + 1}",
          //                           backgroundColor: TColors.white,
          //                           onTap: () {},
          //                           dailyModel: attendance,
          //                         ),
          //                       );
          //                     })
          //
          //                     /// Scrollable List only
          //                   ],
          //                 ),
          //               );
          //             }),
          //           ],
          //         ),
          //       ),
          //     ),
          //   ],
          // ),
          child: Obx(() => SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// 🔸 Horizontal Course Selector
                    SizedBox(
                      height: 30,
                      child: Obx(() => ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: courseController.coursesList.length,
                            separatorBuilder: (context, index) =>
                                const SizedBox(width: 10),
                            itemBuilder: (context, index) {
                              final course = courseController.coursesList[index];
                              final isSelected =
                                  courseController.dailyStreakIndex.value ==
                                      index;
      
                              return GestureDetector(
                                onTap: () async {
                                  courseController.dailyStreakIndex.value = index;
                                  controller.isDialogLoading.value = true;
      
                                  await controller.fetchDailyStreakController(
                                    courseId: course.courseSno.toString(),
                                  );
      
                                  controller.isDialogLoading.value = false;
                                },
                                child: Container(
                                  width: 200,
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 8),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? TColors.classCompleted
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(2),
                                    border: Border.all(color: TColors.grey),
                                  ),
                                  child: Center(
                                    child: Text(
                                      course.courseName,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: isSelected
                                            ? TColors.white
                                            : Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          )),
                    ),
      
                    const SizedBox(height: 10),
      
                    /// 🔸 Main Content - Either Loading or Course Data
                    controller.isDialogLoading.value
                        ? const Center(child: CircularProgressIndicator())
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              /// ✅ Course Info Card
                              CourseDetailsCard(
                                courseModel: courseController.coursesList[
                                    courseController.dailyStreakIndex.value],
                              ),
                              const SizedBox(height: 10),
      
                              /// ✅ Start & End Dates
                              Row(
                                children: [
                                  Text("Start Date: ",
                                      style:
                                          Theme.of(context).textTheme.labelLarge),
                                  Text(
                                    courseController
                                            .coursesList[courseController
                                                .dailyStreakIndex.value]
                                            .startDate ??
                                        "--",
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyLarge!
                                        .apply(color: TColors.primary),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Text("End Date: ",
                                      style:
                                          Theme.of(context).textTheme.labelLarge),
                                  Text(
                                    courseController
                                            .coursesList[courseController
                                                .dailyStreakIndex.value]
                                            .endDate ??
                                        "--",
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyLarge!
                                        .apply(color: TColors.primary),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
      
                              /// 🔸 Attendance or Info
                              controller.dailyAttendanceList.isEmpty
                                  ? const Center(
                                      child: Text("There is No Class Details"))
                                  : Container(
                                      margin: const EdgeInsets.only(bottom: 8),
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: TColors.lightimportant
                                            .withOpacity(0.85),
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                            color: TColors.importantText
                                                .withOpacity(0.85)),
                                      ),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              Text("Days",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodyLarge),
                                              Text("Topics Covered",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodyLarge),
                                              Text("Attendance",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodyLarge),
                                            ],
                                          ),
                                          const SizedBox(height: 5),
                                          ...List.generate(
                                            controller.dailyAttendanceList.length,
                                            (index) {
                                              final attendance = controller
                                                  .dailyAttendanceList[index];
                                              return Padding(
                                                padding: const EdgeInsets.only(
                                                    bottom: 5),
                                                child: ContainerForDailyStreak(
                                                  chapterNumber: "${index + 1}",
                                                  backgroundColor: TColors.white,
                                                  onTap: () {},
                                                  dailyModel: attendance,
                                                ),
                                              );
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                            ],
                          ),
                  ],
                ),
              )),
        ),
      ),
    );
  }
}
