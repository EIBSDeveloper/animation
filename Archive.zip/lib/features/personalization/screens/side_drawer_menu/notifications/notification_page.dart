/*

import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/notifications/notification_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../../common/widget/app_bar/appbar.dart';
import '../../../../../common/widget/background/background_theme.dart';

class NotificationPage extends StatelessWidget {
  NotificationPage({super.key});

  final controller = Get.put(NotificationController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        isMenuNeed: false,
      ),
      body: OurBackgroundTheme(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// 🔔 Page Title
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: Text(
                  "🔔 Notifications",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
              ),
            ),

            /// 📜 Notifications List
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: TSizes.md),
                child: Column(
                  children: List.generate(controller.notificationData.length,
                      (index) {
                    final note = controller.notificationData[index];
                    final date = note["date"];
                    final notifications = note["notifications"];

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        /// 🗓️ Date Label
                        Padding(
                          padding: const EdgeInsets.only(top: TSizes.lg),
                          child: Row(
                            children: [
                              const Expanded(child: Divider(thickness: 1)),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: TSizes.sm),
                                child: Text(
                                  date,
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelMedium
                                      ?.copyWith(
                                        fontWeight: FontWeight.w500,
                                        color: TColors.primary,
                                      ),
                                ),
                              ),
                              const Expanded(child: Divider(thickness: 1)),
                            ],
                          ),
                        ),

                        const SizedBox(height: TSizes.sm),

                        /// 🔔 Notification Cards
                        ...List.generate(notifications.length, (i) {
                          final notifi = notifications[i];
                          return Container(
                            margin: const EdgeInsets.only(bottom: TSizes.md),
                            padding: const EdgeInsets.all(TSizes.sm),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: TColors.primary.withOpacity(0.05),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  offset: const Offset(1, 2),
                                  blurRadius: 4,
                                )
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                /// Title Row
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(Icons.notifications_active_outlined,
                                        color: TColors.primary, size: 20),
                                    const SizedBox(width: TSizes.sm),
                                    Expanded(
                                      child: Text(
                                        notifi["title"],
                                        maxLines: 5,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyMedium
                                            ?.copyWith(
                                                fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  ],
                                ),

                                const SizedBox(height: TSizes.xs),

                                /// Time
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      notifi["time"],
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelSmall
                                          ?.copyWith(color: TColors.red),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    );
                  }),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
*/

import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/notifications/notification_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/text_strings.dart';

class NotificationPage extends StatelessWidget {
  NotificationPage({super.key});

  final controller = Get.put(NotificationController());
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown =
          GetStorage().read(TTexts.notificationtour) ?? false;

      if (!controller.isNotifyTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 600));
        await controller.NotificationTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.notificationtour, true);
        controller.isNotifyTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Notifications"),
        ),
        body: RefreshIndicator(
          onRefresh: () {
            return controller.fetchNotificationList();
          },
          child: Container(
            margin: EdgeInsets.only(left: 10, right: 10),
            child: Obx(() {
              if (controller.isNotifyLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }
      
              if (controller.notificationData.isEmpty) {
                return const Center(child: Text("No notifications found"));
              }
      
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// 🔔 Page Title
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      /// Read All Icon
                      Obx(() => TextButton(
                            key: controller.readAllKey,
                            onPressed: controller.isreadallLoading.value ||
                                    controller.allRead.value
                                ? null
                                : () async {
                                    print("👆 User clicked 'Read All' button");
                                    await controller.notificationreadAll();
                                    await controller
                                        .fetchNotificationList(); // refresh list
                                  },
                            child: controller.isreadallLoading.value
                                ? const SizedBox(
                                    height: 18,
                                    width: 18,
                                    child:
                                        CircularProgressIndicator(strokeWidth: 2),
                                  )
                                : Text(
                                    "Clear All",
                                    style: GoogleFonts.prompt(
                                      color: controller.allRead.value
                                          ? Colors.grey // after "read all"
                                          : TColors.red, // before "read all"
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ))
                    ],
                  ),
      
                  /// 📜 Notifications List
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: TSizes.md),
                      child: Column(
                        children: List.generate(
                          controller.notificationData.length,
                          (index) {
                            final note = controller.notificationData[index];
                            final date = note["date"];
                            final notifications = note["notifications"];
      
                            print(
                                "📅 Rendering date group: $date with ${notifications.length} notifications");
      
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                /// 🗓️ Date Label
                                Padding(
                                  padding: const EdgeInsets.only(top: TSizes.lg),
                                  child: Row(
                                    children: [
                                      const Expanded(
                                          child: Divider(thickness: 1)),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: TSizes.sm),
                                        child: Text(date,
                                            style: GoogleFonts.prompt(
                                                color: TColors.primary,
                                                fontSize: 14,
                                                fontWeight: FontWeight.w500)),
                                      ),
                                      const Expanded(
                                          child: Divider(thickness: 1)),
                                    ],
                                  ),
                                ),
      
                                const SizedBox(height: TSizes.sm),
      
                                /// 🔔 Notification Cards
                                ...List.generate(notifications.length, (i) {
                                  final notifi = notifications[i];
                                  final sno = notifi["sno"] as int?;
                                  final isRead = notifi["isRead"] == true;
      
                                  print(
                                      "🔔 Rendering notification sno=$sno, isRead=$isRead");
      
                                  return Container(
                                    key: index == 0 && i == 0
                                        ? controller
                                            .messageKey // ✅ Only first notification
                                        : null,
                                    margin:
                                        const EdgeInsets.only(bottom: TSizes.md),
                                    padding: const EdgeInsets.all(TSizes.sm),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: TColors.grey),
                                      color: isRead
                                          ? Colors.grey.withAlpha(80)
                                          // ✅ read → grey
                                          : TColors.white, // ❌ unread → highlight
                                      boxShadow: isRead
                                          ? [] // 👉 No shadow for read (grey)
                                          : [],
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        /// Title Row
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const Icon(
                                              Icons.notifications_active_outlined,
                                              color: TColors.primary,
                                              size: 20,
                                            ),
                                            const SizedBox(width: TSizes.sm),
      
                                            /// Notification text
                                            Expanded(
                                              child: Text(
                                                  notifi["notification_content"] ??
                                                      "",
                                                  maxLines: 5,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: GoogleFonts.prompt(
                                                      color: Colors.black,
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 16)),
                                            ),
      
                                            /// ✅ Single Read Icon
                                            Obx(() {
                                              final isLoading = controller
                                                      .isReadLoadingMap[sno] ??
                                                  false;
      
                                              if (sno == null) {
                                                print(
                                                    "⚠️ Skipping notification without sno");
                                                return const SizedBox.shrink();
                                              }
      
                                              return IconButton(
                                                key: i == 0 && index == 0
                                                    ? controller.readKey
                                                    : null, // optional
                                                onPressed: (isRead || isLoading)
                                                    ? null
                                                    : () async {
                                                        print(
                                                            "👆 Marking sno=$sno as read");
                                                        await controller
                                                            .notificationreadById(
                                                                sno);
                                                      },
                                                icon: isLoading
                                                    ? const SizedBox(
                                                        width: 16,
                                                        height: 16,
                                                        child:
                                                            CircularProgressIndicator(
                                                                strokeWidth: 2),
                                                      )
                                                    : Icon(
                                                        isRead
                                                            ? Icons
                                                                .mark_chat_read // ✅ already read
                                                            : Icons
                                                                .markunread, // 🔔 unread
                                                        size: 20,
                                                        color: isRead
                                                            ? Colors.grey
                                                            : TColors.primary,
                                                      ),
                                              );
                                            }),
                                          ],
                                        ),
      
                                        const SizedBox(height: TSizes.xs),
      
                                        /// Formatted Time + Time Ago Row
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              notifi["time_ago"] ?? "",
                                              style: GoogleFonts.prompt(
                                                  color: Colors.red,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14),
                                            ),
                                            Text(
                                              notifi["formated_time"] ?? "",
                                              style: GoogleFonts.prompt(
                                                  color: Colors.grey,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                  )
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
