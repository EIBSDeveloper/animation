import 'package:eapl_student_app/common/widget/app_bar/appbar_controller.dart';
import 'package:eapl_student_app/features/apptour/side/notification/notificationtour.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/http/api_constants.dart';
import '../../../../../utils/http/http_client.dart';
import '../../../../../utils/loaders/loaders.dart';

class NotificationController extends GetxController {
  var isNotifyLoading = false.obs;

  /// List of notifications grouped by date
  var notificationData = <Map<String, dynamic>>[].obs;

  @override
  void onInit() {
    super.onInit();
    print("NotificationController initialized");
    fetchNotificationList(); // fetch automatically on init
  }

  /// Fetch notifications from API
  Future<void> fetchNotificationList() async {
    try {
      isNotifyLoading.value = true;
      final customerId = GetStorage().read(TTexts.userID);
      print("Fetching notifications for customerId: $customerId");

      if (customerId == null) {
        TSnackbar.errorSnackbar(
            title: "Error", message: "Customer ID not found");
        return;
      }

      final body = {"customer_id": customerId};
      print("Request Body: $body");

      final response = await THttpHelper.post(APIConstants.notifications, body);
      print("Notification API response: $response");

      if (response != null && response["status"] == 200) {
        final flatList = List<Map<String, dynamic>>.from(response["data"]);
        final Map<String, List<Map<String, dynamic>>> grouped = {};

        for (var notif in flatList) {
          final date = notif["formated_date"] ?? "Unknown";
          notif["title"] = notif["notification_content"];
          notif["time"] = notif["formated_time"];
          notif["timeAgo"] = notif["time_ago"];
          notif["isRead"] = notif["status"] == 1;

          if (!grouped.containsKey(date)) grouped[date] = [];
          grouped[date]!.add(notif);
        }

        notificationData.value = grouped.entries
            .map((e) => {"date": e.key, "notifications": e.value})
            .toList();

        print("Grouped notifications: ${notificationData.length} dates");
      } else {
        notificationData.clear();
        TSnackbar.errorSnackbar(
            title: "Error",
            message: response["message"] ?? "Something went wrong");
      }
    } catch (e) {
      print("Error in fetchNotificationList: $e");
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    } finally {
      isNotifyLoading.value = false;
    }
  }

  //read notifications
  var isReadLoadingMap = <int, bool>{}.obs;
  Future<void> notificationreadById(int sno) async {
    try {
      print("🔄 Start marking notification sno=$sno as read");
      isReadLoadingMap[sno] = true;

      final customerId = GetStorage().read(TTexts.userID);
      print("📦 customerId from storage = $customerId");

      if (customerId == null) {
        print("❌ No customerId found, stopping...");
        TSnackbar.errorSnackbar(
            title: "Error", message: "Customer ID not found");
        return;
      }

      final body = {"customer_id": customerId};
      print("📤 Sending request to: ${APIConstants.notificationread}/$sno");
      print("📤 Request Body: $body");

      final response =
          await THttpHelper.post("${APIConstants.notificationread}/$sno", body);

      print("📥 API Response: $response");

      if (response != null && response["status"] == 200) {
        print("✅ Notification $sno marked as read on server");

        TSnackbar.successSnackbar(
            title: "Success", message: "Notification marked as read");

        // ✅ Update only that notification in local data
        for (var day in notificationData) {
          for (var n in day["notifications"]) {
            if (n["sno"] == sno) {
              print("📝 Updating local notification sno=$sno as read");
              n["isRead"] = true;
            }
          }
        }
        notificationData.refresh();
        print("🔄 Local notification list refreshed");

        /// 🔥 Refresh appbar count (so badge updates immediately)
        final appbarController = Get.find<AppbarController>();
        await appbarController.fetchPointsDetails();
      } else {
        print("❌ Failed to mark notification $sno as read");
        TSnackbar.errorSnackbar(
            title: "Error",
            message: response?["message"] ?? "Failed to mark read");
      }
    } catch (e) {
      print("💥 Exception while marking notification $sno: $e");
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    } finally {
      isReadLoadingMap[sno] = false;
      print("✅ Finished processing sno=$sno, loader reset");
    }
  }

  //read all notifications
  var isreadallLoading = false.obs;
  var allRead = false.obs; // 🔄 track if all are read

  Future<void> notificationreadAll() async {
    try {
      isreadallLoading.value = true;
      final customerId = GetStorage().read(TTexts.userID);
      print(
          "🔄 Start marking ALL notifications as read for customerId=$customerId");

      if (customerId == null) {
        TSnackbar.errorSnackbar(
            title: "Error", message: "Customer ID not found");
        return;
      }

      final body = {"customer_id": customerId};
      print("📤 Sending request to: ${APIConstants.notificationreadall}");
      print("📤 Request Body: $body");

      final response =
          await THttpHelper.post(APIConstants.notificationreadall, body);
      print("📥 API Response (read all): $response");

      if (response["status"] == 200) {
        print("✅ Successfully marked all notifications as read");
        allRead.value = true; // 🔄 mark all as read
        notificationData.refresh();
        print("🔄 Local notification list refreshed");

        /// 🔥 Refresh appbar count (so badge updates immediately)
        final appbarController = Get.find<AppbarController>();
        await appbarController.fetchPointsDetails();
      } else {
        print(
            "❌ Failed to mark all notifications as read: ${response["message"]}");
      }
    } catch (e) {
      print("🔥 Error in notificationreadAll: $e");
      TSnackbar.errorSnackbar(title: "Error", message: e.toString());
    } finally {
      isreadallLoading.value = false;
      print("🔚 Finished processing read all, loader reset");
    }
  }

  //Notificationtour
  final messageKey = GlobalKey();
  final readKey = GlobalKey();
  final readAllKey = GlobalKey();

  var isNotifyTouron = false.obs;
  Future<void> NotificationTour(BuildContext context) async {
    final targets = NotificationTourList.getTargets(
        messageKey: messageKey, readKey: readKey, readAllKey: readAllKey);

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.notificationtour, true);
        isNotifyTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.notificationtour, true);
        isNotifyTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
