import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/placement_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/placement/placement_history_card.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/placement/placement_job_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/animation_loaders.dart';

class PlacementDetails extends StatelessWidget {
  final placementController = Get.put(PlacementController());
  PlacementDetails({super.key});
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.placementtour) ?? false;

      if (!placementController.isPlacementTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await placementController.PlacementTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.placementtour, true);
        placementController.isPlacementTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);

    return SafeArea(
      child: Scaffold(
        body: Obx(
          () {
            if (placementController.isLoading.value == true) {
              return const TAnimationLoaderWidget(
                text: "Loading...",
                animation: TImages.pencilAnimation,
              );
            }
            if (placementController.placementList.isEmpty) {
              return const Center(
                child: Text("There is No Suitable Job For You"),
              );
            }
            return Column(
              children: [
                CustomHeader(title: "Placement Details"),
                SizedBox(
                  height: 10,
                ),
      
                /// 🔹 Toggle Button Section
                Container(
                  key: placementController.placementtabKey,
                  color: Colors.white,
                  child: Obx(() => Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ToggleButtons(
                            renderBorder: false,
                            fillColor: Colors.transparent,
                            splashColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            isSelected: [
                              !placementController.isSavedJobs.value &&
                                  !placementController.isHistory.value,
                              placementController.isSavedJobs.value,
                              placementController.isHistory.value,
                            ],
                            onPressed: (index) {
                              if (index == 0) {
                                placementController.isSavedJobs.value = false;
                                placementController.isHistory.value = false;
                              } else if (index == 1) {
                                placementController.isSavedJobs.value = true;
                                placementController.isHistory.value = false;
                              } else {
                                placementController.isSavedJobs.value = false;
                                placementController.isHistory.value = true;
      
                                // ✅ Fetch history only if empty
                                if (placementController
                                    .placementhistoryList.isEmpty) {
                                  placementController.fetchPlacementhistory();
                                }
                              }
                            },
                            children: [
                              // Jobs for You
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16),
                                    child: Text(
                                      "Jobs",
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: !placementController
                                                    .isSavedJobs.value &&
                                                !placementController
                                                    .isHistory.value
                                            ? TColors.black
                                            : Colors.grey.shade300,
                                      ),
                                    ),
                                  ),
                                  if (!placementController.isSavedJobs.value &&
                                      !placementController.isHistory.value)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      height: 4,
                                      width: 60,
                                      color: TColors.grey,
                                    ),
                                ],
                              ),
      
                              // Saved Jobs
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16),
                                    child: Text(
                                      "Saved",
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color:
                                            placementController.isSavedJobs.value
                                                ? TColors.black
                                                : Colors.grey.shade300,
                                      ),
                                    ),
                                  ),
                                  if (placementController.isSavedJobs.value)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      height: 4,
                                      width: 60,
                                      color: TColors.grey,
                                    ),
                                ],
                              ),
      
                              // History
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16),
                                    child: Text(
                                      "History",
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: placementController.isHistory.value
                                            ? TColors.black
                                            : Colors.grey.shade300,
                                      ),
                                    ),
                                  ),
                                  if (placementController.isHistory.value)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      height: 4,
                                      width: 60,
                                      color: TColors.grey,
                                    ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      )),
                ),
      
                /// 🔹 Jobs Section
                Expanded(
                  child: Obx(() {
                    final isSavedTab = placementController.isSavedJobs.value;
                    final isHistoryTab = placementController.isHistory.value;
      
                    final jobs = isHistoryTab
                        ? placementController.placementhistoryList
                        : isSavedTab
                            ? placementController.savedJobs
                            : placementController.jobsForYou;
      
                    if (jobs.isEmpty) {
                      return Center(
                        child: Text(
                          isHistoryTab
                              ? "No history jobs"
                              : isSavedTab
                                  ? "No saved jobs"
                                  : "No jobs available",
                          style:
                              const TextStyle(fontSize: 18, color: Colors.grey),
                        ),
                      );
                    }
      
                    return ListView.builder(
                      padding: const EdgeInsets.only(top: 4),
                      itemCount: jobs.length,
                      shrinkWrap: true,
                      physics: const BouncingScrollPhysics(),
                      itemBuilder: (context, index) {
                        if (isHistoryTab) {
                          return HistoryJobCard(
                            placement: jobs[index],
                          );
                        } else {
                          return JobCard(
                            key: index == 0 ? placementController.jobKey : null,
                            placement: jobs[index],
                            index: index,
                          );
                        }
                      },
                    );
                  }),
                )
              ],
            );
          },
        ),
      ),
    );
  }
}
