import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/placement_controller.dart';
import 'package:eapl_student_app/features/personalization/models/placement_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/placement/placementdetails.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class JobCard extends StatefulWidget {
  const JobCard({super.key, required this.placement, required this.index});

  final PlacementModel placement;
  final int index;
  @override
  State<JobCard> createState() => _JobCardState();
}

class _JobCardState extends State<JobCard> {
  bool isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<PlacementController>();
    return InkWell(
      onTap: () {
        Get.to(() => PlacementDetailsPage(placement: widget.placement));
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: TColors.grey)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Job Title + Save Button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(widget.placement.jobRoleName,
                      style: GoogleFonts.prompt(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                ),
                // In JobCard
                Obx(() {
                  final isSaved = widget.placement.jobSaved.value == 1;
                  return InkWell(
                    borderRadius: BorderRadius.circular(50),
                    onTap: () => controller.togglemark(widget.placement.sno),
                    child: Icon(
                      isSaved ? Icons.bookmark : Icons.bookmark_border,
                      color: isSaved ? TColors.primary : Colors.grey,
                      size: 25,
                    ),
                  );
                }),
              ],
            ),

            const SizedBox(height: 20),

            /// Company Name + Expand/Collapse Icon
            Row(
              children: [
                /// Company Name
                Expanded(
                  flex: 3,
                  child: Text(
                    widget.placement.companyName ?? '---',
                    style: GoogleFonts.prompt(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    softWrap: false,
                  ),
                ),

                /// Interview Date
                Expanded(
                  flex: 4,
                  child: Transform.translate(
                    offset: const Offset(-20, 0), // move 8 pixels to the left
                    child: Row(
                      children: [
                        Image.asset(
                          TImages.calender,
                          width: 25,
                          height: 25,
                          fit: BoxFit.contain,
                        ),
                        const SizedBox(width: 5),
                        Flexible(
                          child: Text(
                            DateFormat("dd MMM yyyy").format(
                              DateTime.parse(widget.placement.interviewDate),
                            ),
                            style: GoogleFonts.prompt(
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            softWrap: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                /// Applied Button Indicator
                SizedBox(
                  width: 110, // same width for both buttons
                  height: 36, // same height
                  child: Obx(() {
                    final isApplied = widget.placement.applied.value == 1;

                    return ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            isApplied ? Colors.green : TColors.primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: EdgeInsets.zero, // padding handled by SizedBox
                      ),
                      onPressed: () {
                        // ✅ Navigate to details page instead of applying here
                        Get.to(() =>
                            PlacementDetailsPage(placement: widget.placement));
                      },
                      child: Text(
                        isApplied ? "Applied" : "Apply Now",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    );
                  }),
                ),
              ],
            ),

            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
