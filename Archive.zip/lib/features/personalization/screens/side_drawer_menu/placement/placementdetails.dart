import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/placement_controller.dart';
import 'package:eapl_student_app/features/personalization/models/placement_model.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../../../../../utils/constants/text_strings.dart';

class PlacementDetailsPage extends StatelessWidget {
  final PlacementModel placement;
  final controller = Get.find<PlacementController>();

  PlacementDetailsPage({super.key, required this.placement});
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown =
          GetStorage().read(TTexts.placementdetailtour) ?? false;

      if (!controller.isPlacementdetailTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.PlacementdetailTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.placementdetailtour, true);
        controller.isPlacementdetailTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<PlacementController>();
    return RefreshIndicator(
      onRefresh: () => controller.fetchPlacementDetails(),
      child: SafeArea(
        child: Scaffold(
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                CustomHeader(title: "Placement Details"),
        
                const SizedBox(height: 10),
        
                // Job Details Container
                Container(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      /// Job Title + Bookmark
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              placement.jobRoleName,
                              style: GoogleFonts.prompt(
                                  fontSize: 22, fontWeight: FontWeight.bold),
                            ),
                          ),
                          Obx(() {
                            final isSaved = placement.jobSaved.value == 1;
                            return IconButton(
                              icon: Icon(
                                isSaved ? Icons.bookmark : Icons.bookmark_border,
                                color: isSaved ? TColors.primary : Colors.grey,
                                size: 25,
                              ),
                              onPressed: () =>
                                  controller.togglemark(placement.sno),
                            );
                          }),
                        ],
                      ),
        
                      const SizedBox(height: 8),
        
                      /// Company + Date
                      Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: Text(
                              placement.companyName ?? '---',
                              style: GoogleFonts.prompt(
                                  fontSize: 16, fontWeight: FontWeight.w600),
                            ),
                          ),
                          Expanded(
                            flex: 4,
                            child: Row(
                              children: [
                                Image.asset(
                                  TImages.calender,
                                  width: 25,
                                  height: 25,
                                  fit: BoxFit.contain,
                                ),
                                const SizedBox(width: 5),
                                Flexible(
                                  child: Text(
                                    DateFormat("dd MMM yyyy").format(
                                        DateTime.parse(placement.interviewDate)),
                                    style: GoogleFonts.prompt(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 30),
        
                      _buildDetail(
                        context,
                        TImages.salary,
                        "Salary",
                        "₹ ${NumberFormat.currency(locale: 'en_IN', symbol: '', decimalDigits: 0).format(placement.salary * 12)} PA",
                      ),
                      _buildDetail(
                        context,
                        TImages.vacancy,
                        "Vacancy",
                        placement.vacancyCount.toString().padLeft(2, '0'),
                      ),
                      _buildDetail(
                        context,
                        TImages.interview,
                        "Interview Type",
                        placement.interviewTypeName,
                      ),
                      _buildDetail(
                        context,
                        TImages.address,
                        "Location",
                        placement.companyAddress,
                      ),
        
                      const SizedBox(height: 20),
        
                      /// Apply Button
                      Center(
                        child: Container(
                          key: controller.applyKey,
                          height: 48,
                          width: 150,
                          child: Obx(() => ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: TColors.primary,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 32, vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                onPressed: () async {
                                  if (placement.applied.value == 1 ||
                                      controller.isLoading.value) {
                                    return; // already applied or still loading
                                  }
        
                                  controller.isLoading.value =
                                      true; // start loading
        
                                  bool success =
                                      await controller.applyJob(placement.sno);
        
                                  controller.isLoading.value =
                                      false; // stop loading
        
                                  if (success) {
                                    placement.applied.value =
                                        1; // ✅ immediately update UI
                                    Get.dialog(
                                      Dialog(
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(16),
                                        ),
                                        backgroundColor: Colors.white,
                                        child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Align(
                                                alignment: Alignment.topRight,
                                                child: IconButton(
                                                  icon: const Icon(Icons.close,
                                                      color: Colors.black),
                                                  onPressed: () => Get.back(),
                                                ),
                                              ),
                                              Image.asset(
                                                TImages.applied,
                                                width: 150,
                                                height: 150,
                                                fit: BoxFit.contain,
                                              ),
                                              const SizedBox(height: 20),
                                              Text(
                                                "Successfully Applied!",
                                                textAlign: TextAlign.center,
                                                style: GoogleFonts.prompt(
                                                  fontSize: 22,
                                                  fontWeight: FontWeight.bold,
                                                  color: TColors.primary,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      barrierDismissible: false,
                                    );
                                    await Future.delayed(
                                        const Duration(seconds: 3));
                                    if (Get.isDialogOpen ?? false) Get.back();
                                  } else {
                                    Get.snackbar(
                                      "Failed",
                                      "Could not apply. Please try again.",
                                      backgroundColor: Colors.red,
                                      colorText: Colors.white,
                                    );
                                  }
                                },
                                child: controller.isLoading.value
                                    ? LoadingAnimationWidget.waveDots(
                                        color: Colors.white,
                                        size: 35,
                                      )
                                    : Text(
                                        placement.applied.value == 1
                                            ? "Applied"
                                            : "Apply Now",
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                          color: Colors.white,
                                        ),
                                      ),
                              )),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildToggleItem({required String title, required bool isActive}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            title,
            style: GoogleFonts.prompt(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: isActive ? TColors.black : Colors.grey.shade400,
            ),
          ),
        ),
        if (isActive)
          Container(
            margin: const EdgeInsets.only(top: 4),
            height: 4,
            width: 60,
            color: TColors.grey,
          ),
      ],
    );
  }

  Widget _buildDetail(
      BuildContext context, String imagePath, String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Circular Image with light grey background
          Container(
            width: 35,
            height: 35,
            decoration: BoxDecoration(
              color: Colors.grey.shade200, // light grey bg
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(6),
            child: Image.asset(
              imagePath,
              fit: BoxFit.contain,
            ),
          ),
          const SizedBox(width: 12),

          /// Title and Value
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 130, // fixed width for title
                    child: Text(
                      "$title:",
                      style: GoogleFonts.prompt(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      value,
                      style: GoogleFonts.prompt(
                          fontSize: 15,
                          color: Colors.black,
                          fontWeight: FontWeight.w400),
                      softWrap: true,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
