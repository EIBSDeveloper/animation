import 'package:eapl_student_app/features/personalization/models/placementmodel/placementinterviewmodel.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class Myjobcard extends StatefulWidget {
  const Myjobcard({super.key, required this.myplacement, required this.index});

  final PlacementInterviewModel myplacement;
  final int index;
  @override
  State<Myjobcard> createState() => _MyjobcardState();
}

class _MyjobcardState extends State<Myjobcard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: TColors.grey)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Job Title + Save Button
          Row(
            children: [
              // Job Role Name
              Expanded(
                child: Text(
                  widget.myplacement.companyName,
                  style: GoogleFonts.prompt(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis, // truncate if too long
                  softWrap: false,
                ),
              ),

              const SizedBox(width: 8),

              // Days Remaining
              Row(
                children: [
                  Image.asset(
                    TImages.days,
                    width: 25,
                    height: 25,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    widget.myplacement.daysRemaining,
                    style: GoogleFonts.prompt(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),

          /// Company Name + Expand/Collapse Icon
          Row(
            children: [
              /// Company Name
              Expanded(
                flex: 3,
                child: Text(
                  widget.myplacement.jobRoleName ?? '---',
                  style: GoogleFonts.prompt(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  softWrap: false,
                ),
              ),

              /// Interview Date
              Expanded(
                flex: 4,
                child: Transform.translate(
                  offset: const Offset(27, 0), // move 8 pixels to the left
                  child: Row(
                    children: [
                      Image.asset(
                        TImages.calender,
                        width: 25,
                        height: 25,
                        fit: BoxFit.contain,
                      ),
                      const SizedBox(width: 5),
                      Flexible(
                        child: Text(
                          DateFormat("dd MMM yyyy").format(
                            DateTime.parse(widget.myplacement.interviewDate),
                          ),
                          style: GoogleFonts.prompt(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Colors.orange),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          Row(
            children: [
              Expanded(
                flex: 4,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.address,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        widget.myplacement.companyAddress,
                        style: GoogleFonts.prompt(
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 4,
                child: Transform.translate(
                  offset: const Offset(3, 0),
                  child: Row(
                    children: [
                      Image.asset(
                        TImages.status,
                        width: 25,
                        height: 25,
                        fit: BoxFit.contain,
                        color: TColors.primary,
                      ),
                      const SizedBox(width: 5),
                      Flexible(
                        child: Text(
                          widget.myplacement.interviewStatus,
                          style: GoogleFonts.prompt(
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                              color: Colors.green),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
