import 'package:eapl_student_app/features/personalization/models/placement_model.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class HistoryJobCard extends StatelessWidget {
  const HistoryJobCard({super.key, required this.placement});

  final PlacementModel placement;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: TColors.grey),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Job Title
          Text(
            placement.jobRoleName,
            style: GoogleFonts.prompt(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),

          const SizedBox(height: 10),

          /// Company Name
          Text(
            placement.companyName ?? "---",
            style: GoogleFonts.prompt(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade700,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),

          const SizedBox(height: 10),
          _buildDetail(context, TImages.vacancy, "Experience",
              placement.experience, Colors.black),

          /// Interview Date (RED)
          _buildDetail(
            context,
            TImages.calender,
            "Date",
            _formatDate(placement.interviewDate),
            Colors.red, // set date color to red
          ),

          _buildDetail(
              context,
              TImages.salary,
              "Salary",
              "₹ ${NumberFormat.currency(locale: 'en_IN', symbol: '', decimalDigits: 0).format(placement.salary)}",
              Colors.black),
        ],
      ),
    );
  }

  Widget _buildDetail(BuildContext context, String imagePath, String title,
      String value, Color? valueColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Circular Image with light grey background
          Container(
            width: 35,
            height: 35,
            decoration: BoxDecoration(
              color: Colors.grey.shade200, // light grey bg
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(6),
            child: Image.asset(
              imagePath,
              fit: BoxFit.contain,
            ),
          ),
          const SizedBox(width: 12),

          /// Title and Value
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 130, // fixed width for title
                    child: Text(
                      "$title:",
                      style: GoogleFonts.prompt(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      value,
                      style: GoogleFonts.prompt(
                          fontSize: 15,
                          color:
                              valueColor ?? Colors.black, // use optional color
                          fontWeight: FontWeight.w400),
                      softWrap: true,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String? dateStr) {
    if (dateStr == null || dateStr.isEmpty) return "---";
    try {
      final date = DateTime.tryParse(dateStr);
      return date != null ? DateFormat("dd MMM yyyy").format(date) : "---";
    } catch (e) {
      return "---";
    }
  }
}
