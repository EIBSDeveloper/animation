import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../controllers/side_drawer_controller/placement_controller.dart';
import '../../../models/placementmodel/placedstudentmodel.dart';

class Placedstudent extends StatelessWidget {
  const Placedstudent({super.key});

  @override
  Widget build(BuildContext context) {
    final PlacementController controller = Get.find();
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            const CustomHeader(title: "Placed Students"),
            Container(
              margin: EdgeInsets.only(left: 10, right: 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10), // curved corners
                child: Image.asset(
                  TImages.placedstudent, // your image path
                  height: 150,
                  width: double.infinity,
                  fit: BoxFit
                      .contain, // fills width while maintaining aspect ratio
                ),
              ),
            ),
            // ✅ List Section
            Expanded(
              child: Obx(() {
                if (controller.isplacedstudentLoading.value) {
                  return const Center(child: CircularProgressIndicator());
                }
      
                if (controller.placedstudentlist.isEmpty) {
                  return const Center(
                    child: Text(
                      "No placed students available",
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  );
                }
      
                return ListView.builder(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  itemCount: controller.placedstudentlist.length,
                  itemBuilder: (context, index) {
                    final PlacedStudentModel student =
                        controller.placedstudentlist[index];
      
                    return Container(
                      margin:
                          const EdgeInsets.only(bottom: 16, left: 8, right: 8),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: TColors.grey)),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          // 🔹 Card Content
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // 🔹 Student Image
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: student.customerPic != null &&
                                          student.customerPic!.isNotEmpty
                                      ? Image.network(
                                          student.customerPic!,
                                          height: 60,
                                          width: 60,
                                          fit: BoxFit.cover,
                                        )
                                      : Image.asset(
                                          TImages.profileImage,
                                          height: 60,
                                          width: 60,
                                          fit: BoxFit.cover,
                                        ),
                                ),
                                const SizedBox(width: 10),
      
                                // 🔹 Details
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        student.companyName ?? "Company",
                                        style: GoogleFonts.prompt(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        student.jobPosition ?? "Position",
                                        style: GoogleFonts.prompt(
                                          color: TColors.primary,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        student.courseName ?? "",
                                        style: GoogleFonts.prompt(
                                          color: Colors.black87,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      if (student.selectedDate != null)
                                        Text(
                                          "Placed On: ${student.selectedDate!}",
                                          style: GoogleFonts.prompt(
                                            color: TColors.primary,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
      
                          // 🔹 Top-right badge (Professional / Tesbo)
                          Positioned(
                            top: -5,
                            right: 8,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  (student.courseTypeName ?? "")
                                          .toLowerCase()
                                          .contains("professional")
                                      ? TImages
                                          .professionalbagde // ✅ professional
                                      : TImages.tesbobadge, // ✅ tesbo
                                  height: 50,
                                  width: 110,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
