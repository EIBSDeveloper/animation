import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/payment_controller.dart';
import 'package:eapl_student_app/features/personalization/models/payment_list_model.dart';
import 'package:eapl_student_app/features/personalization/screens/razor_payment/razorpay_controller.dart';
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';

Container paymentHistoryContainer() {
  // Define a common TextStyle to reuse
  const textStyle = TextStyle(
    fontSize: 14,
    color: Colors.black54,
  );
  final controller = Get.put(PaymentController());

  return Container(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
            padding: const EdgeInsets.all(8.0),
            child: IntrinsicHeight(
              child: Row(
                children: [
                  Expanded(
                      flex: 2,
                      child: buildPaymentCardTitle(title: "Payment\nDate")),
                  VerticalDivider(color: Colors.grey[300], thickness: 1),
                  Expanded(flex: 2, child: buildPaymentCardTitle(title: "MDD")),
                  VerticalDivider(color: Colors.grey[300], thickness: 1),
                  Expanded(
                      flex: 2,
                      child: buildPaymentCardTitle(title: "Schd.\nFees")),
                  VerticalDivider(color: Colors.grey[300], thickness: 1),
                  Expanded(
                      flex: 2,
                      child: buildPaymentCardTitle(title: "Bal.\nFees")),
                  VerticalDivider(color: Colors.grey[300], thickness: 1),
                  Expanded(
                      flex: 2, child: buildPaymentCardTitle(title: "Status")),
                  VerticalDivider(color: Colors.grey[300], thickness: 1),
                  Expanded(
                      flex: 2, child: buildPaymentCardTitle(title: "Action")),
                ],
              ),
            )),
        if (controller.paymentList.length == 0)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 100),
                child: Text("No payment history details found"),
              ),
            ],
          ),
        Expanded(
          child: ListView.builder(
            shrinkWrap: true,
            // physics: NeverScrollableScrollPhysics(),
            itemCount: controller.paymentList.length,
            itemBuilder: (context, index) {
              final paymentValues = controller.paymentList[index];

              // ✅ Background color based on status
              final color = paymentValues.status == 1
                  ? TColors.lightprimary // Paid → Light Green
                  : TColors.white; // Not Paid → Light Red

              return Container(
                padding: EdgeInsets.all(8.0),
                width: double.infinity,
                color: color,
                child: Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: buildPaymentTitleValues(
                        titleValue: THelperFunctions.formatCustomDate(
                            paymentValues.initialPayDate),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: buildPaymentTitleValues(
                        titleValue: THelperFunctions.formatCustomDate(
                            paymentValues.nextPayDate),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: buildPaymentTitleValues(
                        titleValue: "₹${paymentValues.amount}", // Raw amount
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: buildPaymentTitleValues(
                        titleValue:
                            "₹${paymentValues.paidAmount}", // Raw paid amount
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: paymentValues.status == 1
                          ? Image.asset(
                              TImages.paid,
                              height: 20,
                              width: 20,
                              fit: BoxFit.contain,
                            )
                          : Image.asset(
                              TImages.pending,
                              height: 20,
                              width: 20,
                              fit: BoxFit.contain,
                            ),
                    ),
                    /* Expanded(
                      flex: 2,
                      child: SizedBox(
                        height: 24,
                        child: ElevatedButton(
                          onPressed: (paymentValues.status == 1 ||
                                  paymentValues.balanceFee == 0)
                              ? null
                              : () {
                                  paymentDialogView(context, paymentValues);
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: TColors.primary,
                            foregroundColor: TColors.white,
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            "Pay",
                            style:
                                Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: TColors.white,
                                      fontSize: 10,
                                    ),
                          ),
                        ),
                      ),
                    ),*/
                    /*Expanded(
                      flex: 2,
                      child: (paymentValues.branchId == 1 ||
                              paymentValues.branchId == 6)
                          ? SizedBox(
                              height: 24,
                              child: ElevatedButton(
                                onPressed: (paymentValues.status == 1 ||
                                        paymentValues.balanceFee == 0)
                                    ? null
                                    : () {
                                        paymentDialogView(
                                            context, paymentValues);
                                      },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: TColors.primary,
                                  foregroundColor: TColors.white,
                                  padding: EdgeInsets.zero,
                                ),
                                child: Text(
                                  "Pay",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                        color: TColors.white,
                                        fontSize: 10,
                                      ),
                                ),
                              ),
                            )
                          : const SizedBox(), // 🔹 Hide button for other branches
                    ),*/
                    /* Expanded(
                      flex: 2,
                      child: (paymentValues.branchId == 1 ||
                              paymentValues.branchId == 6)
                          ? SizedBox(
                              height: 24,
                              child: ElevatedButton(
                                onPressed: (paymentValues.status == 1 ||
                                        paymentValues.balanceFee == 0)
                                    ? null
                                    : () {
                                        final controller =
                                            Get.put(RazorPaymentController());
                                        final paymentController =
                                            Get.put(PaymentController());

                                        // Optional: Set default payment mode
                                        paymentController
                                            .selectedPaymentMode.value = "UPI";

                                        // Open Razorpay directly with balance fee
                                        controller.openCheckout(
                                          paymentValues,
                                          paymentController
                                              .selectedPaymentMode.value,
                                          directAmount: paymentValues
                                              .payableAmount
                                              .toDouble(),
                                        );
                                      },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: TColors.primary,
                                  foregroundColor: TColors.white,
                                  padding: EdgeInsets.zero,
                                ),
                                child: Text(
                                  "Pay",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                        color: TColors.white,
                                        fontSize: 10,
                                      ),
                                ),
                              ),
                            )
                          : const SizedBox(),
                    ),*/
                    Expanded(
                      flex: 2,
                      child: (paymentValues
                              .keyId.isNotEmpty) // ✅ Show only if keyId exists
                          ? SizedBox(
                              height: 24,
                              child: ElevatedButton(
                                onPressed: (paymentValues.status == 1 ||
                                        paymentValues.balanceFee == 0)
                                    ? null
                                    : () {
                                        final controller =
                                            Get.put(RazorPaymentController());
                                        final paymentController =
                                            Get.put(PaymentController());

                                        paymentController
                                            .selectedPaymentMode.value = "UPI";

                                        controller.openCheckout(
                                          paymentValues,
                                          paymentController
                                              .selectedPaymentMode.value,
                                          directAmount: paymentValues
                                              .payableAmount
                                              .toDouble(),
                                        );
                                      },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: TColors.primary,
                                  foregroundColor: TColors.white,
                                  padding: EdgeInsets.zero,
                                ),
                                child: Text(
                                  "Pay",
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                          color: TColors.white, fontSize: 10),
                                ),
                              ),
                            )
                          : const SizedBox(), // ❌ Hide when keyId is null or empty
                    ),
                  ],
                ),
              );
            },
          ),
        )
      ],
    ),
  );
}

Widget buildPaymentTitleValues({required String titleValue}) {
  return Text(
    titleValue,
    maxLines: 2,
    textAlign: TextAlign.center,
    style: GoogleFonts.prompt(
        fontSize: 12, fontWeight: FontWeight.w500, color: Colors.black),
  );
}

Widget buildPaymentCardTitle({required String title}) {
  return Text(
    title,
    style: GoogleFonts.prompt(
        color: TColors.primary, fontWeight: FontWeight.bold, fontSize: 16),
    textAlign: TextAlign.center,
    maxLines: 1,
    overflow: TextOverflow.ellipsis,
  );
}

// void paymentDialogView(BuildContext context, PaymentList paymentValues) {
//   final controller = Get.put(RazorPaymentController());
//    double balanceAmount =double.parse(paymentValues.amount.toString()) - double.parse(controller.payAmount.text.toString()) ;
//   showDialog(
//     context: context,
//     builder: (BuildContext context) {
//
//       return PopScope(
//         canPop: false,
//         child: AlertDialog(
//           backgroundColor: TColors.white,
//           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
//           title: Container(
//             width: double.infinity,
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Row(
//                   children: [
//                     Text("Payment Mode",style:Theme.of(context).textTheme.titleMedium),
//                     Spacer(),
//                     InkWell(
//                         onTap:(){Get.back();},
//                         child: Icon(Icons.close))
//                   ],
//                 ),
//                 SizedBox(height:TSizes.defaultSpace*4),
//                 TextField(
//
//                   controller: controller.payAmount,
//                   keyboardType: TextInputType.numberWithOptions(decimal: true),
//                   inputFormatters: [
//                     FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
//                   ],
//                   decoration:  InputDecoration(
//                     fillColor: TColors.white,
//                     filled: true,
//                     border: OutlineInputBorder(
//
//                     ),
//                     hintText: 'Enter Paid Amount Eg:500',
//                     hintStyle:Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(
//                         fontWeight: FontWeight.w400, fontSize: 14, color: TColors.liteDark),
//                   ),
//                 ),
//                 balanceAmount == 0.0 ? Text("₹$balanceAmount remaining to be paid ") : SizedBox(),
//                 SizedBox(height:TSizes.defaultSpace*2),
//                 TextField(
//                   maxLines: 5,
//                   controller: controller.paymentDescription,
//                   keyboardType: TextInputType.numberWithOptions(decimal: true),
//                   decoration:  InputDecoration(
//                     filled: true,
//
//                     fillColor: TColors.lightimportant,
//                     border: OutlineInputBorder(
//
//                     ),
//                     hintText: 'Description',
//                     hintStyle: Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(
//                         fontWeight: FontWeight.w400, fontSize: 14, color: TColors.liteDark),
//                   ),
//                 ),
//                 SizedBox(height:TSizes.defaultSpace*2),
//                 ElevatedButton(onPressed: (){}, child: Text("Proceed")),
//               ],
//             ),
//           ),
//         ),
//       );
//     },
//   );
// }
void paymentDialogView(BuildContext context, PaymentList paymentValues) {
  final controller = Get.put(RazorPaymentController());
  final paymentController = Get.put(PaymentController());
  // 🔹 Reset form fields every time dialog opens
  controller.payAmount.clear();
  controller.paymentDescription.clear();
  paymentController.selectedPaymentMode.value = "";
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return SingleChildScrollView(
        // physics: NeverScrollableScrollPhysics(),
        child: PopScope(
          canPop: false,
          child: AlertDialog(
            backgroundColor: TColors.white,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SizedBox(
                  width: double.maxFinite,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      /// Title and Close
                      Row(
                        children: [
                          Text("Payment Mode",
                              style: Theme.of(context).textTheme.titleMedium),
                          const Spacer(),
                          InkWell(
                            onTap: () => Navigator.of(context).pop(), // ✅ close
                            child: const Icon(Icons.close),
                          ),
                        ],
                      ),
                      ...paymentController.paymentMode.map(
                        (mode) => Obx(
                          () => RadioListTile(
                              title: Text(mode),
                              value: mode,
                              groupValue:
                                  paymentController.selectedPaymentMode.value,
                              onChanged: (value) {
                                paymentController.setPaymentMode(value!);
                              }),
                        ),
                      ),
                      // Row(
                      //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      //   children: paymentController.paymentMode.map((mode) {
                      //     return Obx(() => Row(
                      //       children: [
                      //         Radio<String>(
                      //           value: mode,
                      //           groupValue: paymentController.selectedPaymentMode.value,
                      //           onChanged: (value) {
                      //             paymentController.setPaymentMode(value!);
                      //           },
                      //         ),
                      //         Text(mode,maxLines: 2,overflow: TextOverflow.ellipsis ,style: Theme.of(context).textTheme.labelMedium,),
                      //       ],
                      //     ));
                      //   }).toList(),
                      // ),

                      SizedBox(height: TSizes.defaultSpace * 2),

                      /// Paid Amount Input
                      /*TextField(
                        controller: controller.payAmount,
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'^\d*\.?\d*')),
                        ],
                        onChanged: (value) => setState(() {}),
                        decoration: InputDecoration(
                          fillColor: TColors.white,
                          filled: true,
                          border: const OutlineInputBorder(),
                          hintText: 'Enter Paid Amount Eg: 500',
                          hintStyle: Theme.of(context)
                              .textTheme
                              .bodyMedium!
                              .copyWith(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  color: TColors.liteDark),
                        ),
                      ),*/
                      TextField(
                        controller: controller.payAmount,
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'^\d*\.?\d*')),
                          LengthLimitingTextInputFormatter(
                              6), // ✅ max 6 characters
                        ],
                        onChanged: (value) => setState(() {}),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white, // 🔹 White background
                          hintText: 'Enter Amount',
                          hintStyle: AppTextStyles.subheading,
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(
                                color: TColors.grey), // 🔹 Grey border
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                                8), // 🔹 Highlighted border when focused
                          ),
                        ),
                      ),

                      /// Balance Display (Reactive)
                      Builder(builder: (_) {
                        final enteredAmount = double.tryParse(controller
                                .payAmount.text
                                .toString()
                                .padLeft(2, "0")) ??
                            0;
                        final dueAmount = double.tryParse(paymentValues.amount
                                .toString()
                                .padLeft(2, "0")) ??
                            0;
                        final balanceAmount = dueAmount - enteredAmount;

                        return balanceAmount > 0
                            ? Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.info,
                                      color: Colors.red,
                                      size: 20,
                                    ),
                                    SizedBox(
                                      width: TSizes.sm,
                                    ),
                                    Text(
                                      "₹${balanceAmount.toStringAsFixed(2)} remaining to be paid",
                                      style: TextStyle(
                                          color: Colors.red, fontSize: 14),
                                    ),
                                  ],
                                ),
                              )
                            : const SizedBox();
                      }),

                      SizedBox(height: TSizes.defaultSpace * 2),

                      /// Description Input
                      /*  TextField(
                        maxLines: 5,
                        controller: controller.paymentDescription,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: TColors.white,
                          border: const OutlineInputBorder(),
                          hintText: 'Description',
                          hintStyle: AppTextStyles.subheading,
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(
                                color: TColors.grey), // 🔹 Grey border
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(
                                8), // 🔹 Highlighted border when focused
                          ),
                        ),
                      ),*/
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextField(
                            maxLines: 5,
                            controller: controller.paymentDescription,
                            inputFormatters: [
                              LengthLimitingTextInputFormatter(
                                  200), // max 200 chars
                            ],
                            onChanged: (value) {
                              controller.paymentCharCount.value =
                                  value.length; // update count
                            },
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: TColors.white,
                              border: const OutlineInputBorder(),
                              hintText: 'Description',
                              hintStyle: AppTextStyles.subheading,
                              errorBorder: InputBorder.none,
                              focusedErrorBorder: InputBorder.none,
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide(color: TColors.grey),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),

                          /// Character count
                          Align(
                            alignment: Alignment.centerRight,
                            child: Obx(() => Text(
                                  "${controller.paymentCharCount.value}/200",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey[600],
                                  ),
                                )),
                          ),
                        ],
                      ),

                      SizedBox(height: TSizes.defaultSpace * 2),

                      /// Proceed Button
                      /* SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            // Parse entered amount
                            final enteredAmount =
                                double.tryParse(controller.payAmount.text) ?? 0;

                            if (enteredAmount <= 0) {
                              Fluttertoast.showToast(
                                msg: "Please enter an amount greater than 0",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: TColors.primary,
                                textColor: Colors.white,
                                fontSize: 14.0,
                              );
                              return; // Stop execution if invalid
                            }
                            controller.openCheckout(
                              paymentValues,
                              paymentController.selectedPaymentMode.value,
                            );
                            Get.back();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: TColors.primary, // ✅ Primary color
                            elevation: 4,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: Text(
                            "Proceed",
                            style: GoogleFonts.prompt(
                              fontWeight: FontWeight.w500,
                              color:
                                  Colors.white, // make text white for contrast
                            ),
                          ),
                        ),
                      )*/
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            // ✅ Check if a payment mode is selected
                            if (paymentController
                                .selectedPaymentMode.value.isEmpty) {
                              Fluttertoast.showToast(
                                msg: "Please select a payment mode",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: TColors.primary,
                                textColor: Colors.white,
                                fontSize: 14.0,
                              );
                              return; // Stop execution
                            }
                            // Parse entered amount
                            final enteredAmount =
                                double.tryParse(controller.payAmount.text) ?? 0;

                            // Get due amount and calculate remaining balance
                            final dueAmount = double.tryParse(
                                    paymentValues.amount.toString()) ??
                                0;
                            final balanceAmount =
                                dueAmount; // assuming full due is remaining

                            // Check if amount is valid
                            if (enteredAmount <= 0) {
                              Fluttertoast.showToast(
                                msg: "Please enter an amount greater than 0",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: TColors.primary,
                                textColor: Colors.white,
                                fontSize: 14.0,
                              );
                              return;
                            }

                            // Check if entered amount exceeds balance
                            if (enteredAmount > balanceAmount) {
                              Fluttertoast.showToast(
                                msg:
                                    "Entered amount cannot exceed the remaining balance (\₹${balanceAmount.toStringAsFixed(2)})",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: Colors.red,
                                textColor: Colors.white,
                                fontSize: 14.0,
                              );
                              return;
                            }

                            // If valid, proceed with payment
                            controller.openCheckout(
                              paymentValues,
                              paymentController.selectedPaymentMode.value,
                            );
                            Get.back();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: TColors.primary,
                            elevation: 4,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: Text(
                            "Proceed",
                            style: GoogleFonts.prompt(
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      );
    },
  );
}
