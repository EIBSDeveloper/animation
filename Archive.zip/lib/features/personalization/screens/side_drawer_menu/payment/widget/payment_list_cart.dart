import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/payment_controller.dart';
import 'package:eapl_student_app/features/personalization/models/payment_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../payment_history_details.dart';

class PaymentDetailCard extends StatelessWidget {
  const PaymentDetailCard({
    super.key,
    required this.paymentModel,
  });

  final CoursePaymentModel paymentModel;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(PaymentController());

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: TColors.grey),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              /// Course Name (single line)
              Expanded(
                child: Text(
                  (paymentModel.courseName != null &&
                          paymentModel.courseName!.isNotEmpty)
                      ? paymentModel.courseName!
                          .split(' ')
                          .sublist(
                              0, paymentModel.courseName!.split(' ').length - 1)
                          .join(' ')
                      : "---",
                  style: GoogleFonts.prompt(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.visible,
                  softWrap: false,
                ),
              ),

              const SizedBox(width: 8),

              /// Pay Now Button
              if (paymentModel.balanceFee > 0)
                SizedBox(
                  height: 30,
                  width: 100,
                  child: ElevatedButton(
                    onPressed: () async {
                      await controller
                          .fetchListOfPaymentData(paymentModel.courseId);
                      Get.to(() =>
                          PaymentHistory(paymentCourseWiseModel: paymentModel));
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: TColors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                      padding: EdgeInsets.zero,
                      elevation: 0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.monetization_on_rounded, // coin icon
                          color: Colors.white,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Pay Now',
                          style: GoogleFonts.prompt(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: Colors.white, // white text
                          ),
                          maxLines: 1,
                          softWrap: false,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: TSizes.md),

          /// Row with amounts
          Row(
            children: [
              Expanded(
                child: _buildAmountTile(
                  context,
                  label: "Course Fee",
                  value: paymentModel.totalAmount,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildAmountTile(
                  context,
                  label: "Paid",
                  value: paymentModel.paidAmount,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildAmountTile(
                  context,
                  label: "Balance",
                  value: paymentModel.balanceFee,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAmountTile(
    BuildContext context, {
    required num value,
    required String label,
  }) {
    final formatter = NumberFormat.decimalPattern('en_IN');

    return Container(
      width: 120,
      height: 90,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: TColors.grey),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: TColors.grey,
            blurRadius: 4,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            "₹ ${formatter.format(value)}",
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: TColors.primary,
            ),
          ),
        ],
      ),
    );
  }
}

/*class PaymentDetailCard extends StatelessWidget {
  const PaymentDetailCard({
    super.key,
    required this.paymentModel,
  });

  final CoursePaymentModel paymentModel;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(PaymentController());
    final formatter = NumberFormat.decimalPattern('en_IN');

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: TColors.grey, width: 0.8),
        boxShadow: [
          BoxShadow(
            color: TColors.grey.withOpacity(0.2),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// 1. Title Row
          Row(
            children: [
              /// Course Name (single line)
              Expanded(
                child: Text(
                  (paymentModel.courseName != null &&
                          paymentModel.courseName!.isNotEmpty)
                      ? paymentModel.courseName!
                          .split(' ')
                          .sublist(
                              0, paymentModel.courseName!.split(' ').length - 1)
                          .join(' ')
                      : "---",
                  style: GoogleFonts.prompt(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.visible,
                  softWrap: false,
                ),
              ),

              const SizedBox(width: 8),

              /// Pay Now Button
              if (paymentModel.balanceFee > 0)
                SizedBox(
                  height: 30,
                  width: 100,
                  child: ElevatedButton(
                    onPressed: () {
                      Get.to(() => PaymentHistory(
                            paymentCourseWiseModel: paymentModel,
                          ));
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: TColors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                      padding: EdgeInsets.zero,
                      elevation: 0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.monetization_on_rounded, // coin icon
                          color: Colors.white,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Pay Now',
                          style: GoogleFonts.prompt(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: Colors.white, // white text
                          ),
                          maxLines: 1,
                          softWrap: false,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 15),

          /// 2. Amount Row (Course Fee, Paid, Balance)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildAmountTile(
                  label: "Course Fee", value: paymentModel.totalAmount),
              _buildAmountTile(label: "Paid", value: paymentModel.paidAmount),
              _buildAmountTile(
                  label: "Balance", value: paymentModel.balanceFee),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAmountTile({required String label, required num value}) {
    final formatter = NumberFormat.decimalPattern('en_IN');
    return Container(
      width: 100,
      height: 70,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: TColors.grey),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: TColors.grey.withOpacity(0.2),
            blurRadius: 3,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            "₹${formatter.format(value)}",
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: TColors.primary,
            ),
          ),
        ],
      ),
    );
  }
}*/
