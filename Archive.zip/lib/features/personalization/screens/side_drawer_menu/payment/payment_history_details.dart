/*import 'package:eapl_student_app/common/widget/app_bar/appbar.dart';
import 'package:eapl_student_app/common/widget/background/title_with_glassy_theme.dart';
import 'package:eapl_student_app/features/personalization/models/payment_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/payment/widget/payment_history_card.dart';
import 'package:eapl_student_app/utils/constants/sizes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../utils/constants/colors.dart';
import '../../razor_payment/razorpay_controller.dart';

class PaymentHistory extends StatelessWidget {
  const PaymentHistory({super.key, required this.paymentCourseWiseModel});

  final CoursePaymentModel paymentCourseWiseModel;

  @override
  Widget build(BuildContext context) {
    final RazorPaymentController paymentController =
        Get.put(RazorPaymentController());

    return Scaffold(
      // drawer: const SideMenuBar(),
      appBar: const CustomAppBar(isMenuNeed: false),
      // extendBodyBehindAppBar: true,
      body: SingleChildScrollView(
        child: TitleWithGlassyTheme(
          title:
              "Payment History Details >> ${paymentCourseWiseModel.courseName}",
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  Card(
                    elevation: 10,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.70),
                          borderRadius: BorderRadius.circular(10.0)),
                      child: IntrinsicHeight(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _buildFeeSummary(
                                paymentCourseWiseModel.totalAmount.toString(),
                                'Course Fee'),
                            const VerticalDivider(
                              indent: 10,
                              endIndent: 10,
                            ),
                            _buildFeeSummary(
                                paymentCourseWiseModel.paidAmount.toString(),
                                'Paid Amount'),
                            VerticalDivider(indent: 10, endIndent: 10),
                            _buildFeeSummary(
                                paymentCourseWiseModel.balanceFee.toString(),
                                'Balance'),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: TSizes.spaceBtwItems),
                  ListView.separated(
                      itemCount: paymentCourseWiseModel.paymentHistory.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return paymentHistoryContainer(
                            payment:
                                paymentCourseWiseModel.paymentHistory[index]);
                      },
                      separatorBuilder: (context, index) {
                        return SizedBox(height: TSizes.md);
                      })
                ],
              ),

              // if (paymentCourseWiseModel.balanceFee >= 1)
              //   ElevatedButton(
              //     onPressed: () {
              //       Get.dialog(AlertDialog(
              //         title: Center(child: Text('Payment')),
              //         content: Column(
              //           mainAxisSize: MainAxisSize.min,
              //           children: [
              //             TextFormField(
              //               controller: paymentController.payAmount,
              //               keyboardType: TextInputType.number,
              //               maxLength: 8,
              //               decoration: InputDecoration(
              //                 hintText: "Amount",
              //                 labelText: "Amount",
              //                 counterText: '',
              //               ),
              //             ),
              //             SizedBox(height: TSizes.md),
              //             Row(
              //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //               children: [
              //                 OutlinedButton(
              //                     onPressed: () {
              //                       Get.back();
              //                     },
              //                     child: Text('back')),
              //                 ElevatedButton(
              //                     onPressed: () {
              //                       if (paymentController
              //                               .payAmount.text.isNotEmpty &&
              //                           paymentController.payAmount.text !=
              //                               "0") {
              //                         if (int.parse(paymentController
              //                                 .payAmount.text) <=
              //                             paymentCourseWiseModel.balanceFee) {
              //                           paymentController.openCheckout();
              //                         } else {
              //                           TSnackbar.warningSnackbar(
              //                               title: 'Check Amount',
              //                               message:
              //                                   'The amount exceeds the balance fees.');
              //                         }
              //                       } else {
              //                         TSnackbar.warningSnackbar(
              //                             title: 'Check Payment Amount',
              //                             message:
              //                                 'Payment amount cannot be empty or zero.');
              //                       }
              //                     },
              //                     child: Text('Pay'))
              //               ],
              //             )
              //           ],
              //         ),
              //       ));
              //     },
              //     child: Text('Make Payment'),
              //     style: ElevatedButton.styleFrom(
              //         backgroundColor: TColors.buttonPrimary),
              //   )
            ],
          ),
        ),
      ),
      */ /*body: paymentCourseWiseModel.paymentHistory.isEmpty
          ? Center(
              child: Text(
                "No history details found",
                style: Theme.of(context)
                    .textTheme
                    .titleMedium!
                    .copyWith(color: Colors.grey),
              ),
            )
          : SingleChildScrollView(
              child: TitleWithGlassyTheme(
                title:
                    "Payment History Details >> ${paymentCourseWiseModel.courseName}",
                child: Column(
                  children: [
                    // ✅ summary card
                    Card(
                      elevation: 10,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.70),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: IntrinsicHeight(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _buildFeeSummary(
                                  paymentCourseWiseModel.totalAmount.toString(),
                                  'Course Fee'),
                              const VerticalDivider(indent: 10, endIndent: 10),
                              _buildFeeSummary(
                                  paymentCourseWiseModel.paidAmount.toString(),
                                  'Paid Amount'),
                              const VerticalDivider(indent: 10, endIndent: 10),
                              _buildFeeSummary(
                                  paymentCourseWiseModel.balanceFee.toString(),
                                  'Balance'),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: TSizes.spaceBtwItems),
                    // ✅ list
                    ListView.separated(
                      itemCount: paymentCourseWiseModel.paymentHistory.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return paymentHistoryContainer(
                          payment: paymentCourseWiseModel.paymentHistory[index],
                        );
                      },
                      separatorBuilder: (context, index) {
                        return SizedBox(height: TSizes.md);
                      },
                    ),
                  ],
                ),
              ),
            ),*/ /*

      floatingActionButton: Align(
        alignment: Alignment.bottomLeft,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 30.0, left: 40.0),
          child: FloatingActionButton(
            onPressed: () {
              Get.back();
              // Add your onPressed code here!
            },
            backgroundColor: TColors.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50.0),
            ),
            child: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

*/ /*  Widget _buildFeeSummary(String amount, String label) {
    return Column(
      children: [
        Text(amount,
            style: Theme.of(Get.context!)
                .textTheme
                .titleLarge!
                .apply(color: TColors.importantText)),
        const SizedBox(height: TSizes.xs),
        Text(label, style: Theme.of(Get.context!).textTheme.bodyLarge),
      ],
    );
  }*/ /*
  Widget _buildFeeSummary(String amount, String label) {
    final formattedAmount =
        NumberFormat.decimalPattern('en_IN').format(int.parse(amount));

    return Column(
      children: [
        Text(
          formattedAmount,
          style: Theme.of(Get.context!)
              .textTheme
              .titleLarge!
              .apply(color: TColors.importantText),
        ),
        const SizedBox(height: TSizes.xs),
        Text(label, style: Theme.of(Get.context!).textTheme.bodyLarge),
      ],
    );
  }

  Widget _buildTableHeader(String text) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(
        text,
        style: Theme.of(Get.context!)
            .textTheme
            .bodyLarge!
            .apply(color: TColors.primary),
        textAlign: TextAlign.center,
      ),
    );
  }

  List<TableRow> _buildTableRows() {
    List<TableRow> rows = [];
    for (int i = 0; i < paymentCourseWiseModel.paymentHistory.length; i++) {
      rows.add(
        _buildTableRow(
          paymentCourseWiseModel.paymentHistory[i].paymentDate,
          paymentCourseWiseModel.paymentHistory[i].paymentId,
          paymentCourseWiseModel.paymentHistory[i].payedAmount.toString(),
          paymentCourseWiseModel.paymentHistory[i].paymentModeName ?? '---',
          i,
          isAlternate: i % 2 == 1,
        ),
      );
    }
    return rows;
  }

  TableRow _buildTableRow(String date, String receipt, String onlinePay,
      String cashPay, int tableCount,
      {bool isAlternate = false}) {
    return TableRow(
      decoration: BoxDecoration(
          color: isAlternate ? Color(0xFFF2DFE1) : Colors.white,
          borderRadius:
              tableCount == paymentCourseWiseModel.paymentHistory.length
                  ? BorderRadius.only(
                      bottomRight: Radius.circular(12.0),
                      bottomLeft: Radius.circular(12.0))
                  : BorderRadius.zero),
      children: [
        _buildTableCell(date),
        _buildTableCell(receipt),
        _buildTableCell(onlinePay),
        _buildTableCell(cashPay),
      ],
    );
  }

  Widget _buildTableCell(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: TSizes.md),
      child: Text(
        text,
        style: Theme.of(Get.context!)
            .textTheme
            .labelMedium!
            .apply(color: Colors.black87),
        textAlign: TextAlign.center,
      ),
    );
  }
}*/

/*import 'package:eapl_student_app/features/personalization/models/payment_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/payment/widget/payment_history_card.dart';
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../controllers/side_drawer_controller/payment_controller.dart';

class PaymentHistory extends StatelessWidget {
  PaymentHistory({
    super.key,
    required this.paymentCourseWiseModel,
  });

  final CoursePaymentModel paymentCourseWiseModel;
  @override
  Widget build(BuildContext context) {
    final PaymentController paymentController = Get.put(PaymentController());
    // 👇 Show tutorial only first time
    Future.delayed(Duration(milliseconds: 800), () async {
      final shown = await GetStorage().read(TTexts.paymenthistorytour) ?? false;
      if (!shown) {
        paymentController.PaymenthistoryTour(context);
      }
    });
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(150),
        child: CustomHeader(title: "Payment History"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 6),
            Text(paymentCourseWiseModel.courseName,
                style: AppTextStyles.heading),
            const SizedBox(height: 20),
            RedeemCouponCard(
              redeemPercent: paymentCourseWiseModel.redeemValue,
              onRedeem: () {
                print("Redeem button clicked!");
              },
            ),

            Obx(() {
              return Row(
                children: [
                  Expanded(
                    child: _buildFeeSummary(
                      value: paymentController.totalAmount.value,
                      label: 'Course Fee',
                      gstPercentage: paymentController
                          .gstPercentageNew.value, // GST in red
                    ),
                  ),
                  Expanded(
                    child: _buildFeeSummary(
                      value: paymentController.paidAmount.value,
                      label: 'Paid',
                    ),
                  ),
                  Expanded(
                    child: _buildFeeSummary(
                      value: paymentController.balanceFee.value,
                      label: 'Balance',
                    ),
                  ),
                ],
              );
            }),

            const SizedBox(height: 20),

            // Payment History List
            Obx(() {
              return Expanded(
                child: paymentController.paymentList.isEmpty
                    ? Center(
                        child: Text(
                          "No payment history available",
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .copyWith(color: Colors.grey),
                        ),
                      )
                    : paymentHistoryContainer(),
              );
            })
          ],
        ),
      ),
    );
  }

  // Fee summary with proper formatting
  Widget _buildFeeSummary({
    required num value,
    required String label,
    int? gstPercentage, // optional GST percentage
  }) {
    final formatter = NumberFormat.decimalPattern('en_IN'); // 14,555 style

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: TColors.grey, width: 1),
        borderRadius: BorderRadius.circular(6),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: SizedBox(
        height: 80, // fixed height for all cards
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Label
            Text(
              label,
              textAlign: TextAlign.center,
              style: GoogleFonts.prompt(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 6),

            // Amount
            Text(
              "₹ ${formatter.format(value)}",
              textAlign: TextAlign.center,
              style: GoogleFonts.prompt(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: TColors.primary,
              ),
            ),

            const SizedBox(height: 4),

            // GST or placeholder to maintain alignment
            Text(
              gstPercentage != null ? "+$gstPercentage% GST" : "",
              textAlign: TextAlign.center,
              style: GoogleFonts.prompt(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RedeemCouponCard extends StatefulWidget {
  final int redeemPercent; // e.g., 20 for 20%
  final VoidCallback onRedeem;

  const RedeemCouponCard({
    super.key,
    required this.redeemPercent,
    required this.onRedeem,
  });

  @override
  State<RedeemCouponCard> createState() => _RedeemCouponCardState();
}

class _RedeemCouponCardState extends State<RedeemCouponCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);

    _animation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _animation,
      child: Container(
        width: 280,
        height: 150,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Colors.redAccent, Colors.red],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.redAccent.withOpacity(0.5),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min, // Add this
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Redeem value %
            Text(
              "${widget.redeemPercent}% OFF",
              style: GoogleFonts.prompt(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),

            // Extra discount text
            Text(
              "Get Extra Discount!",
              style: GoogleFonts.prompt(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.white70,
              ),
            ),
            const Spacer(),

            // Redeem now button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: widget.onRedeem,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  "Redeem Now",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}*/

import 'package:eapl_student_app/features/personalization/models/payment_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/payment/widget/payment_history_card.dart';
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../controllers/side_drawer_controller/payment_controller.dart';
import '../../../models/payment_list_model.dart';

class PaymentHistory extends StatelessWidget {
  PaymentHistory({
    super.key,
    required this.paymentCourseWiseModel,
  });

  final CoursePaymentModel paymentCourseWiseModel;

  @override
  Widget build(BuildContext context) {
    final PaymentController paymentController = Get.put(PaymentController());

    // Show tutorial only first time
    Future.delayed(Duration(milliseconds: 800), () async {
      final shown = await GetStorage().read(TTexts.paymenthistorytour) ?? false;
      if (!shown) {
        paymentController.PaymenthistoryTour(context);
      }
    });

    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Payment History"),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(paymentCourseWiseModel.courseName,
                  style: AppTextStyles.heading),
              const SizedBox(height: 20),
      
              // Redeem Coupon Card
              if (paymentCourseWiseModel.redeemcode > 0)
                RedeemCouponCard(
                  redeemcode: paymentCourseWiseModel.redeemcode,
                  onRedeem: () {
                    showRedeemDialog(
                      context,
                      paymentController,
                      paymentCourseWiseModel.redeemList,
                      paymentController.paymentList.first,
                    );
                  },
                ),
      
              const SizedBox(height: 20),
      
              // Fee Summary Row
              Obx(() {
                return Row(
                  children: [
                    Expanded(
                      child: _buildFeeSummary(
                        value: paymentController.totalAmount.value,
                        label: 'Course Fee',
                        gstPercentage: paymentController.gstPercentageNew.value,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildFeeSummary(
                        value: paymentController.paidAmount.value,
                        label: 'Paid',
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildFeeSummary(
                        value: paymentController.balanceFee.value,
                        label: 'Balance',
                      ),
                    ),
                  ],
                );
              }),
              const SizedBox(height: 20),
      
              // Payment History List
              Expanded(
                child: Obx(() {
                  if (paymentController.paymentList.isEmpty) {
                    return Center(
                      child: Text(
                        "No payment history available",
                        style: Theme.of(context)
                            .textTheme
                            .bodyLarge!
                            .copyWith(color: Colors.grey),
                      ),
                    );
                  } else {
                    return paymentHistoryContainer();
                  }
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Fee summary widget
  Widget _buildFeeSummary({
    required num value,
    required String label,
    int? gstPercentage,
  }) {
    final formatter = NumberFormat.decimalPattern('en_IN');

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: TColors.grey, width: 1),
        borderRadius: BorderRadius.circular(6),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: SizedBox(
        height: 80,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              label,
              textAlign: TextAlign.center,
              style: GoogleFonts.prompt(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              "₹ ${formatter.format(value)}",
              textAlign: TextAlign.center,
              style: GoogleFonts.prompt(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: TColors.primary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              gstPercentage != null ? "+$gstPercentage% GST" : "",
              textAlign: TextAlign.center,
              style: GoogleFonts.prompt(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------- Redeem Dialog -------------------
void showRedeemDialog(
  BuildContext context,
  PaymentController controller,
  List<RedeemModel> redeemList,
  PaymentList payment, // Pass the payment object
) {
  if (redeemList.isEmpty) {
    Get.snackbar(
      "No Coupons",
      "No redeem coupons available right now.",
      snackPosition: SnackPosition.BOTTOM,
    );
    return;
  }

  controller.clearRedeemSelection();

  Get.dialog(
    AlertDialog(
      backgroundColor: TColors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      title: const Text(
        "Select Redeem Coupon",
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: redeemList.length,
            itemBuilder: (context, index) {
              final item = redeemList[index]; // normal list, fine
              return Obx(
                () => CheckboxListTile(
                  value: controller.selectedRedeemIds.contains(item.couponId),
                  onChanged: (_) => controller.toggleRedeemSelection(item),
                  title: Text(
                    item.couponCode,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  subtitle: Text(
                    "₹${item.redeemvalue}  |  Crown: ${item.crownCount}",
                    style: const TextStyle(color: Colors.grey),
                  ),
                ),
              );
            },
          )),
      actions: [
        // ✅ Only this text updates reactively
        Obx(
          () => Padding(
            padding: const EdgeInsets.only(left: 16, bottom: 25),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Total Redeem Value: ₹${controller.totalRedeemValue.value}",
                style: const TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
        Row(
          children: [
            Expanded(
              child: TextButton(
                onPressed: () {
                  controller.clearRedeemSelection();
                  Get.back();
                },
                style: TextButton.styleFrom(
                  backgroundColor: Colors.grey.shade200, // optional styling
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  "Cancel",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(width: 12), // spacing between buttons
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  if (controller.selectedRedeemIds.isEmpty) {
                    Fluttertoast.showToast(
                      msg: "Please choose at least one coupon.",
                      toastLength: Toast.LENGTH_SHORT,
                      gravity: ToastGravity.BOTTOM,
                      backgroundColor: Colors.red, // optional styling
                      textColor: Colors.white,
                      fontSize: 14.0,
                    );

                    return;
                  }

                  Get.back();
                  controller.applyCoupon(payment: payment);

                  Fluttertoast.showToast(
                    msg:
                        "Redeem Applied: ₹${controller.totalRedeemValue.value}",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.BOTTOM,
                    backgroundColor: TColors.primary,
                    textColor: Colors.white,
                    fontSize: 14.0,
                  );

                  print(
                    "✅ Selected Redeem IDs: ${controller.selectedRedeemIds.toList()}",
                  );
                  print(
                      "✅ Total Redeem Value: ${controller.totalRedeemValue.value}");
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: TColors.primary,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  "OK",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        )
      ],
    ),
  );
}

// ------------------- Redeem Coupon Card -------------------
/*class RedeemCouponCard extends StatelessWidget {
  final int redeemcode;
  final VoidCallback onRedeem;

  const RedeemCouponCard({
    super.key,
    required this.redeemcode,
    required this.onRedeem,
  });

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat.decimalPattern('en_IN');
    final PaymentController controller = Get.find<PaymentController>();

    return Obx(() {
      return AnimatedScale(
        duration: const Duration(milliseconds: 600),
        scale: controller.isRedeemAnimating.value ? 1.05 : 1.0,
        child: GestureDetector(
          onTap: onRedeem,
          onTapDown: (_) => controller.isRedeemAnimating.value = true,
          onTapUp: (_) => controller.isRedeemAnimating.value = false,
          onTapCancel: () => controller.isRedeemAnimating.value = false,
          child: Container(
            width: double.infinity,
            height: 160,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              image: const DecorationImage(
                image: AssetImage(TImages.bgcoupon), // your background image
                fit: BoxFit.cover,
              ),
            ),
            child: Stack(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 110, top: 30),
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "₹ ${formatter.format(redeemcode)}",
                              style: GoogleFonts.prompt(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue.shade900,
                                shadows: [
                                  Shadow(
                                    color: Colors.black.withOpacity(0.5),
                                    offset: const Offset(1, 1),
                                    blurRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              "OFF",
                              style: GoogleFonts.prompt(
                                fontSize: 20,
                                fontWeight: FontWeight.w400,
                                color: Colors.blue.shade900,
                                shadows: [
                                  Shadow(
                                    color: Colors.black.withOpacity(0.5),
                                    offset: const Offset(1, 1),
                                    blurRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    });
  }
}*/
class RedeemCouponCard extends StatefulWidget {
  final int redeemcode;
  final VoidCallback onRedeem;

  const RedeemCouponCard({
    super.key,
    required this.redeemcode,
    required this.onRedeem,
  });

  @override
  State<RedeemCouponCard> createState() => _RedeemCouponCardState();
}

class _RedeemCouponCardState extends State<RedeemCouponCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();

    // Smooth continuous zoom in/out animation
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 0.98, end: 1.05).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat.decimalPattern('en_IN');

    return ScaleTransition(
      scale: _scaleAnimation,
      child: GestureDetector(
        onTap: widget.onRedeem,
        child: Container(
          width: double.infinity,
          height: 160,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            image: const DecorationImage(
              image: AssetImage(TImages.bgcoupon),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: [
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 110, top: 0),
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "₹ ${formatter.format(widget.redeemcode)}",
                              style: GoogleFonts.prompt(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue.shade900,
                                shadows: [
                                  Shadow(
                                    color: Colors.black.withOpacity(0.5),
                                    offset: const Offset(1, 1),
                                    blurRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              "OFF",
                              style: GoogleFonts.prompt(
                                fontSize: 20,
                                fontWeight: FontWeight.w400,
                                color: Colors.blue.shade900,
                                shadows: [
                                  Shadow(
                                    color: Colors.black.withOpacity(0.5),
                                    offset: const Offset(1, 1),
                                    blurRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
