/*
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/payment_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/payment/widget/payment_list_cart.dart';

import '../../../../../common/widget/background/title_with_glassy_theme.dart';
import '../../../../../utils/constants/path_provider.dart';

class PaymentPage extends StatelessWidget {
  const PaymentPage({super.key});

  @override
  Widget build(BuildContext context) {
    final paymentController = Get.put(PaymentController());
    return Scaffold(
        */
/*drawer: const SideMenuBar(),
        appBar: const CustomAppBar(),*/ /*

        body: TitleWithGlassyTheme(
            glassHeight: THelperFunctions.screenWidth() > 600
                ? THelperFunctions.screenHeight() / 1.4
                : THelperFunctions.screenHeight() / 1.7,
            title: "Payment History",
            child: Obx(
              () {
                if (paymentController.isLoading.value == true) {
                  return const TAnimationLoaderWidget(
                    text: "Loading...",
                    animation: TImages.pencilAnimation,
                  );
                }
                if (paymentController.paymentCourseList.isEmpty) {
                  return const Center(
                      child: Text("There is No Payment Details"));
                }
                return ListView.builder(
                  itemCount: paymentController.paymentCourseList.length,
                  itemBuilder: (BuildContext context, int index) {
                    return PaymentDetailCard(
                        paymentModel:
                            paymentController.paymentCourseList[index]);
                  },
                );
              },
            )));
  }
}
*/
import 'package:eapl_student_app/common/widget/app_bar/customheader.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/payment_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/payment/widget/payment_list_cart.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../utils/constants/path_provider.dart';
import '../../../../../utils/constants/text_strings.dart';

class PaymentPage extends StatelessWidget {
  final paymentController = Get.put(PaymentController());
  PaymentPage({super.key});
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.paymenttour) ?? false;

      if (!paymentController.isPaymentTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await paymentController.PaymentTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.paymenttour, true);
        paymentController.isPaymentTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(150),
          child: CustomHeader(title: "Payment Details"),
        ),
        body: Container(
          margin: EdgeInsets.only(left: 10, right: 10),
          child: Column(
            children: [
              const SizedBox(height: 20), // spacing from top
              Expanded(
                child: Obx(
                  () {
                    if (paymentController.isLoading.value == true) {
                      return const TAnimationLoaderWidget(
                        text: "Loading...",
                        animation: TImages.pencilAnimation,
                      );
                    }
                    if (paymentController.paymentCourseList.isEmpty) {
                      return const Center(
                          child: Text("There is No Payment Details"));
                    }
                    return ListView.builder(
                      itemCount: paymentController.paymentCourseList.length,
                      itemBuilder: (BuildContext context, int index) {
                        return PaymentDetailCard(
                          key: index == 0
                              ? paymentController.paymentcardKey
                              : null,
                          paymentModel:
                              paymentController.paymentCourseList[index],
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
