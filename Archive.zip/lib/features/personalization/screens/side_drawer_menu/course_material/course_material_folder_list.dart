/* SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: courseModel.materialNames
                        .asMap()
                        .entries
                        .map((entry) {
                      final index = entry.key;
                      final material = entry.value;

                      return Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: MaterialFolderStructureAndName(
                          key: index == 0
                              ? controller.materialdetailKey
                              : null, // ✅ tutorial key for first item
                          onTap: () {
                            controller.fetchMaterialList(
                              courseId: courseModel.courseId.toString(),
                              materialTypeId: material.sno.toString(),
                            );
                            Get.to(() => CourseMaterialFileList());
                          },
                          fileType: material.folderName ?? 'FOLDER',
                          title: material.folderName,
                        ),
                      );
                    }).toList(),
                  ),
                )*/

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../controllers/side_drawer_controller/material_course_controller.dart';
import '../../../models/course_material_model/course_material_model.dart';
import 'course_material_file_list.dart';

class CourseMaterialFolderView extends StatelessWidget {
  final controller = Get.put(CourseMaterialController());
  CourseMaterialFolderView({super.key, required this.courseModel});

  final CourseMaterialListNew courseModel;
  void _showTourOnce(BuildContext context) {
    // Only show tutorial if not already shown
    if (!controller.isMaterialdetailTouron.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final isTutorialShown =
            GetStorage().read(TTexts.materialdetailtour) ?? false;

        if (!isTutorialShown && controller.courseListFolder.isNotEmpty) {
          // Small delay to ensure Overlay exists
          await Future.delayed(const Duration(milliseconds: 1000));

          await controller.MaterialdetailTour(context);

          // Mark tutorial as shown
          GetStorage().write(TTexts.materialdetailtour, true);
          controller.isMaterialdetailTouron.value = true;
        }
      });
    }
  }

/*  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    return Scaffold(
      body: Column(
        children: [
          CustomHeader(title: "Course Materials"),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Top Row: Version + Tag
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                      child: Text(
                        "${courseModel.courseName ?? '---'}",
                        style: GoogleFonts.prompt(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),

                /// Course Type
                Row(
                  children: [
                    Image.asset(
                      TImages.category,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        courseModel.courseSubcategoryName ?? '---',
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 15),

                /// Material Folders Row/List inside the course card

                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: ListView.builder(
                    physics:
                        const NeverScrollableScrollPhysics(), // optional if parent scroll exists
                    shrinkWrap:
                        true, // important to fit content inside another scroll
                    itemCount: courseModel.materialNames.length,
                    itemBuilder: (context, index) {
                      final material = courseModel.materialNames[index];

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey.shade300),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.1),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.folder,
                                color: Colors.orange, size: 28),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                material.folderName ?? "Folder",
                                style: GoogleFonts.prompt(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 35,
                              child: ElevatedButton(
                                onPressed: () {
                                  controller.fetchMaterialList(
                                    courseId: courseModel.courseId.toString(),
                                    materialTypeId: material.sno.toString(),
                                  );
                                  Get.to(() => CourseMaterialFileList());
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16),
                                  elevation: 0,
                                ),
                                child: Text(
                                  'View',
                                  style: GoogleFonts.prompt(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }*/
  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);

    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomHeader(title: "Course Materials"),
              SizedBox(
                height: 15,
              ),
              // Course Name (minimal vertical space)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 4),
                child: Text(
                  "${courseModel.courseName ?? '---'}",
                  style: GoogleFonts.prompt(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
      
              // Material Folders List
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                child: ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  itemCount: courseModel.materialNames.length,
                  itemBuilder: (context, index) {
                    final material = courseModel.materialNames[index];
      
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8), // minimal spacing
                      padding:
                          const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          // Folder icon with count
                          Stack(
                            clipBehavior: Clip.none,
                            children: [
                              const Icon(Icons.folder,
                                  color: Colors.orange, size: 40),
                              Positioned(
                                top: -4, // adjust vertical position
                                left: -4, // adjust horizontal position
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: Colors.red, // count background color
                                    shape: BoxShape.circle,
                                  ),
                                  child: Text(
                                    (material.count ?? 0)
                                        .toString(), // ✅ Safe null handling
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(width: 12),
      
                          // Folder name
                          Expanded(
                            child: Text(
                              material.folderName ?? "Folder",
                              style: GoogleFonts.prompt(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
      
                          // View button
                          SizedBox(
                            height: 36,
                            child: ElevatedButton(
                              onPressed: () {
                                controller.fetchMaterialList(
                                  courseId: courseModel.courseId.toString(),
                                  materialTypeId: material.sno.toString(),
                                );
                                Get.to(() => CourseMaterialFileList());
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: TColors.primary,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 16),
                                elevation: 0,
                              ),
                              child: Text(
                                'View',
                                style: GoogleFonts.prompt(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
