/*
 * /Project Name: eapl_staff_app
 * /Created by: KARTHICK DINESH A
 * /Created on: 24/09/24, 5:01 pm
 * /Last modified 24/09/24, 1:01 pm
 * /Last accessed: $file.lastAccessed
 *
 * /Copyright (c) 2024  KARTHICK DINESH A. All Rights Reserved
 */

import 'package:flutter/material.dart';

import '../../../../../../utils/constants/image_strings.dart';

/*class MaterialFolderStructureAndName extends StatelessWidget {
  final VoidCallback onTap;
  final String fileType;
  final String title;

  const MaterialFolderStructureAndName({
    super.key,
    required this.onTap,
    required this.fileType,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: title,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 110,
          // color: Colors.red,
          padding: EdgeInsets.all(TSizes.xs),
          child: Column(
            children: [
              Image(
                  image: AssetImage(fileType == "FOLDER"
                      ? TImages.folder
                      : fileType == "PDF"
                          ? TImages.pdf
                          : fileType == "IMAGE"
                              ? TImages.imageFolder
                              : fileType == "PPT"
                                  ? TImages.ppt
                                  : TImages.folder),
                  height: 55,
                  width: 60),
              Text(
                title,
                style: Theme.of(context)
                    .textTheme
                    .bodySmall!
                    .apply(color: Colors.black),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}*/
class MaterialFolderStructureAndName extends StatelessWidget {
  final VoidCallback onTap;
  final String fileType;
  final String title;

  const MaterialFolderStructureAndName({
    super.key,
    required this.onTap,
    required this.fileType,
    required this.title,
  });

  // 🔹 Map folder_name → correct image
  String _getFileIcon(String type) {
    switch (type.toLowerCase()) {
      case "pdf":
        return TImages.pdf;
      case "ppt":
        return TImages.ppt;
      case "word":
      case "word sheet": // API gives "Word Sheet"
        return TImages.word;
      case "zip":
      case "zipfile": // API gives "Zipfile"
        return TImages.zip;
      case "image":
        return TImages.imageFolder;
      case "folder":
      default:
        return TImages.folder;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: title,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 110,
          padding: EdgeInsets.all(10),
          child: Column(
            children: [
              Image.asset(
                _getFileIcon(fileType),
                height: 55,
                width: 60,
              ),
              const SizedBox(height: 6),
              /*Text(
                title,
                style: Theme.of(context)
                    .textTheme
                    .bodySmall!
                    .apply(color: Colors.black),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),*/
            ],
          ),
        ),
      ),
    );
  }
}
