import 'package:flutter/material.dart';

import '../../../../../../common/widget/app_bar/appbar.dart';
import '../../../../../../common/widget/background/title_with_glassy_theme.dart';
import '../../../../../../common/widget/menu/side_drawer_menu/side_menu.dart';

class ImageMaterial extends StatelessWidget {
  const ImageMaterial({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: SideMenuBar(),
        // bottomNavigationBar: OurBottomNavigationBar(),
        appBar: CustomAppBar(isMenuNeed: false),
      
        body: TitleWithGlassyTheme(
          title: '${title} >> Images',
      
          child: Text("---"),
          // child: GridView.builder(
          //   itemCount: 25,
          //   shrinkWrap: true,
          //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          //       crossAxisCount: THelperFunctions.screenWidth() > 600 ? 5 : 3,
          //       mainAxisExtent: 100,
          //       mainAxisSpacing: TSizes.xs,
          //       crossAxisSpacing: TSizes.xs),
          //   itemBuilder: (_, index) => FileTypeAndNameStructure(
          //     folderName: '${index + 1}. Course Java & Concepts',
          //     fileType: 'IMAGE',
          //     onTap: () {},
          //   ),
          // ),
        ),
      ),
    );
  }
}
