// // import 'package:flutter/material.dart';
// // import 'package:get/get.dart';
// // import 'package:webview_flutter/webview_flutter.dart';
// // import 'package:eapl_student_app/utils/loaders/loaders.dart';
// //
// // class MaterialWebViewController extends GetxController {
// //   final RxBool isLoading = true.obs;
// //   final WebViewController webViewController = WebViewController();
// //
// //   void initializeWebView(String url) {
// //     webViewController
// //       ..setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
// //       ..setNavigationDelegate(
// //         NavigationDelegate(
// //           onPageStarted: (String url) {
// //             isLoading.value = true;
// //           },
// //           onPageFinished: (String url) {
// //             isLoading.value = false;
// //             TSnackbar.successSnackbar(
// //               title: 'Document Loaded',
// //               message: 'Document viewer loaded successfully',
// //             );
// //           },
// //           onWebResourceError: (WebResourceError error) {
// //             isLoading.value = false;
// //             TSnackbar.errorSnackbar(
// //               title: 'Error',
// //               message: 'Failed to load document: ${error.description}',
// //             );
// //             Get.back();
// //           },
// //         ),
// //       )
// //       ..loadRequest(Uri.parse(url));
// //   }
// // }
// //
// // class MaterialWebView extends StatelessWidget {
// //   final String url;
// //
// //   const MaterialWebView({Key? key, required this.url}) : super(key: key);
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     final controller = Get.put(MaterialWebViewController());
// //     controller.initializeWebView(url);
// //
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text('Document Viewer'),
// //         backgroundColor: Theme.of(context).primaryColor,
// //       ),
// //       body: Obx(
// //             () => Stack(
// //           children: [
// //             WebViewWidget(controller: controller.webViewController),
// //             if (controller.isLoading.value)
// //               const Center(
// //                 child: CircularProgressIndicator(),
// //               ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
//
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:webview_flutter/webview_flutter.dart';
// import 'package:eapl_student_app/utils/loaders/loaders.dart';
//
// class MaterialWebViewController extends GetxController {
//   final RxBool isLoading = true.obs;
//   final WebViewController webViewController = WebViewController();
//
//   void initializeWebView(String url) {
//     webViewController
//       ..setUserAgent(
//           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
//       ..setNavigationDelegate(
//         NavigationDelegate(
//           onPageStarted: (String url) {
//             isLoading.value = true;
//           },
//           onPageFinished: (String url) {
//             isLoading.value = false;
//             TSnackbar.successSnackbar(
//               title: 'Document Loaded',
//               message: 'Document viewer loaded successfully',
//             );
//           },
//           onWebResourceError: (WebResourceError error) {
//             isLoading.value = false;
//             TSnackbar.errorSnackbar(
//               title: 'Error',
//               message: 'Failed to load document: ${error.description}',
//             );
//             Get.back();
//           },
//         ),
//       )
//       ..loadRequest(Uri.parse(url));
//   }
// }
//
// class MaterialWebView extends StatelessWidget {
//   final String url;
//
//   const MaterialWebView({Key? key, required this.url}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     final controller = Get.put(MaterialWebViewController());
//     controller.initializeWebView(url);
//
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Document Viewer'),
//         backgroundColor: Theme.of(context).primaryColor,
//       ),
//       body: Obx(
//             () => Stack(
//           children: [
//             WebViewWidget(controller: controller.webViewController),
//             if (controller.isLoading.value)
//               const Center(
//                 child: CircularProgressIndicator(),
//               ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:eapl_student_app/utils/loaders/loaders.dart';

import '../../../../../../utils/constants/colors.dart';

class MaterialWebViewController extends GetxController {
  final RxBool isLoading = true.obs;

  void initializeWebView(String url, InAppWebViewController controller) {
    controller.loadUrl(
      urlRequest: URLRequest(url: WebUri(url)),
    );
  }
}

class MaterialWebView extends StatelessWidget {
  final String url;

  const MaterialWebView({Key? key, required this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(MaterialWebViewController());

    return Scaffold(
      appBar: AppBar(
        title: const Text('Document Viewer'),
        centerTitle: true,

        backgroundColor: TColors.primary,
      ),
      body: Obx(
            () => Stack(
          children: [
            InAppWebView(
              initialUrlRequest: URLRequest(url: WebUri(url)),
              initialOptions: InAppWebViewGroupOptions(
                crossPlatform: InAppWebViewOptions(
                  userAgent:
                  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                  javaScriptEnabled: true,
                ),
              ),
              onWebViewCreated: (webViewController) {
                controller.initializeWebView(url, webViewController);
              },
              onLoadStart: (webViewController, url) {
                controller.isLoading.value = true;
              },
              onLoadStop: (webViewController, url) {
                controller.isLoading.value = false;
                TSnackbar.successSnackbar(
                  title: 'Document Loaded',
                  message: 'Document viewer loaded successfully',
                );
              },
              onLoadError: (webViewController, url, code, message) {
                controller.isLoading.value = false;
                TSnackbar.errorSnackbar(
                  title: 'Error',
                  message: 'Failed to load document: $message',
                );
                Get.back();
              },
            ),
            if (controller.isLoading.value)
              const Center(
                child: CircularProgressIndicator(),
              ),
          ],
        ),
      ),
    );
  }
}