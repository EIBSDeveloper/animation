
import 'dart:io';

import 'package:flutter_pdfview/flutter_pdfview.dart';

import '../../../../../../utils/constants/path_provider.dart';
import '../../../../../../utils/loaders/loaders.dart';

class MaterialPDFViewScreen extends StatelessWidget {
  final String? filePath;

  const MaterialPDFViewScreen({Key? key, required this.filePath}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (filePath == null || !File(filePath!).existsSync()) {
      Future.microtask(() {
        TSnackbar.errorSnackbar(
          title: 'Error',
          message: 'PDF file not found or has been deleted.',
        );
        Navigator.pop(context);
      });

      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('PDF Viewer',),
          backgroundColor: TColors.primary,
          centerTitle: true,
        ),
        body: PDFView(filePath: filePath!),
      ),
    );
  }
}
