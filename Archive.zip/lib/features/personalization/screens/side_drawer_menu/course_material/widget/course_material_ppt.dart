import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../common/widget/app_bar/appbar.dart';
import '../../../../../../common/widget/background/title_with_glassy_theme.dart';
import '../../../../../../common/widget/menu/side_drawer_menu/side_menu.dart';

class PptMaterial extends StatelessWidget {
  const PptMaterial({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: SideMenuBar(),
        appBar: CustomAppBar(),
        body: TitleWithGlassyTheme(
          child: Text("---"),
          title: '${title} >> PPT',
      
          // child: GridView.builder(
          //   itemCount: 25,
          //   shrinkWrap: true,
          //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          //       crossAxisCount: THelperFunctions.screenWidth() > 600 ? 5 : 3,
          //       mainAxisExtent: 100,
          //       mainAxisSpacing: TSizes.xs,
          //       crossAxisSpacing: TSizes.xs),
          //   itemBuilder: (_, index) => FileTypeAndNameStructure(
          //     folderName: '${index + 1}. Course Java & Concepts',
          //     fileType: 'PPT',
          //     onTap: () {},
          //   ),
          // ),
        ),
        floatingActionButton: Align(
          alignment: Alignment.bottomLeft,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 30.0, left: 40.0),
            child: FloatingActionButton(
              onPressed: () {
                Get.back();
              },
              backgroundColor: TColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(50.0),
              ),
              child: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
