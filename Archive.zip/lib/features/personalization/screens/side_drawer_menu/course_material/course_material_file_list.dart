/*
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/course_material/widget/course_material_file_type_folder_structure.dart';
import 'package:eapl_student_app/utils/constants/sizes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../common/widget/app_bar/appbar.dart';
import '../../../../../common/widget/background/title_with_glassy_theme.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/helpers/helper_functions.dart';
import '../../../../../utils/loaders/animation_loaders.dart';
import '../../../controllers/side_drawer_controller/material_course_controller.dart';

class CourseMaterialFileList extends StatelessWidget {
  const CourseMaterialFileList({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CourseMaterialController());
    return Scaffold(
      // drawer: const SideMenuBar(),
      appBar: const CustomAppBar(
        isMenuNeed: false,
      ),
      body: Stack(
        children: [
          TitleWithGlassyTheme(
              glassHeight: THelperFunctions.screenWidth() > 600
                  ? THelperFunctions.screenHeight() / 1.25
                  : THelperFunctions.screenHeight() / 1.6,
              title: 'Course Material',
              child: Padding(
                padding: EdgeInsets.all(TSizes.defaultSpace),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.all(TSizes.defaultSpace),
                        child: Obx(
                          () {
                            if (controller.isLoading.value)
                              return TAnimationLoaderWidget(
                                  text: "Loading...",
                                  animation: TImages.pencilAnimation);
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (THelperFunctions.screenWidth() > 600)
                                  Text('Course Material',
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineMedium),
                                if (controller.courseMaterialList.value!
                                    .courseMaterials.isEmpty)
                                  Center(child: Text("There is No Material ")),
                                Expanded(
                                  child: GridView.builder(
                                    itemCount: controller.courseMaterialList
                                        .value?.courseMaterials.length,
                                    gridDelegate:
                                        SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount: 3,
                                            mainAxisExtent: 120,
                                            mainAxisSpacing: TSizes.xs,
                                            crossAxisSpacing: TSizes.sm),
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      var course =
                                          controller.courseMaterialList.value;
                                      return MaterialFolderStructureAndName(
                                        onTap: () {
                                          if (controller.isDownloading.value) {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              const SnackBar(
                                                content: Text(
                                                    'Download already in progress'),
                                              ),
                                            );
                                            return;
                                          }

                                          final courseAttachment = controller
                                              .courseMaterialList
                                              .value
                                              ?.courseMaterials[index]
                                              .url;
                                          if (courseAttachment != null) {
                                            // controller.downloadFile(
                                            //     context, courseAttachment);
                                            controller.viewFileInApp(
                                                context, courseAttachment);
                                          } else {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              const SnackBar(
                                                  content: Text(
                                                      'There is no Document')),
                                            );
                                          }
                                        },
                                        fileType: course!.folderName,
                                        title: course.folderName,
                                      );
                                    },
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              )),
          Obx(
            () => controller.downloadProgressInMP.value > 0 &&
                    controller.downloadProgressInMP.value < 1
                ? Center(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 10,
                            spreadRadius: 2,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      padding: EdgeInsets.all(20),
                      height: 120,
                      width: 120,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            value: controller.downloadProgressInMP.value,
                            backgroundColor: Colors.grey[300],
                            color: Colors.blue,
                            strokeWidth: 6,
                          ),
                          SizedBox(height: 8),
                          Text(
                            '${(controller.downloadProgressInMP.value * 100).toStringAsFixed(0)}%',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
      floatingActionButton: Align(
        alignment: Alignment.bottomLeft,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 30.0, left: 40.0),
          child: FloatingActionButton(
            onPressed: () {
              Get.back();
              // Add your onPressed code here!
            },
            backgroundColor: TColors.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50.0),
            ),
            child: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
*/
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/course_material/widget/course_material_file_type_folder_structure.dart';
import 'package:eapl_student_app/utils/constants/sizes.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/helpers/helper_functions.dart';
import '../../../../../utils/loaders/animation_loaders.dart';
import '../../../controllers/side_drawer_controller/material_course_controller.dart';

class CourseMaterialFileList extends StatelessWidget {
  final controller = Get.put(CourseMaterialController());
  CourseMaterialFileList({super.key});

  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.downloadtour) ?? false;

      if (!controller.isdownloadTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.DownloadTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.downloadtour, true);
        controller.isdownloadTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    return SafeArea(
      child: WillPopScope(
        onWillPop: () async {
          // ✅ Return false if a download is in progress
          if (controller.downloadProgressInMP.value > 0 &&
              controller.downloadProgressInMP.value < 1) {
            Fluttertoast.showToast(
              msg: "Cannot leave while download is in progress",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              backgroundColor: TColors.primary,
              textColor: Colors.white,
              fontSize: 14.0,
            );
            return false; // prevent back
          }
          return true; // allow back
        },
        child: Scaffold(
          body: Stack(
            children: [
              Column(
                children: [
                  // 🔹 Header Container
                  CustomHeader(title: "Course Materials"),
      
                  // 🔹 Main Content
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.all(TSizes.defaultSpace),
                      child: Obx(
                        () {
                          if (controller.isLoading.value) {
                            return TAnimationLoaderWidget(
                              text: "Loading...",
                              animation: TImages.pencilAnimation,
                            );
                          }
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (THelperFunctions.screenWidth() > 600)
                                Text(
                                  'Course Material',
                                  style:
                                      Theme.of(context).textTheme.headlineMedium,
                                ),
                              if (controller.courseMaterialList.value!
                                  .courseMaterials.isEmpty)
                                const Center(
                                    child: Text("There is No Material ")),
                              Expanded(
                                child: GridView.builder(
                                  itemCount: controller.courseMaterialList.value
                                      ?.courseMaterials.length,
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    mainAxisExtent: 120,
                                    mainAxisSpacing: TSizes.xs,
                                    crossAxisSpacing: TSizes.sm,
                                  ),
                                  itemBuilder: (BuildContext context, int index) {
                                    var course =
                                        controller.courseMaterialList.value;
                                    return MaterialFolderStructureAndName(
                                      key: index == 0
                                          ? controller.downloadKey
                                          : null, // ✅ Only first item gets the key
                                      onTap: () {
                                        if (controller.isDownloading.value) {
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            const SnackBar(
                                              content: Text(
                                                  'Download already in progress'),
                                            ),
                                          );
                                          return;
                                        }
      
                                        final courseAttachment = controller
                                            .courseMaterialList
                                            .value
                                            ?.courseMaterials[index]
                                            .url;
                                        if (courseAttachment != null) {
                                          controller.viewFileInApp(
                                              context, courseAttachment);
                                        } else {
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            const SnackBar(
                                              content:
                                                  Text('There is no Document'),
                                            ),
                                          );
                                        }
                                      },
                                      fileType: course!.folderName,
                                      title: course.folderName,
                                    );
                                  },
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
      
              // 🔹 Progress Overlay
              Obx(
                () => controller.downloadProgressInMP.value > 0 &&
                        controller.downloadProgressInMP.value < 1
                    ? Center(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                spreadRadius: 2,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(20),
                          height: 120,
                          width: 120,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(
                                value: controller.downloadProgressInMP.value,
                                backgroundColor: Colors.grey[300],
                                color: Colors.blue,
                                strokeWidth: 6,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                '${(controller.downloadProgressInMP.value * 100).toStringAsFixed(0)}%',
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
