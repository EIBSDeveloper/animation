/*import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/course_material/widget/course_material_file_type_folder_structure.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';

import '../../../../../common/widget/background/title_with_glassy_theme.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/helpers/helper_functions.dart';
import '../../../../../utils/loaders/animation_loaders.dart';
import '../../../controllers/side_drawer_controller/material_course_controller.dart';
import 'course_material_folder_list.dart';

class MaterialCourseList extends StatelessWidget {
  const MaterialCourseList({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CourseMaterialController());
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.fetchCourseListFolder();
    });

    return Scaffold(
      */ /*drawer: const SideMenuBar(),
      appBar: const CustomAppBar(),*/ /*
      body: TitleWithGlassyTheme(
        glassHeight: 400,
        title: 'Course material List',
        child: Padding(
          padding: EdgeInsets.all(TSizes.defaultSpace),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (THelperFunctions.screenWidth() > 600)
                  Text(
                    'Course List',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                Obx(
                  () {
                    if (!controller.isLoading.value &&
                        controller.courseListFolder.isEmpty) {
                      return Center(child: Text("No Materials Found"));
                    }
                    if (controller.isLoading.value) {
                      return TAnimationLoaderWidget(
                          text: "Loading...",
                          animation: TImages.pencilAnimation);
                    }
                    */ /*return Expanded(
                      child: GridView.builder(
                        // shrinkWrap: true,
                        // scrollDirection: Axis.horizontal,
                        itemCount: controller.courseListFolder.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: THelperFunctions.screenWidth() > 600
                              ? THelperFunctions.islandscape()
                                  ? 5
                                  : 4
                              : 3,
                          mainAxisExtent: 120,
                          mainAxisSpacing: TSizes.xs,
                          crossAxisSpacing: TSizes.sm,
                        ),
                        itemBuilder: (BuildContext context, int index) {
                          var course = controller.courseListFolder[index];

                          return MaterialFolderStructureAndName(
                            onTap: () {
                              Get.to(() => CourseMaterialFolderView(
                                  courseModel: course));
                            },
                            fileType: 'FOLDER',
                            title: course.courseName,
                          );
                        },
                      ),
                    );*/ /*
                    return SizedBox(
                      // ✅ Replace Expanded with SizedBox and give height
                      height:
                          400, // or MediaQuery.of(context).size.height * 0.6
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics:
                            NeverScrollableScrollPhysics(), // Prevent nested scroll conflict
                        itemCount: controller.courseListFolder.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: THelperFunctions.screenWidth() > 600
                              ? THelperFunctions.islandscape()
                                  ? 5
                                  : 4
                              : 3,
                          mainAxisExtent: 120,
                          mainAxisSpacing: TSizes.xs,
                          crossAxisSpacing: TSizes.sm,
                        ),
                        itemBuilder: (BuildContext context, int index) {
                          var course = controller.courseListFolder[index];
                          return MaterialFolderStructureAndName(
                            onTap: () {
                              Get.to(() => CourseMaterialFolderView(
                                  courseModel: course));
                            },
                            fileType: 'FOLDER',
                            title: course.courseName,
                          );
                        },
                      ),
                    );
                  },
                ),
                // Display download progress as a linear progress indicator
              ],
            ),
          ),
        ),
      ),
    );
  }
}*/

/*import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/material_course_controller.dart';
import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:eapl_student_app/utils/loaders/animation_loaders.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/helpers/helper_functions.dart';
import 'course_material_folder_list.dart';

class MaterialCourseList extends StatelessWidget {
  final controller = Get.put(CourseMaterialController());
  MaterialCourseList({super.key});
  void _showTourOnce(BuildContext context) {
    // Only show tutorial if not already shown
    if (!controller.isMaterialTouron.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final isTutorialShown = GetStorage().read(TTexts.materialtour) ?? false;

        if (!isTutorialShown && controller.courseListFolder.isNotEmpty) {
          // Small delay to ensure Overlay exists
          await Future.delayed(const Duration(milliseconds: 1000));

          await controller.MaterialTour(context);

          // Mark tutorial as shown
          GetStorage().write(TTexts.materialtour, true);
          controller.isMaterialTouron.value = true;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.fetchCourseListFolder();
    });

    return Scaffold(
      body: Column(
        children: [
          CustomHeader(title: "Course Materials"),

          /// Course Material List
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10),
            height: 600,
            width: double.infinity,
            decoration: BoxDecoration(
              color: TColors.sandal,
              border: Border.all(color: TColors.grey),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Padding(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              child: Obx(
                () {
                  if (controller.isLoading.value) {
                    return Center(
                      child: TAnimationLoaderWidget(
                        text: "Loading...",
                        animation: TImages.pencilAnimation,
                      ),
                    );
                  } else if (controller.courseListFolder.isEmpty) {
                    return Center(
                      child: Text(
                        "No Materials Found",
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    );
                  }
                  _showTourOnce(context);
                  return ListView.builder(
                    itemCount: controller.courseListFolder.length,
                    itemBuilder: (context, index) {
                      var course = controller.courseListFolder[index];
                      double progress = double.tryParse(
                              course.courseCompletePercentage ?? "0.0") ??
                          0.0;

                      return Container(
                        height: 140,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 5),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: Colors.grey.shade300, width: 0.8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            /// Title
                            Text(
                              "${course.courseVersion} ${course.courseName}",
                              style: GoogleFonts.prompt(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 15),

                            /// Progress Row
                            Row(
                              children: [
                                /// Progress Bar
                                SizedBox(
                                  width: 195,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: LinearProgressIndicator(
                                      value: progress / 100,
                                      minHeight: 6,
                                      backgroundColor: Colors.grey.shade300,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          TColors.primary),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),

                                /// Percentage
                                Text(
                                  "${progress.toStringAsFixed(0)}%",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black87,
                                  ),
                                ),
                                const SizedBox(width: 10),
                              ],
                            ),
                            const SizedBox(height: 10),

                            /// Info Row
                            Row(
                              children: [
                                /// Category
                                Expanded(
                                  flex: 3,
                                  child: Row(
                                    children: [
                                      Image.asset(
                                        TImages.category,
                                        width: 25,
                                        height: 25,
                                        fit: BoxFit.contain,
                                      ),
                                      const SizedBox(width: 5),
                                      Flexible(
                                        child: Text(
                                          course.courseSubcategoryName ?? '---',
                                          style: GoogleFonts.prompt(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          softWrap: false,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                /// Duration
                                Expanded(
                                  flex: 2,
                                  child: Row(
                                    children: [
                                      Image.asset(
                                        TImages.calender,
                                        width: 25,
                                        height: 25,
                                        fit: BoxFit.contain,
                                      ),
                                      const SizedBox(width: 5),
                                      Flexible(
                                        child: Text(
                                          '${course.courseCompletedDays}/${course.courseDuration}',
                                          style: GoogleFonts.prompt(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          softWrap: false,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                /// Materials Button
                                SizedBox(
                                  key: index == 0
                                      ? controller.materialKey
                                      : null, // ✅ only first
                                  height: 35,
                                  width: 100,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      Get.to(() => CourseMaterialFolderView(
                                            courseModel: course,
                                          ));
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: TColors.primary,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      padding: EdgeInsets.zero,
                                      elevation: 0,
                                    ),
                                    child: Text(
                                      'Materials',
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        color: TColors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}*/
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../common/widget/app_bar/customheader.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/loaders/animation_loaders.dart';
import '../../../controllers/side_drawer_controller/material_course_controller.dart';
import 'course_material_folder_list.dart';

class MaterialCourseList extends StatelessWidget {
  final controller = Get.put(CourseMaterialController());
  MaterialCourseList({super.key});

  void _showTourOnce(BuildContext context) {
    if (!controller.isMaterialTouron.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final isTutorialShown = GetStorage().read(TTexts.materialtour) ?? false;

        if (!isTutorialShown && controller.courseListFolder.isNotEmpty) {
          await Future.delayed(const Duration(milliseconds: 1000));
          await controller.MaterialTour(context);

          // Mark tutorial as shown
          GetStorage().write(TTexts.materialtour, true);
          controller.isMaterialTouron.value = true;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.fetchCourseListFolder();
    });

    return SafeArea(
      child: Scaffold(
        body: Obx(() {
          if (controller.isLoading.value) {
            return Center(
              child: TAnimationLoaderWidget(
                text: "Loading...",
                animation: TImages.pencilAnimation,
              ),
            );
          }
      
          _showTourOnce(context);
      
          if (controller.courseListFolder.isEmpty) {
            return Center(
              child: Text(
                "No Materials Found",
                style: Theme.of(context).textTheme.titleMedium,
              ),
            );
          }
      
          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: CustomHeader(title: "Course Materials"),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      var course = controller.courseListFolder[index];
                      double progress = double.tryParse(
                              course.courseCompletePercentage ?? "0.0") ??
                          0.0;
      
                      return Container(
                        height: 140,
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border:
                              Border.all(color: Colors.grey.shade300, width: 0.8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Title
                            Text(
                              "${course.courseName}",
                              style: GoogleFonts.prompt(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 15),
      
                            // Progress Row
                            Row(
                              children: [
                                // Progress Bar
                                SizedBox(
                                  width: 195,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: LinearProgressIndicator(
                                      value: progress / 100,
                                      minHeight: 6,
                                      backgroundColor: Colors.grey.shade300,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        TColors.primary,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
      
                                // Percentage
                                Text(
                                  "${progress.toStringAsFixed(0)}%",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black87,
                                  ),
                                ),
                                const SizedBox(width: 10),
                              ],
                            ),
                            const SizedBox(height: 10),
      
                            // Info Row
                            Row(
                              children: [
                                // Category
                                Expanded(
                                  flex: 3,
                                  child: Row(
                                    children: [
                                      Image.asset(
                                        TImages.category,
                                        width: 25,
                                        height: 25,
                                        fit: BoxFit.contain,
                                      ),
                                      const SizedBox(width: 5),
                                      Flexible(
                                        child: Text(
                                          course.courseSubcategoryName ?? '---',
                                          style: GoogleFonts.prompt(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          softWrap: false,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
      
                                // Duration
                                Expanded(
                                  flex: 2,
                                  child: Row(
                                    children: [
                                      Image.asset(
                                        TImages.calender,
                                        width: 25,
                                        height: 25,
                                        fit: BoxFit.contain,
                                      ),
                                      const SizedBox(width: 5),
                                      Flexible(
                                        child: Text(
                                          '${course.courseCompletedDays}/${course.courseDuration}',
                                          style: GoogleFonts.prompt(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          softWrap: false,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
      
                                // Materials Button
                                SizedBox(
                                  key: index == 0 ? controller.materialKey : null,
                                  height: 35,
                                  width: 100,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      Get.to(() => CourseMaterialFolderView(
                                            courseModel: course,
                                          ));
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: TColors.primary,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      padding: EdgeInsets.zero,
                                      elevation: 0,
                                    ),
                                    child: Text(
                                      'Materials',
                                      style: GoogleFonts.prompt(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        color: TColors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                    childCount: controller.courseListFolder.length,
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: SizedBox(height: 20),
              ),
            ],
          );
        }),
      ),
    );
  }
}
