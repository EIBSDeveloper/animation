import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../../../../common/widget/course/course_detail_card.dart';
import '../../../../../../common/widget/custom_calender/calender_box_style.dart';
import '../../../../../../utils/constants/path_provider.dart';
import '../../../controllers/side_drawer_controller/attendance_controller.dart';
import '../../../controllers/side_drawer_controller/course_controller.dart';
import 'widget/class_shedule_topic_dialog.dart';

class ClassSchedulePage extends StatelessWidget {
  ClassSchedulePage({super.key});

  // final CourseDetailModel courseModel;

  @override
  Widget build(BuildContext context) {
    final courseController = Get.find<CourseController>();
    AttendanceController controller = Get.put(AttendanceController());

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      courseController.fetchCourses();
      controller.fetchDailyStreakController(
          courseId: courseController
              .coursesList[courseController.courseListIndex.value].courseSno
              .toString());
    });

    return SafeArea(
      child: Scaffold(
        /*drawer: const SideMenuBar(),
        appBar: const CustomAppBar(),*/
        body: OurBackgroundTheme(
          child: Column(
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    /*SizedBox(
                      width: THelperFunctions.screenWidth(),
                      height: 40,
                      child: ListView.separated(
                        itemCount: courseController.coursesList.length,
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                        separatorBuilder: (BuildContext context, int index) =>
                            SizedBox(width: 10),
                        itemBuilder: (_, index) {
                          return InkWell(
                            onTap: () {
                              courseController.courseListIndex.value = index;
      
                              controller.fetchDailyStreakController(
                                  courseId: courseController
                                      .coursesList[
                                          courseController.courseListIndex.value]
                                      .courseSno
                                      .toString());
                              print(
                                  "Couresno: ${courseController.coursesList[courseController.courseListIndex.value].courseSno.toString()}");
                            },
                            child: Obx(
                              () => Container(
                                width: 200,
                                decoration: BoxDecoration(
                                  color: courseController.courseListIndex.value ==
                                          index
                                      ? TColors.classCompleted
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(
                                      8), // Increased border radius for a smoother look
                                  border: Border.all(
                                      color: TColors.grey.withOpacity(0.5),
                                      width: 1), // Softer border
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(
                                          0.05), // Light shadow for depth
                                      blurRadius: 4,
                                      offset: const Offset(2, 2),
                                    ),
                                  ],
                                ),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 4,
                                    horizontal: 8), // More balanced padding
                                margin: const EdgeInsets.all(2),
                                child: Center(
                                  child: Text(
                                    courseController
                                        .coursesList[index].courseName,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize:
                                          14, // Slightly larger font size for readability
                                      fontWeight: FontWeight
                                          .w500, // Medium weight for a professional look
                                      color: courseController
                                                  .courseListIndex.value ==
                                              index
                                          ? TColors.white
                                          : Colors
                                              .black, // Slightly darker text for better contrast
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),*/
                    SizedBox(
                      height: 40,
                      width: THelperFunctions.screenWidth(),
                      child: ListView.separated(
                        itemCount: courseController.coursesList.length,
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                        separatorBuilder: (BuildContext context, int index) =>
                            SizedBox(width: 10),
                        itemBuilder: (_, index) {
                          return Obx(
                            () => InkWell(
                              onTap: () {
                                courseController.courseListIndex.value = index;
                                controller.fetchDailyStreakController(
                                  courseId: courseController
                                      .coursesList[index].courseSno
                                      .toString(),
                                );
                              },
                              child: Container(
                                width: 200,
                                decoration: BoxDecoration(
                                  color: courseController.courseListIndex.value ==
                                          index
                                      ? TColors.classCompleted
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: TColors.grey.withOpacity(0.5),
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.05),
                                      blurRadius: 4,
                                      offset: Offset(2, 2),
                                    ),
                                  ],
                                ),
                                padding: EdgeInsets.symmetric(
                                    vertical: 4, horizontal: 8),
                                margin: EdgeInsets.all(2),
                                child: Center(
                                  child: Text(
                                    courseController
                                        .coursesList[index].courseName,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                      color: courseController
                                                  .courseListIndex.value ==
                                              index
                                          ? TColors.white
                                          : Colors.black,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  ],
                ),
              ),
              Obx(
                () => CourseDetailsCard(
                  courseModel: courseController
                      .coursesList[courseController.courseListIndex.value],
                ),
              ),
              // SizedBox(height: TSizes.sm),
      
              /// Calender Table
              Expanded(
                child: Container(
                  // height: THelperFunctions.screenWidth() > 600
                  //     ? THelperFunctions.screenHeight() / 1.25
                  //     : THelperFunctions.screenHeight() / 1.4,
                  decoration: BoxDecoration(
                      color: TColors.lightimportant.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(7.0),
                      border: Border.all(color: TColors.grey)),
                  child: Obx(
                    () {
                      if (controller.isLoading.value == true) {
                        return const TAnimationLoaderWidget(
                          text: "Loading...",
                          animation: TImages.pencilAnimation,
                        );
                      }
      
                      return SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.all(TSizes.sm),
                              // decoration: BoxDecoration(
                              //     // color: TColors.lightimportant.withOpacity(0.9),
                              //     borderRadius: BorderRadius.circular(7.0),
                              //     border: Border.all(color: TColors.grey)),
                              child: TableCalendar(
                                availableGestures: AvailableGestures.none,
                                pageAnimationEnabled: true,
                                pageJumpingEnabled: true,
                                firstDay: DateTime.utc(1998, 02, 26),
                                lastDay: DateTime.utc(2100, 02, 26),
                                focusedDay: controller.focusedDay.value,
                                calendarFormat: controller.calendarFormat.value,
                                selectedDayPredicate: (day) {
                                  return isSameDay(
                                      controller.selectedDay!.value, day);
                                },
                                onDaySelected: (selectedDay, focusedDay) {
                                  controller.selectedDay!.value = selectedDay;
                                  controller.focusedDay.value = focusedDay;
                                },
                                onPageChanged: (focusedDay) {
                                  controller.focusedDay.value = focusedDay;
                                },
                                calendarStyle: const CalendarStyle(
                                    weekendTextStyle:
                                        TextStyle(color: Colors.red),
                                    holidayTextStyle:
                                        TextStyle(color: Colors.red)),
                                headerStyle: const HeaderStyle(
                                  formatButtonVisible: false,
                                  titleCentered: true,
                                  decoration: BoxDecoration(
                                    color: Colors.transparent,
                                  ),
                                  // headerMargin: EdgeInsets.only(bottom: 8.0),
                                  titleTextStyle: TextStyle(
                                    color: TColors.primary,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18.0,
                                  ),
                                  leftChevronIcon: Icon(
                                    Icons.chevron_left,
                                    color: TColors.primary,
                                  ),
                                  rightChevronIcon: Icon(
                                    Icons.chevron_right,
                                    color: TColors.primary,
                                  ),
                                ),
                                daysOfWeekStyle: const DaysOfWeekStyle(
                                  weekendStyle: TextStyle(
                                    color: Colors.red,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14, // Increase if text still small
                                  ),
                                  weekdayStyle: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600,
                                    fontSize:
                                        14, // Make sure this is not too small
                                  ),
                                ),
                                eventLoader: controller.getEventsForDay,
                                calendarBuilders: CalendarBuilders(
                                  defaultBuilder: (context, date, _) {
                                    controller.dailyStreakModel.map(
                                        (element) => element.attendanceSyllabus);
                                    for (var attendanceModel
                                        in controller.dailyAttendanceList) {
                                      // Use isSameDay() to compare dates ignoring time
                                      if (isSameDay(
                                              DateFormat("yyyy-MM-dd").parse(
                                                  attendanceModel.date ?? ''),
                                              date) &&
                                          attendanceModel.attendance == 'P') {
                                        return CalenderBoxStyle(
                                          date: date,
                                          message: "",
                                          backgroundColor: TColors.primary,
                                          onTap: () {
                                            Get.dialog(ClassScheduleTopicDialog(
                                              date:
                                                  '${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}',
                                              courseId: courseController
                                                  .coursesList[courseController
                                                      .courseListIndex.value]
                                                  .courseSno
                                                  .toString(),
                                              dateByUploadFormat:
                                                  '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
                                            ));
                                          },
                                        );
                                      }
                                      if (isSameDay(
                                              DateFormat("yyyy-MM-dd").parse(
                                                  attendanceModel.date ?? ''),
                                              date) &&
                                          attendanceModel.attendance == 'A') {
                                        return CalenderBoxStyle(
                                          date: date,
                                          message: "",
                                          backgroundColor: TColors.importantText,
                                          onTap: () {
                                            Get.dialog(ClassScheduleTopicDialog(
                                              date:
                                                  '${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}',
                                              courseId: courseController
                                                  .coursesList[courseController
                                                      .courseListIndex.value]
                                                  .courseSno
                                                  .toString(),
                                              dateByUploadFormat:
                                                  '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
                                            ));
                                          },
                                        );
                                      }
                                    }
      
                                    return null;
                                  },
                                  todayBuilder: (context, date, _) {
                                    return CalenderBoxStyle(
                                      date: date,
                                      message: "Today",
                                      backgroundColor: controller.absentClass
                                              .contains(date)
                                          ? TColors.absentOrLeave
                                          : controller.fillFeedback.contains(date)
                                              ? TColors.needToFillFeedback
                                              : controller.classCompleted.value
                                                      .contains(date)
                                                  ? TColors.classCompleted
                                                  : controller.upcomingClasses
                                                          .contains(date)
                                                      ? TColors.upcomingClasses
                                                      : Colors.green,
                                      onTap: () {
                                        if (controller.absentClass
                                            .contains(date)) {
                                          Get.dialog(AlertDialog(
                                            title: Text(
                                                '${date.day}-${date.month}-${date.year}'),
                                          ));
                                        }
                                        if (controller.classCompleted.value
                                            .contains(date)) {
                                          Get.dialog(AlertDialog(
                                            title: Text(
                                                '${date.day}-${date.month}-${date.year}'),
                                          ));
                                        }
                                      },
                                    );
                                  },
                                  selectedBuilder: (context, date, _) {
                                    return CalenderBoxStyle(
                                      date: date,
                                      message: '',
                                      backgroundColor: controller.absentClass
                                              .contains(date)
                                          ? TColors.absentOrLeave
                                          : controller.fillFeedback.contains(date)
                                              ? TColors.needToFillFeedback
                                              : controller.classCompleted.value
                                                      .contains(date)
                                                  ? TColors.classCompleted
                                                  : controller.upcomingClasses
                                                          .contains(date)
                                                      ? TColors.upcomingClasses
                                                      : Colors.green,
                                      onTap: () {},
                                    );
                                  },
                                  markerBuilder: (context, date, events) {
                                    return Container(
                                      width: 0,
                                      height: 0,
                                      decoration: const BoxDecoration(
                                        color: Colors.transparent,
                                        shape: BoxShape.circle,
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
