import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/attendance_controller.dart';

import '../../../../../../../utils/constants/path_provider.dart';

class ClassScheduleTopicDialog extends StatelessWidget {
  ClassScheduleTopicDialog(
      {super.key,
      required this.date,
      required this.courseId,
      required this.dateByUploadFormat});

  final String date;
  // final DailyStreakModel attendanceModel;
  final String courseId;
  final String dateByUploadFormat;

  @override
  Widget build(BuildContext context) {
    final controller = AttendanceController.instance;
    print("formated Date : $dateByUploadFormat");
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.fetchDailyStreakController(
          courseId: courseId, date: dateByUploadFormat, isAlertDialog: true);
    });

    // double rating = 3.0;
    Color activeColor = Colors.red;

    return Dialog(
        child: Stack(
      children: [
        Container(
          margin: const EdgeInsets.all(TSizes.md),
          child: SingleChildScrollView(
            child: Obx(
              () {
                if (controller.isDialogLoading.value) {
                  return const TAnimationLoaderWidget(
                    text: "Loading...",
                    animation: TImages.pencilAnimation,
                  );
                }
                if (controller.dailyAttendanceList.isEmpty) {
                  return const Center(child: Text("There is No Class Details"));
                }
                return Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    /// Date
                    Card(
                      color: Colors.red,
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Text(
                          '$date',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium!
                              .apply(color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(height: TSizes.xs),

                    /// Topic Covered
                    Text("Topic Covered",
                        style: Theme.of(context).textTheme.bodyLarge),
                    const SizedBox(height: TSizes.sm),
                    controller.feedbackTopicList.isNotEmpty
                        ? ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: controller.feedbackTopicList[0].length,
                            itemBuilder: (BuildContext context, int index) {
                              return Text(
                                ' * ${controller.feedbackTopicList[0][index]}',
                                style: Theme.of(context)
                                    .textTheme
                                    .labelLarge!
                                    .apply(color: TColors.primary),
                              );
                            },
                          )
                        : Text(
                            "No topics available",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),

                    Center(
                      child: ElevatedButton(
                          onPressed: () {
                            Get.back();
                          },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: TColors.importantText,
                              side: const BorderSide(
                                  color: TColors.importantText)),
                          child: const Text("Back")),
                    )
                  ],
                );
              },
            ),
          ),
        ),
        Positioned(
          top: 8,
          right: 15,
          child: GestureDetector(
            onTap: () => Get.back(),
            child: const Icon(Icons.close, color: Colors.black),
          ),
        ),
      ],
    ));
  }
}
