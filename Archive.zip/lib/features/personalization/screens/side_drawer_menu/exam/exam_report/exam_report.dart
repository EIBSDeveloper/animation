import 'package:eapl_student_app/common/widget/app_bar/appbar.dart';
import 'package:eapl_student_app/common/widget/menu/side_drawer_menu/side_menu.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_report/exam_report_controller.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_report/widget/report_question_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../common/widget/background/background_theme.dart';
import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/enums.dart';
import '../../../../../../utils/constants/image_strings.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../../../utils/helpers/helper_functions.dart';
import '../../../../../../utils/loaders/animation_loaders.dart';

class ExamReport extends StatelessWidget {
  const ExamReport({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ExamReportController());

    return SafeArea(
      child: Scaffold(
          drawer: SideMenuBar(),
          appBar: CustomAppBar(),
          body: OurBackgroundTheme(
            child: Obx(
              () {
                if (controller.isLoading.value) {
                  return const TAnimationLoaderWidget(
                    text: "Loading...",
                    animation: TImages.pencilAnimation,
                  );
                }
                return Column(
                  children: [
                    ///================== EXAM TITLE CARD ===============////
                    Card(
                      // margin: const EdgeInsets.symmetric(vertical: TSizes.sm,),
                      color: TColors.lightAsh,
                      child: Container(
                        decoration: BoxDecoration(
                            color: TColors.lightAsh,
                            borderRadius: BorderRadius.circular(10)),
                        padding: const EdgeInsets.all(TSizes.sm),
                        width: double.infinity,
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  controller.examReport.first.examName,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleMedium!
                                      .apply(color: TColors.importantText),
                                ),
                                // const InkWell(
                                //     child: Icon(
                                //   Icons.info,
                                //   color: TColors.primary,
                                //   size: TSizes.iconLg,
                                // ))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
      
                    const SizedBox(height: TSizes.md),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                width: double.infinity,
                                padding:
                                    const EdgeInsets.all(TSizes.defaultSpace),
                                decoration: BoxDecoration(
                                    color:
                                        TColors.lightimportant.withOpacity(0.85),
                                    border: Border.all(color: TColors.grey),
                                    borderRadius: BorderRadius.circular(4.0)),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Exam Report",
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineSmall!
                                          .apply(color: TColors.textPrimary)
                                          .copyWith(fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      height: TSizes.spaceBtwItems,
                                    ),
                                    _buildDetailReportText(
                                        'Total Questions',
                                        controller.examReport.first.noOfQuestions
                                            .toString()),
                                    _buildDetailReportText(
                                        'Total Marks',
                                        controller.examProcesses.first.totalMarks
                                            .toString()),
                                    _buildDetailReportText(
                                        'Correct Answers',
                                        controller
                                            .examProcesses.first.studentMarks
                                            .toString(),
                                        color: TColors.correctAnswer),
                                    _buildDetailReportText('Total Duration',
                                        '${controller.examReport.first.examDuration} Mnts'),
                                    _buildDetailReportText('Attended Duration',
                                        '${controller.examProcesses.first.totalAttendedDuration} Mnts'),
                                    const SizedBox(height: TSizes.sm),
                                    const Divider(
                                        color: TColors.darkerGrey,
                                        indent: 10,
                                        endIndent: 10),
                                    const SizedBox(height: TSizes.xs),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("Student Score : ",
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleSmall),
                                        Text(
                                          controller
                                              .examProcesses.first.studentMarks
                                              .toString(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleLarge!
                                              .apply(
                                                  color: const Color(0xFF659724)),
                                        )
                                      ],
                                    ),
                                    const SizedBox(height: TSizes.xs),
                                    // Row(
                                    //   mainAxisAlignment:
                                    //       MainAxisAlignment.spaceBetween,
                                    //   children: [
                                    //     ElevatedButton(
                                    //         onPressed: () {},
                                    //         child: const Text("Ques Bank")),
                                    //     ElevatedButton(
                                    //         onPressed: controller.examReport.first
                                    //                     .certificate ==
                                    //                 'no'
                                    //             ? null
                                    //             : () {},
                                    //         style: ElevatedButton.styleFrom(
                                    //             backgroundColor:
                                    //                 TColors.buttonSecondary,
                                    //             side: const BorderSide(
                                    //                 color:
                                    //                     TColors.buttonSecondary)),
                                    //         child: const Text(
                                    //           "Certificate",
                                    //           style:
                                    //               TextStyle(color: Colors.black),
                                    //         ))
                                    //   ],
                                    // )
                                  ],
                                ),
                              ),
                              SizedBox(height: TSizes.sm),
                              ListView.separated(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: controller.questions.length,
                                separatorBuilder: (context, index) =>
                                    const SizedBox(height: TSizes.sm),
                                itemBuilder: (context, index) {
                                  return questionCard(
                                    question:
                                        controller.questions[index].questionName,
                                    inputType: QuestionType.radio,
                                    options: controller
                                        .questions[index].questionOptions,
                                    userAnswer: controller
                                            .questions[index].studentAnswer ??
                                        '',
                                    correctAnswer: controller
                                            .questions[index].correctAnswer ??
                                        '',
                                    status:
                                        controller.questions[index].correctness ??
                                            '',
                                    timeTaken:
                                        '${controller.questions[index].timeSpent} Sec ',
                                  );
                                },
                              )
                            ]),
                      ),
                    ),
                  ],
                );
              },
            ),
          )),
    );
  }

  Widget _buildDetailReportText(String label, String value,
      {Color color = TColors.primary}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        SizedBox(
          width: THelperFunctions.screenWidth() / 3,
          child: Text(
            label,
            style: Theme.of(Get.context!)
                .textTheme
                .bodySmall!
                .apply(color: Colors.black),
          ),
        ),
        const Spacer(),
        const Text(
          " : ",
          style: TextStyle(fontSize: 16),
        ),
        const Spacer(),
        SizedBox(
          width: THelperFunctions.screenWidth() / 3,
          child: Text(
            value.length == 1 ? '0$value' : value,
            style:
                Theme.of(Get.context!).textTheme.bodyLarge!.apply(color: color),
            textAlign: TextAlign.start,
          ),
        ),
      ],
    );
  }
}
