import 'package:eapl_student_app/utils/loaders/loaders.dart';
import 'package:get/get.dart';

import '../../../../../../utils/http/api_constants.dart';
import '../../../../../../utils/http/http_client.dart';
import '../../../../models/exam/exam_report_model.dart';
import '../exam_page/exam_controller.dart';

class ExamReportController extends GetxController {
  final isLoading = false.obs;
  List<QuestionReportModel> questions = [];
  List<ExamProcessModel> examProcesses = [];
  RxList<ExamReportModel> examReport = <ExamReportModel>[].obs;
  final examController = Get.put(ExamController());

  @override
  void onInit() {
    fetchExamReport();
  }

  Future<void> fetchExamReport() async {
    try {
      isLoading.value = true; // Show loading indicator
      final req = {
        "customer_id": "10",
        "exam_id": "4"

        // "exam_id": examController.examId
      };

      print("Report Request : ${req}");

      final response =
          await THttpHelper.post(APIConstants.examReportEndPoint, req);
      final examList = response['Exam list'] as List<dynamic>? ?? [];
      examReport.value =
          examList.map((item) => ExamReportModel.fromJson(item)).toList();

      // Parse questions
      final mergedQuestions =
          response['merged_questions'] as List<dynamic>? ?? [];
      questions = mergedQuestions
          .map((item) => QuestionReportModel.fromJson(item))
          .toList();

      final examProcessess = response['Exam Process'] as List<dynamic>? ?? [];
      examProcesses = examProcessess
          .map((item) => ExamProcessModel.fromJson(item))
          .toList();
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap", message: "Something Error please try again later");
      print("Error fetching Reports: $e");
    } finally {
      isLoading.value = false;
      // update();
    }
  }
}
