import 'package:flutter/material.dart';

import '../../../../../../../common/widget/button/CustomRadioBtn.dart';
import '../../../../../../../utils/constants/colors.dart';
import '../../../../../../../utils/constants/enums.dart';
import '../../../../../../../utils/constants/sizes.dart';

Widget questionCard({
  required String question,
  required QuestionType inputType,
  List<String>? options,
  required String userAnswer,
  required String correctAnswer,
  required String status,
  required String timeTaken,
}) {
  return LayoutBuilder(
    builder: (context, layout) {
      final isWide = layout.maxWidth > 600;

      return Material(
        color: Color(0xFBFAFD).withOpacity(0.8),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(2),
            side: BorderSide(color: TColors.grey)),
        elevation: 2.0,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      question,
                      style: Theme.of(context)
                          .textTheme
                          .bodyLarge!
                          .apply(color: Colors.black),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5.0),
              Container(
                padding: const EdgeInsets.all(TSizes.md),
                margin: const EdgeInsets.all(TSizes.md),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: _buildInputType(
                  context,
                  inputType,
                  userAnswer,
                  options,
                ),
              ),
              const SizedBox(height: 5.0),
              isWide
                  ? _buildWideLayout(context, status, timeTaken)
                  : _buildNarrowLayout(context, status, timeTaken),
            ],
          ),
        ),
      );
    },
  );
}

Widget _buildWideLayout(BuildContext context, String status, String timeTaken) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      _buildStatusContainer(context, status),
      _buildTimeInfoRow(context, timeTaken),
    ],
  );
}

Widget _buildNarrowLayout(
    BuildContext context, String status, String timeTaken) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _buildStatusContainer(context, status),
      _buildTimeInfoRow(context, timeTaken),
    ],
  );
}

Widget _buildStatusContainer(BuildContext context, String status) {
  return Container(
    height: 40,
    width: 180,
    padding: const EdgeInsets.all(5),
    decoration: BoxDecoration(
      color: status == 'correct' ? TColors.attempted : TColors.notAttempted,
      borderRadius: BorderRadius.circular(50),
    ),
    child: Center(
      child: Text(
        ' $status'.toUpperCase(),
        style: Theme.of(context).textTheme.bodyLarge!.apply(
              color: status == 'correct' ? TColors.black : TColors.white,
            ),
      ),
    ),
  );
}

Widget _buildTimeInfoRow(BuildContext context, String timeTaken) {
  return Row(
    children: [
      Text('Time Taken: ', style: Theme.of(context).textTheme.bodySmall),
      Text(
        timeTaken,
        style: Theme.of(context)
            .textTheme
            .bodyLarge!
            .apply(color: TColors.primary),
      ),
    ],
  );
}

Widget _buildInputType(BuildContext context, QuestionType inputType,
    String userAnswer, List<String>? options) {
  switch (inputType) {
    case QuestionType.text:
      return TextField(
        controller: TextEditingController(text: userAnswer),
        enabled: false,
        maxLines: null,
        decoration: const InputDecoration(
            fillColor: Colors.transparent, border: InputBorder.none),
        style:
            Theme.of(context).textTheme.bodyMedium!.apply(color: Colors.black),
      );
    case QuestionType.radio:
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: options!.map((option) {
          return CustomRadioButton(
            value: option,
            groupValue: userAnswer,
            onChanged: (value) {},
            label: option,
          );
        }).toList(),
      );
    case QuestionType.checkbox:
      return Column(
        children: options!.map((option) {
          return CheckboxListTile(
            value: userAnswer == option,
            onChanged: null,
            title: Text(
              option,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium!
                  .apply(color: Colors.black),
            ),
          );
        }).toList(),
      );
    default:
      return Container();
  }
}
