import 'package:eapl_student_app/common/widget/exam/exam_list_container.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../common/widget/alert/confirmation_alert.dart';
import '../../../../../../common/widget/alert/guidelines_alert.dart';
import '../../../../../../common/widget/app_bar/appbar.dart';
import '../../../../../../common/widget/container/glassy_container.dart';
import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/image_strings.dart';
import '../../../../../../utils/helpers/helper_functions.dart';
import '../exam_page/exam_page.dart';
import 'exam_list_controller.dart';

class ExamListPage extends StatelessWidget {
  const ExamListPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    final screenWidth = THelperFunctions.screenWidth();

    final controller = Get.put(ExamListController());
    // return GetBuilder<ExamListController>(builder: (controller) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: TColors.white,
          appBar: CustomAppBar(isMenuNeed: false),
          floatingActionButton: Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 30.0, left: 40.0),
              child: FloatingActionButton(
                onPressed: () {
                  Get.back();
                  // Add your onPressed code here!
                },
                backgroundColor: TColors.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50.0),
                ),
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          body: GlassyContainer(
            height: THelperFunctions.screenHeight(),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                _buildSectionTitle(context, "Open Exams"),
                Flexible(
                  child: ListView.builder(
                    itemCount: controller.examList.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      controller.examListIndex.value = index;
                      return ExamListContainers(
                        onPressedStartExam: ConfirmationAlert(
                          textWidget: _buildStartExamText(context),
                          imageUrl: TImages.thinkAlert,
                          onpressedYes: () => _onStartExamConfirmed(context),
                          onpressedno: () => Navigator.of(context).pop(),
                        ),
                        exam: controller.examList[index],
                      );
                    },
                  ),
                )
              ],
            ),
          )),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge,
    );
  }

  RichText _buildStartExamText(BuildContext context) {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
        text: 'Are You Sure You Want to ',
        style: Theme.of(context)
            .textTheme
            .headlineMedium!
            .apply(color: TColors.primary),
        children: [
          TextSpan(
            text: 'Start the Exam?',
            style: Theme.of(context)
                .textTheme
                .headlineMedium!
                .apply(color: TColors.notAttempted),
          ),
        ],
      ),
    );
  }

  void _onStartExamConfirmed(BuildContext context) {
    Get.back();
    Get.dialog(ConfirmationAlert(
      textWidget: _buildCertificateText(context),
      imageUrl: TImages.certificateAlert,
      onpressedYes: () => _onCertificateConfirmed(context),
      onpressedno: () => _onCertificateConfirmed(context),
    ));
  }

  RichText _buildCertificateText(BuildContext context) {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
        text: 'Do You Need ',
        style: Theme.of(context)
            .textTheme
            .headlineMedium!
            .apply(color: TColors.primary),
        children: [
          TextSpan(
            text: 'Certificate ',
            style: Theme.of(context)
                .textTheme
                .headlineMedium!
                .apply(color: TColors.notAttempted),
          ),
          TextSpan(
            text: 'for this Exam?',
            style: Theme.of(context)
                .textTheme
                .headlineMedium!
                .apply(color: TColors.primary),
          ),
        ],
      ),
    );
  }

  void _onCertificateConfirmed(BuildContext context) {
    Get.back();
    Get.dialog(GuidelinesDialog(
      onpressed: () {
        Get.back();
        Get.to(() => ExamPage());
      },
    ));
  }
}
