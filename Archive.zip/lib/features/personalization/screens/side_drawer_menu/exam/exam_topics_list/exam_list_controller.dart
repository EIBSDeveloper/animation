import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../../utils/constants/text_strings.dart';
import '../../../../../../utils/http/api_constants.dart';
import '../../../../../../utils/http/http_client.dart';
import '../../../../models/exam/exam_list_model.dart';

class ExamListController extends GetxController {
  bool isLoading = false;
  List<ExamListModel> examList = <ExamListModel>[];
  var examListIndex = 0.obs;

  RxList examIds = <String>[].obs;

  @override
  void onInit() {
    fetchExamList();
  }

  Future<void> fetchExamList() async {
    try {
      isLoading = true;
      update();
      print("Exam IDss: ${examIds}");
      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
        // "exam_ids": examIds.toList()
        "exam_ids": ["1", "2", "1", "3", "4"]
      };

      print("Exam List req : ${req}");
      final response =
          await THttpHelper.post(APIConstants.examListEndPoint, req);

      examList = List<ExamListModel>.from(
          (response['data'] as List).map((x) => ExamListModel.fromJson(x)));
      update();
    } catch (e) {
      print(e);
    } finally {
      isLoading = false;
      update();
    }
  }
}
