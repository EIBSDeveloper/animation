import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../../utils/constants/text_strings.dart';
import '../../../../../../utils/http/api_constants.dart';
import '../../../../../../utils/http/http_client.dart';
import '../../../../models/exam/course_list_model.dart';
import '../../../../models/exam/exam_report_list_model.dart';
import '../exam_topics_list/exam_list_controller.dart';

class ExamDashboardController extends GetxController {
  // static DashboardController get instance => Get.find();
  var isLoading = false.obs;
  List<CourseListModel> courseList = <CourseListModel>[];
  ExamListController examListController = Get.put(ExamListController());
  final examReportList = <ExamResponse>[].obs;
  var courseListIndex = 0.obs;
  var examReportListIndex = 0.obs;
  @override
  void onInit() {
    fetchExamCourseList();
    fetchExamReportList();
  }

  void updateExamIds(List<String> examId) {
    examListController.examIds.value = examId;
    examListController.fetchExamList();
  }

  Future<void> fetchExamCourseList() async {
    try {
      isLoading.value = true;
      update();

      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
      };

      print("Course List Req :${req}");
      final response =
          await THttpHelper.post(APIConstants.courseListEndPoint, req);
      if (response['data'] != null) {
        courseList = List<CourseListModel>.from(
            response['data'].map((x) => CourseListModel.fromJson(x)));
      } else {
        courseList = <CourseListModel>[];
      }
      update();
    } catch (e) {
      print("Error in fetchExamCourseList - fetch Exam course List $e");
    } finally {
      isLoading.value = false;
      update();
    }
  }

  Future<void> fetchExamReportList() async {
    // try {
    isLoading.value = true;
    update();
    final req = {
      "customer_id": GetStorage().read(TTexts.userID),
      // "customer_id": GetStorage().read(TTexts.userID),
    };

    print("Fetch fetchExamReportList: $req");
    final response =
        await THttpHelper.post(APIConstants.examReportListEndPoint, req);
    print("Fetch fetchExamReportList response: $response ");
    print("Fetch fetchExamReportList data: ${response['data']} ");

    if (response['data'] != null) {
      examReportList.value = List<ExamResponse>.from(
          (response as List).map((x) => ExamResponse.fromJson(x)));
    } else {
      examReportList.value = <ExamResponse>[];
    }
    update();
  }
}
