import 'package:eapl_student_app/common/widget/container/glassy_container.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_dashboard/exam_dashboard_controller.dart';
import 'package:eapl_student_app/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../common/widget/app_bar/appbar.dart';
import '../../../../../../common/widget/background/background_theme.dart';
import '../../../../../../common/widget/exam/exam_course_list_container.dart';
import '../../../../../../common/widget/exam/exam_report_container.dart';
import '../../../../../../common/widget/menu/side_drawer_menu/side_menu.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../../../utils/helpers/helper_functions.dart';

class ExamDashboard extends StatelessWidget {
  ExamDashboard({super.key});
  final controller = Get.put(ExamDashboardController());
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: SideMenuBar(),
        appBar: CustomAppBar(),
        body: OurBackgroundTheme(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildExamsCountRow(context),
                      const SizedBox(height: TSizes.md),
                      GlassyContainer(
                        height: THelperFunctions.screenHeight() / 1.4,
                        child: Column(
                          children: [
                            _buildSectionTitle(context, "Your Course"),
                            _buildExamList(context),
                            const SizedBox(height: TSizes.md),
                            _buildSectionTitle(context, "Finished Exams"),
                            _buildExamReportList(context),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExamsCountRow(BuildContext context) {
    return Row(
      children: [
        _buildCountContainer(
          context,
          title: "Total\nExams",
          count: "22",
          color: const Color(0xFFCECDFF),
        ),
        const SizedBox(width: TSizes.sm),
        _buildCountContainer(
          context,
          title: "Finished\nExams",
          count: "04",
          color: const Color(0xFFE34B5A),
        ),
        const SizedBox(width: TSizes.sm),
        _buildCountContainer(
          context,
          title: "Average\nPercentage",
          count: "56%",
          color: const Color(0xFFFAD04A),
        ),
      ],
    );
  }

  Widget _buildCountContainer(
    BuildContext context, {
    required String title,
    required String count,
    required Color color,
  }) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.40),
          borderRadius: BorderRadius.circular(10.0),
          border: Border.all(color: Colors.black),
        ),
        padding: const EdgeInsets.all(TSizes.sm),
        child: Column(
          children: [
            Text(
              title,
              style: Theme.of(context)
                  .textTheme
                  .bodyLarge!
                  .apply(color: Colors.black),
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
            const Divider(color: Colors.black, thickness: 1),
            Text(
              count,
              style: Theme.of(context)
                  .textTheme
                  .headlineLarge!
                  .apply(color: TColors.importantText),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge,
    );
  }

  Widget _buildExamList(BuildContext context) {
    return ListView.separated(
      separatorBuilder: (context, index) => SizedBox(height: TSizes.sm),
      physics: NeverScrollableScrollPhysics(),
      itemCount: controller.courseList.length,
      shrinkWrap: true,
      itemBuilder: (context, index) {
        controller.courseListIndex.value = index;
        return ExamCourseListContainer(
          course: controller.courseList[index],
        );
      },
    );
  }

  Widget _buildExamReportList(BuildContext context) {
    return Obx(
      () {
        if (controller.examReportList.isEmpty) {
          return Center(
            child: Text("There is no finished exam"),
          );
        }
        return ListView.builder(
          itemCount: controller.examReportList.value.length,
          physics: NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (context, index) {
            controller.examReportListIndex.value = index;
            return ExamReportContainer(
              examTitle:
                  controller.examReportList.first.data?[index].examName ?? '',
              questionCount: controller
                  .examReportList.first.data![index].noOfQuestions
                  .toString(),
              timingInMinutes: controller
                  .examReportList.first.data![index].examDuration
                  .toString(),
              exam: controller.examReportList.first.data![index],
            );
          },
        );
      },
    );
  }
}
