import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/enums.dart';
import '../../../../../../utils/constants/text_strings.dart';
import '../../../../../../utils/http/api_constants.dart';
import '../../../../../../utils/http/http_client.dart';
import '../../../../../../utils/loaders/loaders.dart';
import '../../../../models/exam/exam_question_model.dart';
import '../exam_report/exam_report.dart';

class ExamController extends GetxController {
  RxInt currentQuestionIndex = 0.obs;
  RxInt totalTimeInSeconds = 300.obs;

  RxBool showHint = false.obs;
  RxBool showExplain = false.obs;

  final isLoading = false.obs;

  DateTime? lastPressedTime = DateTime.now();
  int? timeDifferenceInSeconds;

  String examId = '';
  RxString? selectedRadioValue = ''.obs;
  RxList<String>? selectedCheckboxValues = RxList<String>([]);
  RxString selectedTextValue = ''.obs;
  Rx<ExamDetailsModel?> examDetails = Rx<ExamDetailsModel?>(null);

  // final questions = <ExamQuestionModel>[].obs;
  final questions = <ExamQuestionModel>[].obs;
  RxList<QuestionStatus> questionStatus = <QuestionStatus>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchExamQuestion();
  }

  Future<String?> fetchGuidelines() async {
    isLoading.value = true;
    final response = await THttpHelper.get(APIConstants.examGuidelinesEndPoint);
    return response['data']['exam_guidelines'];
  }

// Update fetchExamQuestion to handle initialization after data is fetched
  Future<void> fetchExamQuestion() async {
    try {
      isLoading.value = true; // Show loading indicator
      final req = {
        "customer_id": GetStorage().read(TTexts.userID),
        "exam_id": "4"
      };

      final response =
          await THttpHelper.post(APIConstants.examQuestionEndPoint, req);
      examDetails.value = ExamDetailsModel.fromJson(response["Exam Details"]);

      examId = examDetails.value!.sno.toString();
      questions.value = (response['Exam Questions'] as List)
          .map((e) => ExamQuestionModel.fromJson(e))
          .toList();
      questionStatus = RxList<QuestionStatus>.filled(
          questions.length, QuestionStatus.notViewed);

      // Ensure there are questions before initializing
      if (questions.isNotEmpty) {
        initializeQuestionValues();
      } else {
        print("No questions available.");
      }
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap",
          message: "Something Error please try again later$e");
      print("Error fetching questions: $e");
    } finally {
      isLoading.value = false;
      update();
    }
  }

  Future<void> sendAnswerToAPI(String questionId, String answer) async {
    try {
      final DateTime now = DateTime.now();

      if (lastPressedTime != null) {
        // Calculate the difference in seconds
        final difference = now.difference(lastPressedTime!).inSeconds;

        timeDifferenceInSeconds = difference;
      }

      // Update the last pressed time
      lastPressedTime = now;
      // isLoading.value = true; // Show loading indicator
      final req = {
        "customer_id": '10',
        "question_id": questionId,
        "answer_data": {
          "answer": answer,
          "time_spent": timeDifferenceInSeconds
        },
        "exam_id": examId
      };

      print("Request : $req");

      final response =
          await THttpHelper.post(APIConstants.saveAnswerEndPoint, req);
      // Tloaders.successsnackbar(title: 'Success');
    } catch (e) {
      TSnackbar.errorSnackbar(
          title: "Oh Snap", message: "Something went Wrong");
      print("Error Submitting Answer: $e");
    } finally {
      isLoading.value = false;
      update();
    }
  }

  void initializeQuestionValues() {
    ExamQuestionModel currentQuestion = questions[currentQuestionIndex.value];

    // Check if there's a stored answer for the current question
    var storedAnswer = userAnswers[currentQuestionIndex.value];

    if (currentQuestion.questionType == 'radio_button') {
      selectedRadioValue!.value =
          storedAnswer ?? ''; // If an answer is stored, use it
    } else if (currentQuestion.questionType == 'check_boxx') {
      selectedCheckboxValues!.value = storedAnswer ?? '';
    } else if (currentQuestion.questionType == 'text') {
      selectedTextValue.value = storedAnswer ?? ''; // Restore text answer
    } else {
      selectedRadioValue!.value = storedAnswer ?? '';
    }
  }

  // Store the user's selected answers for each question
  RxMap<int, dynamic> userAnswers =
      RxMap<int, dynamic>(); // Store answers by question index

  void storeUserAnswer(int index, dynamic answer) {
    userAnswers[index] = answer; // Save the answer
    if (questions[index].questionType == 'check_boxx') {
      // For checkboxes, store selected options as Strings
      selectedCheckboxValues![index] = answer;
    }
  }

  void nextQuestion() {
    ExamQuestionModel currentQuestion = questions[currentQuestionIndex.value];
    bool isAnswered = false;

    // Determine if the user answered based on question type
    dynamic answer;
    if (currentQuestion.questionType == 'radio_button') {
      answer = selectedRadioValue?.value;
      isAnswered = answer != null && answer.isNotEmpty;
    } else if (currentQuestion.questionType == 'check_boxx') {
      answer = selectedCheckboxValues;
      isAnswered = answer?.any((selected) => selected) ?? false;
    } else if (currentQuestion.questionType == 'text') {
      answer = selectedTextValue.value;
      isAnswered = answer.isNotEmpty;
    } else {
      answer = selectedRadioValue?.value;
      isAnswered = answer != null && answer.isNotEmpty;
    }

    /// Store the user's answer
    if (isAnswered) {
      storeUserAnswer(currentQuestionIndex.value, answer);
    }

    sendAnswerToAPI(currentQuestion.questionId.toString(), answer);
    // Update the status based on whether the question was answered
    questionStatus[currentQuestionIndex.value] =
        isAnswered ? QuestionStatus.attempt : QuestionStatus.notAttempt;

    // Proceed to the next question if available
    if (currentQuestionIndex.value < questions.length - 1) {
      currentQuestionIndex.value++;
      questionStatus[currentQuestionIndex.value] = QuestionStatus.viewed;
      initializeQuestionValues();
    } else {
      Get.to(() => ExamReport());
      // Get.offNamed(AppPage.examReports);
    }
  }

  void jumpToIndexQuestion({required int questionIndex}) {
    ExamQuestionModel currentQuestion = questions[currentQuestionIndex.value];
    bool isAnswered = false;

    // Determine if the user answered based on question type
    dynamic answer;
    if (currentQuestion.questionType == 'radio_button') {
      answer = selectedRadioValue?.value;
      isAnswered = answer != null && answer.isNotEmpty;
    } else if (currentQuestion.questionType == 'check_boxx') {
      answer = selectedCheckboxValues;
      isAnswered = answer?.any((selected) => selected) ?? false;
    } else if (currentQuestion.questionType == 'text') {
      answer = selectedTextValue.value;
      isAnswered = answer.isNotEmpty;
    } else {
      answer = selectedRadioValue?.value;
      isAnswered = answer != null && answer.isNotEmpty;
    }

    /// Store the user's answer
    if (isAnswered) {
      storeUserAnswer(currentQuestionIndex.value, answer);
    }

    sendAnswerToAPI(currentQuestion.questionId.toString(), answer);
    // Update the status based on whether the question was answered
    questionStatus[currentQuestionIndex.value] =
        isAnswered ? QuestionStatus.attempt : QuestionStatus.notAttempt;

    currentQuestionIndex.value = questionIndex;
    questionStatus[currentQuestionIndex.value] = QuestionStatus.viewed;
    initializeQuestionValues();
  }

  void previousQuestion() {
    ExamQuestionModel currentQuestion = questions[currentQuestionIndex.value];

    bool isAnswered = false;
    dynamic answer;
    if (currentQuestion.questionType == 'radio_button') {
      answer = selectedRadioValue?.value;
      isAnswered = answer != null && answer.isNotEmpty;
    } else if (currentQuestion.questionType == 'checkbox') {
      answer = selectedCheckboxValues;
      isAnswered = answer?.any((selected) => selected) ?? false;
    } else if (currentQuestion.questionType == 'text') {
      answer = selectedTextValue.value;
      isAnswered = answer.isNotEmpty;
    } else {
      answer = selectedRadioValue?.value;
      isAnswered = answer != null && answer.isNotEmpty;
    }

    /// Store the user's answer
    if (isAnswered) {
      storeUserAnswer(currentQuestionIndex.value, answer);
    }

    sendAnswerToAPI(currentQuestion.questionId.toString(), answer);
    // Update the status based on whether the question was answered
    questionStatus[currentQuestionIndex.value] =
        isAnswered ? QuestionStatus.attempt : QuestionStatus.notAttempt;

    if (currentQuestionIndex.value > 0) {
      currentQuestionIndex.value--;
      questionStatus[currentQuestionIndex.value] = QuestionStatus.viewed;

      initializeQuestionValues();
      lastPressedTime = DateTime.now();
    }
  }

  Color getStatusColor(QuestionStatus status) {
    switch (status) {
      case QuestionStatus.notViewed:
        return TColors.notViewed;
      case QuestionStatus.viewed:
        return TColors.viewed;
      case QuestionStatus.attempt:
        return TColors.attempted;
      case QuestionStatus.notAttempt:
        return TColors.notAttempted;
      default:
        return Colors.grey;
    }
  }
}
