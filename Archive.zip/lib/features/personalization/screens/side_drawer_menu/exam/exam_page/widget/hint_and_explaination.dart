import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:flutter/material.dart';

import '../exam_controller.dart';

class HintAndExplanation extends StatelessWidget {
  const HintAndExplanation({
    super.key,
    required this.controller,
  });

  final ExamController controller;
  @override
  Widget build(BuildContext context) {
    final currentQuestion =
        controller.questions[controller.currentQuestionIndex.value];

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        /*IconButton(
          onPressed: () {
            controller.showHint.value = !controller.showHint.value;
          },
          icon: Image.asset(
            TImages.hint,
            // Add your SVG asset path
            width: 24,
            height: 24,
          ),
        ),*/
        IconButton(
          onPressed: () {
            controller.showExplain.value = !controller.showExplain.value;
          },
          icon: Image.asset(
            TImages.explain,
            // Add your SVG asset path
            width: 24,
            height: 24,
          ),
        ),
      ],
    );
  }
}
