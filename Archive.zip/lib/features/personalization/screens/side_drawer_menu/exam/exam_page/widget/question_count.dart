import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../../utils/constants/colors.dart';
import '../../../../../../../utils/constants/sizes.dart';
import '../../../../../../../utils/helpers/helper_functions.dart';
import '../exam_controller.dart';

class QuestionCount extends StatelessWidget {
  final ExamController controller;

  const QuestionCount({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() => Card(
          color: TColors.viewed,
          shape:
              BeveledRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: Container(
            height: THelperFunctions.screenHeight() / 1.4,
            margin: const EdgeInsets.only(top: 10.0),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10), color: Colors.white),
            padding: const EdgeInsets.all(TSizes.defaultSpace),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Text(
                        'Question Status',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(TSizes.sm),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.black),
                    ),
                    child: SingleChildScrollView(
                      child: Wrap(
                        spacing: 10.0,
                        runSpacing: 10.0,
                        children:
                            List.generate(controller.questions.length, (index) {
                          return InkWell(
                            onTap: () {
                              controller.jumpToIndexQuestion(
                                  questionIndex: index);
                            },
                            child: Container(
                              height: 30,
                              width: 70,
                              color: controller.getStatusColor(
                                  controller.questionStatus[index]),
                              child: Center(child: Text('${index + 1}')),
                            ),
                          );
                        }),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Column(
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child:
                                _statusIndicator(TColors.attempted, 'Attempt'),
                          ),
                          const SizedBox(width: 10),
                          Flexible(
                            child: _statusIndicator(
                                TColors.notAttempted, 'Not Attempted'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Flexible(
                              child: _statusIndicator(
                                  TColors.viewed, 'To Be Viewed')),
                          const SizedBox(width: 10),
                          Flexible(
                            child: _statusIndicator(
                                TColors.notViewed, 'Not Yet Viewed'),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ));
  }

  Widget _statusIndicator(Color color, String text) {
    return Row(
      children: [
        Container(width: 40, height: 20, color: color),
        const SizedBox(width: 5),
        Expanded(
          child: Text(text, softWrap: true),
        ),
      ],
    );
  }
}
//  return Card(
//       color: TColors.viewed,
//       child: Container(
//         height: 300,
//         margin: const EdgeInsets.only(top: 10.0),
//         padding: const EdgeInsets.all(TSizes.defaultSpace),
//         color: Colors.white,
//         child: SingleChildScrollView(
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Row(
//                 children: [
//                   Text('Question Status',
//                       style:
//                           TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//                 ],
//               ),
//               const SizedBox(height: 10),
//               Container(
//                 height: THelperFunctions.islandscape() ? 200 : 100,
//                 width: double.infinity,
//                 padding: const EdgeInsets.all(TSizes.sm),
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(10),
//                   border: Border.all(color: Colors.black),
//                 ),
//                 child: SingleChildScrollView(
//                   child: Wrap(
//                     spacing: 10.0,
//                     runSpacing: 10.0,
//                     children:
//                         List.generate(controller.questions.length, (index) {
//                       return Container(
//                         height: 30,
//                         width: 70,
//                         color:
//                             _getStatusColor(controller.questionStatus[index]),
//                         child: Center(child: Text('${index + 1}')),
//                       );
//                     }),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 10),
//               Column(
//                 children: [
//                   Row(
//                     children: [
//                       Flexible(
//                           child:
//                               _statusIndicator(TColors.attempted, 'Attempt')),
//                       const SizedBox(width: 10),
//                       Flexible(
//                           child: _statusIndicator(
//                               TColors.notAttempted, 'Not Attempted')),
//                     ],
//                   ),
//                   const SizedBox(height: 10),
//                   Row(
//                     children: [
//                       Flexible(
//                           child:
//                               _statusIndicator(TColors.viewed, 'To Be Viewed')),
//                       const SizedBox(width: 10),
//                       Flexible(
//                           child: _statusIndicator(
//                               TColors.notViewed, 'Not Yet Viewed')),
//                     ],
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 20),
//             ],
//           ),
//         ),
//       ),
//     );
