import 'package:flutter/material.dart';

import '../../../../../../../utils/constants/colors.dart';
import '../../../../../../../utils/constants/sizes.dart';

class ExamTitleCard extends StatelessWidget {
  const ExamTitleCard({
    super.key,
    required this.courseName,
    required this.examType,
    this.timerString,
  });

  final String? courseName;
  final String? examType;
  final String? timerString;

  Stream<String> _startTimer(int totalSeconds) async* {
    int remainingSeconds = totalSeconds;

    while (remainingSeconds > 0) {
      yield _formatTime(remainingSeconds);
      await Future.delayed(const Duration(seconds: 1));
      remainingSeconds--;
    }
    yield _formatTime(0); // When the timer ends, emit 00:00
  }

  String _formatTime(int seconds) {
    int minutes = seconds ~/ 60; // Get the minutes part
    int remainingSeconds = seconds % 60; // Get the seconds part
    return "${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}";
  }

  @override
  Widget build(BuildContext context) {
    // Convert timerString (minutes) to total seconds
    int totalSeconds = (int.tryParse(timerString ?? "0") ?? 0) * 60;

    return Card(
      margin: EdgeInsets.symmetric(vertical: TSizes.sm, horizontal: TSizes.xs),
      color: TColors.primary,
      child: Container(
        decoration: BoxDecoration(
            color: TColors.primary, borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.all(TSizes.sm),
        width: double.infinity,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(
                    courseName ?? '---',
                    style: Theme.of(context)
                        .textTheme
                        .headlineMedium!
                        .apply(color: Colors.white),
                  ),
                ),
              ],
            ),
            SizedBox(height: TSizes.sm),
            StreamBuilder<String>(
              stream: _startTimer(totalSeconds),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }

                String formattedTime = snapshot.data ?? '00:00';

                // Calculate the remaining time in seconds
                int remainingTime =
                    int.tryParse(formattedTime.split(':')[0])! * 60 +
                        int.tryParse(formattedTime.split(':')[1])!;

                // Calculate the progress and the percentage of time left
                double progressValue = remainingTime / totalSeconds;

                // Determine the color based on the remaining time percentage
                Color progressColor;
                if (progressValue > 0.5) {
                  progressColor = TColors.attempted; // Green for > 50%
                } else if (progressValue > 0.2) {
                  progressColor = Colors.orange; // Orange for > 20%
                } else {
                  progressColor = TColors.notAttempted; // Red for <= 20%
                }

                return Column(
                  children: [
                    Text.rich(TextSpan(
                        text: "Remaining Time : ",
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium!
                            .apply(color: TColors.white),
                        children: <TextSpan>[
                          TextSpan(
                            text: formattedTime,
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge!
                                .apply(color: TColors.needToFillFeedback),
                          )
                        ])),
                    const SizedBox(height: TSizes.md),
                    LinearProgressIndicator(
                      value: progressValue,
                      backgroundColor: Colors.grey[300],
                      valueColor: AlwaysStoppedAnimation<Color>(progressColor),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
