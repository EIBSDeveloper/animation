import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../../common/widget/button/CustomRadioBtn.dart';
import '../../../../../../../utils/constants/colors.dart';
import '../../../../../../../utils/constants/sizes.dart';
import '../../../../../../../utils/helpers/helper_functions.dart';
import '../../../../../models/exam/exam_question_model.dart';
import '../exam_controller.dart';
import 'hint_and_explaination.dart';

class QuestionDetail extends StatelessWidget {
  final ExamController controller;

  const QuestionDetail({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      // Get the current question
      if (controller.questions.value.isEmpty) {
        return Center(
          child: Text(
            "No questions available.",
            style: Theme.of(context).textTheme.headlineSmall,
          ),
        );
      }

      final currentQuestion =
          controller.questions[controller.currentQuestionIndex.value];
      print('question:${currentQuestion.toString()}');
      return Card(
        elevation: 5,
        margin: const EdgeInsets.all(2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        child: Container(
          padding: const EdgeInsets.all(TSizes.sm),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Question Title
                _buildQuestionTitle(currentQuestion),
                if (controller.showHint.value)
                  buildHintAndExplainContainer(
                      backgroundColor: Color(0xFFF5DAE0),
                      text: currentQuestion.hintText ?? 'There is no Hint',
                      head: 'Hint'),

                if (controller.showExplain.value)
                  buildHintAndExplainContainer(
                      backgroundColor: Color(0xFFDAC8ED),
                      text: currentQuestion.explanationText ??
                          'There is no Explanation',
                      head: 'Explain'),
                const SizedBox(height: 15),

                // Answer Options
                _buildAnswerOptions(currentQuestion),

                const SizedBox(height: 25),

                // Navigation Buttons
                _buildNavigationButtons(),
              ],
            ),
          ),
        ),
      );
    });
  }

  Widget buildHintAndExplainContainer(
      {required Color backgroundColor,
      required String text,
      required String head}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Material(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Container(
            width: double.infinity,
            padding: EdgeInsets.all(TSizes.xs),
            decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(10)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  head,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline),
                ),
                Text(text),
              ],
            )),
      ),
    );
  }

  Widget _buildQuestionTitle(ExamQuestionModel currentQuestion) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            '${controller.currentQuestionIndex.value + 1}. ${currentQuestion.questionName}',
            style: THelperFunctions.screenWidth() > 600
                ? Theme.of(Get.context!).textTheme.headlineMedium
                : Theme.of(Get.context!).textTheme.bodyMedium,
          ),
        ),
        HintAndExplanation(controller: controller),
      ],
    );
  }

  Widget _buildAnswerOptions(ExamQuestionModel currentQuestion) {
    return Container(
        padding: const EdgeInsets.all(TSizes.md),
        decoration: BoxDecoration(
            border: Border.all(color: TColors.primary, width: 1),
            borderRadius: BorderRadius.circular(10)),
        child: answerOptionType(currentQuestion));
  }

  Widget _buildNavigationButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Previous Button
        SizedBox(
          width: THelperFunctions.screenWidth() > 600
              ? TSizes.buttonTabletWidth
              : TSizes.buttonMobileWidth,
          child: OutlinedButton.icon(
            onPressed: controller.currentQuestionIndex.value > 0
                ? controller.previousQuestion
                : null,
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: TColors.primary),
            label: Text("Previous",
                style: Theme.of(Get.context!)
                    .textTheme
                    .bodySmall!
                    .copyWith(color: TColors.primary)),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: TColors.primary),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ),

        // Next Button
        SizedBox(
          width: THelperFunctions.screenWidth() > 600
              ? TSizes.buttonTabletWidth
              : TSizes.buttonMobileWidth,
          child: ElevatedButton.icon(
            onPressed: controller.nextQuestion,
            icon: Text(
              controller.currentQuestionIndex.value >=
                      controller.questions.length - 1
                  ? "Submit"
                  : "Next",
              style: Theme.of(Get.context!)
                  .textTheme
                  .bodySmall!
                  .copyWith(color: TColors.white),
            ),
            label: const Icon(Icons.arrow_forward_ios_rounded,
                color: Colors.white),
            style: ElevatedButton.styleFrom(
              backgroundColor: TColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget answerOptionType(ExamQuestionModel question) {
    switch (question.questionType) {
      case 'radio_button':
        return Column(
          children: question.questionOption.map((option) {
            return CustomRadioButton(
              value: option,
              groupValue: controller.selectedRadioValue?.value,
              onChanged: (value) {
                controller.selectedRadioValue?.value = value;

                controller.storeUserAnswer(
                    controller.currentQuestionIndex.value, value);
              },
              label: option,
            );
          }).toList(),
        );
      case 'check_bo':
        return Column(
          children: question.questionOption.map((option) {
            return CheckboxListTile(
              title: Text(option),
              value: controller.selectedCheckboxValues?.contains(option),
              onChanged: (value) {
                if (value == true) {
                  controller.selectedCheckboxValues?.add(option);
                } else {
                  controller.selectedCheckboxValues?.remove(option);
                }
                controller.storeUserAnswer(
                    controller.currentQuestionIndex.value,
                    controller.selectedCheckboxValues);
              },
            );
          }).toList(),
        );
      case 'text':
        return TextFormField(
          initialValue: controller.selectedTextValue.value,
          decoration: InputDecoration(
            hintText: "Type your Answer",
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          onChanged: (value) {
            controller.selectedTextValue.value = value;
            controller.storeUserAnswer(
                controller.currentQuestionIndex.value, value);
          },
        );
      default:
        return Column(
          children: question.questionOption.map((option) {
            return CustomRadioButton(
              value: option,
              groupValue: controller.selectedRadioValue?.value,
              onChanged: (value) {
                controller.selectedRadioValue?.value = value;
                controller.storeUserAnswer(
                    controller.currentQuestionIndex.value, value);
              },
              label: option,
            );
          }).toList(),
        );
    }
  }
}
