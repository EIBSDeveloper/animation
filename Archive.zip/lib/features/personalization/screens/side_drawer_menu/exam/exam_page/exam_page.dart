import 'package:eapl_student_app/common/widget/background/background_theme.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_page/widget/exam_title_card.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_page/widget/question_count.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_page/widget/question_details.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/sizes.dart';
import 'exam_controller.dart';

class ExamPage extends StatelessWidget {
  const ExamPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ExamController());
    controller.fetchExamQuestion();
    return SafeArea(
      child: Scaffold(
        backgroundColor: TColors.white,
        body: OrientationBuilder(
          builder: (context, orientation) {
            return OurBackgroundTheme(
              child: Obx(
                () {
                  if (controller.isLoading.value) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }
      
                  return Column(
                    children: [
                      SizedBox(height: TSizes.spaceBtwItems),
                      ExamTitleCard(
                          courseName:
                              controller.examDetails.value?.examName ?? '---',
                          examType: controller.examDetails.value?.examMode,
                          timerString: controller.examDetails.value?.examDuration
                              .toString()),
                      SizedBox(height: TSizes.spaceBtwItems),
                      Expanded(
                        child: Get.width > 600
                            ? _buildTabletLayout(controller, orientation)
                            : _buildMobileLayout(controller),
                      ),
                    ],
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildTabletLayout(
      ExamController controller, Orientation orientation) {
    if (orientation == Orientation.landscape) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(flex: 3, child: QuestionCount(controller: controller)),
          Expanded(flex: 6, child: QuestionDetail(controller: controller)),
        ],
      );
    } else {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(flex: 2, child: QuestionCount(controller: controller)),
          Expanded(flex: 4, child: QuestionDetail(controller: controller)),
        ],
      );
    }
  }

  Widget _buildMobileLayout(ExamController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(flex: 4, child: QuestionCount(controller: controller)),
        Expanded(flex: 6, child: QuestionDetail(controller: controller)),
      ],
    );
  }
}
