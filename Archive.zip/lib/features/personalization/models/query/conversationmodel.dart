class ConversationResponse {
  final int status;
  final String message;
  final List<Issue> data;

  ConversationResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory ConversationResponse.fromJson(Map<String, dynamic> json) {
    return ConversationResponse(
      status: json['status'],
      message: json['message'],
      data:
          (json['data'] as List).map((issue) => Issue.fromJson(issue)).toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'status': status,
        'message': message,
        'data': data.map((e) => e.toJson()).toList(),
      };
}

class Issue {
  final int issueId;
  final List<Conversation> conversationList;

  Issue({
    required this.issueId,
    required this.conversationList,
  });

  factory Issue.fromJson(Map<String, dynamic> json) {
    return Issue(
      issueId: json['issue_id'],
      conversationList: (json['conversation_list'] as List)
          .map((c) => Conversation.fromJson(c))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'issue_id': issueId,
        'conversation_list': conversationList.map((e) => e.toJson()).toList(),
      };
}

class Conversation {
  final String sender;
  final String name;
  final String message;
  final String? attachment;
  final String timestamp;
  final bool seen; // ✅ new field
  int closed; // Add this

  Conversation(
      {required this.sender,
      required this.name,
      required this.message,
      this.attachment,
      required this.timestamp,
      required this.seen,
      required this.closed});

  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      sender: json['sender'],
      name: json['name'] ?? '',
      message: json['message'],
      attachment: json['attachment'],
      timestamp: json['timestamp'],
      seen: json['seen'] ?? false,
      closed: int.tryParse(json['closed'].toString()) ?? 0, // parse as int
    );
  }

  Map<String, dynamic> toJson() => {
        'sender': sender,
        'name': name,
        'message': message,
        'attachment': attachment,
        'timestamp': timestamp,
        'seen': seen,
        'closed': closed,
      };
}
