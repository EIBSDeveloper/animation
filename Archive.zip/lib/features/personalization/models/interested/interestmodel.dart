class Interestmodel {
  int? sno;
  String? courseName;
  String? courseVersion;
  int? courseParticalHours;
  int? courseTheoryHours;
  String? courseCode;
  String? courseSubcategoryName;
  int? courseDuration;
  int? courseDays;
  String? courseTypeName;
  String? attachment;
  String? thumbnail;
  String? courseDesc;
  String? courseGoals;
  String? courseFutureScope;
  String? createdDate;
  int? interested; // <-- new field
  String? averageRating; // ✅ new field

  Interestmodel({
    this.sno,
    this.courseName,
    this.courseVersion,
    this.courseParticalHours,
    this.courseTheoryHours,
    this.courseCode,
    this.courseSubcategoryName,
    this.courseDuration,
    this.courseDays,
    this.courseTypeName,
    this.attachment,
    this.thumbnail,
    this.courseDesc,
    this.courseGoals,
    this.courseFutureScope,
    this.createdDate,
    this.interested,
    required this.averageRating, // ✅ added
  }); // include in constructor

  Interestmodel.fromJson(Map<String, dynamic> json) {
    sno = json['sno'];
    courseName = json['course_name'];
    courseVersion = json['course_version'];
    courseParticalHours = json['course_partical_hours'];
    courseTheoryHours = json['course_theory_hours'];
    courseCode = json['course_code'];
    courseSubcategoryName = json['course_subcategory_name'];
    courseDuration = json['course_duration'];
    courseDays = json['course_days'];
    courseTypeName = json['course_type_name'];
    attachment = json['attachment'];
    thumbnail = json['thumbnail'];
    courseDesc = json['course_desc'];
    courseGoals = json['course_goals'];
    courseFutureScope = json['course_future_scope'];
    createdDate = json['created_date'];
    interested = json['interested'] ?? 0; // <-- parse from API, default 0
    averageRating = json['average_rating'] ?? '0'; // ✅ safe default
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sno'] = this.sno;
    data['course_name'] = this.courseName;
    data['course_version'] = this.courseVersion;
    data['course_partical_hours'] = this.courseParticalHours;
    data['course_theory_hours'] = this.courseTheoryHours;
    data['course_code'] = this.courseCode;
    data['course_subcategory_name'] = this.courseSubcategoryName;
    data['course_duration'] = this.courseDuration;
    data['course_days'] = this.courseDays;
    data['course_type_name'] = this.courseTypeName;
    data['attachment'] = this.attachment;
    data['thumbnail'] = this.thumbnail;
    data['course_desc'] = this.courseDesc;
    data['course_goals'] = this.courseGoals;
    data['course_future_scope'] = this.courseFutureScope;
    data['created_date'] = this.createdDate;
    data['interested'] = this.interested; // <-- include in toJson
    data['average_rating'] = this.averageRating;
    return data;
  }
}
