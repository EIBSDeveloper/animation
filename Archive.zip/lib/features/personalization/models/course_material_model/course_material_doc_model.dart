class CourseMaterialListModel {
  final String folderName;
  final List<CourseMaterial> courseMaterials;

  CourseMaterialListModel({
    required this.folderName,
    required this.courseMaterials,
  });

  factory CourseMaterialListModel.fromJson(Map<String, dynamic> json) {
    return CourseMaterialListModel(
      folderName: json['folder_name'],
      courseMaterials: (json['course_materials'] as List)
          .map((item) => CourseMaterial.fromJson(item))
          .toList(),
    );
  }
}

class CourseMaterial {
  final String url;

  CourseMaterial({
    required this.url,
  });

  factory CourseMaterial.fromJson(Map<String, dynamic> json) {
    return CourseMaterial(
      url: json['url'],
    );
  }
}
