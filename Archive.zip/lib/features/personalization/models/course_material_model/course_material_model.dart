class CourseMaterialListNew {
  final int courseId;
  final String courseName;
  final int courseDays;
  final String courseVersion;
  final int coursePracticalHours;
  final int courseTheoryHours;
  final int courseDuration;
  final String courseCode;
  final String? materials;
  final String courseSubcategoryName;
  final String attachment;
  final String thumbnail;
  final int courseTypeId;
  final String courseTypeName;
  final String staffName;
  final String nickName;
  final int gender;
  final String staffImage;
  final String? courseCompletePercentage;
  final int? courseCompletedDays;
  final List<CourseMaterial> courseMaterials;
  final List<MaterialName> materialNames;

  CourseMaterialListNew({
    required this.courseId,
    required this.courseName,
    required this.courseDays,
    required this.courseVersion,
    required this.coursePracticalHours,
    required this.courseTheoryHours,
    required this.courseDuration,
    required this.courseCode,
    this.materials,
    required this.courseSubcategoryName,
    required this.attachment,
    required this.thumbnail,
    required this.courseTypeId,
    required this.courseTypeName,
    required this.staffName,
    required this.nickName,
    required this.gender,
    required this.staffImage,
    required this.courseMaterials,
    required this.materialNames,
    this.courseCompletePercentage,
    this.courseCompletedDays,
  });

  factory CourseMaterialListNew.fromJson(Map<String, dynamic> json) {
    return CourseMaterialListNew(
      courseId: json['course_id'],
      courseName: json['course_name'],
      courseDays: json['course_days'],
      courseVersion: json['course_version'],
      coursePracticalHours: json['course_partical_hours'],
      courseTheoryHours: json['course_theory_hours'],
      courseDuration: json['course_duration'],
      courseCode: json['course_code'],
      materials: json['materials'],
      courseSubcategoryName: json['course_subcategory_name'],
      attachment: json['attachment'],
      thumbnail: json['thumbnail'],
      courseTypeId: json['course_type_id'],
      courseTypeName: json['course_type_name'],
      staffName: json['staff_name'],
      nickName: json['nick_name'],
      gender: json['gender'],
      staffImage: json['staff_image'],
      courseCompletePercentage: json['course_complete_percentage'],
      courseCompletedDays: json['course_completedDays'],
      courseMaterials: (json['course_materials'] as List)
          .map((e) => CourseMaterial.fromJson(e))
          .toList(),
      materialNames: (json['material_names'] as List)
          .map((e) => MaterialName.fromJson(e))
          .toList(),
    );
  }
}

class CourseMaterial {
  final String type;
  final List<MaterialFile> files;

  CourseMaterial({
    required this.type,
    required this.files,
  });

  factory CourseMaterial.fromJson(Map<String, dynamic> json) {
    return CourseMaterial(
      type: json.keys.first,
      files: (json[json.keys.first] as List?)
              ?.map((e) => MaterialFile.fromJson(e))
              .toList() ??
          [],
    );
  }
}

class MaterialFile {
  final String name;
  final String url;

  MaterialFile({
    required this.name,
    required this.url,
  });

  factory MaterialFile.fromJson(Map<String, dynamic> json) {
    return MaterialFile(
      name: json['name'],
      url: json['url'],
    );
  }
}

class MaterialName {
  final int sno;
  final String folderName;
  final int? count;

  MaterialName({
    required this.sno,
    required this.folderName,
    required this.count,
  });

  factory MaterialName.fromJson(Map<String, dynamic> json) {
    return MaterialName(
      sno: json['sno'],
      folderName: json['folder_name'],
      count: json['count'] ?? 0, // ✅ Default to 0 if null
    );
  }
}
