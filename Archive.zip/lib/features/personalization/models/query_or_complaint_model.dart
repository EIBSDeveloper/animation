/*class QueryOrComplaintModel {
  final int issueSno;
  final String issueId;
  final String createdDate;
  final String issue;
  final String category;
  final String priorityLevel;
  int issueStatus;
  final String? description;
  final String? staffName;
  final String cusName;
  final int cusSno;
  final int cusBranchId;
  final String customerId;
  final String? attachment; // <-- New field for attachment (Base64 or URL)
  final String? attachmentUrl; // <-- URL of attachment

  QueryOrComplaintModel(
      {required this.issueSno,
      required this.issueId,
      required this.createdDate,
      required this.issue,
      required this.category,
      required this.priorityLevel,
      required this.issueStatus,
      this.description,
      this.staffName,
      required this.cusName,
      required this.cusSno,
      required this.cusBranchId,
      required this.customerId,
      required this.attachment, // <-- include in constructor
      required this.attachmentUrl});

  factory QueryOrComplaintModel.fromJson(Map<String, dynamic> json) {
    return QueryOrComplaintModel(
      issueSno: json['issue_sno'],
      createdDate: json['created_at'],
      issueId: json['issue_id'],
      issue: (json['issue'] ?? '').toString(),

      category: json['category'],
      priorityLevel: json['priority_level'],
      issueStatus: json['issue_status'],
      description: json['description'],
      staffName: json['staff_name'],
      cusName: json['cus_name'],
      cusSno: json['cus_sno'],
      cusBranchId: json['cus_branch_id'],
      customerId: json['customer_id'],
      attachment: json['attachment'], // <-- map attachment from API
      attachmentUrl: json['attachment_url'], // <-- map URL from API
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'issue_sno': issueSno,
      'created_at': createdDate,
      'issue_id': issueId,
      'issue': issue,
      'category': category,
      'priority_level': priorityLevel,
      'issue_status': issueStatus,
      'description': description,
      'staff_name': staffName,
      'cus_name': cusName,
      'cus_sno': cusSno,
      'cus_branch_id': cusBranchId,
      'customer_id': customerId,
      'attachment': attachment, // <-- include in JSON serialization
      'attachment_url': attachmentUrl, // <-- include in JSON
    };
  }
}*/

// class QueryOrComplaintModel {
//   final int issueSno;
//   final String issueId;
//   final DateTime createdAt;
//   final String issue;
//   final String category;
//   final String priorityLevel;
//   final int status;
//   final String description;
//   final String staffName;
//   final String cusName;
//   final int cusSno;
//   final int cusBranchId;
//   final String customerId;
//
//   QueryOrComplaintModel({
//     required this.issueSno,
//     required this.issueId,
//     required this.createdAt,
//     required this.issue,
//     required this.category,
//     required this.priorityLevel,
//     required this.status,
//     required this.description,
//     required this.staffName,
//     required this.cusName,
//     required this.cusSno,
//     required this.cusBranchId,
//     required this.customerId,
//   });
//
//   factory QueryOrComplaintModel.fromJson(Map<String, dynamic> json) {
//     return QueryOrComplaintModel(
//       issueSno: json['issue_sno'],
//       issueId: json['issue_id'],
//       createdAt: DateTime.parse(json['created_at']),
//       issue: json['issue'],
//       category: json['category'],
//       priorityLevel: json['priority_level'],
//       status: json['status'],
//       description: json['description'],
//       staffName: json['staff_name'],
//       cusName: json['cus_name'],
//       cusSno: json['cus_sno'],
//       cusBranchId: json['cus_branch_id'],
//       customerId: json['customer_id'],
//     );
//   }
//
//   Map<String, dynamic> toJson() {
//     return {
//       'issue_sno': issueSno,
//       'issue_id': issueId,
//       'created_at': createdAt.toIso8601String(),
//       'issue': issue,
//       'category': category,
//       'priority_level': priorityLevel,
//       'status': status,
//       'description': description,
//       'staff_name': staffName,
//       'cus_name': cusName,
//       'cus_sno': cusSno,
//       'cus_branch_id': cusBranchId,
//       'customer_id': customerId,
//     };
//   }
// }
