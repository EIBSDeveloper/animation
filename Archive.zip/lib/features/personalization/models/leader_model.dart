class LeaderModel {
  final String cusName;
  final String cusMobile;
  final int sno;
  final String customerId;
  final String cusPic;
  final int pointsScore;
  final int rank;

  LeaderModel({
    required this.cusName,
    required this.cusMobile,
    required this.sno,
    required this.customerId,
    required this.cusPic,
    required this.pointsScore,
    required this.rank,
  });

  factory LeaderModel.fromMap(Map<String, dynamic> map) {
    return LeaderModel(
      cusName: map['cus_name'],
      cusMobile: map['cus_mobile'],
      sno: map['sno'],
      customerId: map['customer_id'] ?? " ",
      cusPic: map['cus_pic'],
      pointsScore: map['points_score'],
      rank: map['rank'],
    );
  }
}
