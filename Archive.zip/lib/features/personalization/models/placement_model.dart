import 'dart:convert';

import 'package:get/get_rx/src/rx_types/rx_types.dart';

class PlacementModel {
  final int sno;
  final int branchId;
  final String jobId;
  final int jobCategoryId;
  final int jobSubcategoryId;
  final int companyId;
  final int interviewModeId;
  final int salary;
  final int vacancyCount;
  final String experience;
  final String lastApplyDate;
  final String interviewDate;
  final List<String> interviewChecklistId;
  final List<Skill> skillDescription;
  final List<String> interestStudentIds;
  final String createdAt;
  final int createdBy;
  final String updatedAt;
  final int updatedBy;
  final int status;
  final String companyName;
  final String jobCategoryName;
  final String jobRoleName;
  final String interviewTypeName;
  final String companyAddress;
  RxInt applied; // 👈 make reactive
  RxInt jobSaved;

  PlacementModel({
    required this.sno,
    required this.branchId,
    required this.jobId,
    required this.jobCategoryId,
    required this.jobSubcategoryId,
    required this.companyId,
    required this.interviewModeId,
    required this.salary,
    required this.vacancyCount,
    required this.experience,
    required this.lastApplyDate,
    required this.interviewDate,
    required this.interviewChecklistId,
    required this.skillDescription,
    required this.interestStudentIds,
    required this.createdAt,
    required this.createdBy,
    required this.updatedAt,
    required this.updatedBy,
    required this.status,
    required this.companyName,
    required this.jobCategoryName,
    required this.jobRoleName,
    required this.interviewTypeName,
    required this.companyAddress,
    required this.applied,
    required this.jobSaved,
  });

  factory PlacementModel.fromJson(Map<String, dynamic> json) {
    return PlacementModel(
      sno: (json['sno'] as num?)?.toInt() ?? 0,
      branchId: (json['branch_id'] as num?)?.toInt() ?? 0,
      jobId: json['job_id']?.toString() ?? '',
      jobCategoryId: (json['job_category_id'] as num?)?.toInt() ?? 0,
      jobSubcategoryId: (json['job_subcategory_id'] as num?)?.toInt() ?? 0,
      companyId: (json['company_id'] as num?)?.toInt() ?? 0,
      interviewModeId: (json['interview_mode_id'] as num?)?.toInt() ?? 0,
      salary: (json['salary'] as num?)?.toInt() ?? 0,
      vacancyCount: (json['vacancy_count'] as num?)?.toInt() ?? 0,
      experience: json['experience']?.toString() ?? '',
      lastApplyDate: json['last_apply_date']?.toString() ?? '',
      interviewDate: json['interview_date']?.toString() ?? '',
      interviewChecklistId: json['interview_checklist_id'] != null
          ? List<String>.from(jsonDecode(json['interview_checklist_id']))
          : [],
      skillDescription: json['skill_description'] != null
          ? List<Skill>.from(jsonDecode(json['skill_description'])
              .map((x) => Skill.fromJson(x)))
          : [],
      // interestStudentIds: json['interest_student_ids'] != null
      //     ? List<String>.from(jsonDecode(json['interest_student_ids']))
      //     : [],
      interestStudentIds: json['interest_student_ids'] != null
          ? List<String>.from((jsonDecode(json['interest_student_ids']) as List)
              .map((x) => x.toString()))
          : [],

      createdAt: json['created_at']?.toString() ?? '',
      createdBy: (json['created_by'] as num?)?.toInt() ?? 0,
      updatedAt: json['updated_at']?.toString() ?? '',
      updatedBy: (json['updated_by'] as num?)?.toInt() ?? 0,
      status: (json['status'] as num?)?.toInt() ?? 0,
      companyName: json['company_name']?.toString() ?? '',
      jobCategoryName: json['job_category_name']?.toString() ?? '',
      jobRoleName: json['job_role_name']?.toString() ?? '',
      interviewTypeName: json['interview_type_name']?.toString() ?? '',
      companyAddress: json['company_address']?.toString() ?? '',
      applied:
          ((json['applied'] as num?)?.toInt() ?? 0).obs, // wrap int in .obs
      jobSaved:
          ((json['job_saved'] as num?)?.toInt() ?? 0).obs, // wrap int in .obs
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sno': sno,
      'branch_id': branchId,
      'job_id': jobId,
      'job_category_id': jobCategoryId,
      'job_subcategory_id': jobSubcategoryId,
      'company_id': companyId,
      'interview_mode_id': interviewModeId,
      'salary': salary,
      'vacancy_count': vacancyCount,
      'experience': experience,
      'last_apply_date': lastApplyDate,
      'interview_date': interviewDate,
      'interview_checklist_id': jsonEncode(interviewChecklistId),
      'skill_description':
          jsonEncode(skillDescription.map((skill) => skill.toJson()).toList()),
      'interest_student_ids': jsonEncode(interestStudentIds),
      'created_at': createdAt,
      'created_by': createdBy,
      'updated_at': updatedAt,
      'updated_by': updatedBy,
      'status': status,
      'company_name': companyName,
      'job_category_name': jobCategoryName,
      'job_role_name': jobRoleName,
      'interview_type_name': interviewTypeName,
      'company_address': companyAddress,
      'applied': applied.value,
      'job_saved': jobSaved.value, // 👈 added
    };
  }
}

class Skill {
  final String value;

  Skill({required this.value});

  factory Skill.fromJson(Map<String, dynamic> json) {
    return Skill(value: json['value']?.toString() ?? '');
  }

  Map<String, dynamic> toJson() {
    return {'value': value};
  }
}
