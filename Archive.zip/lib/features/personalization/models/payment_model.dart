/*class PaymentHistoryModel {
  final String paymentDate;
  final String paymentId;
  final int paymentHistoryCustomerId;
  final int payedAmount;
  final String? paymentModeName;

  PaymentHistoryModel({
    required this.paymentDate,
    required this.paymentId,
    required this.paymentHistoryCustomerId,
    required this.payedAmount,
    this.paymentModeName,
  });

  factory PaymentHistoryModel.fromJson(Map<String, dynamic> json) {
    return PaymentHistoryModel(
      payedAmount: json['amount'],
      paymentDate: json['payment_date'],
      paymentHistoryCustomerId: json['payment_historycustomer_id'],
      paymentId: json['payment_id'],
      paymentModeName: json['paymentmode_name'],
    );
  }
}*/
class PaymentHistoryModel {
  final String paymentDate;
  final String paymentId;
  final int paymentHistoryCustomerId;
  final int payedAmount;
  final String? paymentModeName;

  PaymentHistoryModel({
    required this.paymentDate,
    required this.paymentId,
    required this.paymentHistoryCustomerId,
    required this.payedAmount,
    this.paymentModeName,
  });

  factory PaymentHistoryModel.fromJson(Map<String, dynamic> json) {
    return PaymentHistoryModel(
      paymentDate: json['payment_date'] ?? '',
      paymentId: json['payment_id'] ?? '',
      paymentHistoryCustomerId: json['payment_historycustomer_id'] ?? 0,
      payedAmount: json['amount'] ?? 0,
      paymentModeName: json['paymentmode_name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'payment_date': paymentDate,
      'payment_id': paymentId,
      'payment_historycustomer_id': paymentHistoryCustomerId,
      'amount': payedAmount,
      'paymentmode_name': paymentModeName,
    };
  }
}

/*class CoursePaymentModel {
  final String courseName;
  final int courseId;
  final int totalAmount;
  final int customerId;
  final int balanceFee;
  final int paidAmount;
  final List<PaymentHistoryModel> paymentHistory;

  CoursePaymentModel({
    required this.courseName,
    required this.courseId,
    required this.totalAmount,
    required this.customerId,
    required this.balanceFee,
    required this.paidAmount,
    required this.paymentHistory,
  });

  factory CoursePaymentModel.fromJson(Map<String, dynamic> json) {
    var paymentHistoryList = json['payment_history'] as List;
    List<PaymentHistoryModel> paymentHistory = paymentHistoryList
        .map((item) => PaymentHistoryModel.fromJson(item))
        .toList();

    return CoursePaymentModel(
      courseName: json['course_name'],
      courseId: json['course_id'],
      totalAmount: json['total_amount'],
      customerId: json['customer_id'],
      paidAmount: json['paidAmount'],
      balanceFee: json['balanceFee'],
      paymentHistory: paymentHistory,
    );
  }
}*/
class CoursePaymentModel {
  final String courseName;
  final int courseId;
  final int totalAmount;
  final int customerId;
  final int balanceFee;
  final int paidAmount;
  final int redeemcode; // total redeem value
  final List<PaymentHistoryModel> paymentHistory;
  final List<RedeemModel> redeemList;

  CoursePaymentModel({
    required this.courseName,
    required this.courseId,
    required this.totalAmount,
    required this.customerId,
    required this.balanceFee,
    required this.paidAmount,
    required this.redeemcode,
    required this.paymentHistory,
    required this.redeemList,
  });

  factory CoursePaymentModel.fromJson(Map<String, dynamic> json) {
    // Parse payment history
    var paymentHistoryList = json['payment_history'] as List? ?? [];
    List<PaymentHistoryModel> paymentHistory = paymentHistoryList
        .map((item) => PaymentHistoryModel.fromJson(item))
        .toList();

    // Parse redeem list
    var redeemListJson = json['redeemlist'] as List? ?? [];
    List<RedeemModel> redeemList =
        redeemListJson.map((item) => RedeemModel.fromJson(item)).toList();

    return CoursePaymentModel(
      courseName: json['course_name'] ?? '',
      courseId: json['course_id'] ?? 0,
      totalAmount: json['total_amount'] ?? 0,
      customerId: json['customer_id'] ?? 0,
      paidAmount: json['paidAmount'] ?? 0,
      balanceFee: json['balanceFee'] ?? 0,
      redeemcode: json['redeemValue'] ?? 0,
      paymentHistory: paymentHistory,
      redeemList: redeemList,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'course_name': courseName,
      'course_id': courseId,
      'total_amount': totalAmount,
      'customer_id': customerId,
      'paidAmount': paidAmount,
      'balanceFee': balanceFee,
      'redeemValue': redeemcode,
      'payment_history': paymentHistory.map((e) => e.toJson()).toList(),
      'redeemlist': redeemList.map((e) => e.toJson()).toList(),
    };
  }
}

class RedeemModel {
  final int sno;
  final int branchId;
  final int studentId;
  final int crownCount;
  final int couponId;
  final int redeemvalue;
  final String couponCode;
  final String endDate;
  final int merge;
  final String createdAt;
  final int createdBy;
  final String updatedAt;
  final int updatedBy;
  final int status;

  RedeemModel({
    required this.sno,
    required this.branchId,
    required this.studentId,
    required this.crownCount,
    required this.couponId,
    required this.redeemvalue,
    required this.couponCode,
    required this.endDate,
    required this.merge,
    required this.createdAt,
    required this.createdBy,
    required this.updatedAt,
    required this.updatedBy,
    required this.status,
  });

  factory RedeemModel.fromJson(Map<String, dynamic> json) {
    return RedeemModel(
      sno: json['sno'] ?? 0,
      branchId: json['branch_id'] ?? 0,
      studentId: json['student_id'] ?? 0,
      crownCount: json['crown_count'] ?? 0,
      couponId: json['coupon_id'] ?? 0,
      redeemvalue: json['redeem_value'] ?? 0, // ✅ FIXED
      couponCode: json['coupon_code'] ?? '',
      endDate: json['end_date'] ?? '',
      merge: json['merge'] ?? 0,
      createdAt: json['created_at'] ?? '',
      createdBy: json['created_by'] ?? 0,
      updatedAt: json['updated_at'] ?? '',
      updatedBy: json['updated_by'] ?? 0,
      status: json['status'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sno': sno,
      'branch_id': branchId,
      'student_id': studentId,
      'crown_count': crownCount,
      'coupon_id': couponId,
      'redeem_value': redeemvalue,
      'coupon_code': couponCode,
      'end_date': endDate,
      'merge': merge,
      'created_at': createdAt,
      'created_by': createdBy,
      'updated_at': updatedAt,
      'updated_by': updatedBy,
      'status': status,
    };
  }
}
