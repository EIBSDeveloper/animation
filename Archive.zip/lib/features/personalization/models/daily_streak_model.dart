class CourseData {
  final int status;
  final String message;
  final String? errorMsg;
  final List<DailyStreakModel> data;

  CourseData({
    required this.status,
    required this.message,
    this.errorMsg,
    required this.data,
  });

  factory CourseData.fromJson(Map<String, dynamic> json) {
    return CourseData(
      status: int.parse(json['status']),
      message: json['message'],
      errorMsg: json['error_msg'],
      data: (json['data'] as List)
          .map((item) => DailyStreakModel.fromJson(item))
          .toList(),
    );
  }
}

class DailyStreakModel {
  final DailyStreakCourseDataModel coursesDetails;
  final List<DailyAttendanceTopicsModel> attendanceSyllabus;

  DailyStreakModel({
    required this.coursesDetails,
    required this.attendanceSyllabus,
  });

  factory DailyStreakModel.fromJson(Map<String, dynamic> json) {
    return DailyStreakModel(
      coursesDetails: DailyStreakCourseDataModel.fromJson(json['coursesDetails']),
      attendanceSyllabus: (json['AttendanceSyllabus'] as List)
          .map((item) => DailyAttendanceTopicsModel.fromJson(item))
          .toList(),
    );
  }
}

class DailyStreakCourseDataModel {
  final int customerId;
  final int courseId;
  final int batchId;
  final String courseName;
  final int courseDuration;
  final int coursePracticalHours;
  final int courseTheoryHours;
  final String courseSubcategoryName;

  DailyStreakCourseDataModel({
    required this.customerId,
    required this.courseId,
    required this.batchId,
    required this.courseName,
    required this.courseDuration,
    required this.coursePracticalHours,
    required this.courseTheoryHours,
    required this.courseSubcategoryName,
  });

  factory DailyStreakCourseDataModel.fromJson(Map<String, dynamic> json) {
    return DailyStreakCourseDataModel(
      customerId: json['customer_id'],
      courseId: json['course_id'],
      batchId: json['batch_id'],
      courseName: json['course_name'],
      courseDuration: json['course_duration'],
      coursePracticalHours: json['course_partical_hours'],
      courseTheoryHours: json['course_theory_hours'],
      courseSubcategoryName: json['course_subcategory_name'],
    );
  }
}

class DailyAttendanceTopicsModel {
  final String? date;
  final String? attendance;
  final List<String?> topics;

  DailyAttendanceTopicsModel({
    this.date,
    this.attendance,
    required this.topics,
  });

  factory DailyAttendanceTopicsModel.fromJson(Map<String, dynamic> json) {
    return DailyAttendanceTopicsModel(
      date: json['date'] as String?,
      attendance: json['attendance'] as String?,
      topics: (json['topics'] as List<dynamic>).map((item) => item as String?).toList(),
    );
  }
}