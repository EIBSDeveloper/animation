/*
class CoursePaymentResponse {
  final int status;
  final String message;
  final String? errorMsg;
  final CoursePaymentData data;

  CoursePaymentResponse({
    required this.status,
    required this.message,
    this.errorMsg,
    required this.data,
  });

  factory CoursePaymentResponse.fromJson(Map<String, dynamic> json) {
    return CoursePaymentResponse(
      status: json['status'],
      message: json['message'],
      errorMsg: json['error_msg'],
      data: CoursePaymentData.fromJson(json['data']),
    );
  }
}

class CoursePaymentData {
  final List<CourseDetails> courseDetails;
  final List<PaymentDetails> paymentDetails;

  CoursePaymentData({
    required this.courseDetails,
    required this.paymentDetails,
  });

  factory CoursePaymentData.fromJson(Map<String, dynamic> json) {
    return CoursePaymentData(
      courseDetails: (json['course_details'] as List)
          .map((e) => CourseDetails.fromJson(e))
          .toList(),
      paymentDetails: (json['payment_details'] as List)
          .map((e) => PaymentDetails.fromJson(e))
          .toList(),
    );
  }
}

class CourseDetails {
  final int sno;
  final int customerId;
  final String courseId;
  final int batchId;
  final String batchName;
  final String courseName;
  final String courseCode;
  final String thumbnail;
  final String attachment;
  final String courseCompletePercentage;
  final int courseCompletedDays;
  final String courseVersion;

  CourseDetails({
    required this.sno,
    required this.customerId,
    required this.courseId,
    required this.batchId,
    required this.batchName,
    required this.courseName,
    required this.courseCode,
    required this.thumbnail,
    required this.attachment,
    required this.courseCompletePercentage,
    required this.courseCompletedDays,
    required this.courseVersion,
  });

  factory CourseDetails.fromJson(Map<String, dynamic> json) {
    return CourseDetails(
      sno: json['sno'],
      customerId: json['customer_id'],
      courseId: json['course_id'],
      batchId: json['batch_id'],
      batchName: json['batch_name'] ?? "",
      courseName: json['course_name'],
      courseCode: json['course_code'],
      thumbnail: json['thumbnail'],
      attachment: json['attachment'],
      courseCompletePercentage: json['course_complete_percentage'],
      courseCompletedDays: json['course_completedDays'],
      courseVersion: json['course_version'],
    );
  }
}

class PaymentDetails {
  final String courseName;
  final int courseId;
  final double totalAmount;
  final double paidAmount;
  final double balanceFee;
  final List<PaymentHistory> paymentHistory;

  PaymentDetails({
    required this.courseName,
    required this.courseId,
    required this.totalAmount,
    required this.paidAmount,
    required this.balanceFee,
    required this.paymentHistory,
  });

  factory PaymentDetails.fromJson(Map<String, dynamic> json) {
    return PaymentDetails(
      courseName: json['course_name'],
      courseId: json['course_id'],
      totalAmount: json['total_amount'].toDouble(),
      paidAmount: json['paidAmount'].toDouble(),
      balanceFee: json['balanceFee'].toDouble(),
      paymentHistory: (json['payment_history'] as List)
          .map((e) => PaymentHistory.fromJson(e))
          .toList(),
    );
  }
}

class PaymentHistory {
  final String paymentDate;
  final double amount;
  final String paymentMode;
  final String paymentId;

  PaymentHistory({
    required this.paymentDate,
    required this.amount,
    required this.paymentMode,
    required this.paymentId,
  });

  factory PaymentHistory.fromJson(Map<String, dynamic> json) {
    return PaymentHistory(
      paymentDate: json['payment_date'],
      amount: json['amount'].toDouble(),
      paymentMode: json['paymentmode_name'],
      paymentId: json['payment_id'],
    );
  }
}
*/
