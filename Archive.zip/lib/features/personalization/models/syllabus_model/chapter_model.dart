class ChapterModel {
  final String chapterCode;
  final String chapterName;
  final String chapterstatus;
  final double chapterTheoryHours;
  final double chapterPracticalHours;
  final int chapterId;

  // New fields
  final bool hasStudyDoc;
  final bool hasPpt;
  final bool hasLabCode;
  final bool hasPdf;

  ChapterModel({
    required this.chapterCode,
    required this.chapterName,
    required this.chapterTheoryHours,
    required this.chapterPracticalHours,
    required this.chapterId,
    required this.chapterstatus,
    required this.hasStudyDoc,
    required this.hasPpt,
    required this.hasLabCode,
    required this.hasPdf,
  });

  // Factory constructor to create an instance from JSON
  factory ChapterModel.fromJson(Map<String, dynamic> json) {
    return ChapterModel(
      chapterCode: json['chapter_code'],
      chapterName: json['chapter_name'],
      chapterstatus: json['chapter_status'],
      chapterTheoryHours: (json['chapter_theory_hours'] as num).toDouble(),
      chapterPracticalHours:
          (json['chapter_practical_hours'] as num).toDouble(),
      chapterId: json['chapter_id'],
      hasStudyDoc: json['has_study_doc'] ?? false,
      hasPpt: json['has_ppt'] ?? false,
      hasLabCode: json['has_lab_code'] ?? false,
      hasPdf: json['has_pdf'] ?? false,
    );
  }
}
