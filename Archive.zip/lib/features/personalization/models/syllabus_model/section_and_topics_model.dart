// // Main Data Model
//
// class ChapterAndSectionModel {
//   final List<ChapterDetailModelForFetchTopics> chapterDetails;
//   final List<SectionModel> sections;
//
//   ChapterAndSectionModel({
//     required this.chapterDetails,
//     required this.sections,
//   });
//
//   // Factory constructor to create an instance from JSON
//   factory ChapterAndSectionModel.fromJson(Map<String, dynamic> json) {
//     return ChapterAndSectionModel(
//       chapterDetails: (json['chapterDetails'] as List)
//           .map((e) => ChapterDetailModelForFetchTopics.fromJson(e))
//           .toList(),
//       sections: (json['sections'] as List)
//           .map((e) => SectionModel.fromJson(e))
//           .toList(),
//     );
//   }
// }
//
// class ChapterDetailModelForFetchTopics {
//   final String courseChapterName;
//   final int courseChapterPracticalHours;
//   final int courseChapterTheoryHours;
//   final int sno;
//   final int courseId;
//   final String courseChapterId;
//
//   ChapterDetailModelForFetchTopics({
//     required this.courseChapterName,
//     required this.courseChapterPracticalHours,
//     required this.courseChapterTheoryHours,
//     required this.sno,
//     required this.courseId,
//     required this.courseChapterId,
//   });
//
//   factory ChapterDetailModelForFetchTopics.fromJson(Map<String, dynamic> json) {
//     return ChapterDetailModelForFetchTopics(
//       courseChapterName: json['course_chapter_name'],
//       courseChapterPracticalHours: json['course_chapter_practical_hours'],
//       courseChapterTheoryHours:
//           int.parse(json['course_chapter_theory_hours'].toString()),
//       sno: json['sno'],
//       courseId: json['course_id'],
//       courseChapterId: json['course_chapter_id'],
//     );
//   }
// }
//
// // Section Model
// class SectionModel {
//   final String sectionId;
//   final String sectionName;
//   final int maxSno;
//   final List<TopicModel> topics;
//
//   SectionModel({
//     required this.sectionId,
//     required this.sectionName,
//     required this.maxSno,
//     required this.topics,
//   });
//
//   factory SectionModel.fromJson(Map<String, dynamic> json) {
//     return SectionModel(
//       sectionId: json['section_id'],
//       sectionName: json['section_name'],
//       maxSno: json['max_sno'],
//       topics:
//           (json['topics'] as List).map((e) => TopicModel.fromJson(e)).toList(),
//     );
//   }
// }
//
// // Topic Model
// class TopicModel {
//   final String topicId;
//   final String topicName;
//   final int maxSno;
//
//   TopicModel({
//     required this.topicId,
//     required this.topicName,
//     required this.maxSno,
//   });
//
//   factory TopicModel.fromJson(Map<String, dynamic> json) {
//     return TopicModel(
//       topicId: json['topic_id'],
//       topicName: json['topic_name'],
//       maxSno: json['max_sno'],
//     );
//   }
// }
// Main Data Model
class ChapterAndSectionModel {
  final List<ChapterDetailModelForFetchTopics> chapterDetails;
  final List<SectionModel> sections;

  ChapterAndSectionModel({
    required this.chapterDetails,
    required this.sections,
  });

  factory ChapterAndSectionModel.fromJson(Map<String, dynamic> json) {
    return ChapterAndSectionModel(
      chapterDetails: (json['chapterDetails'] as List? ?? [])
          .map((e) => ChapterDetailModelForFetchTopics.fromJson(
              e as Map<String, dynamic>))
          .toList(),
      sections: (json['sections'] as List? ?? [])
          .map((e) => SectionModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

// Chapter Details Model
class ChapterDetailModelForFetchTopics {
  final String courseChapterName;
  final double courseChapterPracticalHours; // Changed to double
  final double courseChapterTheoryHours; // Changed to double
  final int sno;
  final int courseId;
  final String courseChapterId;

  ChapterDetailModelForFetchTopics({
    required this.courseChapterName,
    required this.courseChapterPracticalHours,
    required this.courseChapterTheoryHours,
    required this.sno,
    required this.courseId,
    required this.courseChapterId,
  });

  factory ChapterDetailModelForFetchTopics.fromJson(Map<String, dynamic> json) {
    return ChapterDetailModelForFetchTopics(
      courseChapterName: json['course_chapter_name'] as String? ?? '',
      courseChapterPracticalHours:
          (json['course_chapter_practical_hours'] as num? ?? 0.0).toDouble(),
      courseChapterTheoryHours:
          (json['course_chapter_theory_hours'] as num? ?? 0.0).toDouble(),
      sno: json['sno'] as int? ?? 0,
      courseId: json['course_id'] as int? ?? 0,
      courseChapterId: json['course_chapter_id'] as String? ?? '',
    );
  }
}

// Section Model
class SectionModel {
  final String sectionId;
  final String sectionName;
  final int maxSno;
  final List<TopicModel> topics;

  SectionModel({
    required this.sectionId,
    required this.sectionName,
    required this.maxSno,
    required this.topics,
  });

  factory SectionModel.fromJson(Map<String, dynamic> json) {
    return SectionModel(
      sectionId: json['section_id'] as String? ?? '',
      sectionName: json['section_name'] as String? ?? '',
      maxSno: json['max_sno'] as int? ?? 0,
      topics: (json['topics'] as List? ?? [])
          .map((e) => TopicModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

// Topic Model
class TopicModel {
  final String topicId;
  final String topicName;
  final int maxSno;
  final String topicdescription;

  TopicModel(
      {required this.topicId,
      required this.topicName,
      required this.maxSno,
      required this.topicdescription});

  factory TopicModel.fromJson(Map<String, dynamic> json) {
    return TopicModel(
      topicId: json['topic_id'] as String? ?? '',
      topicName: json['topic_name'] as String? ?? '',
      maxSno: json['max_sno'] as int? ?? 0,
      topicdescription: json['topic_description'] as String? ?? '',
    );
  }
}
