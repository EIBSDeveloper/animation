// Course.dart

class CourseDetailModel {
  final int? sno;
  final int? customerId;
  final String? courseId;
  final int? batchId;
  final int? status;
  final int courseSno;
  final String? batchName;
  final String? startDate;
  final String? endDate;
  final int? slotType;
  final String? courseVersion;
  final String courseName;
  final String? courseCode;
  final String? attachment;
  final String? thumbnail;
  final int? courseDuration;
  final int? coursePracticalHours;
  final int? courseTheoryHours;
  final String? courseTypeName;
  final String? courseCategoryName;
  final String? courseSubcategoryName;
  final String? courseCompletePercentage;
  final int? courseCompletedDays;
  final int? remainingdays;
  final String? statuslabel;
  String rating;
  CourseDetailModel({
    this.sno,
    this.customerId,
    this.courseId,
    this.batchId,
    this.status,
    required this.courseSno,
    this.batchName,
    this.startDate,
    this.endDate,
    this.slotType,
    this.courseVersion,
    required this.courseName,
    this.courseCode,
    this.attachment,
    this.thumbnail,
    this.courseDuration,
    this.coursePracticalHours,
    this.courseTheoryHours,
    this.courseTypeName,
    this.courseCategoryName,
    this.courseSubcategoryName,
    this.courseCompletePercentage,
    this.courseCompletedDays,
    this.remainingdays,
    required this.statuslabel,
    required this.rating,
  });

  factory CourseDetailModel.fromJson(Map<String, dynamic> json) {
    return CourseDetailModel(
      sno: json['sno'],
      customerId: json['customer_id'],
      courseId: json['course_id'],
      batchId: json['batch_id'],
      status: json['status'],
      courseSno: json['course_sno'],
      batchName: json['batch_name'],
      startDate: json['start_date'],
      endDate: json['end_date'],
      slotType: json['slot_type'],
      courseVersion: json['course_version'],
      courseName: json['course_name'],
      courseCode: json['course_code'],
      attachment: json['attachment'],
      thumbnail: json['thumbnail'],
      courseDuration: json['course_duration'],
      coursePracticalHours: json['course_partical_hours'],
      courseTheoryHours: json['course_theory_hours'],
      courseTypeName: json['course_type_name'],
      courseCategoryName: json['course_category_name'],
      courseSubcategoryName: json['course_subcategory_name'],
      courseCompletePercentage: json['course_complete_percentage'],
      courseCompletedDays: json['course_completedDays'],
      statuslabel: json['status_label'],
      remainingdays: json['remaining_days'] ?? 0,
      rating: json['rating'] ?? '0', // ✅ safe default
    );
  }
}
