class ExamResponse {
  final int status;
  final String message;
  final String? errorMsg;
  final ExamDetailsModel examDetails;
  final List<ExamQuestionModel> examQuestions;

  ExamResponse({
    required this.status,
    required this.message,
    this.errorMsg,
    required this.examDetails,
    required this.examQuestions,
  });

  factory ExamResponse.fromJson(Map<String, dynamic> json) {
    return ExamResponse(
      status: json['status'],
      message: json['message'],
      errorMsg: json['error_msg'],
      examDetails: ExamDetailsModel.fromJson(json['Exam Details']),
      examQuestions: (json['Exam Questions'] as List)
          .map((q) => ExamQuestionModel.fromJson(q))
          .toList(),
    );
  }
}

class ExamDetailsModel {
  final int sno;
  final String examId;
  final int isGroup;
  final String? multiExamIds;
  final int branchId;
  final String examName;
  final int examCategory;
  final int examBasedOn;
  final int questionBankId;
  final int examType;
  final int noOfQuestions;
  final List<ExamQuestionId> examQuestionIds;
  final int examDuration;
  final String examStartDate;
  final String examEndDate;
  final String examAttempt;
  final int? noOfAttempt;
  final int positiveMarkPerQuest;
  final int negativeMarkPerQuest;
  final int totalMarks;
  final int passingMarks;
  final String examBatch;
  final int examHint;
  final String? hintText;
  final int examExplanation;
  final String? explanationText;
  final int questionGenerate;
  final int displayTotalScore;
  final int displayReport;
  final String certificate;
  final String? certificateTemplate;
  final String examMode;
  final int? examModeAmount;
  final int? examModePoints;
  final int knowledgeLevelId;
  final String? examDescription;
  final String thumbnailImage;
  final int createdBy;
  final String createdAt;
  final int updatedBy;
  final String updatedAt;
  final int status;
  final String questionBankName;

  ExamDetailsModel({
    required this.sno,
    required this.examId,
    required this.isGroup,
    this.multiExamIds,
    required this.branchId,
    required this.examName,
    required this.examCategory,
    required this.examBasedOn,
    required this.questionBankId,
    required this.examType,
    required this.noOfQuestions,
    required this.examQuestionIds,
    required this.examDuration,
    required this.examStartDate,
    required this.examEndDate,
    required this.examAttempt,
    this.noOfAttempt,
    required this.positiveMarkPerQuest,
    required this.negativeMarkPerQuest,
    required this.totalMarks,
    required this.passingMarks,
    required this.examBatch,
    required this.examHint,
    this.hintText,
    required this.examExplanation,
    this.explanationText,
    required this.questionGenerate,
    required this.displayTotalScore,
    required this.displayReport,
    required this.certificate,
    this.certificateTemplate,
    required this.examMode,
    this.examModeAmount,
    this.examModePoints,
    required this.knowledgeLevelId,
    this.examDescription,
    required this.thumbnailImage,
    required this.createdBy,
    required this.createdAt,
    required this.updatedBy,
    required this.updatedAt,
    required this.status,
    required this.questionBankName,
  });

  factory ExamDetailsModel.fromJson(Map<String, dynamic> json) {
    return ExamDetailsModel(
      sno: json['sno'],
      examId: json['exam_id'],
      isGroup: json['is_group'],
      multiExamIds: json['multi_exam_ids'],
      branchId: json['branch_id'],
      examName: json['exam_name'],
      examCategory: json['exam_category'],
      examBasedOn: json['exam_based_on'],
      questionBankId: json['question_bank_id'],
      examType: json['exam_type'],
      noOfQuestions: json['no_of_questions'],
      examQuestionIds: (json['exam_question_ids'] as List)
          .map((e) => ExamQuestionId.fromJson(e))
          .toList(),
      examDuration: json['exam_duration'],
      examStartDate: json['exam_start_date'],
      examEndDate: json['exam_end_date'],
      examAttempt: json['exam_attempt'],
      noOfAttempt: json['no_of_attempt'],
      positiveMarkPerQuest: json['positive_mark_per_quest'],
      negativeMarkPerQuest: json['negative_mark_per_quest'],
      totalMarks: json['total_marks'],
      passingMarks: json['passing_marks'],
      examBatch: json['exam_batch'],
      examHint: json['exam_hint'],
      hintText: json['hint_text'],
      examExplanation: json['exam_explanation'],
      explanationText: json['explanation_text'],
      questionGenerate: json['question_generate'],
      displayTotalScore: json['display_total_score'],
      displayReport: json['display_report'],
      certificate: json['certificate'],
      certificateTemplate: json['certificate_template'],
      examMode: json['exam_mode'],
      examModeAmount: json['exam_mode_amount'],
      examModePoints: json['exam_mode_points'],
      knowledgeLevelId: json['knowledge_level_id'],
      examDescription: json['exam_description'],
      thumbnailImage: json['thumbnail_image'],
      createdBy: json['created_by'],
      createdAt: json['created_at'],
      updatedBy: json['updated_by'],
      updatedAt: json['updated_at'],
      status: json['status'],
      questionBankName: json['question_bank_name'],
    );
  }
}

class ExamQuestionId {
  final int questionId;

  ExamQuestionId({required this.questionId});

  factory ExamQuestionId.fromJson(Map<String, dynamic> json) {
    return ExamQuestionId(
      questionId: json['question_id'],
    );
  }
}

class ExamQuestionModel {
  final int questionId;
  final int branchId;
  final int questionBankId;
  final String questionName;
  final String questionType;
  final String? examName;
  final String questionIdAuto;
  final List<String> questionOption;
  final String answer;
  final int questionHint;
  final String? questionExplanation;
  final String? hintText;
  final String? explanationText;
  final int questionSnippet;
  final String snippetContent;
  final int status;

  ExamQuestionModel({
    required this.questionId,
    required this.branchId,
    required this.questionBankId,
    required this.questionName,
    required this.questionType,
    this.examName,
    required this.questionIdAuto,
    required this.questionOption,
    required this.answer,
    required this.questionHint,
    this.questionExplanation,
    required this.hintText,
    this.explanationText,
    required this.questionSnippet,
    required this.snippetContent,
    required this.status,
  });

  factory ExamQuestionModel.fromJson(Map<String, dynamic> json) {
    return ExamQuestionModel(
      questionId: json['question_id'],
      branchId: json['branch_id'],
      questionBankId: json['question_bank_id'],
      questionName: json['question_name'],
      questionType: json['question_type'],
      examName: json['exam_name'],
      questionIdAuto: json['question_id_auto'],
      questionOption: List<String>.from(json['question_option']),
      answer: json['answer'],
      questionHint: json['question_hint'],
      questionExplanation: json['question_explanation'],
      hintText: json['hint_text'],
      explanationText: json['explanation_text'],
      questionSnippet: json['question_snippet'],
      snippetContent: json['snippet_content'],
      status: json['status'],
    );
  }
}
