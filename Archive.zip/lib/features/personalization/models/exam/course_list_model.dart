class CourseListModel {
  int customerId;
  int courseId;
  int batchId;
  String courseName;
  int examCount;
  List<String>? examIds;

  CourseListModel({
    required this.customerId,
    required this.courseId,
    required this.batchId,
    required this.courseName,
    required this.examCount,
    this.examIds,
  });

  factory CourseListModel.fromJson(Map<String, dynamic> json) {
    return CourseListModel(
      customerId: json['customer_id'],
      courseId: json['course_id'],
      batchId: json['batch_id'],
      courseName: json['course_name'],
      examCount: json['exam_count'],
      examIds: List<String>.from(json['exam_ids']),
    );
  }
}
