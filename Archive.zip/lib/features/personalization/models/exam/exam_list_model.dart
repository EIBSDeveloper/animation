class ExamResponse {
  final int status;
  final String message;
  final String? errorMsg;
  final List<ExamListModel> data;

  ExamResponse({
    required this.status,
    required this.message,
    this.errorMsg,
    required this.data,
  });

  factory ExamResponse.fromJson(Map<String, dynamic> json) {
    return ExamResponse(
      status: json['status'],
      message: json['message'],
      errorMsg: json['error_msg'],
      data:
          (json['data'] as List).map((e) => ExamListModel.fromJson(e)).toList(),
    );
  }
}

class ExamListModel {
  final String examId;
  final int sno;
  final int isGroup;
  final int questionBankId;
  final int examType;
  final int examDuration;
  final String examName;
  final String examStartDate;
  final String examEndDate;
  final int? noOfAttempt;
  final int positiveMarkPerQuest;
  final int negativeMarkPerQuest;
  final String examAttempt;
  final List<int> questionIds;
  final int noOfQuestions;
  final int totalMarks;
  final int examHint;
  final String? hintText;
  final int examExplanation;
  final String? explanationText;
  final int displayTotalScore;
  final String certificate;
  final String examMode;
  final double? examModeAmount;
  final int? examModePoints;
  final String? examDescription;
  final String thumbnailImage;
  final int status;

  ExamListModel({
    required this.examId,
    required this.sno,
    required this.isGroup,
    required this.questionBankId,
    required this.examType,
    required this.examDuration,
    required this.examName,
    required this.examStartDate,
    required this.examEndDate,
    this.noOfAttempt,
    required this.positiveMarkPerQuest,
    required this.negativeMarkPerQuest,
    required this.examAttempt,
    required this.questionIds,
    required this.noOfQuestions,
    required this.totalMarks,
    required this.examHint,
    this.hintText,
    required this.examExplanation,
    this.explanationText,
    required this.displayTotalScore,
    required this.certificate,
    required this.examMode,
    this.examModeAmount,
    this.examModePoints,
    this.examDescription,
    required this.thumbnailImage,
    required this.status,
  });

  factory ExamListModel.fromJson(Map<String, dynamic> json) {
    return ExamListModel(
      examId: json['exam_id'],
      sno: json['sno'],
      isGroup: json['is_group'],
      questionBankId: json['question_bank_id'],
      examType: json['exam_type'],
      examDuration: json['exam_duration'],
      examName: json['exam_name'],
      examStartDate: json['exam_start_date'],
      examEndDate: json['exam_end_date'],
      noOfAttempt: json['no_of_attempt'],
      positiveMarkPerQuest: json['positive_mark_per_quest'],
      negativeMarkPerQuest: json['negative_mark_per_quest'],
      examAttempt: json['exam_attempt'],
      questionIds: List<int>.from(json['question_ids']),
      noOfQuestions: json['no_of_questions'],
      totalMarks: json['total_marks'],
      examHint: json['exam_hint'],
      hintText: json['hint_text'],
      examExplanation: json['exam_explanation'],
      explanationText: json['explanation_text'],
      displayTotalScore: json['display_total_score'],
      certificate: json['certificate'],
      examMode: json['exam_mode'],
      examModeAmount: json['exam_mode_amount']?.toDouble(),
      examModePoints: json['exam_mode_points'],
      examDescription: json['exam_description'],
      thumbnailImage: json['thumbnail_image'],
      status: json['status'],
    );
  }
}
