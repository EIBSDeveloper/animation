class ExamResponse {
  int? status;
  String? message;
  String? errorMsg;
  List<ExamReportListModel>? data;

  ExamResponse({
    this.status,
    this.message,
    this.errorMsg,
    this.data,
  });

  factory ExamResponse.fromJson(Map<String, dynamic> json) {
    return ExamResponse(
      status: json['status'],
      message: json['message'],
      errorMsg: json['error_msg'],
      data: json['data'] != null
          ? (json['data'] as List)
              .map((item) => ExamReportListModel.fromJson(item))
              .toList()
          : [],
    );
  }
}

class ExamReportListModel {
  String? examId;
  int? sno;
  int? isGroup;
  int? questionBankId;
  int? examType;
  int? examDuration;
  String? examName;
  String? examStartDate;
  String? examEndDate;
  int? noOfAttempt;
  int? positiveMarkPerQuest;
  int? negativeMarkPerQuest;
  String? examAttempt;
  List<int>? questionIds;
  int? noOfQuestions;
  int? totalMarks;
  int? examHint;
  String? hintText;
  int? examExplanation;
  String? explanationText;
  int? displayTotalScore;
  String? certificate;
  String? examMode;
  int? examModeAmount;
  dynamic examModePoints;
  String? examDescription;
  String? thumbnailImage;
  int? status;

  ExamReportListModel({
    this.examId,
    this.sno,
    this.isGroup,
    this.questionBankId,
    this.examType,
    this.examDuration,
    this.examName,
    this.examStartDate,
    this.examEndDate,
    this.noOfAttempt,
    this.positiveMarkPerQuest,
    this.negativeMarkPerQuest,
    this.examAttempt,
    this.questionIds,
    this.noOfQuestions,
    this.totalMarks,
    this.examHint,
    this.hintText,
    this.examExplanation,
    this.explanationText,
    this.displayTotalScore,
    this.certificate,
    this.examMode,
    this.examModeAmount,
    this.examModePoints,
    this.examDescription,
    this.thumbnailImage,
    this.status,
  });

  factory ExamReportListModel.fromJson(Map<String, dynamic> json) {
    return ExamReportListModel(
      examId: json['exam_id'],
      sno: json['sno'],
      isGroup: json['is_group'],
      questionBankId: json['question_bank_id'],
      examType: json['exam_type'],
      examDuration: json['exam_duration'],
      examName: json['exam_name'],
      examStartDate: json['exam_start_date'],
      examEndDate: json['exam_end_date'],
      noOfAttempt: json['no_of_attempt'],
      positiveMarkPerQuest: json['positive_mark_per_quest'],
      negativeMarkPerQuest: json['negative_mark_per_quest'],
      examAttempt: json['exam_attempt'],
      questionIds: json['question_ids'] != null
          ? List<int>.from(json['question_ids'])
          : null,
      noOfQuestions: json['no_of_questions'],
      totalMarks: json['total_marks'],
      examHint: json['exam_hint'],
      hintText: json['hint_text'],
      examExplanation: json['exam_explanation'],
      explanationText: json['explanation_text'],
      displayTotalScore: json['display_total_score'],
      certificate: json['certificate'],
      examMode: json['exam_mode'],
      examModeAmount: json['exam_mode_amount'],
      examModePoints: json['exam_mode_points'],
      examDescription: json['exam_description'],
      thumbnailImage: json['thumbnail_image'],
      status: json['status'],
    );
  }
}
