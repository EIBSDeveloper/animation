class QuestionReportModel {
  final int questionId;
  final String questionName;
  final String questionType;
  final List<String> questionOptions;
  final String? correctAnswer; // Nullable field
  final String? hintText; // Nullable field
  final String? explanationText; // Nullable field
  final String? studentAnswer; // Nullable field
  final int timeSpent;
  final String? correctness; // Nullable field

  QuestionReportModel({
    required this.questionId,
    required this.questionName,
    required this.questionType,
    required this.questionOptions,
    this.correctAnswer,
    this.hintText,
    this.explanationText,
    this.studentAnswer,
    required this.timeSpent,
    this.correctness,
  });

  factory QuestionReportModel.fromJson(Map<String, dynamic> json) {
    return QuestionReportModel(
      questionId: json['question_id'] ?? 0,
      questionName: json['question_name'] ?? '',
      questionType: json['question_type'] ?? '',
      questionOptions: List<String>.from(json['question_options'] ?? []),
      correctAnswer: json['correct_answer'],
      hintText: json['hint_text'],
      explanationText: json['explanation_text'],
      studentAnswer: json['student_answer'],
      timeSpent: json['time_spent'] ?? 0,
      correctness: json['correctness'],
    );
  }
}

class ExamReportModel {
  final String examId;
  final int sno;
  final int isGroup;
  final int questionBankId;
  final int examType;
  final int examDuration;
  final String examName;
  final String examStartDate;
  final String examEndDate;
  final int noOfAttempt;
  final int positiveMarkPerQuest;
  final int negativeMarkPerQuest;
  final String? examAttempt; // Nullable field
  final List<int> questionIds;
  final int noOfQuestions;
  final int totalMarks;
  final int examHint;
  final String? hintText; // Nullable field
  final int examExplanation;
  final String? explanationText; // Nullable field
  final int displayTotalScore;
  final String certificate;
  final String examMode;
  final dynamic examModeAmount;
  final dynamic examModePoints;
  final String? examDescription; // Nullable field
  final String thumbnailImage;
  final int status;

  ExamReportModel({
    required this.examId,
    required this.sno,
    required this.isGroup,
    required this.questionBankId,
    required this.examType,
    required this.examDuration,
    required this.examName,
    required this.examStartDate,
    required this.examEndDate,
    required this.noOfAttempt,
    required this.positiveMarkPerQuest,
    required this.negativeMarkPerQuest,
    this.examAttempt,
    required this.questionIds,
    required this.noOfQuestions,
    required this.totalMarks,
    required this.examHint,
    this.hintText,
    required this.examExplanation,
    this.explanationText,
    required this.displayTotalScore,
    required this.certificate,
    required this.examMode,
    this.examModeAmount,
    this.examModePoints,
    this.examDescription,
    required this.thumbnailImage,
    required this.status,
  });

  factory ExamReportModel.fromJson(Map<String, dynamic> json) {
    return ExamReportModel(
      examId: json['exam_id'] ?? '',
      sno: json['sno'] ?? 0,
      isGroup: json['is_group'] ?? 0,
      questionBankId: json['question_bank_id'] ?? 0,
      examType: json['exam_type'] ?? 0,
      examDuration: json['exam_duration'] ?? 0,
      examName: json['exam_name'] ?? '',
      examStartDate: json['exam_start_date'] ?? '',
      examEndDate: json['exam_end_date'] ?? '',
      noOfAttempt: json['no_of_attempt'] ?? 0,
      positiveMarkPerQuest: json['positive_mark_per_quest'] ?? 0,
      negativeMarkPerQuest: json['negative_mark_per_quest'] ?? 0,
      examAttempt: json['exam_attempt'],
      questionIds: List<int>.from(json['question_ids'] ?? []),
      noOfQuestions: json['no_of_questions'] ?? 0,
      totalMarks: json['total_marks'] ?? 0,
      examHint: json['exam_hint'] ?? 0,
      hintText: json['hint_text'],
      examExplanation: json['exam_explanation'] ?? 0,
      explanationText: json['explanation_text'],
      displayTotalScore: json['display_total_score'] ?? 0,
      certificate: json['certificate'] ?? '',
      examMode: json['exam_mode'] ?? '',
      examModeAmount: json['exam_mode_amount'],
      examModePoints: json['exam_mode_points'],
      examDescription: json['exam_description'],
      thumbnailImage: json['thumbnail_image'] ?? '',
      status: json['status'] ?? 0,
    );
  }
}

class ExamProcessModel {
  final String examProcessId;
  final int sno;
  final int branchId;
  final int examId;
  final int studentId;
  final int totalMarks;
  final int studentMarks;
  final int attemptedNotCount;
  final int totalAttendedDuration;
  final int status;

  ExamProcessModel({
    required this.examProcessId,
    required this.sno,
    required this.branchId,
    required this.examId,
    required this.studentId,
    required this.totalMarks,
    required this.studentMarks,
    required this.attemptedNotCount,
    required this.totalAttendedDuration,
    required this.status,
  });

  // Factory method to create an instance of ExamProcess from a JSON map
  factory ExamProcessModel.fromJson(Map<String, dynamic> json) {
    return ExamProcessModel(
      examProcessId: json['exam_process_id'] ?? '',
      sno: json['sno'] ?? 0,
      branchId: json['branch_id'] ?? 0,
      examId: json['exam_id'] ?? 0,
      studentId: json['student_id'] ?? 0,
      totalMarks: json['total_marks'] ?? 0,
      studentMarks: json['student_marks'] ?? 0,
      attemptedNotCount: json['attempted_not_count'] ?? 0,
      totalAttendedDuration: json['total_attended_duration'] ?? 0,
      status: json['status'] ?? 0,
    );
  }
}
