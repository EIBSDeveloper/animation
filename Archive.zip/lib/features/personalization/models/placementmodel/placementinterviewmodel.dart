class PlacementInterviewModel {
  final int sno;
  final int branchId;
  final String interviewDate;
  final String jobCategoryName;
  final String jobRoleName;
  final String interviewTypeName;
  final String companyName;
  final String companyAddress;
  final String interviewStatus;
  final String daysRemaining;

  PlacementInterviewModel({
    required this.sno,
    required this.branchId,
    required this.interviewDate,
    required this.jobCategoryName,
    required this.jobRoleName,
    required this.interviewTypeName,
    required this.companyName,
    required this.companyAddress,
    required this.interviewStatus,
    required this.daysRemaining,
  });

  factory PlacementInterviewModel.fromJson(Map<String, dynamic> json) {
    return PlacementInterviewModel(
      sno: json['sno'] ?? 0,
      branchId: json['branch_id'] ?? 0,
      interviewDate: json['interview_date'] ?? '',
      jobCategoryName: json['job_category_name'] ?? '',
      jobRoleName: json['job_role_name'] ?? '',
      interviewTypeName: json['interview_type_name'] ?? '',
      companyName: json['company_name'] ?? '',
      companyAddress: json['company_address'] ?? '',
      interviewStatus: json['interview_status'] ?? '',
      daysRemaining: json['days_remaining'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sno': sno,
      'branch_id': branchId,
      'interview_date': interviewDate,
      'job_category_name': jobCategoryName,
      'job_role_name': jobRoleName,
      'interview_type_name': interviewTypeName,
      'company_name': companyName,
      'company_address': companyAddress,
      'interview_status': interviewStatus,
      'days_remaining': daysRemaining,
    };
  }
}
