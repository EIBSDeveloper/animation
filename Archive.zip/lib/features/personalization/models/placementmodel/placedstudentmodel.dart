class PlacedStudentModel {
  final int? customerId;
  final String? companyName;
  final String? selectedDate;
  final String? jobPosition;
  final String? courseName;
  final String? courseTypeName;
  final String? cusPic;
  final String? customerPic;

  PlacedStudentModel({
    this.customerId,
    this.companyName,
    this.selectedDate,
    this.jobPosition,
    this.courseName,
    this.courseTypeName,
    this.cusPic,
    this.customerPic,
  });

  factory PlacedStudentModel.fromJson(Map<String, dynamic> json) {
    return PlacedStudentModel(
      customerId: json['customer_id'] as int?,
      companyName: json['company_name'] as String?,
      selectedDate: json['selected_date'] as String?,
      jobPosition: json['job_position'] as String?,
      courseName: json['course_name'] as String?, // ✅ corrected
      courseTypeName: json['course_type_name'] as String?, // ✅ corrected
      cusPic: json['cus_pic'] as String?,
      customerPic: json['customer_pic'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'customer_id': customerId,
      'company_name': companyName,
      'selected_date': selectedDate,
      'job_position': jobPosition,
      'course_name': courseName,
      'course_type_name': courseTypeName,
      'cus_pic': cusPic,
      'customer_pic': customerPic,
    };
  }
}
