
class BatchDetailsModel {

  final String batchName;
  final int courseTypeId;
  final int courseId;
  final int slotId;
  final String startDate;
  final String endDate;
  final int classroomId;
  final String staffId;
  final String? batchDesc;
  final int status;
  final String slotName;
  final String courseName;
  final int customerId;
  final int batchId;
  final String batchAutoIncrementId;
  final String courseTypeName;
  final int courseDuration;
  final String courseVersion;
  final String classRoomName;
  final int classRoomType;
  final String slotTypeName;
  final String startTime;
  final String endTime;
  final List<String> slotTypeDays;
  final String staffName;
  final int? batchDurationStatus;

  BatchDetailsModel({
    required this.batchName,
    required this.courseTypeId,
    required this.courseId,
    required this.slotId,
    required this.startDate,
    required this.endDate,
    required this.classroomId,
    required this.staffId,
    this.batchDesc,
    required this.status,
    required this.slotName,
    required this.courseName,
    required this.customerId,
    required this.batchId,
    required this.batchAutoIncrementId,
    required this.courseTypeName,
    required this.courseDuration,
    required this.courseVersion,
    required this.classRoomName,
    required this.classRoomType,
    required this.slotTypeName,
    required this.startTime,
    required this.endTime,
    required this.slotTypeDays,
    required this.staffName,
    required this.batchDurationStatus,
  });

  // Factory constructor to create a Data object from JSON
  factory BatchDetailsModel.fromJson(Map<String, dynamic> json) {
    return BatchDetailsModel(

      batchName: json['batch_name'],
      courseTypeId: json['course_type_id'],
      courseId: json['course_id'],
      slotId: json['slot_id'],
      startDate: json['start_date'],
      endDate: json['end_date'],
      classroomId: json['classroom_id'],
      staffId: json['staff_id'],
      batchDesc: json['batch_desc'],
      status: json['status'],
      slotName: json['slot_name'],
      courseName: json['course_name'],
      customerId: json['customer_id'],
      batchId: json['batch_sno'],
      batchAutoIncrementId: json['auto_increment_id'],
      courseTypeName: json['course_type_name'],
      courseDuration: json['course_duration'],
      courseVersion: json['course_version'],
      classRoomName: json['class_room_name'],
      classRoomType: json['class_room_type'],
      slotTypeName: json['slot_type_name'],
      startTime: json['start_time'],
      endTime: json['end_time'],
      slotTypeDays: List<String>.from(json['slot_type_days']),
      staffName: json['staff_name'],
      batchDurationStatus: json['course_duration_staus'],
    );
  }

}
