class NewCourseModel {
  int sno;
  String courseName;
  String courseVersion;
  int courseParticalHours;
  int courseTheoryHours;
  String courseCode;
  String courseSubcategoryName;
  int courseDuration;
  int courseDays;
  String courseTypeName;
  String attachment;
  String thumbnail;
  String? courseDesc;
  String? courseGoals;
  String? courseFutureScope;
  String createdDate;
  int interested;
  String averageRating; // ✅ new field
  NewCourseModel({
    required this.sno,
    required this.courseName,
    required this.courseVersion,
    required this.courseParticalHours,
    required this.courseTheoryHours,
    required this.courseCode,
    required this.courseSubcategoryName,
    required this.courseDuration,
    required this.courseDays,
    required this.courseTypeName,
    required this.attachment,
    required this.thumbnail,
    this.courseDesc,
    this.courseGoals,
    this.courseFutureScope,
    required this.createdDate,
    required this.interested,
    required this.averageRating, // ✅ added
  });

  // Factory constructor to create an instance from JSON
  factory NewCourseModel.fromJson(Map<String, dynamic> json) {
    return NewCourseModel(
      sno: _toInt(json['sno']),
      courseName: json['course_name'] ?? '',
      courseVersion: json['course_version'] ?? '',
      courseParticalHours: _toInt(json['course_partical_hours']),
      courseTheoryHours: _toInt(json['course_theory_hours']),
      courseCode: json['course_code'] ?? '',
      courseSubcategoryName: json['course_subcategory_name'] ?? '',
      courseDuration: _toInt(json['course_duration']),
      courseDays: _toInt(json['course_days']),
      courseTypeName: json['course_type_name'] ?? '',
      attachment: json['attachment'] ?? '',
      thumbnail: json['thumbnail'] ?? '',
      courseDesc: json['course_desc'],
      courseGoals: json['course_goals'],
      courseFutureScope: json['course_future_scope'],
      createdDate: json['created_date'] ?? '',
      interested: _toInt(json['interested']),
      averageRating: json['average_rating'] ?? '0', // ✅ safe default
    );
  }

  // Helper method to convert dynamic values to int
  static int _toInt(dynamic value) {
    if (value is int) return value;
    if (value is String) return int.tryParse(value) ?? 0;
    return 0; // Default value if conversion fails
  }
}
