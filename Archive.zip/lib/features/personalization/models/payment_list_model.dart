/*class PaymentListModel {
  final String status;
  final String message;
  final int courseFee;
  final int paidFee;
  final int balanceFee;
  final List<PaymentList> paymentList;

  PaymentListModel({
    required this.status,
    required this.message,
    required this.courseFee,
    required this.paidFee,
    required this.balanceFee,
    required this.paymentList,
  });

  factory PaymentListModel.fromJson(Map<String, dynamic> json) {
    return PaymentListModel(
      status: json['status'],
      message: json['message'],
      courseFee: json['Course_fee'],
      paidFee: json['Paid_fee'],
      balanceFee: json['balance_fee'],
      paymentList: (json['payment_list'] as List)
          .map((item) => PaymentList.fromJson(item))
          .toList(),
    );
  }
}

class PaymentList {
  final int sno;
  final String? paymentId;
  final int branchId;
  final int customerId;
  final int courseId;
  final String initialPayDate;
  final String nextPayDate;
  final num? amount;
  final num? paidAmount;
  final num? gstAmount;
  final num? balanceFee;
  final num? totalAmount;
  final String? paymentModeLabel;
  final String? transaction;
  final String? invoiceId;
  final int createdBy;
  final String? createdAt;
  final int updatedBy;
  final String? updatedAt;
  final int status;
  final int reschedulePayment;
  final String? remainderMsgDate;
  final int isOnline;

  PaymentList({
    required this.sno,
    required this.paymentId,
    required this.branchId,
    required this.customerId,
    required this.courseId,
    required this.initialPayDate,
    required this.nextPayDate,
    required this.amount,
    required this.paidAmount,
    required this.gstAmount,
    required this.balanceFee,
    required this.totalAmount,
    required this.paymentModeLabel,
    required this.transaction,
    required this.invoiceId,
    required this.createdBy,
    required this.createdAt,
    required this.updatedBy,
    required this.updatedAt,
    required this.status,
    required this.reschedulePayment,
    required this.remainderMsgDate,
    required this.isOnline,
  });

  factory PaymentList.fromJson(Map<String, dynamic> json) {
    return PaymentList(
      sno: json['sno'],
      paymentId: json['payment_id'],
      branchId: json['branch_id'],
      customerId: json['customer_id'],
      courseId: json['course_id'],
      initialPayDate: json['initialPayDate'],
      nextPayDate: json['nextPayDate'],
      amount: json['amount'],
      paidAmount: json['paidAmount'],
      gstAmount: json['gst_amount'],
      balanceFee: json['balanceFee'],
      totalAmount: json['total_amount'],
      paymentModeLabel: json['payment_mode_label'],
      transaction: json['transaction'],
      invoiceId: json['invoice_id'],
      createdBy: json['created_by'],
      createdAt: json['created_at'],
      updatedBy: json['updated_by'],
      updatedAt: json['updated_at'],
      status: json['status'],
      reschedulePayment: json['reschedule_payment'],
      remainderMsgDate: json['remainder_msg_date'],
      isOnline: json['is_online'],
    );
  }
}*/
class PaymentListModel {
  final String status;
  final String message;
  final int courseFee;
  final int paidFee;
  final int balanceFee;
  final List<PaymentList> paymentList;

  PaymentListModel({
    required this.status,
    required this.message,
    required this.courseFee,
    required this.paidFee,
    required this.balanceFee,
    required this.paymentList,
  });

  factory PaymentListModel.fromJson(Map<String, dynamic> json) {
    return PaymentListModel(
      status: json['status'] ?? '',
      message: json['message'] ?? '',
      courseFee: json['Course_fee'] ?? 0,
      paidFee: json['Paid_fee'] ?? 0,
      balanceFee: json['balance_fee'] ?? 0,
      paymentList: (json['payment_list'] as List<dynamic>? ?? [])
          .map((item) => PaymentList.fromJson(item))
          .toList(),
    );
  }
}

class PaymentList {
  final int sno;
  final String paymentId;
  final int branchId;
  final int customerId;
  final int courseId;
  final String initialPayDate;
  final String nextPayDate;
  final num amount;
  final num paidAmount;
  final num gstAmount;
  final num balanceFee;
  final num totalAmount;
  final String paymentModeLabel;
  final String transaction;
  final String invoiceId;
  final int createdBy;
  final String createdAt;
  final int updatedBy;
  final String updatedAt;
  final int status;
  final int reschedulePayment;
  final String remainderMsgDate;
  final int isOnline;
  final int gstPercentageNew; // new field
  final int payableAmount; // new field
  final String keyId; // 🔑 Added field
  final String keySecret; // 🔑 Added field

  PaymentList({
    required this.sno,
    required this.paymentId,
    required this.branchId,
    required this.customerId,
    required this.courseId,
    required this.initialPayDate,
    required this.nextPayDate,
    required this.amount,
    required this.paidAmount,
    required this.gstAmount,
    required this.balanceFee,
    required this.totalAmount,
    required this.paymentModeLabel,
    required this.transaction,
    required this.invoiceId,
    required this.createdBy,
    required this.createdAt,
    required this.updatedBy,
    required this.updatedAt,
    required this.status,
    required this.reschedulePayment,
    required this.remainderMsgDate,
    required this.isOnline,
    required this.gstPercentageNew,
    required this.payableAmount,
    required this.keyId,
    required this.keySecret,
  });

  factory PaymentList.fromJson(Map<String, dynamic> json) {
    return PaymentList(
      sno: json['sno'] ?? 0,
      paymentId: json['payment_id'] ?? '',
      branchId: json['branch_id'] ?? 0,
      customerId: json['customer_id'] ?? 0,
      courseId: json['course_id'] ?? 0,
      initialPayDate: json['initialPayDate'] ?? '',
      nextPayDate: json['nextPayDate'] ?? '',
      amount: json['amount'] ?? 0,
      paidAmount: json['paidAmount'] ?? 0,
      gstAmount: json['gst_amount'] ?? 0,
      balanceFee: json['balanceFee'] ?? 0,
      totalAmount: json['total_amount'] ?? 0,
      paymentModeLabel: json['payment_mode_label'] ?? '',
      transaction: json['transaction'] ?? '',
      invoiceId: json['invoice_id'] ?? '',
      createdBy: json['created_by'] ?? 0,
      createdAt: json['created_at'] ?? '',
      updatedBy: json['updated_by'] ?? 0,
      updatedAt: json['updated_at'] ?? '',
      status: json['status'] ?? 0,
      reschedulePayment: json['reschedule_payment'] ?? 0,
      remainderMsgDate: json['remainder_msg_date'] ?? '',
      isOnline: json['is_online'] ?? 0,
      gstPercentageNew: (json['gst_percentage_new'] ?? 0).toInt(),
      payableAmount: (json['payable_amount'] ?? 0).toInt(),
      keyId: json['key_id'] ?? '', // 🔑 Added
      keySecret: json['key_secret'] ?? '', // 🔑 Added
    );
  }
}
