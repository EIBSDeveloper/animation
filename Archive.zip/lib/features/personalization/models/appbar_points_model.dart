class AppBarPointsModel {
  final String cusName;
  final int heartScore;
  final int coinsValue;
  final int diamondValue;
  final int crownValue;
  final int notifycount;

  AppBarPointsModel({
    required this.cusName,
    required this.heartScore,
    required this.coinsValue,
    required this.diamondValue,
    required this.crownValue,
    required this.notifycount,
  });

  factory AppBarPointsModel.fromJson(Map<String, dynamic> json) {
    return AppBarPointsModel(
        cusName: json['cus_name'],
        heartScore: json['heart_score'],
        coinsValue: json['coins_value'],
        diamondValue: json['diamond_value'],
        crownValue: json['crown_value'],
        notifycount: json['notify_count']);
  }

  Map<String, dynamic> toJson() => {
        'cus_name': cusName,
        'heart_score': heartScore,
        'coins_value': coinsValue,
        'diamond_value': diamondValue,
        'crown_value': crownValue,
        'notify_count': notifycount,
      };
}
