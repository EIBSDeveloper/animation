import 'dart:convert';

class AttendanceAndBatchModel {
  final int status;
  final String message;
  final String? errorMsg;
  final List<AttendanceModel> attendance;
  final Batch batch;

  AttendanceAndBatchModel({
    required this.status,
    required this.message,
    this.errorMsg,
    required this.attendance,
    required this.batch,
  });

  factory AttendanceAndBatchModel.fromJson(Map<String, dynamic> json) {
    return AttendanceAndBatchModel(
      status: json['status'],
      message: json['message'],
      errorMsg: json['error_msg'],
      attendance: (json['attendance'] as List)
          .map((item) => AttendanceModel.fromJson(item))
          .toList(),
      batch: Batch.fromJson(json['batch']),
    );
  }
}

class AttendanceModel {
  final int sno;
  final String? attendanceId;
  final int branchId;
  final String attDate;
  final int customerId;
  final int batchId;
  final int staffId;
  final int courseId;
  final String attendance;
  final int totalDuration;
  final double perHrCost;
  final double totalCost;
  final int staffAttStatus;
  final String? feedback;
  final int? feedbackScore;
  final String createdAt;
  final int createdBy;
  final String updatedAt;
  final int updatedBy;
  final int status;
  final int dayCount; // ✅ New field

  AttendanceModel({
    required this.sno,
    required this.attendanceId,
    required this.branchId,
    required this.attDate,
    required this.customerId,
    required this.batchId,
    required this.staffId,
    required this.courseId,
    required this.attendance,
    required this.totalDuration,
    required this.perHrCost,
    required this.totalCost,
    required this.staffAttStatus,
    this.feedback,
    this.feedbackScore,
    required this.createdAt,
    required this.createdBy,
    required this.updatedAt,
    required this.updatedBy,
    required this.status,
    required this.dayCount, // ✅ Constructor
  });

  factory AttendanceModel.fromJson(Map<String, dynamic> json) {
    return AttendanceModel(
      sno: json['sno'] ?? 0,
      attendanceId: json['attendance_id']?.toString(), // ✅ no int.parse
      branchId: json['branch_id'] ?? 0,
      attDate: json['att_date'] ?? DateTime.now().toString(),
      customerId: json['customer_id'] ?? 0,
      batchId: json['batch_id'] ?? 0,
      staffId: json['staff_id'] ?? 0,
      courseId: json['course_id'] ?? 0,
      attendance: json['attendance'] ?? '',
      totalDuration: json['total_duration'] ?? 0,
      perHrCost: (json['per_hr_cost'] != null)
          ? (json['per_hr_cost'] as num).toDouble()
          : 0.0,
      totalCost: (json['total_cost'] != null)
          ? (json['total_cost'] as num).toDouble()
          : 0.0,
      staffAttStatus: json['staff_att_status'] ?? 0,
      feedback: json['feedback'] ?? '',
      feedbackScore: (json['feedback_score'] != null)
          ? (json['feedback_score'] as num).toInt()
          : 0,
      createdAt: json['created_at'] ?? '',
      createdBy: json['created_by'] ?? 0,
      updatedAt: json['updated_at'] ?? '',
      updatedBy: json['updated_by'] ?? 0,
      status: json['status'] is int
          ? json['status']
          : int.tryParse(json['status'].toString()) ?? 0,
      dayCount: json['day_count'] ?? 0,
    );
  }

  bool hasFeedbackOrScore() {
    return feedbackScore! > 0 || (feedback != null && feedback!.isNotEmpty);
  }
}

class Batch {
  final int batchSno;
  final String autoIncrementId;
  final String batchName;
  final int courseTypeId;
  final int courseId;
  final int slotId;
  final String startDate;
  final String endDate;
  final int classroomId;
  final String staffId;
  final String? batchDesc;
  final int status;
  final String slotName;
  final String courseName;
  final int customerId;
  final int trainingSno;
  final int customerSno;
  final String courseTypeName;
  final int courseDuration;
  final String courseVersion;
  final String classRoomName;
  final int classRoomType;
  final String slotTypeName;
  final String startTime;
  final String endTime;
  final List<String> slotDays;
  final String staffName;
  final List<String> slotTypeDays;

  Batch({
    required this.batchSno,
    required this.autoIncrementId,
    required this.batchName,
    required this.courseTypeId,
    required this.courseId,
    required this.slotId,
    required this.startDate,
    required this.endDate,
    required this.classroomId,
    required this.staffId,
    this.batchDesc,
    required this.status,
    required this.slotName,
    required this.courseName,
    required this.customerId,
    required this.trainingSno,
    required this.customerSno,
    required this.courseTypeName,
    required this.courseDuration,
    required this.courseVersion,
    required this.classRoomName,
    required this.classRoomType,
    required this.slotTypeName,
    required this.startTime,
    required this.endTime,
    required this.slotDays,
    required this.staffName,
    required this.slotTypeDays,
  });

  factory Batch.fromJson(Map<String, dynamic> json) {
    return Batch(
      batchSno: json['batch_sno'],
      autoIncrementId: json['auto_increment_id'],
      batchName: json['batch_name'],
      courseTypeId: json['course_type_id'],
      courseId: json['course_id'],
      slotId: json['slot_id'],
      startDate: json['start_date'],
      endDate: json['end_date'],
      classroomId: json['classroom_id'],
      staffId: json['staff_id'],
      batchDesc: json['batch_desc'],
      status: json['status'],
      slotName: json['slot_name'],
      courseName: json['course_name'],
      customerId: json['customer_id'],
      trainingSno: json['training_sno'],
      customerSno: json['customer_sno'],
      courseTypeName: json['course_type_name'],
      courseDuration: json['course_duration'],
      courseVersion: json['course_version'],
      classRoomName: json['class_room_name'],
      classRoomType: json['class_room_type'],
      slotTypeName: json['slot_type_name'],
      startTime: json['start_time'],
      endTime: json['end_time'],
      slotDays: List<String>.from(jsonDecode(json['slot_days'])),
      staffName: json['staff_name'],
      slotTypeDays: List<String>.from(
          json['slot_type_days'].map((item) => item.toString())),
    );
  }
}
