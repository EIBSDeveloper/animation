class RedeemModel {
  final int sno;
  final int branchId;
  final int studentId;
  final int couponId;
  final int redeemValue;
  final String couponCode;
  final String endDate;
  final int merge;
  final String createdAt;
  final int status;

  RedeemModel({
    required this.sno,
    required this.branchId,
    required this.studentId,
    required this.couponId,
    required this.redeemValue,
    required this.couponCode,
    required this.endDate,
    required this.merge,
    required this.createdAt,
    required this.status,
  });

  factory RedeemModel.fromJson(Map<String, dynamic> json) {
    return RedeemModel(
      sno: json['sno'],
      branchId: json['branch_id'],
      studentId: json['student_id'],
      couponId: json['coupon_id'],
      redeemValue: json['redeem_value'],
      couponCode: json['coupon_code'],
      endDate: json['end_date'],
      merge: json['merge'],
      createdAt: json['created_at'],
      status: json['status'],
    );
  }
}
