class PointsModel {
  final int sno;
  final int coin;
  final int diamond;
  final int heart;
  final int crown;

  PointsModel({
    required this.sno,
    required this.coin,
    required this.diamond,
    required this.heart,
    required this.crown,
  });

  factory PointsModel.fromJson(Map<String, dynamic> json) {
    return PointsModel(
      sno: json['sno'],
      coin: json['coin'],
      diamond: json['diamond'],
      heart: json['heart'],
      crown: json['crown'],
    );
  }
}
