/*
class EventModel {
  final int eventId;
  final String eventName;
  final String contactPersonName;
  final String eventDate;
  final String? eventAddress;
  final int eventAmount;
  final String? eventDescription;
  int booked; // 0/1 guaranteed non-null
  String? remainingParticipants;
  final String? city;
  final String? start_time;
  final String? end_time;
  final String? eventType;
  final String? eventCertificate;
  final String? eventSpeaker;
  int status; // guaranteed non-null
  int daysremaining;

  EventModel({
    required this.eventId,
    required this.eventName,
    required this.contactPersonName,
    required this.eventDate,
    this.eventAddress,
    required this.eventAmount,
    this.eventDescription,
    required this.booked,
    this.remainingParticipants,
    required this.city,
    required this.start_time,
    required this.end_time,
    required this.eventType,
    required this.eventCertificate,
    required this.eventSpeaker,
    required this.status,
    required this.daysremaining,
  });

  factory EventModel.fromJson(Map<String, dynamic> json) {
    int asInt(dynamic v, {int def = 0}) {
      if (v == null) return def;
      if (v is int) return v;
      if (v is String) return int.tryParse(v) ?? def;
      if (v is bool) return v ? 1 : 0;
      return def;
    }

    String asString(dynamic v, {String def = ""}) {
      if (v == null) return def;
      return v.toString();
    }

    // Handle bad key "status " (with space) and other fallbacks
    final dynamic rawStatus =
        json['status'] ?? json['status_id'] ?? json['status '];

    return EventModel(
      eventId: asInt(json['event_id']),
      eventName: asString(json['event_name']),
      contactPersonName: asString(json['contact_person_name']),
      eventDate: asString(json['event_date']),
      eventAddress: json['event_address']?.toString(),
      eventAmount: asInt(json['event_amount']),
      eventDescription: json['event_description']?.toString(),
      booked: asInt(json['booked'], def: 0), // <- never null
      remainingParticipants: json['remaining_participants']?.toString(),
      city: json['city']?.toString(),
      start_time: asString(json['start_time']),
      end_time: asString(json['end_time']),
      eventType: json['event_type_id']?.toString(),
      eventCertificate: json['certificate_type']?.toString(),
      eventSpeaker: json['handle_others_name']?.toString(),
      daysremaining: asInt(json['days_remaining'], def: 0),
      status: asInt(rawStatus, def: 0), // <- never null
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'event_id': eventId,
      'event_name': eventName,
      'contact_person_name': contactPersonName,
      'event_date': eventDate,
      'event_address': eventAddress,
      'event_amount': eventAmount,
      'event_description': eventDescription,
      'booked': booked,
      'remaining_participants': remainingParticipants,
      'city': city,
      'start_time': start_time,
      'end_time': end_time,
      'event_type_id': eventType,
      'certificate_type': eventCertificate,
      'handle_others_name': eventSpeaker,
      'status': status,
    };
  }
}
*/
import 'package:get/get.dart';

class EventModel {
  final int eventId;
  final String eventName;
  final String contactPersonName;
  final String eventDate;
  final String? eventAddress;
  final int eventAmount;
  final String? eventDescription;
  RxInt booked; // ✅ reactive
  String? remainingParticipants;
  final String? city;
  final String? start_time;
  final String? end_time;
  final String? eventType;
  final String? eventCertificate;
  final String? eventSpeaker;
  int status; // guaranteed non-null
  int daysremaining;

  EventModel({
    required this.eventId,
    required this.eventName,
    required this.contactPersonName,
    required this.eventDate,
    this.eventAddress,
    required this.eventAmount,
    this.eventDescription,
    required int booked,
    this.remainingParticipants,
    required this.city,
    required this.start_time,
    required this.end_time,
    required this.eventType,
    required this.eventCertificate,
    required this.eventSpeaker,
    required this.status,
    required this.daysremaining,
  }) : booked = booked.obs; // initialize Rx

  factory EventModel.fromJson(Map<String, dynamic> json) {
    int asInt(dynamic v, {int def = 0}) {
      if (v == null) return def;
      if (v is int) return v;
      if (v is String) return int.tryParse(v) ?? def;
      if (v is bool) return v ? 1 : 0;
      return def;
    }

    String asString(dynamic v, {String def = ""}) {
      if (v == null) return def;
      return v.toString();
    }

    final dynamic rawStatus =
        json['status'] ?? json['status_id'] ?? json['status '];

    return EventModel(
      eventId: asInt(json['event_id']),
      eventName: asString(json['event_name']),
      contactPersonName: asString(json['contact_person_name']),
      eventDate: asString(json['event_date']),
      eventAddress: json['event_address']?.toString(),
      eventAmount: asInt(json['event_amount']),
      eventDescription: json['event_description']?.toString(),
      booked: asInt(json['booked'], def: 0), // <- RxInt initialized
      remainingParticipants: json['remaining_participants']?.toString(),
      city: json['city']?.toString(),
      start_time: asString(json['start_time']),
      end_time: asString(json['end_time']),
      eventType: json['event_type_id']?.toString(),
      eventCertificate: json['certificate_type']?.toString(),
      eventSpeaker: json['handle_others_name']?.toString(),
      daysremaining: asInt(json['days_remaining'], def: 0),
      status: asInt(rawStatus, def: 0),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'event_id': eventId,
      'event_name': eventName,
      'contact_person_name': contactPersonName,
      'event_date': eventDate,
      'event_address': eventAddress,
      'event_amount': eventAmount,
      'event_description': eventDescription,
      'booked': booked.value, // ✅ use .value
      'remaining_participants': remainingParticipants,
      'city': city,
      'start_time': start_time,
      'end_time': end_time,
      'event_type_id': eventType,
      'certificate_type': eventCertificate,
      'handle_others_name': eventSpeaker,
      'status': status,
    };
  }
}
