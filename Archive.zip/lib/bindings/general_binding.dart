/*
 * /Project Name:eapl_Mobile_app
 * /Created by KARTHICK DINESH A
 * /Copyrights(c) 2024. All Rights reserved
 * /Last modified 22/08/24, 2:49 pm
 */
import 'package:eapl_student_app/features/authendication/controllers/login_controller.dart';
import 'package:eapl_student_app/features/personalization/controllers/side_drawer_controller/query_or_complaint_controller.dart';
import 'package:get/get.dart';

import '../common/widget/menu/side_drawer_menu/side_menu_controller.dart';
import '../features/authendication/controllers/dailycheckcontroller.dart';
import '../features/authendication/controllers/splashcontroller.dart';
import '../features/authendication/controllers/walkthroughcontroller.dart';
import '../features/personalization/controllers/side_drawer_controller/course_controller.dart';
import '../utils/helpers/network_manager.dart';

class GeneralBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(NetworkManager());
    // Register DailycheckController permanently
    Get.put(DailycheckController(), permanent: true);
    Get.lazyPut<SplashController>(() => SplashController(), fenix: true);
    Get.lazyPut(() => WalkthroughController(), fenix: true);

    // Get.put(OrientationController());
    // DependencyInjection.init();

    Get.lazyPut(() => QueryOrComplaintController());
    Get.lazyPut(() => LoginController());
    Get.lazyPut(() => CourseController());
    Get.lazyPut(() => SideMenuController(), fenix: true);
    // TODO: implement dependencies
  }
}
