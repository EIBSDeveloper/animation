import 'package:flutter/material.dart';

class RoundedColorFillContainer extends StatelessWidget {
  const RoundedColorFillContainer({
    super.key,
    required this.size,
    required this.color,
  });

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
    );
  }
}
