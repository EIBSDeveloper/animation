/*
import 'dart:ui';

import 'package:flutter/material.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';

class GlassyContainer extends StatelessWidget {
  const GlassyContainer({
    super.key,
    this.opacity = 0.85,
    this.height,
    this.width,
    required this.child,
    this.color,
    this.borderRadius = 5,
    this.padding = TSizes.sm,
    this.margin = const EdgeInsets.only(bottom: 8),
  });

  final double? opacity;
  final double? borderRadius;
  final double? padding;
  final EdgeInsetsGeometry? margin;

  final Color? color;
  final double? height;

  final double? width;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      height: height,
      width: width,
      decoration: BoxDecoration(
        color: color?.withOpacity(opacity!) ??
            TColors.lightimportant.withOpacity(opacity!),
        borderRadius: BorderRadius.circular(borderRadius!),
        border: Border.all(
            color: color ?? TColors.importantText.withOpacity(opacity!)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius!),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            width: double.infinity,
            // height: double.infinity,
            padding: EdgeInsets.all(padding!),
            child: child,
          ),
        ),
      ),
    );
  }
}
*/
import 'package:flutter/material.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';

class GlassyContainer extends StatelessWidget {
  const GlassyContainer({
    super.key,
    this.opacity = 0.85,
    this.height = 200, // adjusted height for compact card
    this.width,
    required this.child,
    this.color,
    this.borderRadius = 10, // rounded bottom corners
    this.padding = TSizes.sm,
    this.margin = const EdgeInsets.only(bottom: 8),
  });

  final double? opacity;
  final double borderRadius;
  final double? padding;
  final EdgeInsetsGeometry? margin;

  final Color? color;
  final double height;
  final double? width;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      width: width ?? double.infinity,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(10),
          bottomRight: Radius.circular(10),
        ),
        color: TColors.primary,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(borderRadius),
          bottomRight: Radius.circular(borderRadius),
        ),
        child: Container(
          alignment: Alignment.center,
          padding: EdgeInsets.all(padding ?? 8),
          child: child,
        ),
      ),
    );
  }
}
