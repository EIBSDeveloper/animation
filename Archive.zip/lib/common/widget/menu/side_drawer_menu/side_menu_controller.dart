import 'dart:convert';
import 'dart:io';

import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../../features/apptour/side/sidemenu/sidemenutour.dart';

class SideMenuController extends GetxController {
  final bottomMenuController = Get.put(BottomNavigationController());
  final storage = GetStorage();

  // Observables for user data
  final RxString userName = '---'.obs;
  final RxString userAutoId = '---'.obs;
  final RxString profileImage = TImages.profileImage.obs;

  @override
  void onInit() {
    super.onInit();
    _loadProfileData();
    profileUrl.value = GetStorage().read(TTexts.profileURL) ?? '';
  }

  void _loadProfileData() {
    // Load from storage
    userName.value = storage.read(TTexts.userName) ?? '---';
    userAutoId.value = storage.read(TTexts.userAutoId) ?? '---';

    // Load profile image
    final networkImage = GetStorage().read(TTexts.profileURL);
    profileImage.value = (networkImage?.isNotEmpty == true)
        ? networkImage!
        : TImages.profileImage;
  }

  void navigateTo(int index) {
    if (index < 0 || index > 10) {
      print("Invalid choice");
      return;
    }

    final newIndex = index + 5; // Map input index to `selectedIndex` values
    _updateBottomMenu(newIndex);
  }

  void _updateBottomMenu(int newIndex) {
    bottomMenuController.currentPage.value = 0;
    bottomMenuController.selectedIndex.value = newIndex;

    // Add or remove the index from the selectedIndexList
    if (bottomMenuController.selectedIndexList.contains(newIndex)) {
      bottomMenuController.selectedIndexList.remove(newIndex);
      print('Removed index: $newIndex from selectedIndexList');
    }
    // Get.offAll(() => OurBottomNavigationBar());
    bottomMenuController.selectedIndexList.add(newIndex);
    // Get.offAll(() => OurBottomNavigationBar());
    Get.back();
    print('Added index: $newIndex to selectedIndexList');
    // update();
  }

  var profileUrl = ''.obs;
  final ImagePicker _picker = ImagePicker();
  Future<void> uploadProfile(String base64Image) async {
    try {
      final customerId = GetStorage().read(TTexts.userID);

      final body = {
        "customer_id": customerId,
        "attachment": "data:image/png;base64,$base64Image",
      };

      final response =
          await THttpHelper.post(APIConstants.profileendpoint, body);

      if (response["status"] == 1) {
        final newUrl = response["data"]["cus_pic"];

        // ✅ Save and update UI
        profileUrl.value = newUrl;
        GetStorage().write(TTexts.profileURL, newUrl);

        Fluttertoast.showToast(
          msg: response["message"] ?? "Profile updated successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: TColors.primary,
          textColor: Colors.white,
          fontSize: 16.0,
        );
      } else {
        Fluttertoast.showToast(
          msg: response["message"] ?? "Failed to update profile",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0,
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Error: $e",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    }
  }

/*  Future<void> pickImage() async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );

      if (pickedFile != null) {
        File imageFile = File(pickedFile.path);

        // Update UI immediately
        profileUrl.value = imageFile.path;

        // Convert to Base64 and upload
        String base64Image = base64Encode(await imageFile.readAsBytes());
        await uploadProfile(base64Image);
      }
    } catch (e) {
      Get.snackbar("Error", e.toString());
    }
  }*/
  Future<void> pickImage() async {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Colors.blue),
              title: const Text("Take Photo"),
              onTap: () {
                Get.back();
                _pickFromSource(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.green),
              title: const Text("Choose from Gallery"),
              onTap: () {
                Get.back();
                _pickFromSource(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickFromSource(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );

      if (pickedFile != null) {
        File imageFile = File(pickedFile.path);

        // Update image locally
        profileUrl.value = imageFile.path;

        // Convert and upload to server
        String base64Image = base64Encode(await imageFile.readAsBytes());
        await uploadProfile(base64Image);
      }
    } catch (e) {
      Get.snackbar("Error", e.toString());
    }
  }

  //sidemenutour
  final logoutKey = GlobalKey();
  final notificationKey = GlobalKey();

  var isSidemenuTouron = false.obs;
  Future<void> SidemenuTour(BuildContext context) async {
    final targets = SidemenuTourList.getTargets(
      logoutKey: logoutKey,
      notificationKey: notificationKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.sidemenutour, true);
        isSidemenuTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.sidemenutour, true);
        isSidemenuTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
