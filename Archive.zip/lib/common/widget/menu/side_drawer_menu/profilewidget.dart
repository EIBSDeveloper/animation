import 'package:eapl_student_app/common/widget/menu/side_drawer_menu/side_menu_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/constants/image_strings.dart';
import '../../images/t_circular_image.dart';

class ProfileImageWidget extends StatelessWidget {
  final controller = Get.put(SideMenuController());

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Obx(() => TCircularImage(
              padding: 1,
              image: controller.profileUrl.value.isNotEmpty
                  ? controller.profileUrl.value
                  : TImages.profileImage,
              width: 50,
              height: 50,
              isNetworkImage: controller.profileUrl.value.startsWith('http'),
            )),
        Positioned(
          bottom: 0,
          right: 0,
          child: InkWell(
            onTap: () => controller.pickImage(),
            child: const CircleAvatar(
              radius: 12,
              backgroundColor: Colors.grey,
              child: Icon(Icons.camera_alt, size: 16, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }
}
