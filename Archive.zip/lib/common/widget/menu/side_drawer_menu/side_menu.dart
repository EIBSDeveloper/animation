import 'package:eapl_student_app/common/widget/app_bar/appbar_controller.dart';
import 'package:eapl_student_app/common/widget/menu/side_drawer_menu/profilewidget.dart';
import 'package:eapl_student_app/features/authendication/screens/login.dart';
import 'package:eapl_student_app/utils/constants/image_strings.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../features/personalization/screens/bottom_menu/points/points_benfits.dart';
import '../../../../features/personalization/screens/side_drawer_menu/course/course_list.dart';
import '../../../../features/personalization/screens/side_drawer_menu/course_material/material_course_list.dart';
import '../../../../features/personalization/screens/side_drawer_menu/daily_attendance/attendance.dart';
import '../../../../features/personalization/screens/side_drawer_menu/notifications/notification_controller.dart';
import '../../../../features/personalization/screens/side_drawer_menu/notifications/notification_page.dart';
import '../../../../features/personalization/screens/side_drawer_menu/payment/payment_page.dart';
import '../../../../features/personalization/screens/side_drawer_menu/placement/placedstudent.dart';
import '../../../../features/personalization/screens/side_drawer_menu/placement/placement.dart';
import '../../../../features/personalization/screens/side_drawer_menu/query/query_list_page.dart';
import '../../../../features/personalization/screens/side_drawer_menu/refferal/refferal_page.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../../utils/constants/text_strings.dart';
import '../bottom_menu/bottom_menu.dart';
import 'side_menu_controller.dart';

class SideMenuBar extends StatelessWidget {
  final SideMenuController controller = Get.find();
  SideMenuBar({super.key});
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.sidemenutour) ?? false;

      if (!controller.isSidemenuTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 700));
        await controller.SidemenuTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.sidemenutour, true);
        controller.isSidemenuTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _showTourOnce(context);
    final NotificationController notificationController =
        Get.put(NotificationController());
    final appbarController = Get.put(AppbarController());

    return Drawer(
      child: Container(
        color: TColors.menubgcolor,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // Premium Header
            Container(
              margin: EdgeInsets.only(top: 70, bottom: 20, left: 10),
              child: Row(
                children: [
                  ProfileImageWidget(),

                  const SizedBox(width: 12),

                  // Name & UserId
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Obx(() => Text(
                              controller.userName.value,
                              style: GoogleFonts.prompt(
                                color: TColors.primary,
                                fontWeight: FontWeight.w600,
                                fontSize: 18,
                                letterSpacing: 0.2,
                              ),
                              overflow: TextOverflow.ellipsis,
                            )),
                        const SizedBox(height: 4),
                        Obx(() => Text(
                              controller.userAutoId.value,
                              style:
                                  TextStyle(color: Colors.black, fontSize: 14),
                              overflow: TextOverflow.ellipsis,
                            )),
                      ],
                    ),
                  ),

                  // Logout Button
                  /*IconButton(
                    key: controller.logoutKey,
                    onPressed: () {
                      _showLogoutDialog(context);
                    },
                    icon: Icon(Iconsax.logout, color: TColors.primary),
                    tooltip: 'Logout',
                  ),*/
                  IconButton(
                    key: controller.logoutKey,
                    onPressed: () {
                      _showLogoutDialog(context);
                    },
                    icon: Image.asset(
                      TImages.logout, // your image path
                      width: 25, // adjust as needed
                      height: 25,
                      color: TColors.primary, // optional: tint color
                    ),
                    tooltip: 'Logout',
                  ),

                  Obx(() => SizedBox(
                        width: 40, // ✅ restrict width
                        height: 40, // ✅ restrict height
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            IconButton(
                              key: controller.notificationKey,
                              padding:
                                  EdgeInsets.zero, // ✅ remove extra padding
                              onPressed: () {
                                Get.to(() => NotificationPage(),
                                    transition: Transition.rightToLeft);
                              },
                              icon: Image.asset(
                                TImages.notification,
                                width: 25,
                                height: 25,
                                fit: BoxFit.contain,
                              ),
                            ),
                            if (appbarController.notifyCount.value > 0)
                              Positioned(
                                right: 4,
                                top: 4,
                                child: Container(
                                  padding: const EdgeInsets.all(3),
                                  decoration: const BoxDecoration(
                                    color: Colors.redAccent,
                                    shape: BoxShape.circle,
                                  ),
                                  constraints: const BoxConstraints(
                                    minWidth: 16,
                                    minHeight: 16,
                                  ),
                                  child: Center(
                                    child: Text(
                                      '${appbarController.notifyCount.value}',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ))
                ],
              ),
            ),

            // Drawer Items
            _buildDrawerItem(
                context, TImages.mycourses, "My Course", 0, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(context, TImages.coursematerials,
                "Course Materials", 3, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(
                context, TImages.payment, "Payment History", 4, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(
                context, TImages.daily, "Daily Attendance", 5, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(context, TImages.help, "Help Desk", 6, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(
                context, TImages.placements, "Placements", 7, controller),
            _buildDrawerItem(
                context, TImages.placed, "Placed students", 9, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(
                context, TImages.referrel, "Referral", 8, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(
                context, TImages.rewards, "Rewards", 10, controller),
            SizedBox(height: TSizes.sm),
            _buildDrawerItem(context, TImages.playbutton, "Classmate Explorer",
                11, controller),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(BuildContext context, String imagePath, String title,
      int index, SideMenuController controller) {
    return Center(
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: MediaQuery.of(context).size.width * 0.75,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        margin: const EdgeInsets.only(top: 3, left: 10, right: 10),
        /* decoration: BoxDecoration(
          color: index == 10 ? const Color(0xFFEFBF04) : Colors.white,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: TColors.grey,
          ),
        ),*/
        decoration: BoxDecoration(
          color: index == 10
              ? const Color(0xFFEFBF04) // yellow
              : index == 9
                  ? Colors.green // green for index 9
                  : Colors.white, // default
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: TColors.grey,
          ),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(6),
          onTap: () {
            Get.back();
            if (index == 0) {
              Get.to(CourseList());
            }
            if (index == 3) {
              Get.to(MaterialCourseList());
            }
            if (index == 4) {
              Get.to(PaymentPage());
            }
            if (index == 5) {
              Get.to(AttendancePage());
            }
            if (index == 6) {
              Get.to(QueryList());
            }
            if (index == 7) {
              Get.to(PlacementDetails());
            }
            if (index == 9) {
              Get.to(Placedstudent());
            }
            if (index == 8) {
              Get.to(ReferralPage());
            }
            if (index == 10) {
              Get.to(PointsBenfits());
            }
            if (index == 11) {
              Get.dialog(
                AlertDialog(
                  backgroundColor: Colors.white,
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'App Tour',
                        style: GoogleFonts.prompt(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                  content: Text(
                    'Do you want to start the app tour?',
                    style: GoogleFonts.prompt(fontSize: 16),
                  ),
                  actions: [
                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment.center, // ✅ Center the buttons
                      children: [
                        // No Button
                        SizedBox(
                          width: 100,
                          height: 45,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: TColors.grey),
                            ),
                            child: TextButton(
                              onPressed: () =>
                                  Navigator.of(Get.context!).pop(false),
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.black,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: Text(
                                'No',
                                style: GoogleFonts.prompt(fontSize: 18),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        // Yes Button
                        SizedBox(
                          width: 100,
                          height: 45,
                          child: ElevatedButton(
                            onPressed: () async {
                              print("✅ Yes button clicked");
                              Navigator.of(Get.context!).pop(true);
                              // ✅ Start your app tour here
                              await GetStorage().remove(TTexts.appbartour);
                              await GetStorage().remove(TTexts.dashboardtour);
                              await GetStorage().remove(TTexts.newLaunchTour);
                              await GetStorage()
                                  .remove(TTexts.newLaunchdetailsTour);
                              await GetStorage().remove(TTexts.eventtour);
                              await GetStorage()
                                  .remove(TTexts.eventdetailstour);
                              await GetStorage().remove(TTexts.leadertour);
                              await GetStorage().remove(TTexts.exchangetour);
                              await GetStorage()
                                  .remove(TTexts.exchangedialogtour);

                              await GetStorage()
                                  .remove(TTexts.notificationtour);
                              await GetStorage().remove(TTexts.mycoursetour);
                              await GetStorage()
                                  .remove(TTexts.mycoursedetailstour);
                              await GetStorage()
                                  .remove(TTexts.chapterdetailstour);
                              await GetStorage().remove(TTexts.materialtour);
                              await GetStorage()
                                  .remove(TTexts.materialdetailtour);
                              await GetStorage().remove(TTexts.downloadtour);
                              await GetStorage().remove(TTexts.placementtour);
                              await GetStorage()
                                  .remove(TTexts.placementdetailtour);
                              await GetStorage().remove(TTexts.attendencetour);
                              await GetStorage().remove(TTexts.querytour);
                              await GetStorage()
                                  .remove(TTexts.querydetailstour);
                              await GetStorage().remove(TTexts.queryviewtour);
                              await GetStorage().remove(TTexts.referreltour);
                              await GetStorage().remove(TTexts.rewardtour);
                              await GetStorage().remove(TTexts.paymenttour);
                              await GetStorage()
                                  .remove(TTexts.paymenthistorytour);
                              await GetStorage().remove(TTexts.sidemenutour);
                              Get.back();
                              Get.offAll(OurBottomNavigationBar());
                              // ✅ Show native toast
                              Fluttertoast.showToast(
                                msg: "Tutorial begins!",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                backgroundColor: TColors.primary,
                                textColor: Colors.white,
                                fontSize: 16.0,
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: TColors.primary,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              'Yes',
                              style: GoogleFonts.prompt(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }
          }, // ✅ whole container clickable
          child: Row(
            children: [
              Image.asset(
                imagePath,
                width: 28,
                height: 28,
                fit: BoxFit.contain,
                color: index == 5
                    ? null
                    : TColors.primary, // ✅ remove color for index 5
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: GoogleFonts.prompt(
                  color: Colors.black,
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showLogoutDialog(BuildContext context) async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: Center(
            child: Text('Confirm Logout',
                style: GoogleFonts.prompt(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: TColors.primary))),
        content: Text(
          'Do you want to logout?',
          textAlign: TextAlign.center,
          style: GoogleFonts.prompt(fontSize: 16, color: Colors.grey[800]),
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          Container(
            width: 100,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: TColors.grey),
            ),
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text(
                'No',
                style: GoogleFonts.prompt(
                  color: Colors.grey[800],
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            width: 100,
            height: 45,
            margin: EdgeInsets.only(left: 10), // spacing between buttons
            decoration: BoxDecoration(
              color: TColors.primary,
              borderRadius: BorderRadius.circular(10),
            ),
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: Text(
                'Yes',
                style: GoogleFonts.prompt(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );

    if (shouldLogout == true) {
      //GetStorage().erase();
      final storage = GetStorage();

      await storage.remove(TTexts.userID);
      await storage.remove(TTexts.userMobNo);
      await storage
          .remove(TTexts.userName); // replace with the other keys you need
      await storage.remove(TTexts.userEmailId);
      await storage.remove(TTexts.userAutoId);
      await storage.remove(TTexts.profileURL);
      await storage.remove(TTexts.userOtp);
      await storage.remove(TTexts.incrementTimer);
      Get.offAll(() => const Login());
    }
  }
}
