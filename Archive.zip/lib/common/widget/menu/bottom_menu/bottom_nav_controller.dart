import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/notifications/notification_page.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/refferal/refferal_page.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../features/personalization/screens/bottom_menu/dashboard_home/dashboard.dart';
import '../../../../features/personalization/screens/bottom_menu/event/events.dart';
import '../../../../features/personalization/screens/bottom_menu/leaders-board/leaders_board.dart';
import '../../../../features/personalization/screens/bottom_menu/new_launch_course/new_launch_course.dart';
import '../../../../features/personalization/screens/bottom_menu/points/points_benfits.dart';
import '../../../../features/personalization/screens/bottom_menu/points/points_screen.dart';
import '../../../../features/personalization/screens/side_drawer_menu/class_schedule/class_schedule_page.dart';
import '../../../../features/personalization/screens/side_drawer_menu/course/course_list.dart';
import '../../../../features/personalization/screens/side_drawer_menu/course_material/material_course_list.dart';
import '../../../../features/personalization/screens/side_drawer_menu/daily_attendance/attendance.dart';
import '../../../../features/personalization/screens/side_drawer_menu/daily_streak/daily_streak.dart';
import '../../../../features/personalization/screens/side_drawer_menu/payment/payment_page.dart';
import '../../../../features/personalization/screens/side_drawer_menu/placement/placement.dart';
import '../../../../features/personalization/screens/side_drawer_menu/query/query_list_page.dart';
import '../../../../utils/constants/path_provider.dart';

class BottomNavigationController extends GetxController {
  // The current selected page index
  var currentPage = 0.obs;
  var selectedIndex = 0.obs;
  var selectedIndexList = <int>[0].obs;

  int back = 0;

  // List of all the screens for the bottom navigation
  final List<Widget> screens = [
    DashBoard(),
    const NewLaunch(),
    PointsScreen(),
    EventPage(),
    const LeaderBoard(),

    CourseList(),
    ClassSchedulePage(),
    DailyStreak(),
    // ExamDashboard(),
    MaterialCourseList(),
    PaymentPage(),
    AttendancePage(),
    QueryList(),
    PlacementDetails(),
    ReferralPage(),
    NotificationPage(),
    PointsBenfits()
  ];

  // Function to change the selected page
  void setPage(int index) {
    currentPage.value = index;
    selectedIndex.value = index;
    selectedIndexList.clear();
    // if (selectedIndexList.contains(index)) {
    //   selectedIndexList.remove(index);
    //   update();
    // }
    selectedIndexList.add(index);
    update();
  }

  Future<bool> backControl(
      context, GlobalKey<ScaffoldState> scaffoldKey) async {
    if (scaffoldKey.currentState?.isDrawerOpen ?? false) {
      // Close the drawer
      Navigator.of(context).pop(); // Closes the drawer
      return false;
    }

    if (currentPage == 0) {
      final shouldPop = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: Colors.white,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Confirm Exit',
                style: GoogleFonts.prompt(),
              ),
              /*IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: Icon(Icons.close))*/
            ],
          ),
          content: Text(
            'Do you want to Exit ?',
            style: GoogleFonts.prompt(),
          ),
          /*actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false), // Stay in app
              child: const Text('No'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true), // Exit the page
              child: const Text('Yes'),
            ),
          ],*/
          actions: [
            // No Button
            SizedBox(
              width: 100, // Set your desired width
              height: 45, // Set your desired height
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: TColors.grey),
                ),
                child: TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'No',
                    style: GoogleFonts.prompt(fontSize: 18),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            // Yes Button
            SizedBox(
              width: 100, // Match the width of the No button
              height: 45, // Match the height of the No button
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: TColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'Yes',
                  style: GoogleFonts.prompt(),
                ),
              ),
            ),
          ],
        ),
      );
      // back = 0;
      // update();
      return shouldPop ?? false;
    } else {
      setPage(0);
      update();
      return false;
    }
  }
}
