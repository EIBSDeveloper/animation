import '../../../../utils/constants/path_provider.dart';

class OurBottomNavigationBar extends StatelessWidget {
  OurBottomNavigationBar({super.key});
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BottomNavigationController>(
      init: BottomNavigationController(),
      builder: (controller) {
        return SafeArea(
          child: WillPopScope(
            onWillPop: () => controller.backControl(context, scaffoldKey),
            child: Scaffold(
              key: scaffoldKey,
              drawer: SideMenuBar(),
              /* appBar: (controller.selectedIndexList.last == 2
                  ? const ExchangeAppBar()
                  : CustomAppBar(isKeyNeed: true,)) as PreferredSizeWidget?,*/
              appBar: CustomAppBar(isKeyNeed: true),
              bottomNavigationBar: Obx(() => CurvedNavigationBar(
                    index: controller.currentPage.value,
                    items: const <Widget>[
                      Image(
                          image: AssetImage(TImages.bIcon1),
                          width: 30,
                          height: 30),
                      Image(
                          image: AssetImage(TImages.bIcon2),
                          width: 30,
                          height: 30),
                      /* Image(
                          image: AssetImage(TImages.bIcon3),
                          width: 30,
                          height: 30),*/
                      Image(
                          image: AssetImage(TImages.bIcon4),
                          width: 30,
                          height: 30),
                      Image(
                          image: AssetImage(
                            TImages.bIcon5,
                          ),
                          width: 30,
                          height: 30),
                    ],
                    color: TColors.primary,
                    buttonBackgroundColor: TColors.Bottomcolor,
                    backgroundColor: Colors.transparent,
                    animationCurve: Curves.easeInOut,
                    animationDuration: const Duration(milliseconds: 600),
                    onTap: (index) {
                      controller.setPage(index);
                    },
                    letIndexChange: (index) => true,
                  )),
              body: Obx(
                  () => controller.screens[controller.selectedIndexList.last]),
            ),
          ),
        );
      },
    );
  }
}
