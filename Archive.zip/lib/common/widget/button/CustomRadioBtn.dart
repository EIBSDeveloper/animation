import 'package:flutter/material.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';

class CustomRadioButton extends StatelessWidget {
  final String value;
  final String? groupValue;
  final ValueChanged<String> onChanged;
  final String label;

  const CustomRadioButton({
    required this.value,
    required this.groupValue,
    required this.onChanged,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    bool isSelected = value == groupValue;

    return GestureDetector(
      onTap: () {
        onChanged(value);
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          children: [
            CustomPaint(
              painter: DoubleCirclePainter(isSelected: isSelected),
              child: SizedBox(width: 24, height: 24),
            ),
            SizedBox(width: TSizes.sm),
            Flexible(
                child: Text(
              label,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium!
                  .apply(color: Colors.black),
            )), // Display the label next to the radio button
          ],
        ),
      ),
    );
  }
}

class DoubleCirclePainter extends CustomPainter {
  final bool isSelected;

  DoubleCirclePainter({required this.isSelected});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = isSelected ? TColors.primary : Colors.grey
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final double outerRadius = size.width / 2;
    final double innerRadius = outerRadius - 5;

    canvas.drawCircle(
        Offset(size.width / 2, size.height / 2), outerRadius, paint);
    if (isSelected) {
      paint.style = PaintingStyle.fill;
    }
    canvas.drawCircle(
        Offset(size.width / 2, size.height / 2), innerRadius, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
