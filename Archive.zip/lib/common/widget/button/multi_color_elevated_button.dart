import 'package:flutter/material.dart';

import '../../../utils/constants/colors.dart';

class MultiColorElevatedButton extends StatelessWidget {
  final VoidCallback onPressed;
  final List<Color>? colors;
  final String text;
  final double width;

  MultiColorElevatedButton({
    required this.onPressed,
    this.colors,
    required this.text,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      onPressed: onPressed,
      child: Ink(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colors??[TColors.primary,TColors.primary, TColors.importantText, TColors.importantText],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Container(
          width: width,
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }
}
