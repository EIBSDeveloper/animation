

import '../../../utils/constants/path_provider.dart';

class TCustomGardientButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String label;
  final bool useGradient;
  final Color solidColor;
  final Gradient? gradient;
  final TextStyle? textStyle;
  final double borderRadius;
  final double? height;
  final double? width;

  const TCustomGardientButton({
    super.key,
    required this.onPressed,
    required this.label,
    this.useGradient = false,
    this.solidColor = TColors.absentOrLeave,
    this.gradient,
    this.textStyle,
    this.borderRadius = 8.0,
    this.height,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height ?? 45,
      width: width ?? 150,
      decoration: BoxDecoration(
        color: useGradient ? null : solidColor,
        gradient: useGradient
            ? gradient ??
            const LinearGradient(
              colors: [TColors.gardientBlue, TColors.gardientRed],
            )
            : null,
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(borderRadius),
          ),
        ),
        child: Text(
          label,
          style: textStyle ?? const TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}


