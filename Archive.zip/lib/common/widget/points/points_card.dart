import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../utils/constants/colors.dart';

class PointsCard extends StatelessWidget {
  const PointsCard({
    super.key,
    required this.points,
    required this.total,
    required this.pointsImage,
    required this.isSelected,
    required this.onTap,
  });

  final String points; // from API
  final int total; // static
  final String pointsImage;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final int current = int.tryParse(points) ?? 0;
    final double progress = total > 0 ? current / total : 0.0;
    // 🔹 Format total with 2 digits (01, 05, 250 stays 250)
    final String formattedTotal =
        total < 10 ? total.toString().padLeft(2, '0') : total.toString();

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 130,
        width: 100,
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isSelected ? TColors.Bottomcolor : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: TColors.grey, width: 1.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(pointsImage, width: 60, height: 60),
            const SizedBox(height: 8),

            // Points in "current/total"
            Text(
              "${current.toString().padLeft(2, '0')}/$formattedTotal",
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),

            const SizedBox(height: 8),

            // Progress bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 6,
                backgroundColor: TColors.grey,
                color: TColors.primary,
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;

  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48, // fixed height
      width: 140, // fixed width
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: TColors.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        onPressed: onPressed,
        child: Text(
          label,
          style: GoogleFonts.prompt(
              color: TColors.white, fontWeight: FontWeight.w500, fontSize: 16),
        ),
      ),
    );
  }
}
