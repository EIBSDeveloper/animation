import 'package:eapl_student_app/features/personalization/models/exam/course_list_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_topics_list/exam_list_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/helper_functions.dart';

class ExamCourseListContainer extends StatelessWidget {
  const ExamCourseListContainer({
    super.key,
    required this.course,
  });

  final CourseListModel course;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(TSizes.sm),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: THelperFunctions.screenWidth() > 600 ? 2 : 1,
            child: Text(
              course.courseName,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context)
                  .textTheme
                  .bodyLarge!
                  .apply(color: TColors.primary),
            ),
          ),
          Flexible(
            child: Column(
              children: [
                Text(
                  course.examCount.toString(),
                  style: Theme.of(context).textTheme.headlineMedium!.copyWith(
                      color: TColors.importantText,
                      fontWeight: FontWeight.bold),
                ),
                Text("Exam Count",
                    style: Theme.of(context).textTheme.bodyMedium)
              ],
            ),
          ),
          Flexible(
            child: SizedBox(
                width: THelperFunctions.screenWidth() > 600 ? 180 : 200,
                height: THelperFunctions.screenWidth() > 600 ? 62 : 42,
                child: ElevatedButton(
                  onPressed: course.examCount <= 0
                      ? null
                      : () {
                          Get.to(() => ExamListPage());
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: TColors.buttonSecondary,
                    side: BorderSide(
                      color: course.examCount <= 0
                          ? TColors.grey
                          : TColors.buttonSecondary,
                    ),
                  ),
                  child: const Text(
                    "Start",
                    style: TextStyle(color: Colors.black),
                  ),
                )),
          )
        ],
      ),
    );
    // },
    // );
  }
}
