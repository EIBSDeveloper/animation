import 'package:eapl_student_app/features/personalization/models/exam/exam_list_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/helper_functions.dart';

class ExamListContainers extends StatelessWidget {
  const ExamListContainers({
    super.key,
    required this.onPressedStartExam,
    required this.exam,
  });

  final Widget onPressedStartExam;

  final ExamListModel exam;
  @override
  Widget build(BuildContext context) {
    // return Obx(
    //   () {
    //     final exam = controller.examList[controller.examListIndex.value];
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(TSizes.sm),
      margin: EdgeInsets.symmetric(
        vertical: TSizes.xs,
      ),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "${exam.examName}",
            style: Theme.of(context)
                .textTheme
                .bodyLarge!
                .apply(color: TColors.primary),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Column(
                  children: [
                    Text(
                      exam.examDuration.toString(),
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium!
                          .copyWith(
                              color: TColors.importantText,
                              fontWeight: FontWeight.bold),
                    ),
                    Text("Minutes",
                        style: Theme.of(context).textTheme.bodyMedium)
                  ],
                ),
              ),
              Flexible(
                child: Column(
                  children: [
                    Text(
                      exam.noOfQuestions.toString(),
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium!
                          .copyWith(
                              color: TColors.importantText,
                              fontWeight: FontWeight.bold),
                    ),
                    Text("Questions",
                        style: Theme.of(context).textTheme.bodyMedium)
                  ],
                ),
              ),
              Flexible(
                child: SizedBox(
                    width: THelperFunctions.screenWidth() > 600 ? 180 : 200,
                    height: THelperFunctions.screenWidth() > 600 ? 62 : 42,
                    child: ElevatedButton(
                      onPressed: () {
                        Get.dialog(onPressedStartExam);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: TColors.buttonSecondary,
                        side: BorderSide(
                          color: TColors.buttonSecondary,
                        ),
                      ),
                      child: const Text(
                        "Start",
                        style: TextStyle(color: Colors.black),
                      ),
                    )),
              )
            ],
          ),
        ],
      ),
    );
    //   },
    // );
  }
}
