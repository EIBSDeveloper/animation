import 'package:eapl_student_app/features/personalization/models/exam/exam_report_list_model.dart';
import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_report/exam_report.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/helper_functions.dart';

class ExamReportContainer extends StatelessWidget {
  const ExamReportContainer({
    super.key,
    required this.examTitle,
    required this.questionCount,
    required this.timingInMinutes,
    required this.exam,
  });

  final String examTitle;
  final String questionCount;
  final String timingInMinutes;
  final ExamReportListModel exam;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(TSizes.sm),
      margin: EdgeInsets.symmetric(vertical: TSizes.xs),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10.0)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(exam.examName ?? "---",
              style: Theme.of(context)
                  .textTheme
                  .bodyLarge!
                  .apply(color: TColors.primary)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Column(
                  children: [
                    Text(
                      exam.examDuration.toString(),
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium!
                          .copyWith(
                              color: TColors.importantText,
                              fontWeight: FontWeight.bold),
                    ),
                    Text("Minutes",
                        style: Theme.of(context).textTheme.bodyMedium)
                  ],
                ),
              ),
              Flexible(
                child: Column(
                  children: [
                    Text(
                      exam.noOfQuestions.toString(),
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium!
                          .copyWith(
                              color: TColors.importantText,
                              fontWeight: FontWeight.bold),
                    ),
                    Text("Questions",
                        style: Theme.of(context).textTheme.bodyMedium)
                  ],
                ),
              ),
              Flexible(
                child: SizedBox(
                    width: THelperFunctions.screenWidth() > 600 ? 180 : 200,
                    height: THelperFunctions.screenWidth() > 600 ? 62 : 42,
                    child: ElevatedButton(
                      onPressed: () {
                        Get.to(() => ExamReport());
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: TColors.primary,
                        side: BorderSide(
                          color: TColors.buttonSecondary,
                        ),
                      ),
                      child: const Text(
                        "View",
                        style: TextStyle(color: Colors.white),
                      ),
                    )),
              )
            ],
          ),
        ],
      ),
    );
  }
}
