import 'package:flutter/material.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/helper_functions.dart';

class ConfirmationAlert extends StatelessWidget {
  // final String text;
  final Widget textWidget;
  final VoidCallback onpressedYes;
  final VoidCallback onpressedno;
  final String imageUrl;
  final BoxFit? fit;
  final bool isNetworkImage;

  const ConfirmationAlert(
      {super.key,
      // required this.text,
      required this.onpressedYes,
      required this.onpressedno,
      required this.imageUrl,
      this.fit = BoxFit.fill,
      this.isNetworkImage = false,
      required this.textWidget});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          SizedBox(
            height: THelperFunctions.screenHeight() / 3,
            width: THelperFunctions.screenWidth() < 600
                ? double.infinity
                : THelperFunctions.screenWidth() / 2.8,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(TSizes.defaultSpace),
                  child: Column(
                    children: [
                      SizedBox(
                          height: TSizes.md), // space for the overlapping image
                      textWidget,
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    SizedBox(
                      // width: THelperFunctions.screenWidth()>600?150:120,
                      child: ElevatedButton(
                        onPressed: onpressedYes,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: TColors.importantText,
                          side: BorderSide(color: TColors.importantText),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: Text('Yes'),
                      ),
                    ),
                    SizedBox(
                      // width: THelperFunctions.screenWidth()>600?120:100,

                      child: ElevatedButton(
                        onPressed: onpressedno,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFF494949),
                          side: BorderSide(color: Color(0xFF494949)),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        child: Text(
                          'No',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: TSizes.sm),
              ],
            ),
          ),
          Positioned(
            top: THelperFunctions.screenWidth() > 600 ? -100 : -70,
            child: Image.asset(
              imageUrl, // Replace with your asset path
              height: THelperFunctions.screenWidth() > 600 ? 150 : 130,
              width: THelperFunctions.screenWidth() > 600 ? 150 : 130,
            ),
          ),
        ],
      ),
    );
  }
}
