import 'package:eapl_student_app/features/personalization/screens/side_drawer_menu/exam/exam_page/exam_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/helpers/helper_functions.dart';

class GuidelinesDialog extends StatelessWidget {
  const GuidelinesDialog({super.key, required this.onpressed});

  final VoidCallback onpressed;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ExamController());

    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Container(
        // height: THelperFunctions.screenWidth() > 600
        //     ? THelperFunctions.screenHeight() / 1.2
        //     : THelperFunctions.screenHeight() / 1.2,
        width: THelperFunctions.screenWidth() > 600
            ? THelperFunctions.screenWidth() / 1.1
            : THelperFunctions.screenWidth(),
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Guidelines to Online Examination',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              width: THelperFunctions.screenWidth() > 600
                  ? THelperFunctions.screenWidth() / 1.2
                  : THelperFunctions.screenWidth() / 1.1,
              height: THelperFunctions.screenHeight() / 1.5,
              decoration: BoxDecoration(
                border: Border.all(color: TColors.primary, width: 2.0),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: FutureBuilder<String?>(
                future: controller.fetchGuidelines(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else if (!snapshot.hasData || snapshot.data == null) {
                    return const Center(
                        child: Text('No guidelines available.'));
                  } else {
                    return SingleChildScrollView(
                      child: Html(
                        data: snapshot.data,
                      ),
                    );
                  }
                },
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: onpressed,
                child: const Text('Agree'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
