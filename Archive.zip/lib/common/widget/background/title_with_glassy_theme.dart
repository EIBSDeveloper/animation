import 'package:eapl_student_app/utils/helpers/helper_functions.dart';
import 'package:flutter/material.dart';

import '../../../utils/constants/sizes.dart';
import '../container/glassy_container.dart';
import 'background_theme.dart';

class TitleWithGlassyTheme extends StatelessWidget {
  final Widget child;
  final String title;
  final bool? centerTitle;
  final double? glassHeight;

  const TitleWithGlassyTheme(
      {super.key,
      required this.child,
      required this.title,
      this.centerTitle = false,
      this.glassHeight});
  @override
  Widget build(BuildContext context) {
    return OurBackgroundTheme(
      // fit: StackFit.expand,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment:
            centerTitle! ? CrossAxisAlignment.center : CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(context)
                .textTheme
                .titleLarge!
                .apply(fontSizeDelta: 1.2),
          ),
          SizedBox(height: TSizes.sm),
          GlassyContainer(
              height: glassHeight ??
                  (THelperFunctions.screenWidth() > 600
                      ? THelperFunctions.screenHeight() / 1.20
                      : THelperFunctions.screenHeight() / 1.1),
              width: double.infinity,
              margin: EdgeInsets.only(top: TSizes.sm),
              child: child),
        ],
      ),
    );
  }
}
