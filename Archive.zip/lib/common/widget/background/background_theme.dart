import 'package:flutter/material.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';
import '../container/rounded_color_fill_container.dart';

class OurBackgroundTheme extends StatelessWidget {
  const OurBackgroundTheme({
    super.key,
    required this.child,
    this.fit = StackFit.loose,
  });

  final Widget child;
  final StackFit fit;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.loose,
      children: [
        Positioned(
            top: -50,
            right: -50,
            child: RoundedColorFillContainer(
                size: 100, color: Colors.yellow.withOpacity(0.8))),
        Positioned(
            // top: 10,
            bottom: 10,
            left: -100,
            child: RoundedColorFillContainer(
                size: 250, color: TColors.primary.withOpacity(0.4))),
        Positioned(
            right: -2,
            top: 15,
            bottom: 200,
            child: RoundedColorFillContainer(
                size: 50, color: TColors.darkSkyBlue.withOpacity(0.5))),

        // Positioned(
        //    bottom: 280,
        //    top: 10,
        //    right: 50,
        //    child:
        //        RoundedColorFillContainer(size: 50, color: TColors.importantText.withOpacity(0.8))),
        Positioned(
            right: -50,
            bottom: -50,
            child: RoundedColorFillContainer(
                size: 100, color: TColors.importantText.withOpacity(0.4))),
        // const Positioned(
        //     top: 5,
        //     bottom: 50,
        //     right: -10,
        //     child: RoundedColorFillContainer(
        //         size: 140, color: TColors.darkskyblue)),

        //
        // Container(
        //     width: double.infinity,
        //     height: double.infinity,
        //     color: Colors.white.withOpacity(0.80)),
        Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: child,
        ),
      ],
    );
  }
}
