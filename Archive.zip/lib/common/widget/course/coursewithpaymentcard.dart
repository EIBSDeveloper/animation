import 'package:eapl_student_app/features/personalization/models/course_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../../utils/constants/colors.dart';
import '../../../features/personalization/models/payment_model.dart';
import '../../../features/personalization/screens/side_drawer_menu/course/current_course_details_view.dart';
import '../../../features/personalization/screens/side_drawer_menu/payment/payment_history_details.dart';
import '../../../utils/constants/image_strings.dart';

class CourseWithPaymentCard extends StatelessWidget {
  final CourseDetailModel courseDetails;
  final CoursePaymentModel paymentModel;

  const CourseWithPaymentCard({
    super.key,
    required this.courseDetails,
    required this.paymentModel,
  });

  @override
  Widget build(BuildContext context) {
    double progress =
        double.tryParse(courseDetails.courseCompletePercentage ?? "0.0") ?? 0.0;
    final formatter = NumberFormat.decimalPattern('en_IN');

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300, width: 0.8),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min, // ← add this
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// 1️⃣ Course Title
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                courseDetails.courseName,
                style: GoogleFonts.prompt(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                getDisplayStatus(courseDetails.statuslabel),
                style: GoogleFonts.prompt(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: getStatusColor(courseDetails.statuslabel),
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
          const SizedBox(height: 10),

          /// 2️⃣ Progress Row
          Row(
            children: [
              /// Progress Bar
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: progress / 100,
                    minHeight: 6,
                    backgroundColor: Colors.grey.shade300,
                    valueColor: AlwaysStoppedAnimation<Color>(TColors.primary),
                  ),
                ),
              ),
              const SizedBox(width: 10),

              /// Percentage
              Text(
                "${progress.toStringAsFixed(0)}%",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(width: 10),

              /// View Details Button (fixed h & w)
              SizedBox(
                height: 30,
                width: 100,
                child: ElevatedButton(
                  onPressed: () {
                    Get.to(
                      () =>
                          CurrentCourseDetailsView(courseModel: courseDetails),
                      transition: Transition.cupertino,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: TColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    padding: EdgeInsets.zero,
                    elevation: 0,
                  ),
                  child: Text(
                    'View Details',
                    style: GoogleFonts.prompt(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: TColors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),

          /// 3️⃣ Course Info Row
          Row(
            children: [
              /// Category
              Expanded(
                flex: 3,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.calender,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        courseDetails.endDate != null
                            ? "Date: ${DateFormat('d MMM yyyy', 'en_US').format(DateTime.parse(courseDetails.endDate!))}"
                            : "Date: ---",
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
              ),

              /// Days
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    Image.asset(
                      TImages.days,
                      width: 25,
                      height: 25,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        'Days: ${courseDetails.remainingdays ?? "0"}',
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      ),
                    ),
                  ],
                ),
              ),

              /// ✅ Pay Now Button (instead of rating)
              if (paymentModel != null && paymentModel.balanceFee > 0)
                SizedBox(
                  height: 30,
                  width: 100,
                  child: ElevatedButton(
                    onPressed: () {
                      Get.to(() => PaymentHistory(
                            paymentCourseWiseModel: paymentModel,
                          ));
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: TColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                    ),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        'Pay Now',
                        style: GoogleFonts.prompt(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: TColors.white,
                        ),
                        maxLines: 1,
                        softWrap: false,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 15),

          /// 4️⃣ Payment Section
          if (paymentModel != null) ...[
            Row(
              children: [
                _buildAmountTile(
                    label: "Course Fee",
                    value: paymentModel.totalAmount,
                    formatter: formatter),
                const SizedBox(width: 8),
                _buildAmountTile(
                    label: "Paid",
                    value: paymentModel.paidAmount,
                    formatter: formatter),
                const SizedBox(width: 8),
                _buildAmountTile(
                    label: "Balance",
                    value: paymentModel.balanceFee,
                    formatter: formatter),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ],
      ),
    );
  }

  Widget _buildAmountTile({
    required num value,
    required String label,
    required NumberFormat formatter,
  }) {
    return Flexible(
      // Changed from Expanded to Flexible
      fit: FlexFit.tight,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: TColors.grey),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min, // Important
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label,
                style: GoogleFonts.prompt(
                    fontSize: 14, fontWeight: FontWeight.w500)),
            const SizedBox(height: 6),
            Text("₹ ${formatter.format(value)}",
                style: GoogleFonts.prompt(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: TColors.primary)),
          ],
        ),
      ),
    );
  }

// Map API status to display text
  String getDisplayStatus(String? status) {
    if (status == null) return "";
    switch (status.toLowerCase()) {
      case "complete":
        return "Completed";
      case "on progress":
        return "On Progress";
      case "not yet started":
        return "Not Yet Started";
      default:
        return status; // fallback, display as-is
    }
  }

// Get color based on API status
  Color getStatusColor(String? status) {
    if (status == null) return Colors.black;
    switch (status.toLowerCase()) {
      case "complete":
        return Colors.green;
      case "on progress":
        return Colors.orange;
      case "not yet started":
        return Colors.red;
      default:
        return Colors.black;
    }
  }
}
