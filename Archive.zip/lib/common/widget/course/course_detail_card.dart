import 'package:eapl_student_app/features/personalization/models/course_model.dart';
import 'package:eapl_student_app/utils/constants/apptextstyles.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/image_strings.dart';

class CourseDetailsCard extends StatelessWidget {
  const CourseDetailsCard({super.key, required this.courseModel});
  final CourseDetailModel? courseModel;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      height: 300,
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: TColors.sandal,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: TColors.grey),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Course Version + Name + Code
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                courseModel?.courseVersion ?? "---",
                style: GoogleFonts.prompt(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  height: 1.0,
                  letterSpacing: 0.32,
                ),
              ),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  courseModel?.courseName ?? "---",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.prompt(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              /* Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: TColors.primary,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  courseModel?.courseCode ?? "---",
                  style: GoogleFonts.prompt(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: TColors.white,
                  ),
                ),
              ),*/
            ],
          ),

          const SizedBox(height: 10),

          /// Subcategory
          Row(
            children: [
              Image.asset(
                TImages.category,
                width: 25,
                height: 25,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 4),
              Text(
                courseModel?.courseSubcategoryName ?? "---",
                style: GoogleFonts.prompt(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          /// Duration Grid
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: _DurationCard(
                  imagePath: TImages.theory,
                  label: "Theory  Class",
                  value: "${courseModel?.coursePracticalHours ?? "---"} Hrs",
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _DurationCard(
                  imagePath: TImages.practical,
                  label: "Practical Class",
                  value: "${courseModel?.courseTheoryHours ?? "---"} Hrs",
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _DurationCard(
                  imagePath: TImages.hrs,
                  label: "Total Duration",
                  value: "${courseModel?.courseDuration ?? "---"} Hrs",
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),
          Text(
            "Course Duration: ",
            style: AppTextStyles.heading,
          ),
          SizedBox(
            height: 5,
          ),
          Expanded(
            child: Row(
              children: [
                Image.asset(
                  TImages.calender,
                  width: 25,
                  height: 25,
                  fit: BoxFit.contain,
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                      "${formatDate(courseModel?.startDate)}  to  ${formatDate(courseModel?.endDate)}",
                      style: AppTextStyles.heading),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Helper to format date
String formatDate(String? dateStr) {
  if (dateStr == null || dateStr.isEmpty) return "---";
  try {
    final date = DateTime.parse(dateStr);
    return DateFormat("dd MMM yyyy").format(date); // e.g. 05 Sep 2025
  } catch (e) {
    return dateStr; // fallback if parsing fails
  }
}

/// Small reusable widget for duration
class _DurationCard extends StatelessWidget {
  final String imagePath;
  final String label;
  final String value;

  const _DurationCard({
    Key? key,
    required this.imagePath,
    required this.label,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: TColors.grey.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            imagePath,
            width: 25,
            height: 25,
            fit: BoxFit.contain,
          ),
          const SizedBox(height: 6),
          Text(
            label,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            textAlign: TextAlign.center,
            style: GoogleFonts.prompt(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: TColors.black,
            ),
          ),
        ],
      ),
    );
  }
}
