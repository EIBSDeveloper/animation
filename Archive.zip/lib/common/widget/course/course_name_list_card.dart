import 'package:eapl_student_app/features/personalization/models/course_model.dart';
import 'package:eapl_student_app/utils/constants/sizes.dart';
import 'package:flutter/material.dart';

import '../../../../../../utils/constants/colors.dart';
import '../container/glassy_container.dart';

class CourseNameListCard extends StatelessWidget {
  const CourseNameListCard({
    super.key,
    required this.courseModel,
    required this.onTap,
  });

  final CourseDetailModel courseModel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: GlassyContainer(
        width: double.infinity,
        color: const Color(0xFFEFEFEF),
        margin: EdgeInsets.symmetric(vertical: TSizes.sm),
        opacity: 0.8,
        child: IntrinsicHeight(
          child: Row(
            children: [
              Expanded(
                child: Text(
                  courseModel.courseName,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodyLarge!
                      .apply(color: TColors.black),
                ),
              ),
              // const Spacer(),
              const Icon(Icons.arrow_forward_ios_rounded),
            ],
          ),
        ),
      ),
    );
  }
}
