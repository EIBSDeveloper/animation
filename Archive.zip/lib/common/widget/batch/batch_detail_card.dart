import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../features/personalization/controllers/side_drawer_controller/batch_controller.dart';
import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';

/*
class BatchDetailsCard extends StatelessWidget {
  const BatchDetailsCard({
    super.key,
    required this.courseId,
  });
  final String courseId;

  @override
  Widget build(BuildContext context) {
    final batchController = Get.put(BatchController());
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      batchController.fetchBatchDetailsController(courseId: courseId);
    });

    return Obx(
      () {
        if (batchController.isLoading.value == true) {
          return Center(child: CircularProgressIndicator());
        }
        if (batchController.batchDetails.value == null) {
          return Text("There is no Batch");
        }
        final batchDetail = batchController.batchDetails.value!;
        return GlassyContainer(
          color: const Color(0xFFEFEFEF),
          opacity: 0.80,
          borderRadius: 7,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                batchDetail.batchAutoIncrementId,
                style: Theme.of(context)
                    .textTheme
                    .bodyLarge!
                    .apply(color: TColors.importantText),
              ),
              Divider(
                indent: 5,
                endIndent: THelperFunctions.screenWidth() / 2,
              ),
              const SizedBox(height: TSizes.xs),
              Row(
                children: [
                  const Icon(
                    Icons.calendar_today_outlined,
                    color: TColors.primary,
                    size: TSizes.md,
                  ),
                  const SizedBox(width: TSizes.xs),
                  Text(
                    batchDetail.slotName,
                    style: Theme.of(context).textTheme.labelLarge,
                  )
                ],
              ),
              const SizedBox(height: TSizes.xs),
              Row(
                children: [
                  const Icon(
                    Icons.calendar_month,
                    color: TColors.primary,
                    size: TSizes.md,
                  ),
                  const SizedBox(width: TSizes.xs),
                  Text(
                    batchDetail.slotTypeDays.join(", "),
                    style: Theme.of(context).textTheme.labelLarge,
                  )
                ],
              ),
              const SizedBox(height: TSizes.xs),
              IntrinsicHeight(
                child: Row(
                  children: [
                    Text(
                      "Start Date - ",
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium!
                          .apply(color: TColors.black),
                    ),
                    Text(
                      batchDetail.startDate,
                      style: Theme.of(context)
                          .textTheme
                          .labelLarge!
                          .apply(color: TColors.primary),
                    ),
                    const VerticalDivider(),
                    Text(
                      "End Date - ",
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium!
                          .apply(color: TColors.black),
                    ),
                    Text(
                      batchDetail.endDate,
                      style: Theme.of(context)
                          .textTheme
                          .labelLarge!
                          .apply(color: TColors.primary),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: TSizes.xs),
              IntrinsicHeight(
                child: Row(
                  children: [
                    Text(
                      "Start Time - ",
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium!
                          .apply(color: TColors.black),
                    ),
                    Text(
                      batchDetail.startTime.substring(0, 5),
                      style: Theme.of(context)
                          .textTheme
                          .labelLarge!
                          .apply(color: TColors.primary),
                    ),
                    const VerticalDivider(),
                    Text(
                      "End Time - ",
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium!
                          .apply(color: TColors.black),
                    ),
                    Text(
                      batchDetail.endTime.substring(0, 5),
                      style: Theme.of(context)
                          .textTheme
                          .labelLarge!
                          .apply(color: TColors.primary),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}*/
class BatchDetailsCard extends StatelessWidget {
  const BatchDetailsCard({
    super.key,
    required this.courseId,
  });
  final String courseId;

  @override
  Widget build(BuildContext context) {
    final batchController = Get.put(BatchController());
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      batchController.fetchBatchDetailsController(courseId: courseId);
    });

    return Obx(() {
      if (batchController.isLoading.value) {
        return Center(child: CircularProgressIndicator());
      }

      if (batchController.batchDetails.value == null) {
        return Center(
          child: Text(
            "No batch available",
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        );
      }

      final batchDetail = batchController.batchDetails.value!;

      return Container(
        margin: const EdgeInsets.symmetric(
            vertical: TSizes.sm, horizontal: TSizes.sm),
        padding: const EdgeInsets.all(TSizes.md),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Color.fromRGBO(60, 64, 67, 0.3),
                blurRadius: 2,
                spreadRadius: 0,
                offset: Offset(
                  0,
                  1,
                ),
              ),
              BoxShadow(
                color: Color.fromRGBO(60, 64, 67, 0.15),
                blurRadius: 6,
                spreadRadius: 2,
                offset: Offset(
                  0,
                  2,
                ),
              ),
            ]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Batch ID
            Text(
              batchDetail.batchAutoIncrementId,
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall!
                  .apply(color: TColors.importantText),
            ),
            Divider(
              height: TSizes.sm,
              thickness: 1,
              color: Colors.grey.shade300,
            ),

            // Slot Name
            Row(
              children: [
                const Icon(Icons.calendar_today_outlined,
                    color: TColors.primary, size: TSizes.md),
                const SizedBox(width: TSizes.xs),
                Text(
                  batchDetail.slotName,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
            const SizedBox(height: TSizes.sm),

            // Slot Days
            Row(
              children: [
                const Icon(Icons.calendar_month,
                    color: TColors.primary, size: TSizes.md),
                const SizedBox(width: TSizes.xs),
                Flexible(
                  child: Text(
                    batchDetail.slotTypeDays.join(", "),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
              ],
            ),
            const SizedBox(height: TSizes.md),

            // Dates
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.event,
                        color: TColors.primary, size: TSizes.md),
                    const SizedBox(width: TSizes.xs),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Start Date",
                          style: Theme.of(context)
                              .textTheme
                              .labelMedium!
                              .apply(color: TColors.black),
                        ),
                        Text(
                          batchDetail.startDate,
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium!
                              .apply(color: TColors.primary),
                        ),
                      ],
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Icon(Icons.event_available,
                        color: TColors.primary, size: TSizes.md),
                    const SizedBox(width: TSizes.xs),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "End Date",
                          style: Theme.of(context)
                              .textTheme
                              .labelMedium!
                              .apply(color: TColors.black),
                        ),
                        Text(
                          batchDetail.endDate,
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium!
                              .apply(color: TColors.primary),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: TSizes.md),

// Times
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.access_time,
                        color: TColors.primary, size: TSizes.md),
                    const SizedBox(width: TSizes.xs),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Start Time",
                          style: Theme.of(context)
                              .textTheme
                              .labelMedium!
                              .apply(color: TColors.black),
                        ),
                        Text(
                          batchDetail.startTime.substring(0, 5),
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium!
                              .apply(color: TColors.primary),
                        ),
                      ],
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 32),
                  child: Row(
                    children: [
                      const Icon(Icons.access_time_filled,
                          color: TColors.primary, size: TSizes.md),
                      const SizedBox(width: TSizes.xs),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "End Time",
                            style: Theme.of(context)
                                .textTheme
                                .labelMedium!
                                .apply(color: TColors.black),
                          ),
                          Text(
                            batchDetail.endTime.substring(0, 5),
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium!
                                .apply(color: TColors.primary),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    });
  }
}
