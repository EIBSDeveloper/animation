import 'package:eapl_student_app/common/widget/menu/side_drawer_menu/side_menu_controller.dart';
import 'package:eapl_student_app/features/personalization/controllers/bottom_bar_controller/points_controller.dart';
import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../features/personalization/models/appbar_points_model.dart';
import '../../../features/personalization/screens/bottom_menu/leaders-board/leaders_board.dart';
import '../../../utils/constants/path_provider.dart';
import '../images/t_circular_image.dart';
import 'appbar_controller.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  CustomAppBar({super.key, this.isMenuNeed = true, this.isKeyNeed = false});

  final bool isMenuNeed;
  final bool isKeyNeed;
  final AppbarController controller = Get.put(AppbarController());
  void _showTourOnce(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isTutorialShown = GetStorage().read(TTexts.appbartour) ?? false;

      if (!controller.isappbarTouron.value && !isTutorialShown) {
        await Future.delayed(const Duration(milliseconds: 500));
        await controller.AppbarTour(context);

        // ✅ Mark it as shown
        GetStorage().write(TTexts.appbartour, true);
        controller.isappbarTouron.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final SideMenuController sideMenuController = Get.put(SideMenuController());
    final PointController = Get.put(PointsController())..fetchLeaderBoard();
    _showTourOnce(context);
    return SizedBox(
      height: preferredSize.height, // 👈 Force total height
      child: GlassyContainer(
        color: TColors.primary,
        borderRadius: 1,
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center, // keep vertically centered
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                if (isMenuNeed)
                  IconButton(
                    onPressed: () {
                      Scaffold.of(context).openDrawer();
                    },
                    icon: Icon(
                      key: isKeyNeed ? controller.menuKey : null,
                      Icons.menu,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      size: 30,
                    ),
                  ),

                // Profile Image
                Obx(() => TCircularImage(
                      key: isKeyNeed ? controller.profileKey : null,
                      padding: 1,
                      image: sideMenuController.profileUrl.value.isNotEmpty
                          ? sideMenuController.profileUrl.value
                          : TImages.profileImage,
                      width: 50,
                      height: 50,
                      isNetworkImage: sideMenuController.profileUrl.value
                          .startsWith('http'),
                    )),

                const SizedBox(width: TSizes.sm),

                // Name and ID text wrapped inside Expanded to prevent overflow
                Expanded(
                  key: isKeyNeed ? controller.nameKey : null,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        GetStorage().read(TTexts.userName),
                        style: GoogleFonts.prompt(
                          fontSize: 18,
                          color: TColors.white,
                          fontWeight: FontWeight.w500,
                          fontStyle: FontStyle.normal,
                          height: 1.0,
                          letterSpacing: 0.32,
                        ),
                        overflow:
                            TextOverflow.ellipsis, // Avoid overflow in text
                      ),
                      const SizedBox(
                        height: 3,
                      ),
                      Text(
                        GetStorage().read(TTexts.userAutoId),
                        style: GoogleFonts.prompt(
                          fontSize: 14,
                          color: TColors.white,
                          fontWeight: FontWeight.w400,
                          fontStyle: FontStyle.normal,
                          height: 1.0,
                          letterSpacing: 0.32,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),

                // Badge Section
                InkWell(
                  onTap: () {
                    Get.to(const LeaderBoard());
                  },
                  child: SizedBox(
                    key: isKeyNeed ? controller.badgeKey : null,
                    height: 70,
                    width: 70,
                    child: Stack(
                      clipBehavior: Clip.none, // avoid overflow issues
                      children: [
                        /// Badge background
                        SizedBox.expand(
                          // 👈 instead of Positioned.fill
                          child: Image.asset(
                            TImages.badge,
                            fit: BoxFit
                                .contain, // 👈 ensure it scales to the box
                          ),
                        ),

                        /// Rank circular badge at bottom-right
                        Positioned(
                          key: isKeyNeed ? controller.rankKey : null,
                          bottom: 4,
                          right: 6,
                          child: Obx(() {
                            final user = PointController.currentUser.value;
                            if (user == null || user.rank == null) {
                              return const SizedBox.shrink();
                            }
                            return Container(
                              height: 22,
                              width: 22,
                              decoration: const BoxDecoration(
                                color: Colors.black,
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Text(
                                  "${user.rank}",
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: TColors.white,
                                  ),
                                ),
                              ),
                            );
                          }),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
            const SizedBox(
              height: TSizes.sm,
            ),
            Flexible(
              child: Obx(() {
                final points = controller.appBarPointsList.isNotEmpty
                    ? controller.appBarPointsList.first
                    : AppBarPointsModel(
                        coinsValue: 0,
                        diamondValue: 0,
                        heartScore: 0,
                        crownValue: 0,
                        cusName: '',
                        notifycount: 0);
                return controller.isLoading.value
                    ? const CircularProgressIndicator()
                    : Transform.translate(
                        offset: const Offset(0, -8), // move 8px up (negative Y)
                        child: Container(
                          key: isKeyNeed ? controller.pointsKey : null,
                          padding: const EdgeInsets.all(TSizes.sm),
                          height: TSizes.insideAppBarHeight,
                          width: 350,
                          decoration: const BoxDecoration(
                            //borderRadius: BorderRadius.circular(5),
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(
                                  12), // reduced bottom-left corner
                              topRight:
                                  Radius.circular(12), // keep small or default
                            ),
                            color: TColors.secondary,
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: _buildPointsContainer(
                                  context,
                                  TImages.coin,
                                  points.coinsValue.toString(),
                                ),
                              ),
                              Expanded(
                                child: _buildPointsContainer(
                                  context,
                                  TImages.diamond,
                                  points.diamondValue.toString(),
                                ),
                              ),
                              Expanded(
                                child: _buildPointsContainer(
                                  context,
                                  TImages.heart,
                                  points.heartScore.toString(),
                                ),
                              ),
                              Expanded(
                                child: _buildPointsContainer(
                                  context,
                                  TImages.crown,
                                  points.crownValue.toString(),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
              }),
            ),
          ],
        ),
      ),
    );
  }

  /// Points Image Containers
/*  Widget _buildPointsContainer(
      BuildContext context, String imagePath, String points) {
    bool isWideScreens = THelperFunctions.screenWidth() > 600;
    final double containerWidth = isWideScreens ? 120 : 75;
    final double containerHeight = isWideScreens ? 100 : 55;

    return SizedBox(
      height: containerHeight,
      width: containerWidth,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          // Points text at bottom
          Positioned(
            bottom: 0,
            child: Container(
              height: 25,
              width: 50,
              decoration: BoxDecoration(
                color: TColors.white,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(8), // reduced bottom-left corner
                  topRight: Radius.circular(8), // keep small or default
                ),
              ),
              padding: const EdgeInsets.all(2.0),
              child: Center(
                child: Text(
                  points, // ✅ full points value
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),

          // Image above the points
          Positioned(
            top: 0,
            child: Image.asset(
              imagePath,
              width: isWideScreens ? 70 : 35,
              height: isWideScreens ? 70 : 35,
            ),
          ),
        ],
      ),
    );
  }*/

/*  Widget _buildPointsContainer(
    BuildContext context,
    String imagePath,
    String points,
  ) {
    bool isWideScreens = THelperFunctions.screenWidth() > 600;
    final double containerWidth = isWideScreens ? 120 : 75;
    final double containerHeight = isWideScreens ? 100 : 65;

    return SizedBox(
      height: containerHeight,
      width: containerWidth,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          // 🌈 Animated glowing background behind the image
          Positioned.fill(
            child: AnimatedContainer(
              duration: const Duration(seconds: 2),
              curve: Curves.easeInOut,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.8),
                    Colors.grey.shade900.withOpacity(0.9),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blueAccent.withOpacity(0.3),
                    blurRadius: 12,
                    spreadRadius: 2,
                    offset: const Offset(0, 4),
                  ),
                ],
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 0.8,
                ),
              ),
            ),
          ),

          // ✨ Main icon with glowing pulse
          Positioned(
            top: 0,
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.9, end: 1.1),
              duration: const Duration(seconds: 2),
              curve: Curves.easeInOut,
              builder: (context, scale, child) {
                return Transform.scale(
                  scale: scale,
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.blueAccent.withOpacity(0.6),
                          blurRadius: 15,
                          spreadRadius: 3,
                        ),
                      ],
                    ),
                    child: Image.asset(
                      imagePath,
                      width: isWideScreens ? 55 : 35,
                      height: isWideScreens ? 55 : 35,
                    ),
                  ),
                );
              },
              onEnd: () {}, // Keeps looping implicitly
            ),
          ),

          // 💎 Glowing border for the points container
          Positioned(
            bottom: 0,
            child: Container(
              height: 28,
              width: 60,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.blueAccent.withOpacity(0.8),
                    Colors.purpleAccent.withOpacity(0.8),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blueAccent.withOpacity(0.5),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
              child: Center(
                child: Text(
                  points, // ✅ Dynamic points from API
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        color: Colors.blueAccent,
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }*/
  Widget _buildPointsContainer(
    BuildContext context,
    String imagePath,
    String points,
  ) {
    bool isWideScreens = THelperFunctions.screenWidth() > 600;
    final double containerWidth = isWideScreens ? 110 : 75;
    final double containerHeight = isWideScreens ? 120 : 80;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      width: containerWidth,
      height: containerHeight,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF4E342E), // medium brown
            Color(0xFF3E2723), // dark brown
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: const Color(0xFFFFD700), // subtle golden border
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.brown.withOpacity(0.3),
            blurRadius: 6,
            spreadRadius: 1,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          // 🔹 Image slightly outside (3D look)
          Positioned(
            top: -10,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.amberAccent.withOpacity(0.12),
                    blurRadius: 6,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Image.asset(
                imagePath,
                width: isWideScreens ? 52 : 36,
                height: isWideScreens ? 52 : 36,
              ),
            ),
          ),

          // 🧾 Points container (inside main box)
          /*Positioned(
            bottom: 10,
            child: Container(
              width: isWideScreens ? 70 : 55,
              height: isWideScreens ? 28 : 24,
              decoration: BoxDecoration(
                color: const Color(0xFF5D4037),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: const Color(0xFFFFD700),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 4,
                    spreadRadius: 0.5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  points, // ✅ Dynamic points
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        color: Colors.black45,
                        blurRadius: 3,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),*/
          Positioned(
            bottom: 10,
            child: Container(
              width: isWideScreens ? 70 : 55,
              height: isWideScreens ? 28 : 24,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFFFFD700), // bright gold top
                    Color(0xFFF5B800), // rich golden mid
                    Color(0xFFE5A400), // deeper gold bottom
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: const Color(0xFFFFE082), // soft outer golden edge
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.amberAccent.withOpacity(0.2),
                    blurRadius: 6,
                    spreadRadius: 1,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  points, // ✅ Dynamic points
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    shadows: [
                      Shadow(
                        color: Colors.white,
                        blurRadius: 6,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => const Size.fromHeight(TSizes.appBarHeight + 120);
}
