import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/constants/text_strings.dart';

class CustomExamAppBar extends StatelessWidget {
  const CustomExamAppBar({
    super.key,
    this.textColor = Colors.white,
  });

  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            ClipOval(
              child: Image.asset(TImages.profileImage,
                  width: 60, // Adjust the width as needed
                  height: 60, // Adjust the height as needed
                  fit: BoxFit.cover),
            ),
            SizedBox(width: TSizes.md),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  GetStorage().read(TTexts.userName) ?? "----",
                  textAlign: TextAlign.start,
                  style: Theme.of(context).textTheme.titleLarge!.apply(
                        color: textColor,
                      ),
                ),
                Text(
                  GetStorage().read(TTexts.userAutoId) ?? "---",
                  textAlign: TextAlign.start,
                  style: Theme.of(context)
                      .textTheme
                      .labelLarge!
                      .apply(color: textColor),
                ),
              ],
            ),
          ],
        ),
        IconButton(
            onPressed: () {},
            icon: Icon(Icons.notifications_active,
                color: TColors.secondary, size: TSizes.iconLg))
      ],
    );
  }
}
