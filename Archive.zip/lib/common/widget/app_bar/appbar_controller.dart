import 'package:eapl_student_app/features/apptour/appbar/appbartour.dart';
import 'package:eapl_student_app/features/personalization/models/appbar_points_model.dart';
import 'package:eapl_student_app/utils/constants/path_provider.dart';
import 'package:eapl_student_app/utils/http/api_constants.dart';
import 'package:eapl_student_app/utils/http/http_client.dart';
import 'package:get_storage/get_storage.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '../../../utils/constants/text_strings.dart';

class AppbarController extends GetxController {
  var appBarPointsList = <AppBarPointsModel>[].obs;
  RxBool isLoading = false.obs;
  // 🔹 Separate reactive notifyCount for instant updates
  RxInt notifyCount = 0.obs;
  @override
  void onInit() {
    super.onInit();
    fetchPointsDetails();
  }

  Future<void> fetchPointsDetails() async {
    try {
      isLoading.value = true;

      var userid = GetStorage().read(TTexts.userID);
      print("User ID: $userid");

      var reqBody = {
        "customer_id": userid,
      };

      final response =
          await THttpHelper.post(APIConstants.appBarPointsEndPoint, reqBody);
      print("Raw Response: $response");

      if (response["data"] != null &&
          response["data"] is Map<String, dynamic>) {
        final dataMap = response["data"] as Map<String, dynamic>;
        final model = AppBarPointsModel.fromJson(dataMap);

        appBarPointsList.value = [model];

        // ✅ Update notifyCount reactively
        notifyCount.value = model.notifycount;
        appBarPointsList.value = [AppBarPointsModel.fromJson(dataMap)];
        print("✅ Points Loaded: ${appBarPointsList.first.toJson()}");
      } else {
        print("❌ Invalid or empty 'data' field");
      }

      isLoading.value = false;
    } catch (e) {
      print("❌ Exception in fetchPointsDetails(): $e");
      isLoading.value = false;
    }
  }

  // 🔹 Increment instantly when new notification comes
  void incrementNotify() {
    notifyCount.value++;
  }

  // 🔹 Reset when needed (optional)
  void resetNotify() {
    notifyCount.value = 0;
  }

  //appbar tour
  final pointsKey = GlobalKey();
  final badgeKey = GlobalKey();
  final rankKey = GlobalKey();
  final menuKey = GlobalKey();
  final profileKey = GlobalKey();
  final nameKey = GlobalKey();

  var isappbarTouron = false.obs;
  Future<void> AppbarTour(BuildContext context) async {
    final targets = AppbarTourList.getTargets(
      pointsKey: pointsKey,
      badgeKey: badgeKey,
      rankKey: rankKey,
      menuKey: menuKey,
      profileKey: profileKey,
      nameKey: nameKey,
    );

    final tutorial = TutorialCoachMark(
      targets: targets,
      colorShadow: Colors.black,
      opacityShadow: 0.9,
      textSkip: "SKIP",
      alignSkip: Alignment.topRight,
      onFinish: () async {
        print("Tutorial finished");
        await GetStorage().write(TTexts.appbartour, true);
        isappbarTouron.value = true;
      },
      onSkip: () {
        GetStorage().write(TTexts.appbartour, true);
        isappbarTouron.value = true;
        return true;
      },
      onClickTarget: (target) {
        print("Clicked on ${target.identify}");
      },
      onClickOverlay: (target) {
        print("Overlay clicked");
      },
    );

    Future.delayed(Duration(milliseconds: 600), () {
      tutorial.show(context: context);
      // Show the tutorial
    });
  }
}
