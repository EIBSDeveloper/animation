import 'package:eapl_student_app/utils/constants/text_strings.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../features/personalization/controllers/bottom_bar_controller/points_controller.dart';
import '../../../features/personalization/screens/bottom_menu/leaders-board/leaders_board.dart';
import '../../../utils/constants/path_provider.dart';
import '../images/t_circular_image.dart';
import 'appbar_controller.dart';

class ExchangeAppBar extends StatelessWidget implements PreferredSizeWidget {
  const ExchangeAppBar({super.key, this.isMenuNeed = true});

  final bool isMenuNeed;

  @override
  Widget build(BuildContext context) {
    final AppbarController controller = Get.put(AppbarController());
    final PointController = Get.put(PointsController())..fetchLeaderBoard();

    return GlassyContainer(
      borderRadius: 1,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              if (isMenuNeed)
                IconButton(
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  icon: const Icon(
                    Icons.menu,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    size: 30,
                  ),
                ),

              // Profile Image
              TCircularImage(
                padding: 1,
                image: GetStorage().read(TTexts.profileURL).isNotEmpty
                    ? GetStorage().read(TTexts.profileURL)
                    : TImages.profileImage,
                width: 50,
                height: 50,
                isNetworkImage:
                    GetStorage().read(TTexts.profileURL).isEmpty ? false : true,
              ),

              const SizedBox(width: TSizes.sm),

              // Name and ID text wrapped inside Expanded to prevent overflow
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      GetStorage().read(TTexts.userName),
                      style: GoogleFonts.prompt(
                        fontSize: 18,
                        color: TColors.white,
                        fontWeight: FontWeight.w500,
                        fontStyle: FontStyle.normal,
                        height: 1.0,
                        letterSpacing: 0.32,
                      ),
                      overflow: TextOverflow.ellipsis, // Avoid overflow in text
                    ),
                    SizedBox(
                      height: 3,
                    ),
                    Text(
                      GetStorage().read(TTexts.userAutoId),
                      style: GoogleFonts.prompt(
                        fontSize: 14,
                        color: TColors.white,
                        fontWeight: FontWeight.w400,
                        fontStyle: FontStyle.normal,
                        height: 1.0,
                        letterSpacing: 0.32,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),

              // Badge Section
              /*SizedBox(
                height: 70,
                width: 70,
                child: Stack(
                  children: [
                    Image.asset(TImages.badge),
                  ],
                ),
              ),*/
              InkWell(
                onTap: () {
                  Get.to(LeaderBoard());
                },
                child: SizedBox(
                  height: 70,
                  width: 70,
                  child: Stack(
                    children: [
                      /// Badge background
                      Positioned.fill(
                        child: Image.asset(TImages.badge),
                      ),

                      /// Rank circular badge at bottom-right
                      Positioned(
                        bottom: 4,
                        right: 6,
                        child: Obx(() {
                          final user = PointController.currentUser.value;
                          if (user == null || user.rank == null) {
                            return const SizedBox.shrink();
                          }
                          return Container(
                            height: 22,
                            width: 22,
                            decoration: const BoxDecoration(
                              color: Colors.white, // 👈 white background
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                "${user.rank}", // 👈 your LeaderModel.rank
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color:
                                      TColors.primary, // 👈 primary color text
                                ),
                              ),
                            ),
                          );
                        }),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: TSizes.sm,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, top: 15),
            child: Row(
              children: [
                Text(
                  "Exchange",
                  style: GoogleFonts.prompt(
                      color: TColors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildPointsContainer(
      BuildContext context, String imagePath, String points) {
    bool isWideScreens = THelperFunctions.screenWidth() > 600;
    final double pointsContainersWidth = 90;
    final double pointsContainersHeight = 90;

    return SizedBox(
      height: isWideScreens ? 120 : pointsContainersHeight,
      width: isWideScreens ? 120 : pointsContainersWidth,
      child: Stack(
        clipBehavior: Clip.none, // ✅ allow child to overflow safely
        alignment: Alignment.center,
        children: <Widget>[
          // ✅ Image (slightly moved down)
          Positioned(
            top: 8, // move image down
            child: Image.asset(
              imagePath,
              width: isWideScreens ? 70 : 50,
              height: isWideScreens ? 70 : 50,
              fit: BoxFit.contain,
            ),
          ),

          // ✅ Circular badge (always fully visible)
          Positioned(
            top: 0, // keep fully visible inside parent
            right: 7,
            child: Container(
              height: 25,
              width: 25,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  points,
                  style: GoogleFonts.prompt(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    fontStyle: FontStyle.normal,
                    height: 1.0,
                    letterSpacing: 0.32,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => Size.fromHeight(TSizes.appBarHeight + 80);
}
