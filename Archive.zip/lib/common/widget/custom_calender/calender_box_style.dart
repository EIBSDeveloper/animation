import '../../../utils/constants/path_provider.dart';

class CalenderBoxStyle extends StatelessWidget {
  const CalenderBoxStyle({
    super.key,
    required this.date,
    required this.message,
    required this.backgroundColor,
    this.textColor,
    required this.onTap,
  });

  final DateTime date;
  final String message;
  final Color backgroundColor;
  final Color? textColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Tooltip(
        message: message,
        child: Card(
          margin: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 10.0),
          child: Container(
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: backgroundColor,
              shape: BoxShape.rectangle,
            ),
            child: Text(
              '${date.day}',
              style: TextStyle(color: textColor ?? Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}
