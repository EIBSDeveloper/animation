import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:itracker/src/app/utils/notificationservice.dart';
import 'package:itracker/src/core/app_text_theme.dart';

import 'app.dart';
import 'src/app/bindings/app_binding.dart';
import 'src/app/utils/routes/app_pages.dart';
import 'src/app/widgets/contect_popup.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await NotificationService.initialize();

  AppBinding().dependencies();
  await Hive.openBox('tagsBox');
  runApp(const MyApp());

  FlutterOverlayWindow.overlayListener.listen((event) {
    print("DATA FROM OVERLAY: $event");

    if (navigatorKey.currentState != null) {
      navigatorKey.currentState!.pushNamed(
        RouteNames.leadsDetails,
        arguments: event,  
      );
    }
  });
}

@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MaterialApp(
      theme: ThemeData(textTheme: AppTextTheme.style),
      debugShowCheckedModeBanner: false,
      home: const ContactPopup(),
    ),
  );
}
