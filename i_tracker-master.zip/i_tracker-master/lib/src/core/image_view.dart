import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ImageView extends StatelessWidget {
  const ImageView(
    this.icon, {
    super.key,

    this.width,
    this.height,
    this.color,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String icon;
  final double? width;
  final double? height;
  final Color? color;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  bool _isNetworkImage(String url) =>
      url.startsWith('http://') || url.startsWith('https://');

  bool _isAssetImage(String path) =>
      !path.startsWith('/') && !path.startsWith('http');

  bool _isLocalFile(String path) => File(path).existsSync();

  bool _isSvg(String path) => path.toLowerCase().endsWith('.svg');

  @override
  Widget build(BuildContext context) {
    if (_isSvg(icon)) {
      // ✅ Handle SVG Images
      if (_isNetworkImage(icon)) {
        return SvgPicture.network(
          icon,
          width: width,
          height: height,
          colorFilter:
              color != null ? ColorFilter.mode(color!, BlendMode.srcIn) : null,
          placeholderBuilder:
              (context) =>
                  placeholder ??
                  const Center(child: CircularProgressIndicator()),
        );
      } else if (_isAssetImage(icon)) {
        return SvgPicture.asset(
          icon,
          width: width,
          height: height,
          colorFilter:
              color != null ? ColorFilter.mode(color!, BlendMode.srcIn) : null,
        );
      } else if (_isLocalFile(icon)) {
        return SvgPicture.file(
          File(icon),
          width: width,
          height: height,
          colorFilter:
              color != null ? ColorFilter.mode(color!, BlendMode.srcIn) : null,
        );
      }
    } else {
      // ✅ Handle Raster Images (PNG, JPG, JPEG, WEBP, etc.)
      if (_isNetworkImage(icon)) {
        return CachedNetworkImage(
          imageUrl: icon,
          width: width,
          height: height,
          fit: fit,
          color: color,
          placeholder:
              (context, url) =>
                  placeholder ??
                  const Center(child: CircularProgressIndicator()),
          errorWidget:
              (context, url, error) =>
                  errorWidget ??
                  const Icon(Icons.broken_image, color: Colors.grey),
        );
      } else if (_isAssetImage(icon)) {
        return Image.asset(
          icon,
          width: width,
          height: height,
          fit: fit,
          color: color,
          errorBuilder:
              (context, error, stackTrace) =>
                  errorWidget ??
                  const Icon(Icons.broken_image, color: Colors.grey),
        );
      } else if (_isLocalFile(icon)) {
        return Image.file(
          File(icon),
          width: width,
          height: height,
          fit: fit,
          color: color,
          errorBuilder:
              (context, error, stackTrace) =>
                  errorWidget ??
                  const Icon(Icons.broken_image, color: Colors.grey),
        );
      }
    }

    // Default fallback if nothing matches
    return errorWidget ?? const Icon(Icons.broken_image, color: Colors.grey);
  }
}
