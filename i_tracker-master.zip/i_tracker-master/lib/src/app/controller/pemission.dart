// import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';

Future<void> requestPermissions() async {
  await [
    Permission.phone,
    Permission.contacts,

    Permission.systemAlertWindow,
  ].request();
  // if (!await FlutterOverlayWindow.isPermissionGranted()) {
  //   await FlutterOverlayWindow.requestPermission();
  // }
}
