
import 'package:flutter/material.dart';
import 'package:itracker/src/core/app_colors.dart';

import '../../core/app_style.dart';

class InputCardStyle extends StatelessWidget {
  final Widget child;
  final bool noHeight;
  final EdgeInsetsGeometry? padding;
  const InputCardStyle({
    super.key,
    this.noHeight = false,
    required this.child,
    this.padding,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: AppStyle.decoration.copyWith(
      boxShadow: [],
      border: Border.all(color: AppColors.draft.withAlpha(100,),width: 0.5)
    ),
    padding: padding ?? const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
    constraints: noHeight
        ? null
        : const BoxConstraints(
            minHeight: 40, 
          ),
    child: child,
  );
}
