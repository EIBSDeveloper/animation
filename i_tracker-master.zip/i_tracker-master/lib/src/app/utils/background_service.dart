// import 'dart:async';
// import 'dart:ui';

// import 'package:flutter_background_service/flutter_background_service.dart';

// Future<void> initializeService() async {
//   final service = FlutterBackgroundService();

//   await service.configure(
//     androidConfiguration: AndroidConfiguration(
//       onStart: onStart,
//       autoStart: true,
//       autoStartOnBoot: true,
//       isForegroundMode: true,
//       notificationChannelId: 'background_service',
//       initialNotificationTitle: 'My Background Service',
//       initialNotificationContent: 'Running background tasks...',
//       foregroundServiceNotificationId: 999,
//     ),
//     iosConfiguration: IosConfiguration(),
//   );

//   service.startService();
// }

// @pragma('vm:entry-point')
// void onStart(ServiceInstance service) async {
//   DartPluginRegistrant.ensureInitialized();

//   if (service is AndroidServiceInstance) {
//     service.on('stopService').listen((event) {
//       service.stopSelf();
//     });
//   }

//   Timer.periodic(const Duration(minutes: 15), (timer) async {
//     final now = DateTime.now().toIso8601String();

//     if (service is AndroidServiceInstance) {
//       service.setForegroundNotificationInfo(
//         title: 'Background Service Active',
//         content: 'Last updated: $now',
//       );
//     }
//   });
// }
