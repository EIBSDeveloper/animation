class RouteNames {
  static const splash = '/'; 
 
  static const home = '/home';
  static const permission  = '/permission' ;
  static const leadsDetails = '/leads-details';
  static const onboarding = '/onboarding';
  static const dialPad = '/dialPad'; 
  static const notification = '/notification';  
  static const profile = '/profile'; 
  static const addSchedule = '/add-schedule';
  static const active = '/active';
  static const incoming = '/incoming';
  static const addLead = '/add-lead';
}
