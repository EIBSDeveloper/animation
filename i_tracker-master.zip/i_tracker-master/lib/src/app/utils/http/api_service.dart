import 'package:dio/dio.dart';
import 'package:get/get.dart' hide Response;

import '../../controller/app_controller.dart';

final AppDataController appDeta = Get.find();

class ApiService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: appDeta.baseUrl.string, // change
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {"Content-Type": "application/json"},
    ),
  );
  // GET
  Future<Response> getData(
    String endpoint, {
    Map<String, dynamic>? query,
  }) async {
    try {
      return await _dio.get(endpoint, queryParameters: query);
    } catch (e) {
      rethrow;
    }
  }

  // POST
  Future<Response> postData(
    String endpoint,
    Map<String, dynamic> data, {
    Map<String, dynamic>? query,
  }) async {
    try {
      return await _dio.post(endpoint, data: data, queryParameters: query);
    } catch (e) {
      rethrow;
    }
  }

  // PUT
  Future<Response> putData(
    String endpoint,
    Map<String, dynamic> data, {
    Map<String, dynamic>? query,
  }) async {
    try {
      return await _dio.put(endpoint, data: data, queryParameters: query);
    } catch (e) {
      rethrow;
    }
  }
}
