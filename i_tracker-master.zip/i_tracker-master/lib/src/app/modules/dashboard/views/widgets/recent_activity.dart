 
import 'package:flutter/material.dart';
 
import 'package:itracker/src/core/app_style.dart';

import '../../../../../core/app_colors.dart';

class RecentActivityItem extends StatelessWidget {
  final String name;
  final String subtitle;
  final String time;
  final String icon;
  final String colorName;
  const RecentActivityItem({
    super.key,
    required this.name,
    required this.subtitle,
    required this.time,
    required this.icon,
    required this.colorName,
  });

  Color _colorForName(String name) {
    switch (name) {
      case 'primary':
        return AppColors.primary;
      case 'secondary':
        return AppColors.secondary;
      case 'tertiary':
        return AppColors.tertiary;
      case 'danger':
        return AppColors.danger;
      default:
        return AppColors.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final bodyMedium = Theme.of(context).textTheme.bodyMedium!;
    final bodySmall = Theme.of(context).textTheme.bodySmall!;
    final c = _colorForName(colorName);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(10),
      decoration: AppStyle.decoration,
      child: Row(
        children: [
          Container(
            height: 44,
            width: 44,
            decoration: BoxDecoration(
              color: c.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(_mapIcon(icon), color: c),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: bodyMedium.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: bodySmall.copyWith(color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          Text(time, style: bodySmall.copyWith(color: AppColors.textSecondary)),
        ],
      ),
    );
  }

  IconData _mapIcon(String name) {
    switch (name) {
      case 'call_made':
        return Icons.call_made;
      case 'call_received':
        return Icons.call_received;
      case 'call_missed':
        return Icons.call_missed;
      default:
        return Icons.call;
    }
  }
}
