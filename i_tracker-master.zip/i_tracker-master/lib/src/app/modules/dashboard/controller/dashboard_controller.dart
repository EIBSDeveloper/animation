// lib/modules/dashboard/controller/dashboard_controller.dart
import 'package:get/get.dart';

class DashboardController extends GetxController {
  // counts (animated)
  final outgoing = 124.obs;
  final incoming = 82.obs;
  final missed = 12.obs;
  final rejected = 5.obs;
  final calls = "5/10".obs;

  // total calls number (for center donut)
  final totalCalls = 218.obs;

  // weekly data (0..1 relative heights)
  final weeklyData = <double>[0.6, 0.8, 0.5, 0.9, 1.0, 0.4, 0.2].obs;

  // percent change
  final percentChange = 5.2.obs;

  // recent activity list
  final recent = <Map<String, String>>[
    {
      'name': 'Johnathan Doe',
      'type': 'Outgoing Call',
      'time': '10:45 AM',
      'icon': 'call_made',
      'color': 'primary',
    },
    {
      'name': 'Jane Smith',
      'type': 'Incoming Call',
      'time': '10:32 AM',
      'icon': 'call_received',
      'color': 'secondary',
    },
    {
      'name': 'Michael Johnson',
      'type': 'Missed Call',
      'time': '9:58 AM',
      'icon': 'call_missed',
      'color': 'tertiary',
    },
  ].obs;

  // For demo — you could update values to see animations
  void simulateUpdate() {
    outgoing.value += 3;
    incoming.value += 2;
    missed.value += 1;
    rejected.value += 0;
    totalCalls.value =
        outgoing.value + incoming.value + missed.value + rejected.value;
  }
}
