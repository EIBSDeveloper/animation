import 'package:flutter/material.dart';

import '../../../../../core/app_style.dart';

class TagCard extends StatelessWidget {
  const TagCard({
    super.key,
    required this.color,
    required this.lable,
    this.onTap,
    this.icon,
  });
  final void Function()? onTap;
  final MaterialColor color;
  final String lable;
  final IconData? icon;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Container(
    
      decoration: AppStyle.decoration.copyWith(
        borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
        boxShadow: [
    // BoxShadow(
    //   color: Color.fromRGBO(0, 0, 0, 0.15),
    //   blurRadius: 15,
    //   spreadRadius: 0,
    //   offset: Offset(0, 5),
    // )
  ]
      ),
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 2), 
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 3),
         decoration:  BoxDecoration( 
          
          
           color: (lable.isNotEmpty) ? color.withAlpha(60) : Colors.transparent,
        borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
      ),
      
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null)
              Icon(icon, color: color, size: AppStyle.iconSize2),

            if (lable.isNotEmpty) ...[
              const SizedBox(width: 3),
              Flexible(
                child: Text(
                  lable,
                  style: Theme.of(context).textTheme.bodySmall!.copyWith(
                    color: color,fontWeight: FontWeight.w600,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    ),
  );
}
