import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../app.dart';
import '../../../../../../core/models/call_log_entry.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../widgets/widget_gap.dart';
import '../../../payment_tracker/view/screens/customerscreen.dart';
import '../../controller/call_logcontroller.dart';
import '../../model/call.dart';
import '../widgets/call_card.dart';

class CallLogsScreen extends GetView<CallLogsController> {
  const CallLogsScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,

    floatingActionButton: FloatingActionButton(
      onPressed: () {
        Navigator.pushNamed(context, RouteNames.dialPad);
      },
      backgroundColor: AppColors.primary,
      child: const Icon(Icons.dialpad, color: Colors.white, size: 28),
    ),
    body: RefreshIndicator(
      onRefresh: () async {
        controller.loadAvailableAgents();
      },
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const AppSearchBar(),
            const WidgetGap(),
            _filterChips(controller),
            Obx(() {
              if (controller.isLogLoad.value) {
                return const Center(child: CircularProgressIndicator());
              }

              if (controller.callLogsByDate.isEmpty) {
                return Center(
                  child: ElevatedButton(
                    onPressed: () {
                      controller.loadAvailableAgents();
                    },
                    child: const Text("Load data "),
                  ),
                );
              }

              return Expanded(
                // keep this if parent is Column
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: controller.callLogsByDate.entries.map((entry) {
                      String date = entry.key;
                      List<CallLog> logs = entry.value;

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              date,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),

                          // logs
                          ...logs.map((callLog) => CallCard(
                              call: callLog,
                              isExpended:
                                  controller.isExpended.value == callLog.id,
                              onTop: () {
                                if (controller.isExpended.value == callLog.id) {
                                  controller.isExpended.value = 0;
                                } else {
                                  controller.isExpended.value = callLog.id;
                                }
                              },
                            )).toList(),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    ),
  );

  Widget _filterChips(CallLogsController controller) => Obx(
    () => SizedBox(
      height: 43,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.only(bottom: 8, right: 10, left: 10),

        children: [
          _chip(controller, "All", CallType.all, AppColors.primary, 20),
          _chip(
            controller,
            "Incoming",
            CallType.incoming,
            AppColors.secondary,
            10,
            Icons.south_west,
          ),
          _chip(
            controller,
            "Outgoing",
            CallType.outgoing,
            AppColors.primary,
            3,
            Icons.north_east,
          ),
          _chip(
            controller,
            "Missed",
            CallType.missed,
            AppColors.danger,
            4,
            Icons.call_missed,
          ),
          _chip(
            controller,
            "Not Answer",
            CallType.missed,
            AppColors.danger,
            3,
            Icons.call_missed,
          ),
        ],
      ),
    ),
  );

  Widget _chip(
    CallLogsController controller,
    String label,
    CallType type,
    Color color,
    int count, [
    IconData? icon,
  ]) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;
    final bool active = controller.selectedFilter.value == type;
    return GestureDetector(
      onTap: () => controller.changeFilter(type),
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: AppStyle.decoration.copyWith(
          color: active ? AppColors.primary : AppColors.card,
          borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
        ),
        child: Row(
          children: [
            if (icon != null)
              Icon(icon, color: active ? Colors.white : color, size: 18),
            if (icon != null) const SizedBox(width: 6),
            Text(
              label,
              style: theme.bodyMedium?.copyWith(
                color: active ? Colors.white : AppColors.textPrimary,
              ),
            ),
            // const SizedBox(width: 2),
            // Text(
            //   "($count)",
            //   style: theme.bodyMedium?.copyWith(
            //     fontWeight: FontWeight.w600,
            //     color: active ? Colors.white : AppColors.textPrimary,
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 5, 16, 8),
    child: Text(
      title,
      style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium!
          .copyWith(fontWeight: FontWeight.bold, color: AppColors.textPrimary),
    ),
  );
}
