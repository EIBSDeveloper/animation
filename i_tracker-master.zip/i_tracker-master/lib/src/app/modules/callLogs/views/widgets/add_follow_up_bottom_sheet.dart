import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';
import 'package:lottie/lottie.dart';

import '../../../../../../app.dart';
import '../../../../../../bottom_sheet.dart';
import '../../../../utils/notificationservice.dart';
import '../../controller/followup_add_controller.dart';

class AddFollowUpBottomSheet extends GetView<FollowUpAddController> {
  const AddFollowUpBottomSheet({super.key});

  @override
  Widget build(BuildContext context) => Obx(
    () => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10),
          _buildHeader(),
          const SizedBox(height: 8),
          _buildTabs(),
          const SizedBox(height: 8),

          if (controller.selectedTab.value == 'Add Notes')
            _buildAddNotesSection()
          else ...[
            _buildWhenSection(),
            const SizedBox(height: 8),
            if (controller.selectedWhenOption.value == 'Custom') ...[
              _buildDateSection(context),
              const SizedBox(height: 8),
              _buildTimeSection(context),
            ],
            const SizedBox(height: 8),
            _buildreminderBoxSection(),
            const SizedBox(height: 8),
            _buildActionButtons(),
            const SizedBox(height: 16),
            _buildPreviousReminders(),
          ],
          const SizedBox(height: 30),
        ],
      ),
    ),
  );

  // HEADER
  Widget _buildHeader() => Center(
    child: Container(
      width: 60,
      height: 4,
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(4),
      ),
    ),
  );

  // TABS
  Widget _buildTabs() => Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
      _buildTab(Icons.note_add, 'Add Notes'),
      _buildTab(Icons.alarm, 'Reminder'),
    ],
  );

  Widget _buildTab(IconData icon, String label) => GestureDetector(
    onTap: () => controller.selectedTab.value = label,
    child: Obx(() {
      final isSelected = controller.selectedTab.value == label;
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 20,
                color: isSelected
                    ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                    : Colors.grey,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: Theme.of(navigatorKey.currentContext!)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: isSelected
                          ? Theme.of(
                              navigatorKey.currentContext!,
                            ).colorScheme.primary
                          : Colors.grey,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            height: 2,
            width: 80,
            color: isSelected
                ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                : Colors.transparent,
          ),
        ],
      );
    }),
  );

  // ADD NOTES
  Widget _buildAddNotesSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Note',
        style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]),
      ),
      const SizedBox(height: 7),
      TextField(
        maxLines: 5,
        onChanged: (val) => controller.noteDescription.value = val,
        decoration: InputDecoration(
          hintText: 'Type your note here...',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
              width: 1.5,
            ),
          ),
        ),
      ),
      const SizedBox(height: 24),
      SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            backgroundColor: Theme.of(
              navigatorKey.currentContext!,
            ).primaryColor,
            padding: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'SAVE',
            style: Theme.of(
              navigatorKey.currentContext!,
            ).textTheme.bodyMedium?.copyWith(color: Colors.white),
          ),
        ),
      ),
    ],
  );
  // ADD NOTES
  Widget _buildreminderBoxSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Remarks',
        style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]),
      ),
      const SizedBox(height: 8),
      TextField(
        maxLines: 3,
        onChanged: (val) => controller.noteDescription.value = val,
        decoration: InputDecoration(
          hintText: 'Ender Remarks',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
              width: 1.5,
            ),
          ),
        ),
      ),
    ],
  );

  // WHEN / DATE / TIME / OPTIONS
  Widget _buildWhenSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(
            Icons.timelapse,
            color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
          ),
          const SizedBox(width: 6),
          Text('WHEN?', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('2 sec', controller.selectedWhenOption),
          _buildOption('15 min', controller.selectedWhenOption),
          _buildOption('30 min', controller.selectedWhenOption),
          _buildOption('1 hour', controller.selectedWhenOption),
          _buildOption('2 hours', controller.selectedWhenOption),
          _buildCustomOption('Custom', controller.selectedWhenOption),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  Widget _buildDateSection(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(
            Icons.calendar_today,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 6),
          Text('DATE', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('Today', controller.selectedDateOption),
          _buildOption('Tomorrow', controller.selectedDateOption),
          _buildOption('In 7 days', controller.selectedDateOption),
          GestureDetector(
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime(2100),
              );
              if (picked != null) {
                controller.selectedCustomDate.value = DateFormat(
                  'MMM dd, yyyy',
                ).format(picked);
              }
            },
            child: Obx(() {
              final hasDate = controller.selectedCustomDate.isNotEmpty;
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: hasDate
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black87,
                  ),
                ),
                child: Text(
                  hasDate ? controller.selectedCustomDate.value : 'Select date',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: hasDate
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black,
                  ),
                ),
              );
            }),
          ),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  Widget _buildTimeSection(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(Icons.access_time, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 6),
          Text('TIME', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('Morning 5 am', controller.selectedTimeOption),
          _buildOption('Afternoon 1 pm', controller.selectedTimeOption),
          _buildOption('Evening 5 pm', controller.selectedTimeOption),
          _buildOption('Night 8 pm', controller.selectedTimeOption),
          GestureDetector(
            onTap: () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (picked != null) {
                controller.selectedCustomTime.value = picked.format(
                  Get.context!,
                );
              }
            },
            child: Obx(() {
              final hasTime = controller.selectedCustomTime.isNotEmpty;
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: hasTime
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black87,
                  ),
                ),
                child: Text(
                  hasTime ? controller.selectedCustomTime.value : 'Select time',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: hasTime
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black,
                  ),
                ),
              );
            }),
          ),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  Widget _buildOption(String text, RxString selected) => Obx(() {
    final isSelected = selected.value == text;
    return GestureDetector(
      onTap: () => selected.value = text,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
              : Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: isSelected
                ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                : Colors.black87,
          ),
        ),
        child: Text(
          text,
          style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
              ?.copyWith(
                color: isSelected ? Colors.white : Colors.black,
                fontWeight: FontWeight.w500,
              ),
        ),
      ),
    );
  });

  Widget _buildCustomOption(String text, RxString selected) => Obx(() {
    final isSelected = selected.value == text;
    return GestureDetector(
      onTap: () => selected.value = text,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: isSelected
                ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                : Colors.black87,
          ),
        ),
        child: Text(
          text,
          style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
              ?.copyWith(
                color: isSelected
                    ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                    : Colors.black,
                fontWeight: FontWeight.w500,
              ),
        ),
      ),
    );
  });

  Widget _buildActionButtons() => Row(
    children: [
      Expanded(
        child: OutlinedButton(
          onPressed: Get.back,
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'CANCEL',
            style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium,
          ),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: ElevatedButton(
          onPressed: () => controller.submitReminder(),
          /*   onPressed: () {
            Navigator.pop(navigatorKey.currentContext!);

            Future.delayed(const Duration(milliseconds: 200), () {
              InAppReminderDialog.showTestDialog(
                navigatorKey.currentContext!,
                "Testing Reminder Dialog UI",
              );
            });
          },*/
          style: ElevatedButton.styleFrom(
            backgroundColor: Theme.of(
              navigatorKey.currentContext!,
            ).primaryColor,
            padding: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'SAVE',
            style: Theme.of(
              navigatorKey.currentContext!,
            ).textTheme.bodyMedium?.copyWith(color: Colors.white),
          ),
        ),
      ),
    ],
  );

  Widget _buildPreviousReminders() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Previous reminders',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
            ),
          ),
          GestureDetector(
            onTap: () {},
            child: Text(
              'VIEW ALL',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Theme.of(
                  navigatorKey.currentContext!,
                ).colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildReminderItem(
        'Reminder to explore Superfone trial',
        'Nov 09, 2025, 09:45 am',
      ),
      const SizedBox(height: 16),
      _buildReminderItem('Remind me!', 'Nov 08, 2025, 09:50 am'),
    ],
  );

  Widget _buildReminderItem(String title, String date) => Container(
    padding: const EdgeInsets.all(16),
    width: double.infinity,
    decoration: AppStyle.decoration,
    child: Row(
      children: [
        Container(
          width: 6,
          height: 60,
          decoration: BoxDecoration(
            color: Colors.green,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(
                navigatorKey.currentContext!,
              ).textTheme.bodyMedium,
            ),

            Text(
              date,
              style: Theme.of(navigatorKey.currentContext!).textTheme.bodySmall!
                  .copyWith(color: Colors.grey[600], fontSize: 12),
            ),
          ],
        ),
      ],
    ),
  );

  TextStyle get sectionTitleStyle =>
      TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]);
}

Future<void> openAddFollowUpBottomSheet() async {
  Get.lazyPut(() => FollowUpAddController());
  await openButtomsheet(const AddFollowUpBottomSheet());
}

class InAppReminderDialog {
  // <-- Make sure this is present
  static Timer? _timer;

  /// Schedule a local popup with [remarks] shown when the popup appears.
  static void schedule(
    BuildContext context,
    DateTime time,
    String remarks,
    Map<String, dynamic>? call,
  ) {
    final diff = time.difference(DateTime.now());
    if (diff.isNegative) return;

    // Cancel previous timer so only the latest reminder fires
    _timer?.cancel();
    _timer = Timer(diff, () {
      _showBeautifulDialog(context, remarks, call);
    });
  }

  // Internal dialog that shows the remarks and snooze options
  /*  static void _showBeautifulDialog(BuildContext context, String remarks) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          backgroundColor: AppColors.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
          ),
          child: Container(
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Lottie.asset(
                  "assets/AlarmClock.json",
                  height: 120,
                  repeat: true,
                ),
                Text(
                  "Reminder Alert!",
                  style: Theme.of(navigatorKey.currentContext!)
                      .textTheme
                      .titleLarge
                      ?.copyWith(
                        color: AppColors.textDark,
                        fontWeight: FontWeight.bold,
                      ),
                ),

                const SizedBox(height: 8),

                Text(
                  remarks.isNotEmpty ? remarks : "You have a reminder.",
                  textAlign: TextAlign.center,
                  style: Theme.of(navigatorKey.currentContext!)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w400,
                      ),
                ),

                const SizedBox(height: 10),

                Wrap(
                  spacing: 12,
                  children: [
                    _snoozeButton(context, 5, remarks),
                    _snoozeButton(context, 10, remarks),
                    _snoozeButton(context, 15, remarks),
                  ],
                ),

                const SizedBox(height: 10),

                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _timer?.cancel();
                    _timer = null;
                  },
                  child: Text(
                    "Dismiss",
                    style: Theme.of(navigatorKey.currentContext!)
                        .textTheme
                        .bodyMedium
                        ?.copyWith(
                          color: AppColors.danger,
                          fontWeight: FontWeight.w400,
                        ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }*/
  static void _showBeautifulDialog(
    BuildContext context,
    String remarks,
    Map<String, dynamic>? call,
  ) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          backgroundColor: AppColors.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
          ),
          child: Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Lottie.asset(
                  "assets/AlarmClock.json",
                  height: 120,
                  repeat: true,
                ),

                const SizedBox(height: 10),

                Text(
                  "Reminder Alert!",
                  style: Theme.of(navigatorKey.currentContext!)
                      .textTheme
                      .titleLarge
                      ?.copyWith(
                        color: AppColors.textDark,
                        fontWeight: FontWeight.bold,
                      ),
                ),

                const SizedBox(height: 12),

                // User info row
                if (call != null)
                  Row(
                    children: [
                      // Name + Number
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              call['name'],
                              style: Theme.of(context).textTheme.bodyLarge
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textDark,
                                  ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              call['number'],
                              style: Theme.of(context).textTheme.bodyMedium
                                  ?.copyWith(color: AppColors.textPrimary),
                            ),
                          ],
                        ),
                      ),
                      // Call Icon
                      Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withAlpha(20),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppColors.primary.withAlpha(100),
                          ),
                        ),
                        child: Icon(
                          Icons.call,
                          color: AppColors.primary,
                          size: AppStyle.iconSize,
                        ),
                      ),
                    ],
                  ),

                const SizedBox(height: 10),

                // Remarks text
                Text(
                  remarks.isNotEmpty ? remarks : "You have a reminder.",
                  textAlign: TextAlign.center,
                  style: Theme.of(navigatorKey.currentContext!)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w400,
                      ),
                ),

                const SizedBox(height: 10),

                Wrap(
                  spacing: 12,
                  children: [
                    _snoozeButton(context, 5, remarks, call!),
                    _snoozeButton(context, 10, remarks, call),
                    _snoozeButton(context, 15, remarks, call!),
                  ],
                ),

                const SizedBox(height: 10),

                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _timer?.cancel();
                    _timer = null;
                  },
                  child: Text(
                    "Dismiss",
                    style: Theme.of(navigatorKey.currentContext!)
                        .textTheme
                        .bodyMedium
                        ?.copyWith(
                          color: AppColors.danger,
                          fontWeight: FontWeight.w400,
                        ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /*  static void showTestDialog(BuildContext context, String remarks) {
    _showBeautifulDialog(context, remarks);
  }*/

  // Snooze button that schedules the same remarks again
  static Widget _snoozeButton(
    BuildContext context,
    int minutes,
    String remarks,
    Map<String, dynamic> call, // ✅ pass call
  ) {
    return GestureDetector(
      onTap: () {
        final newTime = DateTime.now().add(Duration(minutes: minutes));

        // Schedule system notification
        NotificationService.scheduleNotification(
          1,
          "Reminder",
          remarks.isNotEmpty ? remarks : "Snoozed reminder",
          newTime,
        );

        // Schedule in-app popup again
        schedule(context, newTime, remarks, call);

        Navigator.pop(context);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: AppColors.textPrimary),
        ),
        child: Text(
          "$minutes min",
          style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
              ?.copyWith(
                color: AppColors.textDark,
                fontWeight: FontWeight.w500,
              ),
        ),
      ),
    );
  }
}
