


 

 
class FollowUpModel {
 
  final String id;
  
 
  final String leadId;
  
 
  final DateTime followUpDate;
 
  final String reason;
  
 
  final String status; // Scheduled, Completed, Cancelled, Postponed
 
  final String notes;
 
  final DateTime createdAt;

  FollowUpModel({
    required this.id,
    required this.leadId,
    required this.followUpDate,
    required this.reason,
    required this.status,
    required this.notes,
    required this.createdAt,
  });FollowUpModel copyWith({
    String? id,
    String? leadId,
    DateTime? followUpDate,
    String? reason,
    String? status,
    String? notes,
    DateTime? createdAt,
  }) => FollowUpModel(
      id: id ?? this.id,
      leadId: leadId ?? this.leadId,
      followUpDate: followUpDate ?? this.followUpDate,
      reason: reason ?? this.reason,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );

}