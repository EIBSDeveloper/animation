 
import '../model/model.dart';

class FollowUpRepository {
  
  // Mock API call since backend not developed
  Future<FollowUpResponse> addFollowUp(FollowUp followUp) async {
    // Simulate API delay
    await Future.delayed(const Duration(seconds: 1));
    
    try {
      // Mock successful response - simulate what the API would return
      final mockResponse = {
        'status': true,
        'message': 'Follow up added successfully',
        'data': {
          'id': 'follow_up_${DateTime.now().millisecondsSinceEpoch}',
          'date': followUp.toJson()['date'],
          'time': followUp.toJson()['time'],
          'reason': followUp.reason,
          'notes': followUp.notes,
          'created_at': DateTime.now().toIso8601String(),
        }
      };
      
      return FollowUpResponse.fromJson(mockResponse);
    } catch (e) {
      return FollowUpResponse(
        status: false,
        message: 'Failed to add follow up: $e',
        data: null,
      );
    }
  }

  // Validation method
  Map<String, String?> validateFollowUp(FollowUp followUp) {
    final errors = <String, String?>{};

    if (followUp.reason.isEmpty) {
      errors['reason'] = 'Reason is required';
    } else if (followUp.reason.length < 2) {
      errors['reason'] = 'Reason must be at least 2 characters';
    } else if (followUp.reason.length > 100) {
      errors['reason'] = 'Reason must be less than 100 characters';
    }

    if (followUp.notes != null && followUp.notes!.length > 250) {
      errors['notes'] = 'Notes must be less than 250 characters';
    }

    return errors;
  }
}