 

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/models/call_log_entry.dart';

import '../../../utils/http/api_service.dart';
import '../model/call.dart';
import '../model/client_model.dart';
import '../repository/client_repository.dart';

class CallLogsController extends GetxController {
  RxInt isExpended = 0.obs;
  final api = ApiService();
  final ClientRepository repository = Get.find();
  RxMap callLogsByDate = {}.obs;
  RxBool isLogLoad = false.obs;
  var selectedFilter = CallType.all.obs;
  final RxList<CallLog> callLog = <CallLog>[].obs;

  final selectedAgent = Rxn<AgentModel>();
  final reasonTextController = TextEditingController();
  final selectedcallStatus = ''.obs;
  final selectedleadStatus = ''.obs;
  void changeFilter(CallType filter) {
    selectedFilter.value = filter;
  }

  @override
  void onInit() {
    super.onInit();

    loadAvailableAgents();
    update();
  }

  Future<void> loadAvailableAgents() async {
    try {
      callLogsByDate.clear();
      isLogLoad(true);
      final CallResponse response = await getCallLogs();

      response.data.forEach((date, logs) {
        callLogsByDate[date] = (logs as List)
            .map((ee) => CallLog.fromJson(ee))
            .toList();
      });
    } finally {
      isLogLoad(false);
    }
  }

  Future<CallResponse> getCallLogs() async {
    try {
      final response = await api.getData("/call/staff/1");

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = response.data;
        return CallResponse.fromJson(data);
      } else {
        throw Exception('Failed to load call logs: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to load call logs: $e');
    }
  }

  void onSnooze(String value) {}

  void onCustom() {}

  // Show/hide custom fields
  var showCustomFields = false.obs;

  // Store the selected date and time
  var customDateTime = Rxn<DateTime>();

  void toggleCustomFields() {
    showCustomFields.value = !showCustomFields.value;
  }
}
