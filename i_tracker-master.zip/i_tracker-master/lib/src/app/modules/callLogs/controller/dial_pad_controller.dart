import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';

import '../../../../../app.dart';
import '../../../../../core/call_service.dart';
import '../../../../../pages/active_call_screen.dart';
import '../../../utils/routes/app_pages.dart';

class DialPadController extends GetxController {
  var typedNumber = ''.obs;

  // Dummy contact list
  final contacts = [
    {"name": "Kumar", "number": "9876543210"},
    {"name": "Sumar", "number": "9143552671"},
    {"name": "Rumar", "number": "9876501234"},
    {"name": "Dumar", "number": "9643552671"},
  ];
  var isPressed = ''.obs;
  // Filter related numbers
  List<Map<String, String>> get filteredContacts {
    if (typedNumber.isEmpty) return [];
    return contacts.where((c) => c["number"]!.contains(typedNumber)).toList();
  }

  void addDigit(String d) {
    typedNumber.value += d;
  }

  void removeDigit() {
    if (typedNumber.isNotEmpty) {
      typedNumber.value = typedNumber.value.substring(
        0,
        typedNumber.value.length - 1,
      );
    }
  }

  Future<void> makeCall() async {
    if (typedNumber.value.isEmpty) return;

    debugPrint('Initiate call for ${typedNumber.value}');

    try {
      // Use CallService to make call (integrates with our dialer system)
      final bool success = await CallService.makeCall(typedNumber.value);

      if (success) {
        // Navigate to active call screen for UI

        navigatorKey.currentState?.pushNamedAndRemoveUntil(
          RouteNames.active,
          (Route<dynamic> route) => route.settings.name == RouteNames.home,
          arguments: ActiveCallArguments(
            number: typedNumber.value,
            caller: null,
            isDialing: true,
          ),
        );
      } else {
        throw Exception('Call method returned false');
      }
    } on PlatformException catch (e) {
      debugPrint('Platform exception making call: ${e.message}');

      // Fallback to direct caller
      try {
        await FlutterPhoneDirectCaller.callNumber(typedNumber.value);
      } catch (fallbackError) {
        debugPrint('Fallback call also failed: $fallbackError');
        // if (mounted) {
        ScaffoldMessenger.of(navigatorKey.currentContext!).showSnackBar(
          SnackBar(
            content: Text('Failed to make call: ${e.message}'),
            backgroundColor: Colors.red,
          ),
        );
        // }
      }
    } catch (e) {
      debugPrint('Error making call: $e');

      // if (mounted) {
      ScaffoldMessenger.of(navigatorKey.currentContext!).showSnackBar(
        SnackBar(
          content: Text('Failed to make call: $e'),
          backgroundColor: Colors.red,
        ),
      );
      // }
    }
  }
}
