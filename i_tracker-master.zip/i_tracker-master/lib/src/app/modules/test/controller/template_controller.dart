// import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../../../../../app.dart';
import '../model/template_model.dart';

class TemplateController extends GetxController {
  final TemplateRepository _repository = TemplateRepository();
  
  final RxList<TemplateModel> _templates = <TemplateModel>[].obs;
  final RxList<TemplateModel> _filteredTemplates = <TemplateModel>[].obs;
  final RxString _searchQuery = ''.obs;
  final RxBool _isLoading = false.obs;
  final RxBool _isSearching = false.obs;

  List<TemplateModel> get templates => _templates.toList();
  List<TemplateModel> get filteredTemplates => _filteredTemplates.toList();
  bool get isLoading => _isLoading.value;
  bool get isSearching => _isSearching.value;

  @override
  void onInit() {
    super.onInit();
    loadTemplates();
  }

  Future<void> loadTemplates() async {
    try {
      _isLoading.value = true;
      final response = await _repository.getTemplates();
      
      if (response.status) {
        _templates.assignAll(response.data);
        _filteredTemplates.assignAll(response.data);
      } else {
        _showToast('load_failed'.tr);
      }
    } catch (e) {
      _showToast('load_error'.tr);
    } finally {
      _isLoading.value = false;
    }
  }

  void searchTemplates(String query) {
    _searchQuery.value = query;
    
    if (query.isEmpty) {
      _filteredTemplates.assignAll(_templates);
      _isSearching.value = false;
    } else {
      _isSearching.value = true;
      final filtered = _templates.where((template) =>
          template.title.toLowerCase().contains(query.toLowerCase()) ||
          template.message.toLowerCase().contains(query.toLowerCase())
      ).toList();
      _filteredTemplates.assignAll(filtered);
    }
  }

  Future<void> selectTemplate(TemplateModel template) async {
    try {
      _isLoading.value = true;
      final response = await _repository.selectTemplate(template.id);
      
      if (response.status) {
        _showToast('selected'.tr);
        // Close bottom sheet and return selected template
        Get.back(result: template);
      } else {
        _showToast('selection_failed'.tr);
      }
    } catch (e) {
      _showToast('selection_error'.tr);
    } finally {
      _isLoading.value = false;
    }
  }

  void closeBottomSheet() {
     navigatorKey.currentState!.pop();
  }

  void _showToast(String message) {
    // Fluttertoast.showToast(
    //   msg: message,
    //   toastLength: Toast.LENGTH_SHORT,
    //   gravity: ToastGravity.BOTTOM,
    //   backgroundColor: Theme.of(context).colorScheme.onBackground.withOpacity(0.8),
    //   textColor: Theme.of(context).colorScheme.background,
    // );
  }

  @override
  void onClose() {
    _searchQuery.close();
    super.onClose();
  }
}