import 'package:get/get.dart';

import '../../../../../../bottom_sheet.dart';
import '../../controller/template_controller.dart';
import 'template_selection_view.dart';

class TemplateBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<TemplateController>(() => TemplateController());
  }
}

Future<void> openTemplateBottomSheet() async {
  Get.lazyPut<TemplateController>(() => TemplateController());
  final selectedTemplate = await openButtomsheet(const TemplateBottomSheet());

  if (selectedTemplate != null) {
    // Handle the selected template
    // print('Selected template: ${selectedTemplate.title}');
    // You can use the template message, send it, etc.
  }
}
