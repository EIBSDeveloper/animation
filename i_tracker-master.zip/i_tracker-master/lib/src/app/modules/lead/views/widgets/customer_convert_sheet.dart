import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../app.dart';
import '../../../../../core/app_colors.dart';
import '../../../../widgets/bottom_sheet_syle.dart';
import '../../controller/customer_convert_controller.dart';

class CustomerConvertSheet extends StatelessWidget {
  final controller = Get.put(CustomerConvertController());

  CustomerConvertSheet({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDark = Get.isDarkMode;

    return BottomSheetStyle(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const SizedBox(width: 40),
                Expanded(
                  child: Text(
                    "Customer Convert",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : const Color(0xFF111618),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _conversionType(),
                _salesDocument(isDark),
                _communicationVia(),
                _paymentType(),
                _paymentMode(),
                _minPayment(isDark),

                const SizedBox(height: 20),

                // ========================= ACTION BUTTONS =========================
                Row(
                  children: [
                    Expanded(
                      child: _borderButton(
                        title: "Cancel",
                        onTap: () => navigatorKey.currentState!.pop(),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _primaryButton(
                        title: "Convert Customer",
                        onTap: () {},
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------- COMPONENTS ----------------------------

  Widget _conversionType() => Obx(
    () => _groupTitle(
      "Conversion Type*",
      children: [
        _chipSelect(
          title: "Send Document",
          selected: controller.conversionType.value == "Send Document",
          onTap: () => controller.conversionType.value = "Send Document",
        ),
        const SizedBox(width: 8),
        _chipSelect(
          title: "Direct Convert",
          selected: controller.conversionType.value == "Direct Convert",
          onTap: () => controller.conversionType.value = "Direct Convert",
        ),
      ],
    ),
  );

  Widget _salesDocument(bool isDark) => Obx(
    () => _dropdown(
      title: "Sales Document*",
      value: controller.salesDocument.value,
      onTap: () {
        // open bottom sheet or list popup
      },
      isDark: isDark,
    ),
  );

  Widget _communicationVia() => Obx(
    () => _groupTitle(
      "Communication Via*",
      children: [
        _chipSelect(
          title: "Email",
          selected: controller.communicationVia.value == "Email",
          onTap: () => controller.communicationVia.value = "Email",
        ),
        const SizedBox(width: 8),
        _chipSelect(
          title: "Whatsapp",
          selected: controller.communicationVia.value == "Whatsapp",
          onTap: () => controller.communicationVia.value = "Whatsapp",
        ),
      ],
    ),
  );

  Widget _paymentType() => Obx(
    () => _groupTitle(
      "Payment Type*",
      children: [
        _chipSelect(
          title: "With Payment",
          selected: controller.paymentType.value == "With Payment",
          onTap: () => controller.paymentType.value = "With Payment",
        ),
        const SizedBox(width: 8),
        _chipSelect(
          title: "Without Payment",
          selected: controller.paymentType.value == "Without Payment",
          onTap: () => controller.paymentType.value = "Without Payment",
        ),
      ],
    ),
  );

  Widget _paymentMode() => Obx(
    () => _groupTitle(
      "Payment Mode*",
      children: [
        _chipSelect(
          title: "Cash In Hand",
          selected: controller.paymentMode.value == "Cash In Hand",
          onTap: () => controller.paymentMode.value = "Cash In Hand",
        ),
        const SizedBox(width: 8),
        _chipSelect(
          title: "Online Mode",
          selected: controller.paymentMode.value == "Online Mode",
          onTap: () => controller.paymentMode.value = "Online Mode",
        ),
      ],
    ),
  );

  Widget _minPayment(bool isDark) => _groupTitle(
    "Min Payment Amount*",
    children: [
      TextField(
        onChanged: (v) => controller.minPaymentAmount.value = v,
        keyboardType: TextInputType.number,
        style: Theme.of(navigatorKey.currentContext!).textTheme.bodySmall,
        scrollPadding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.symmetric(horizontal: 8),
          hintText: "Enter Minimum Payment Amount",
          filled: true,
          fillColor: isDark ? const Color(0xFF101C22) : AppColors.background,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    ],
  );

  // ---------------------------- UI BUILDERS ----------------------------

  Widget _groupTitle(String title, {required List<Widget> children}) => Padding(
    padding: const EdgeInsets.only(top: 10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(
            navigatorKey.currentContext!,
          ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 3),
        if (children.length == 1) children[0] else Row(children: children),
      ],
    ),
  );

  Widget _chipSelect({
    required String title,
    required bool selected,
    required VoidCallback onTap,
  }) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        // margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        width: double.infinity,
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primary.withOpacity(.15)
              : Colors.transparent,
          border: Border.all(
            color: selected ? AppColors.primary : const Color(0xFFDBE2E6),
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(
              selected
                  ? Icons.radio_button_checked
                  : Icons.radio_button_unchecked,
              color: selected ? AppColors.primary : const Color(0xFF607C8A),
            ),
            const SizedBox(width: 5),
            Text(
              title,
              style: Theme.of(navigatorKey.currentContext!).textTheme.bodySmall!
                  .copyWith(color: selected ? AppColors.primary : null),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _dropdown({
    required String title,
    required String value,
    required VoidCallback onTap,
    required bool isDark,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const SizedBox(height: 8),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 2),
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF101C22) : Colors.white,
            border: Border.all(
              color: isDark ? const Color(0xFF344049) : const Color(0xFFDBE2E6),
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  value,
                  style: TextStyle(
                    color: isDark ? Colors.white : const Color(0xFF111618),
                  ),
                ),
              ),
              Icon(
                Icons.expand_more,
                color: isDark
                    ? const Color(0xFF9FB3BF)
                    : const Color(0xFF607C8A),
              ),
            ],
          ),
        ),
      ),
    ],
  );

  Widget _borderButton({required String title, required VoidCallback onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFDBE2E6)),
          ),
          alignment: Alignment.center,
          child: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      );

  Widget _primaryButton({required String title, required VoidCallback onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: const Text(
            "Convert Customer",
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
      );
}
