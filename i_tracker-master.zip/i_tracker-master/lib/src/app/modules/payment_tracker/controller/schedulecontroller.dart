import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class PaymentSchedule {
  final String title;
  final String statusLabel; // Overdue / Upcoming / Paid
  final double progress; // 0..1
  final double paid;
  final double remaining;
  final double total;
  final String note; // next payment text

  PaymentSchedule({
    required this.title,
    required this.statusLabel,
    required this.progress,
    required this.paid,
    required this.remaining,
    required this.total,
    required this.note,
  });
}

class LeadNames {
  final String name;

  LeadNames(this.name);

  @override
  String toString() => name; // Required for dropdown display
}

class SchedulesController extends GetxController {
  final RxList<PaymentSchedule> schedules = <PaymentSchedule>[].obs;

  @override
  void onInit() {
    super.onInit();
    // Sample data matching your HTML
    schedules.assignAll([
      PaymentSchedule(
        title: 'Client Name',
        statusLabel: 'Overdue',
        progress: 0.20,
        paid: 500,
        remaining: 2000,
        total: 2500,
        note: 'Next due on 20 Dec 2024',
      ),
      PaymentSchedule(
        title: 'Project Alpha',
        statusLabel: 'Upcoming',
        progress: 0.75,
        paid: 1500,
        remaining: 500,
        total: 2000,
        note: 'Next due on 15 Dec 2024',
      ),
      PaymentSchedule(
        title: 'Website Redesign',
        statusLabel: 'Paid',
        progress: 1.0,
        paid: 5000,
        remaining: 0,
        total: 5000,
        note: 'Final made on 01 Nov 2024',
      ),
    ]);
  }

  // for demo: toggle empty state
  void clearAll() => schedules.clear();
  void resetSample() => onInit();

  //New schedule
  final clientName = TextEditingController();
  final projectName = TextEditingController();
  final totalAmount = TextEditingController();
  final dueDate = TextEditingController();
  final notes = TextEditingController();

  final paymentMethod = ''.obs;
  final frequency = 'One-time'.obs;
  final status = 'Upcoming'.obs;

  // show loading or saving state
  final saving = false.obs;

  @override
  void onClose() {
    clientName.dispose();
    projectName.dispose();
    totalAmount.dispose();
    dueDate.dispose();
    notes.dispose();
    super.onClose();
  }

  Future<void> pickDate(BuildContext context) async {
    DateTime initial = DateTime.now();
    try {
      if (dueDate.text.isNotEmpty) {
        initial = DateFormat('yyyy-MM-dd').parse(dueDate.text);
      }
    } catch (e) {
      initial = DateTime.now();
    }

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      builder: (context, child) => child!,
    );

    if (picked != null) {
      dueDate.text = DateFormat('yyyy-MM-dd').format(picked);
    }
  }

  void setPaymentMethod(String value) {
    paymentMethod.value = value;
  }

  void setFrequency(String value) {
    frequency.value = value;
  }

  void setStatus(String value) {
    status.value = value;
  }

  Future<void> saveSchedule() async {
    if (saving.value) return;
    saving.value = true;

    // Simulate save operation
    await Future.delayed(const Duration(milliseconds: 700));

    // For demo: simply show snackbar and clear fields (you can replace with API)
    Get.showSnackbar(
      const GetSnackBar(
        message: 'Schedule saved',
        duration: Duration(seconds: 2),
      ),
    );

    saving.value = false;

    // Optionally clear or navigate back
    //  navigatorKey.currentState!.pop();
  }
}
