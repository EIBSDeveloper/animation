import 'package:get/get.dart';

/// Customer Model
class Customer {
  final String name;
  final String id;
  final String profileImage;
  final String dueAmount;
  final String proposalStatus;
  // final String phone;
  final String? reminderStatus;

  Customer({
    required this.name,
    required this.id,
    required this.profileImage,
    required this.dueAmount,
    // required this.phone,
    required this.proposalStatus,
    this.reminderStatus,
  });
}

/// Customer details Model
class Invoice {
  final String id;
  final DateTime date;
  final double amount;
  final String status; // Paid / Overdue / etc

  Invoice({
    required this.id,
    required this.date,
    required this.amount,
    required this.status,
  });
}

class ProposalModel {
  final String id;
  final String date;
  final String amount;
  final String status; // Approved, Pending, Rejected
  ProposalModel({
    required this.id,
    required this.date,
    required this.amount,
    required this.status,
  });
}

class NoteItem {
  final DateTime date;
  final String text;

  NoteItem({required this.date, required this.text});
}

class Interaction {
  final String id;
  final String title;
  final String body;
  final DateTime at;
  final InteractionType type;

  Interaction({
    required this.id,
    required this.title,
    required this.body,
    required this.at,
    required this.type,
  });
}

enum InteractionType { meeting, email, call, note }

/// GetX Controller
class CustomerController extends GetxController {
  var customers = <Customer>[].obs;

  @override
  void onInit() {
    super.onInit();

    //customer list
    loadData();
  }

  void loadData() {
       //customer list
    customers.addAll([
      Customer(
        name: "John Appleseed",
        id: "123456789",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDLDFxgqsAXjLtu5DKx_HR7Ts8sJK5DVAthanMpcLQzhRECNKHW3IKu-F3s4xHuR8yDgUNYZkelLHvFubWW9PKDhwXsS9VlwBU-EuyZxv3hRG8SGArDtQUbOcSUb5p7tuZUIofDIKGtsPcpWbd5I82N_YHUv7kuIIWF4CM9PL1XBWshr2WHLqlh9_bcgr9xSm9aAe-gsrcNBU_E75jqHKCNfq8gny91RY1ilCexW20qquoqN_cfwDoyxCqvORVXRzKxw6PEa95nEhgI",
        dueAmount: "₹500",
        proposalStatus: "Accepted",
        reminderStatus: "Sent",
      ),
      Customer(
        name: "Kate Bell",
        id: "987654321",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDGD1yN32wo1IeLSgcJEQwkhpVeG3fom4bYeeY2opU7hKpAn6wkzR961BV5d0XQ2QxtqcAZ3L_0rCe7dpF-l4E57_rpFw4xkxDAZRVDTqHHXBPlFJZGqS1aZjMyMAjHFnKbOF3-cXBWlzEakNCSJWFMr0bsP72oMvXc-JyeYFx7nK80KXUyTGehxF05FbeDe7-9HThLokZTMgO0rY3Y2K8pU48lF39RUws5ojSwAcC_zAUqPaqCEvk1ycLCVSoryk69x235DG69vwWV",
        dueAmount: "₹1,200",
        proposalStatus: "Sent",
      ),
      Customer(
        name: "Anna Haro",
        id: "456123789",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuCEuKlqztliRgV5ShbvLuN6N-n-gj1opA8acDOw_Dfotgxe5puNLfdvDejqHyDMMLIFcB7oLOUW33eNof3lUtbkjCT7e6F_s6SnzIAOsg7kJ2PKSE7qHTfmNPCXKAhrj72uDao8z5LK2Y7VR7Vtt8F7tbobaw1jYmY_syfGTX4RBX0DPp-UwuRZN9xRjrFTwGBIhmjOoOEcIVLwAM2WjjjI1hOHoLxFjg1gxe0oTFb1H0o83KMBGGkWPNGve70aMfu9lqlE47HiSqbV",
        dueAmount: "₹250",
        proposalStatus: "Draft",
        reminderStatus: "Scheduled",
      ),
      Customer(
        name: "John Appleseed",
        id: "123456789",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDLDFxgqsAXjLtu5DKx_HR7Ts8sJK5DVAthanMpcLQzhRECNKHW3IKu-F3s4xHuR8yDgUNYZkelLHvFubWW9PKDhwXsS9VlwBU-EuyZxv3hRG8SGArDtQUbOcSUb5p7tuZUIofDIKGtsPcpWbd5I82N_YHUv7kuIIWF4CM9PL1XBWshr2WHLqlh9_bcgr9xSm9aAe-gsrcNBU_E75jqHKCNfq8gny91RY1ilCexW20qquoqN_cfwDoyxCqvORVXRzKxw6PEa95nEhgI",
        dueAmount: "₹500",
        proposalStatus: "Accepted",
        reminderStatus: "Sent",
      ),
      Customer(
        name: "Kate Bell",
        id: "987654321",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDGD1yN32wo1IeLSgcJEQwkhpVeG3fom4bYeeY2opU7hKpAn6wkzR961BV5d0XQ2QxtqcAZ3L_0rCe7dpF-l4E57_rpFw4xkxDAZRVDTqHHXBPlFJZGqS1aZjMyMAjHFnKbOF3-cXBWlzEakNCSJWFMr0bsP72oMvXc-JyeYFx7nK80KXUyTGehxF05FbeDe7-9HThLokZTMgO0rY3Y2K8pU48lF39RUws5ojSwAcC_zAUqPaqCEvk1ycLCVSoryk69x235DG69vwWV",
        dueAmount: "₹1,200",
        proposalStatus: "Sent",
      ),
      Customer(
        name: "Anna Haro",
        id: "456123789",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuCEuKlqztliRgV5ShbvLuN6N-n-gj1opA8acDOw_Dfotgxe5puNLfdvDejqHyDMMLIFcB7oLOUW33eNof3lUtbkjCT7e6F_s6SnzIAOsg7kJ2PKSE7qHTfmNPCXKAhrj72uDao8z5LK2Y7VR7Vtt8F7tbobaw1jYmY_syfGTX4RBX0DPp-UwuRZN9xRjrFTwGBIhmjOoOEcIVLwAM2WjjjI1hOHoLxFjg1gxe0oTFb1H0o83KMBGGkWPNGve70aMfu9lqlE47HiSqbV",
        dueAmount: "₹250",
        proposalStatus: "Draft",
        reminderStatus: "Scheduled",
      ),
      Customer(
        name: "John Appleseed",
        id: "123456789",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDLDFxgqsAXjLtu5DKx_HR7Ts8sJK5DVAthanMpcLQzhRECNKHW3IKu-F3s4xHuR8yDgUNYZkelLHvFubWW9PKDhwXsS9VlwBU-EuyZxv3hRG8SGArDtQUbOcSUb5p7tuZUIofDIKGtsPcpWbd5I82N_YHUv7kuIIWF4CM9PL1XBWshr2WHLqlh9_bcgr9xSm9aAe-gsrcNBU_E75jqHKCNfq8gny91RY1ilCexW20qquoqN_cfwDoyxCqvORVXRzKxw6PEa95nEhgI",
        dueAmount: "₹500",
        proposalStatus: "Accepted",
        reminderStatus: "Sent",
      ),
      Customer(
        name: "Kate Bell",
        id: "987654321",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDGD1yN32wo1IeLSgcJEQwkhpVeG3fom4bYeeY2opU7hKpAn6wkzR961BV5d0XQ2QxtqcAZ3L_0rCe7dpF-l4E57_rpFw4xkxDAZRVDTqHHXBPlFJZGqS1aZjMyMAjHFnKbOF3-cXBWlzEakNCSJWFMr0bsP72oMvXc-JyeYFx7nK80KXUyTGehxF05FbeDe7-9HThLokZTMgO0rY3Y2K8pU48lF39RUws5ojSwAcC_zAUqPaqCEvk1ycLCVSoryk69x235DG69vwWV",
        dueAmount: "₹1,200",
        proposalStatus: "Sent",
      ),
      Customer(
        name: "Anna Haro",
        id: "456823789",
        profileImage:
            "https://lh3.googleusercontent.com/aida-public/AB6AXuCEuKlqztliRgV5ShbvLuN6N-n-gj1opA8acDOw_Dfotgxe5puNLfdvDejqHyDMMLIFcB7oLOUW33eNof3lUtbkjCT7e6F_s6SnzIAOsg7kJ2PKSE7qHTfmNPCXKAhrj72uDao8z5LK2Y7VR7Vtt8F7tbobaw1jYmY_syfGTX4RBX0DPp-UwuRZN9xRjrFTwGBIhmjOoOEcIVLwAM2WjjjI1hOHoLxFjg1gxe0oTFb1H0o83KMBGGkWPNGve70aMfu9lqlE47HiSqbV",
        dueAmount: "₹250",
        proposalStatus: "Draft",
        reminderStatus: "Scheduled",
      ),
    ]);
    
    //customer details
    invoices.assignAll([
      Invoice(
        id: 'Invoice #2024-051',
        date: DateTime(2024, 5, 15),
        amount: 1250.00,
        status: 'Paid',
      ),
      Invoice(
        id: 'Invoice #2024-043',
        date: DateTime(2024, 4, 12),
        amount: 875.50,
        status: 'Overdue',
      ),
      Invoice(
        id: 'Invoice #2024-037',
        date: DateTime(2024, 3, 21),
        amount: 2500.00,
        status: 'Paid',
      ),
    ]);
    
    notes.assignAll([
      NoteItem(
        date: DateTime(2024, 5, 10),
        text:
            'Followed up on the overdue invoice. John mentioned payment will be processed by EOD Friday.',
      ),
    ]);
  }

  // Tabs: 0 = Payments, 1 = Proposals, 2 = Interactions
  final selectedTab = 0.obs;

  // sample invoices
  final invoices = <Invoice>[].obs;

  // notes
  final notes = <NoteItem>[].obs;

  // customer info
  final customerName = 'John Doe'.obs;
  final customerCompany = 'Doe Enterprises'.obs;
  final profileImage = RxString(
    'https://lh3.googleusercontent.com/aida-public/AB6AXuDyavTNVMrs5sG7WTtaKOEh5A1bYxL9UfjJ_uBQHryzklGBZGmCkmIe2pyvn9tGDiT4mWBkgFOekR-SSmVccMT7L9so5py7VgQNosY9BUOB43H6UdkqLZL5qol7AtccwLnw4_QRqHUlAfa15rFJ0jolJmemSOUKpLZR3S3JT4kkAOYmowi3UPKZgtpt5-K96OwCP36S0TIkKZSxdWLrZ8r_TEEgz2b3_yfCUknZsi7p92Z9H_oc75trYY1ltSI4ek341khlHbnMuCD5',
  );

  void setTab(int idx) => selectedTab.value = idx;

  void addNote(String text) {
    notes.insert(0, NoteItem(date: DateTime.now(), text: text));
  }

  // For demo: toggle invoice status
  void toggleInvoiceStatus(int index) {
    final inv = invoices[index];
    final newStatus = inv.status == 'Paid' ? 'Overdue' : 'Paid';
    invoices[index] = Invoice(
      id: inv.id,
      date: inv.date,
      amount: inv.amount,
      status: newStatus,
    );
  }

  RxList<ProposalModel> proposals = <ProposalModel>[
    ProposalModel(
      id: "P2024-015",
      date: "May 20, 2024",
      amount: "\$5,500.00",
      status: "Approved",
    ),
    ProposalModel(
      id: "P2024-012",
      date: "Apr 28, 2024",
      amount: "\$3,200.00",
      status: "Pending",
    ),
    ProposalModel(
      id: "P2024-011",
      date: "Apr 15, 2024",
      amount: "\$8,900.00",
      status: "Rejected",
    ),
    ProposalModel(
      id: "P2024-009",
      date: "Mar 10, 2024",
      amount: "\$4,750.00",
      status: "Approved",
    ),
    ProposalModel(
      id: "P2024-005",
      date: "Feb 05, 2024",
      amount: "\$12,300.00",
      status: "Approved",
    ),
  ].obs;

  // sample interactions (mirrors the HTML sample)
  final interactions = <Interaction>[
    Interaction(
      id: 'i1',
      title: 'Quarterly Review Meeting',
      body:
          'Discussed Q2 performance and upcoming projects. Agreed on new payment terms for next phase.',
      at: DateTime(2024, 6, 5, 10, 0),
      type: InteractionType.meeting,
    ),
    Interaction(
      id: 'i2',
      title: 'Email: Follow-up on Proposal',
      body:
          'Sent the revised proposal as discussed. Awaiting confirmation from their finance team.',
      at: DateTime(2024, 5, 28, 14, 15),
      type: InteractionType.email,
    ),
    Interaction(
      id: 'i3',
      title: 'Phone Call: Invoice Query',
      body:
          'John called to confirm receipt of Invoice #2024-051. Confirmed payment will be processed this week.',
      at: DateTime(2024, 5, 15, 11, 30),
      type: InteractionType.call,
    ),
    Interaction(
      id: 'i4',
      title: 'Internal Note Added',
      body:
          'Followed up on the overdue invoice. John mentioned payment will be processed by EOD Friday.',
      at: DateTime(2024, 5, 10, 16, 45),
      type: InteractionType.note,
    ),
  ].obs;
}
