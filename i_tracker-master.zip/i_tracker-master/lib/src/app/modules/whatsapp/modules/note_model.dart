class NoteModel {
  final String id;
  final String title;
  final String content;
  final String label;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPinned;

  NoteModel({
    required this.id,
    required this.title,
    required this.content,
    required this.label,
    required this.createdAt,
    required this.updatedAt,
    this.isPinned = false,
  });

  factory NoteModel.fromJson(Map<String, dynamic> json) => NoteModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      label: json['label'] ?? 'Notes',
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      isPinned: json['is_pinned'] ?? false,
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'title': title,
      'content': content,
      'label': label,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'is_pinned': isPinned,
    };

  NoteModel copyWith({
    String? id,
    String? title,
    String? content,
    String? label,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isPinned,
  }) => NoteModel(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      label: label ?? this.label,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isPinned: isPinned ?? this.isPinned,
    );

  String get previewContent {
    if (content.length <= 100) return content;
    return '${content.substring(0, 100)}...';
  }

  // String get formattedDate {
  //   final now = DateTime.now();
  //   final difference = now.difference(createdAt);
    
  //   if (difference.inDays == 0) {
  //     return 'Today';
  //   } else if (difference.inDays == 1) {
  //     return 'Yesterday';
  //   } else if (difference.inDays < 7) {
  //     return '${difference.inDays} days ago';
  //   } else {
  //     return '${createdAt.day}/${createdAt.month}/${createdAt.year}';
  //   }
  // }
}

class NoteFilter {
  final String label;
  final bool isSelected;

  NoteFilter({required this.label, this.isSelected = false});

  NoteFilter copyWith({String? label, bool? isSelected}) => NoteFilter(
      label: label ?? this.label,
      isSelected: isSelected ?? this.isSelected,
    );
}