import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../../../../../app.dart';
import '../modules/note_model.dart';
import '../repository/note_repository.dart';

class NotesController extends GetxController {
  final NoteRepository repository = Get.find();

  NotesController();
  final TextEditingController searchController = TextEditingController();
  final RxList<NoteModel> notes = <NoteModel>[].obs;
  final RxList<NoteFilter> labels = <NoteFilter>[].obs;
  final RxBool isLoading = false.obs;
  final RxString error = ''.obs;
  final RxString selectedLabel = 'All'.obs;
  final RxString searchQuery = ''.obs;

  @override
  void onInit() {
    super.onInit();
    loadLabels();
    loadNotes();
  }

  Future<void> loadNotes() async {
    try {
      isLoading(true);
      error('');
      final notesData = await repository.getNotes(
        labelFilter: selectedLabel.value == 'All' ? null : selectedLabel.value,
      );
      notes.assignAll(notesData);
    } catch (e) {
      error(e.toString());
      showErrorToast('Failed to load notes');
    } finally {
      isLoading(false);
    }
  }

  Future<void> loadLabels() async {
    try {
      final labelsData = await repository.getAvailableLabels();
      labels.assignAll(labelsData);
    } catch (e) {
      showErrorToast('Failed to load labels');
    }
  }

  Future<void> createNote(NoteModel note) async {
    try {
      isLoading(true);
      final newNote = await repository.createNote(note);
      notes.add(newNote);
      showSuccessToast('Note created successfully');
       navigatorKey.currentState!.pop(); // Navigate back to notes list
    } catch (e) {
      showErrorToast('Failed to create note');
    } finally {
      isLoading(false);
    }
  }

  Future<void> updateNote(NoteModel note) async {
    try {
      isLoading(true);
      final updatedNote = await repository.updateNote(note);
      final index = notes.indexWhere((n) => n.id == note.id);
      if (index != -1) {
        notes[index] = updatedNote;
      }
      showSuccessToast('Note updated successfully');
       navigatorKey.currentState!.pop(); // Navigate back to notes list
    } catch (e) {
      showErrorToast('Failed to update note');
    } finally {
      isLoading(false);
    }
  }

  Future<void> deleteNote(String noteId) async {
    try {
      isLoading(true);
      final success = await repository.deleteNote(noteId);
      if (success) {
        notes.removeWhere((note) => note.id == noteId);
        showSuccessToast('Note deleted successfully');
      }
    } catch (e) {
      showErrorToast('Failed to delete note');
    } finally {
      isLoading(false);
    }
  }

  void filterByLabel(String label) {
    selectedLabel(label);
    loadNotes();
  }

  void searchNotes(String query) {
    searchQuery(query);
    // In a real app, you'd call an API or filter locally
    // For now, we'll just reload all notes and filter in UI
    loadNotes();
  }

  List<NoteModel> get filteredNotes {
    if (searchQuery.value.isEmpty) {
      return notes;
    }
    return notes.where((note) => note.title.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
          note.content.toLowerCase().contains(searchQuery.value.toLowerCase())).toList();
  }

  void showSuccessToast(String message) {
    // Fluttertoast.showToast(
    //   msg: message,
    //   toastLength: Toast.LENGTH_SHORT,
    //   gravity: ToastGravity.BOTTOM,
    //   backgroundColor: Colors.green,
    //   textColor: Colors.white,
    // );
  }

  void showErrorToast(String message) {
    // Fluttertoast.showToast(
    //   msg: message,
    //   toastLength: Toast.LENGTH_SHORT,
    //   gravity: ToastGravity.BOTTOM,
    //   backgroundColor: Colors.red,
    //   textColor: Colors.white,
    // );
  }

  void clearSearch() {
    searchQuery('');
    loadNotes();
  }

  @override
  void onClose() {
    // Dispose any resources if needed
    super.onClose();
  }
}