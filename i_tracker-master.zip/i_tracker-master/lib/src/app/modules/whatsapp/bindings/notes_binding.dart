import 'package:get/get.dart';

import '../controller/note_detail_controller.dart';
import '../controller/notes_controller.dart';
import '../repository/note_repository.dart';

class NotesBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<NoteRepository>(() => NoteRepository());

    Get.lazyPut<NotesController>(() => NotesController());
  }
}

class NoteDetailBinding extends Bindings {
  NoteDetailBinding();

  @override
  void dependencies() {
    Get.lazyPut<NoteDetailController>(() => NoteDetailController());
  }
}
