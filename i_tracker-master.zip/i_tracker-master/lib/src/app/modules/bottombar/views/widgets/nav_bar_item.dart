import 'package:flutter/material.dart';
import 'package:itracker/src/core/app_colors.dart';

import '../../../../../core/app_style.dart';
import '../../model/bottom_nav_bar_item.dart';
import 'package:hugeicons/hugeicons.dart';

class NavBarItem extends StatefulWidget {
  final BottomNavBarItem item;
  final int index;
  final bool selected;
  final Function onTap;
  final Color? backgroundColor;
  const NavBarItem({
    super.key,
    required this.item,
    this.selected = false,
    required this.onTap,
    this.backgroundColor,
    required this.index,
  });

  @override
  State<NavBarItem> createState() => _NavBarItemState();
}

class _NavBarItemState extends State<NavBarItem> {
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () {
      widget.onTap();
    },
    child: AnimatedContainer(
      padding: const EdgeInsets.all(8),
      margin: const EdgeInsets.symmetric(vertical: 5),
      duration: const Duration(milliseconds: 300),
      constraints: BoxConstraints(minWidth: widget.selected ? 70 : 50),
      height: 56,

      decoration: BoxDecoration(
        color: widget.selected ? AppColors.primary : Colors.transparent,
        borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          HugeIcon(
            icon: widget.item.icon,
            color: widget.selected ? Colors.white : AppColors.primary,
            size: AppStyle.iconSize,
          ),

          // const SizedBox(width: 4),
          // Offstage(
          //   offstage: !widget.selected,
          //   child: Text(
          //     widget.item.title,
          //     style: TextStyle(color: widget.backgroundColor),
          //   ),
          // ),
        ],
      ),
    ),
  );
}

class CheckInOutSwitch extends StatefulWidget {
  final bool initialValue;
  final Function(bool)? onChanged;

  const CheckInOutSwitch({
    super.key,
    this.initialValue = false,
    this.onChanged,
  });

  @override
  State<CheckInOutSwitch> createState() => _CheckInOutSwitchState();
}

class _CheckInOutSwitchState extends State<CheckInOutSwitch> {
  late bool isCheckedIn;

  @override
  void initState() {
    super.initState();
    isCheckedIn = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) => Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Switch(
          value: isCheckedIn,
          onChanged: (value) {
            setState(() => isCheckedIn = value);
            if (widget.onChanged != null) widget.onChanged!(value);
          },
          activeThumbColor: Colors.white,
          activeTrackColor: Colors.green,
          inactiveThumbColor: Colors.white,
          inactiveTrackColor: Colors.red,
        ),
      ],
    );
}
