import 'package:flutter/material.dart';

class SlideRightToLeftTransition extends PageTransitionsBuilder {
  const SlideRightToLeftTransition();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final offsetAnimation = animation.drive(
      Tween(
        begin: const Offset(1.0, 0.0), // Slide from right
        end: Offset.zero,
      ).chain(CurveTween(curve: Curves.easeOutCubic)),
    );

    return SlideTransition(position: offsetAnimation, child: child);
  }
}

class SlidePageRoute<T> extends MaterialPageRoute<T> {
  SlidePageRoute({required super.builder, super.settings});

  @override
  Duration get transitionDuration => const Duration(milliseconds: 500);
}
