import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
// import 'package:hive_flutter/hive_flutter.dart';
import 'package:itracker/src/core/app_colors.dart';

import 'bottom_sheet.dart';
import 'src/app/utils/http/api_service.dart';
import 'src/app/widgets/bottom_sheet_syle.dart';
import 'src/app/widgets/input_card_style.dart';
import 'src/app/widgets/title_text.dart';

class Tag {
  String label;
  Color color;
  bool isSelected;
  Tag({required this.label, required this.color, this.isSelected = false});
}

class TagController extends GetxController {
  var tags = <Tag>[].obs;
  final api = ApiService();

  // final Box box = Hive.box('tagsBox');

  @override
  void onInit() {
    super.onInit();
    loadTagsFromLocal();
  }

  Future<void> loadTagsFromLocal() async {
    // Map<String, String> savedMap = Map<String, String>.from(
    //    box.get('tags', defaultValue: {}),
    // );
    // tags.value = savedMap.entries
    //     .map((e) => Tag(label: e.key, color: _colorFromHex(e.value)))
    //     .toList();

    final res = await api.getData("/tags");

    // Tag map = res.data.map(
    //   (tag) => Tag(label: tag['label'], color: _colorFromHex(tag.color)),
    // );
    tags.addAll([
      ...res.data.map(
        (tag) => Tag(label: tag['label'], color: _colorFromHex(tag["color"])),
      ),
    ]);

    // Add some defaults if box is empty
    // if (map.isEmpty) {
    //   tags.addAll([
    //     Tag(label: 'Interior Design', color: Colors.teal),
    //     Tag(label: 'Pets', color: Colors.orange),
    //     Tag(label: 'Skin Care', color: Colors.pink),
    //     Tag(label: 'Party Planning', color: Colors.grey),
    //     Tag(label: 'Hair Care & Styling', color: Colors.blue),
    //     Tag(label: 'Makeup', color: Colors.purple),
    //     Tag(label: 'Gardening', color: Colors.green),
    //   ]);
    //   saveTagsToLocal();
  }

  /// Save tags to Hive as Map<String, String>
  // void saveTagsToLocal() {
  //   Map<String, String> map = {
  //     for (var tag in tags) tag.label: _colorToHex(tag.color),
  //   };
  //   // box.put('tags', map);
  // }

  void toggleTag(Tag tag) {
    tag.isSelected = !tag.isSelected;
    tags.refresh();
  }

  // void addTag(String label, Color color) {
  //   tags.add(Tag(label: label, color: color));
  //   saveTagsToLocal();
  // }

  /// Helpers
  String _colorToHex(Color color) =>
      '#${color.value.toRadixString(16).padLeft(8, '0')}';

  Color _colorFromHex(String hexColor) {
    hexColor = hexColor.replaceAll('#', '');
    if (hexColor.length == 6) hexColor = 'ff$hexColor';
    return Color(int.parse(hexColor, radix: 16));
  }
}

class TagBottomSheet extends StatelessWidget {
  final TagController controller = Get.put(TagController());

  TagBottomSheet({super.key});

  @override
  Widget build(BuildContext context) => BottomSheetStyle(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const TitleText("Tags"),
          const SizedBox(height: 16),
          Obx(
            () => Wrap(
              spacing: 4,
              runSpacing: 8,
              children: controller.tags
                  .map(
                    (tag) => FilterChip(
                      label: Text(tag.label),
                      labelStyle: Theme.of(context).textTheme.bodyMedium,
                      selected: tag.isSelected,
                      backgroundColor: AppColors.card,
                      selectedColor: tag.color.withOpacity(0.2),
                      checkmarkColor: tag.color,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 4,
                        vertical: 4,
                      ),
                      onSelected: (_) => controller.toggleTag(tag),
                      shape: StadiumBorder(
                        side: BorderSide(
                          color: tag.isSelected
                              ? tag.color
                              : Colors.grey.shade400,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
          const SizedBox(height: 10),
          // Center(
          //   child: ElevatedButton(
          //     style: ElevatedButton.styleFrom(
          //       minimumSize: const Size(double.infinity, 45),
          //       backgroundColor:AppColors.primary,
          //     ),
          //     onPressed: () {
          //       openButtomsheet(
          //         AddTagSheet(controller: controller),

          //       );
          //     },
          //     child: Text(
          //       "Add New Tag",
          //       style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          //         color: Colors.white,
          //       ),
          //     ),
          //   ),
          // ),
          // const SizedBox(height: 10),
        ],
      ),
    ),
  );
}

// class AddTagSheet extends StatefulWidget {
//   final TagController controller;
//   const AddTagSheet({super.key, required this.controller});

//   @override
//   State<AddTagSheet> createState() => _AddTagSheetState();
// }

// class _AddTagSheetState extends State<AddTagSheet> {
//   final TextEditingController labelController = TextEditingController();
//   Color selectedColor = Colors.blue;

//   @override
//   Widget build(BuildContext context) => BottomSheetStyle(
//     child: Padding(
//       padding: const EdgeInsets.all(16),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const TitleText("Add New Tag"),

//           const SizedBox(height: 16),
//           InputCardStyle(
//             child: TextField(
//               controller: labelController,
//               decoration: const InputDecoration(
//                 labelText: 'Label',
//                 border: InputBorder.none,
//               ),
//             ),
//           ),
//           const SizedBox(height: 16),
//           Row(
//             children: [
//               const Text("Pick Color:"),
//               const SizedBox(width: 10),
//               GestureDetector(
//                 onTap: () {
//                   showDialog(
//                     context: context,
//                     builder: (_) => AlertDialog(
//                       title: const Text("Pick a color"),
//                       content: BlockPicker(
//                         pickerColor: selectedColor,
//                         onColorChanged: (color) =>
//                             setState(() => selectedColor = color),
//                       ),
//                       actions: [
//                         TextButton(
//                           onPressed: () => Navigator.pop(context),
//                           child: const Text("Done"),
//                         ),
//                       ],
//                     ),
//                   );
//                 },
//                 child: CircleAvatar(backgroundColor: selectedColor),
//               ),
//             ],
//           ),
//           const SizedBox(height: 24),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(
//               minimumSize: const Size(double.infinity, 45),
//               backgroundColor: AppColors.primary,
//             ),
//             onPressed: () {
//               // if (labelController.text.trim().isNotEmpty) {
//               //   widget.controller.addTag(
//               //     labelController.text.trim(),
//               //     selectedColor,
//               //   );
//               //   Get.back();
//               // }
//             },
//             child: Text(
//               "Add Tag",
//               style: Theme.of(
//                 context,
//               ).textTheme.bodyMedium?.copyWith(color: Colors.white),
//             ),
//           ),
//         ],
//       ),
//     ),
//   );
// }

void showTagBottomSheet() {
  openButtomsheet(TagBottomSheet());
}
